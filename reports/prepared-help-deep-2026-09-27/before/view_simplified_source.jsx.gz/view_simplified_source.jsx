
  // Keep one validated result per reader instance, never a process-wide cache.
  // The envelope is serialized so an in-place support edit also invalidates it.
  function useSimplifiedAdaptedSupportView(item, learnerScope) {
    var api = getInstructionalContextApi();
    var supports = item?.adaptedReadingSupports, version;
    try { version = JSON.stringify(supports || null); } catch (_) { version = {}; }
    var form = getSimplifiedInstructionalText(item).form;
    var splitReferences = typeof window !== 'undefined' && window.AlloModules?.TextPipelineHelpers?.splitReferencesFromBody;
    return React.useMemo(function () {
      if (!api?.isAdaptedReading?.(item) || !api.validateAdaptedReadingSupports) return { help: null, snapshot: null, version };
      var help = api.validateAdaptedReadingSupports(item, supports);
      return { help, snapshot: help.status === 'stale' ? null : api.getAdaptedSupportSnapshot?.(item, supports), version };
    }, [api, api?.validateAdaptedReadingSupports, api?.getAdaptedSupportSnapshot, splitReferences,
      item?.id, item?.type, item?.data, form, item?.language, item?.config?.language, item?.sourceFamilyId, item?.unitId, item?.config?.unitId, learnerScope, version]);
  }


  // A sweep changes only its active sentence. Inactive sentence fragments keep
  // their word elements and handlers, without adding layout-changing wrappers.
  const SimplifiedImmersiveSentence = React.memo(function SimplifiedImmersiveSentence({
    group, chunkActive, playingActive, isChunkReaderActive, chunkReaderMood,
    chunkReaderReadAlong, chunkReaderSweepPct, chunkTypewriterCharIdx,
    immersiveSettings, reduceMotion, ImmersiveWord, onWordClick
  }) {
              // Typewriter char-offset bookkeeping for the active sentence (mood='typewriter').
              // Resets when we encounter the first token of the active sentence; each token in
              // the active sentence contributes wordData.text.length to the rolling offset.
              let activeChunkCharOffset = 0;
              // Read-along uses its own whitespace-free weight clock. The host supplies
              // chunkReaderSweepPct from the playing clip; convert that sentence-level
              // percentage into a local fill for each word instead of lighting the whole
              // sentence at once.
              let activeSweepCharOffset = 0;
              let lastWasActiveSentence = false;
              return group.words.map(({ wordData, index: i }) => {
                if (wordData.pos === 'newline') {
                  return <div key={wordData.id || i} className="w-full h-4" />;
                }
                const tokenStr = wordData.text.replace(/\s+/g, '').toLowerCase();
                const assignedIdx = group.sentence;
                const isChunkHighlight = chunkActive;
                const isChunkDimmed = isChunkReaderActive && !chunkActive;
                // Track word's char-offset within the active sentence for typewriter mood
                let wordStartChar = -1;
                let wordSweepStart = -1;
                let wordSweepWeight = 0;
                let sentenceSweepWeight = 1;
                if (isChunkHighlight) {
                  if (!lastWasActiveSentence) {
                    activeChunkCharOffset = 0;
                    activeSweepCharOffset = 0;
                  }
                  wordStartChar = activeChunkCharOffset;
                  activeChunkCharOffset += (wordData.text || '').length;
                  wordSweepStart = activeSweepCharOffset;
                  wordSweepWeight = Math.max(1, tokenStr.length);
                  activeSweepCharOffset += wordSweepWeight;
                  sentenceSweepWeight = group.sweepWeight;
                  lastWasActiveSentence = true;
                } else {
                  lastWasActiveSentence = false;
                }
                // Mood-aware styling: highlight (default), typewriter, popin, pulse
                let moodOpacity = isChunkDimmed ? 0.45 : 1;
                let moodAnimation = '';
                let showHighlight = isChunkHighlight;
                let readAlongWordProgress = null;
                let readAlongWordState = null;
                if (isChunkHighlight && chunkReaderReadAlong) {
                  const sweep = Math.max(0, Math.min(100, Number(chunkReaderSweepPct) || 0));
                  const wordStartPct = (wordSweepStart / sentenceSweepWeight) * 100;
                  const wordEndPct = ((wordSweepStart + wordSweepWeight) / sentenceSweepWeight) * 100;
                  readAlongWordProgress = Math.max(0, Math.min(100,
                    ((sweep - wordStartPct) / Math.max(0.0001, wordEndPct - wordStartPct)) * 100
                  ));
                  readAlongWordState = readAlongWordProgress >= 100 ? 'complete' : readAlongWordProgress > 0 ? 'current' : 'pending';
                  showHighlight = readAlongWordProgress > 0;
                  moodOpacity = 1;
                } else if (isChunkReaderActive && chunkReaderMood === 'typewriter') {
                  if (isChunkDimmed) moodOpacity = 0.2;
                  if (isChunkHighlight) {
                    moodOpacity = wordStartChar < chunkTypewriterCharIdx ? 1 : 0;
                    if (wordStartChar >= chunkTypewriterCharIdx) showHighlight = false;
                  }
                } else if (isChunkReaderActive && chunkReaderMood === 'popin' && isChunkHighlight && !reduceMotion) {
                  moodAnimation = 'allo-chunk-popin 0.25s ease-out';
                } else if (isChunkReaderActive && chunkReaderMood === 'pulse' && isChunkHighlight && !reduceMotion) {
                  moodAnimation = 'allo-chunk-pulse 2s ease-in-out infinite';
                }
                return <span key={wordData.id || i} data-sentence-idx={assignedIdx} data-immersive-word-index={i}
                  data-read-along-state={readAlongWordState || undefined}
                  data-read-along-progress={readAlongWordProgress == null ? undefined : Math.round(readAlongWordProgress)}
                  style={{
                  opacity: moodOpacity,
                  transition: chunkReaderMood === 'typewriter' ? 'opacity 0.05s linear' : 'all 0.3s ease',
                  // In chunk-read mode every word is click-to-jump (onClick below);
                  // pointer cursor surfaces the affordance without needing instructions.
                  ...(isChunkReaderActive ? {
                    cursor: 'pointer'
                  } : {}),
                  ...(moodAnimation ? {
                    animation: moodAnimation
                  } : {}),
                  ...(readAlongWordProgress != null ? {
                    backgroundImage: `linear-gradient(to right, rgba(250, 204, 21, 0.58) 0%, rgba(250, 204, 21, 0.58) ${readAlongWordProgress}%, transparent ${readAlongWordProgress}%, transparent 100%)`,
                    borderRadius: '4px',
                    boxDecorationBreak: 'clone',
                    WebkitBoxDecorationBreak: 'clone'
                  } : showHighlight || playingActive ? {
                    backgroundColor: 'rgba(250, 204, 21, 0.35)',
                    borderRadius: '4px',
                    boxDecorationBreak: 'clone',
                    WebkitBoxDecorationBreak: 'clone'
                  } : {})
                }}><ImmersiveWord wordData={wordData} settings={immersiveSettings} isActive={
                  playingActive
                  || isChunkHighlight && (!chunkReaderReadAlong || readAlongWordProgress > 0)
                } onClick={onWordClick} /></span>;
              });

  });


  function SimplifiedReadingRoleControl(props) {
    // Collapsed to its one-line summary unless it needs the teacher: no role
    // chosen yet, or the original was not captured.
    const [open, setOpen] = React.useState(!!props.isTeacherMode && (!props.role || props.role === 'unspecified' || !!props.missingOriginal));
    const [pending, setPending] = React.useState(false);
    const [error, setError] = React.useState('');
    const summaryRef = React.useRef(null);
    const confirmRef = React.useRef(null);
    const selectRef = React.useRef(null);
    React.useEffect(() => { if (pending && confirmRef.current) confirmRef.current.focus(); }, [pending]);
    const save = role => {
      if (props.disabled) return;
      try {
        if (props.onSave(role) === false) {
          setError(simplifiedText('simplified.role_the_choice_could_not_be_saved', 'The choice could not be saved. Please try again.')); setOpen(true);
          return;
        }
        setPending(false); setError(''); setOpen(false);
        if (summaryRef.current) summaryRef.current.focus();
      } catch (_) { setError(simplifiedText('simplified.role_the_choice_could_not_be_saved', 'The choice could not be saved. Please try again.')); setOpen(true); }
    };
    // Students get one plain sentence. The form and role names, and notes such
    // as "Original not captured... before sharing", are for the teacher.
    if (!props.isTeacherMode) return <p data-instructional-role={props.role} data-student-role-note className="my-3 text-sm text-slate-700">{props.studentLabel || props.formLabel}</p>;
    return <details data-instructional-role={props.role} open={open}
      className="my-3 rounded-xl border border-slate-200 bg-white p-3 text-sm text-slate-800">
      <summary ref={summaryRef} onClick={event => { event.preventDefault(); setOpen(value => !value); }} className="min-h-11 cursor-pointer rounded-lg py-2 focus-visible:outline focus-visible:outline-2 focus-visible:outline-indigo-600">
        <strong>{props.formLabel}</strong><span aria-hidden="true"> · </span><span>{props.roleLabel}</span>
      </summary>
      {props.isTeacherMode && <div className="mt-3 flex flex-wrap items-center gap-3">
        <label className="inline-flex flex-wrap items-center gap-2">{simplifiedText('simplified.role_use_in_this_lesson', 'Use in this lesson')}<select ref={selectRef} aria-label={simplifiedText('simplified.role_use_in_this_lesson', 'Use in this lesson')} value={pending ? 'primary' : props.role} disabled={props.disabled}
            onChange={event => { const role = event.target.value; setError(''); if (role === 'primary' && props.needsAuthorization) setPending(true); else save(role); }}
            className="min-h-11 max-w-full rounded-lg border border-slate-300 bg-white px-2">
            <option value="primary">{simplifiedText('simplified.role_main_reading', 'Main reading')}</option><option value="supplemental">{simplifiedText('simplified.role_supporting_reading', 'Supporting reading')}</option><option value="unspecified">{simplifiedText('simplified.role_not_designated', 'Not designated')}</option>
          </select>
        </label>
        {props.role === 'primary' && props.needsAuthorization && !pending && <button type="button" disabled={props.disabled} onClick={() => setPending(true)} className="min-h-11 rounded-lg border border-amber-400 px-3">{simplifiedText('simplified.role_review_main_reading_choice', 'Review main-reading choice')}</button>}
        {props.onSelectSource && <button type="button" disabled={props.disabled || pending} onClick={props.onSelectSource} className="min-h-11 rounded-lg border border-indigo-300 px-3 text-indigo-900">{simplifiedText('simplified.role_use_for_activities', 'Use for activities')}</button>}
      </div>}
      {pending && props.isTeacherMode && <div role="group" aria-label={simplifiedText('simplified.role_confirm_main_reading', 'Confirm main reading')} className="mt-3 rounded-lg border border-amber-400 bg-amber-50 p-3 text-amber-950">
        <p>{simplifiedText('simplified.role_use_this_adapted_text_as_the', 'Use this adapted text as the main reading? The grade-level original would no longer be the main text students read, which matters most when they are working toward literacy standards in ELA, science, or history. Confirm that replacing the original fits the student’s documented plan, instructional target, assessment conditions, and local policy.')}</p>
        <div className="mt-3 flex flex-wrap gap-2">
          <button ref={confirmRef} type="button" disabled={props.disabled} onClick={() => save('primary')} className="min-h-11 rounded-lg border border-amber-700 bg-white px-3 font-semibold">{simplifiedText('simplified.role_confirm_main_reading', 'Confirm main reading')}</button>
          <button type="button" disabled={props.disabled} onClick={() => { setPending(false); setError(''); if (selectRef.current) selectRef.current.focus(); }} className="min-h-11 rounded-lg border border-slate-400 bg-white px-3">{simplifiedText('common.cancel', 'Cancel')}</button>
        </div>
      </div>}
      {error && <p role="alert" className="mt-2 text-red-800">{error}</p>}
      {props.showCompanionNote && <p className="mt-2">{simplifiedText('simplified.role_adapted_companions_help_preview_ideas_an', 'Adapted companions can activate background knowledge, build context, preview key concepts, and scaffold students toward the original.')}</p>}
      {props.missingOriginal && <p role="status" className="mt-2 text-amber-900">{simplifiedText('simplified.role_original_not_captured_check_the_matching', 'Original not captured. Check the matching source before sharing.')}</p>}
    </details>;
  }
// A model field the prompt declares as text is not guaranteed to BE text, and React throws
  // "Objects are not valid as a React child" on anything else - costing the whole panel rather
  // than the one value (2026-09-13: one such entry blanked an entire Curriculum Audit). The
  // level-check rubric's per-dimension `reason` is printed straight from the model, so it goes
  // through this. Text passes; a single-text object is flattened; anything else renders as
  // nothing. Pure. (The syllable list nearby already filters to strings, so it needs no guard.)
  function simplifiedAiText(value) {
    if (typeof value === 'string') return value;
    if (typeof value === 'number' || typeof value === 'boolean') return String(value);
    if (!value || typeof value !== 'object' || Array.isArray(value)) return '';
    var keys = ['reason', 'text', 'value', 'label', 'explanation'];
    for (var i = 0; i < keys.length; i++) {
      if (typeof value[keys[i]] === 'string' && value[keys[i]].trim()) return value[keys[i]];
    }
    return '';
  }

  // Inject Chunk Read mood keyframes once. Reduced-motion media query disables
  // the animations globally so users with that preference see static styling.
  (function () {
    if (typeof document === 'undefined') return;
    if (document.getElementById('allo-chunk-mood-css')) return;
    var st = document.createElement('style');
    st.id = 'allo-chunk-mood-css';
    st.textContent = '@keyframes allo-chunk-popin { 0% { transform: scale(0.95); opacity: 0; } 100% { transform: scale(1); opacity: 1; } }' + '@keyframes allo-chunk-pulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.02); } }' + '@media (prefers-reduced-motion: reduce) {' + '  [data-sentence-idx] { animation: none !important; }' + '}';
    if (document.head) document.head.appendChild(st);
  })();
  // Authoritative dictionary panel (Wiktionary via dictionaryapi.dev, offline-cached)
  // rendered beside the AI's leveled definition in the Define popup — triangulation.
  // Pure fn of (entry, t); returns null when there's no entry (AI-only fallback).
  function lookupDictionaryText(t, key, fallback) {
    var value = t(key); return value && value !== key ? value : fallback;
  }
  function dictionarySenseForLookup(data) {
    var dictionary = data?.dictionary;
    if (!dictionary) return null;
    var request = data.lookupRequest || {}, passage = String(request.passageText || '');
    var context = passage;
    if (Number.isInteger(request.selectionStart)) {
      var start = Math.max(0, Math.min(passage.length, request.selectionStart));
      var end = Math.min(passage.length, Math.max(start, request.selectionEnd ?? start + String(data.word || '').length));
      var before = passage.slice(0, start), after = passage.slice(end);
      var boundary = Math.max(before.lastIndexOf('.'), before.lastIndexOf('!'), before.lastIndexOf('?'), before.lastIndexOf('\n'));
      var next = after.search(/[.!?\n]/);
      context = passage.slice(boundary + 1, next < 0 ? passage.length : end + next + 1);
    }
    if (typeof window.AlloDictionary?.matchPassageSense === 'function') return window.AlloDictionary.matchPassageSense(dictionary, context);
    var senses = (dictionary.meanings || []).flatMap((m, mi) => (m.definitions || []).map((d, di) => ({ ...d, partOfSpeech: m.partOfSpeech, meaningIndex: mi, definitionIndex: di })));
    return senses.length === 1 ? senses[0] : null;
  }
  function renderDictionaryPronunciations(dict, t, renderRecording, prefix) {
    // Legacy cached fields were assembled independently. Show them separately;
    // only the new per-record variants assert a text/audio pairing.
    var variants = Array.isArray(dict.pronunciations) && dict.pronunciations.length ? dict.pronunciations : [
      { phonetic: dict.phonetic || '', audio: '' }, { phonetic: '', audio: dict.audio || '' }
    ];
    var recordingIndex = 0;
    return variants.filter(p => p && (p.phonetic || p.audio)).map(function (p, index) {
      var key = prefix + '-recording' + (recordingIndex ? '-' + recordingIndex : '');
      if (p.audio) recordingIndex++;
      return <div key={index} data-dictionary-pronunciation={index} className="flex flex-wrap items-center gap-2">
        {p.phonetic && <span className="font-mono text-xs text-slate-700">{p.phonetic}</span>}
        {p.audio && renderRecording && renderRecording(key, p.audio, null, 'English', lookupDictionaryText(t, 'simplified.lookup_listen_pronunciation', 'Listen to pronunciation') + (variants.length > 1 ? ' ' + (index + 1) : ''))}
      </div>;
    });
  }
  function renderDictionaryPanel(dict, t, renderRecording, lookupData) {
    if (!dict) return null;
    var selected = dictionarySenseForLookup(lookupData || { dictionary: dict });
    var senses = (dict.meanings || []).flatMap((meaning, mi) => (meaning.definitions || []).map((definition, di) => ({ ...definition, partOfSpeech: meaning.partOfSpeech, meaningIndex: mi, definitionIndex: di })));
    var same = sense => selected && sense.meaningIndex === selected.meaningIndex && sense.definitionIndex === selected.definitionIndex;
    var other = senses.filter(sense => !same(sense));
    var renderSense = function (sense) {
      var key = sense.meaningIndex + '-' + sense.definitionIndex;
      return <div key={key} data-dictionary-sense={key} className="my-2 text-sm text-slate-800">
        {sense.partOfSpeech && <span className="mr-1 italic">{sense.partOfSpeech}</span>}{sense.definition}
        {sense.example && <p className="mt-1 text-xs italic">{sense.example}</p>}
        {renderRecording && renderRecording('definition-meaning-' + key, null, sense.definition, 'English', lookupDictionaryText(t, 'simplified.lookup_listen_meaning', 'Listen to this meaning'))}
      </div>;
    };
    var sourceUrl = dict.sourceUrl || (dict.word ? 'https://en.wiktionary.org/wiki/' + encodeURIComponent(dict.word) : '');
    return <div data-dictionary-panel className="mt-3 border-t border-emerald-200 pt-3">
      <p className="text-xs font-bold text-emerald-800">{lookupDictionaryText(t, 'glossary.popups.dictionary', 'Dictionary')}</p>
      {renderDictionaryPronunciations(dict, t, renderRecording, 'definition')}
      {selected && <div data-dictionary-suggested><p className="mt-2 text-xs font-semibold">{lookupDictionaryText(t, 'simplified.lookup_possible_meaning', 'Possible meaning in this passage')}</p>{renderSense(selected)}</div>}
      {selected && other.length > 0 ? <details><summary className="min-h-11 cursor-pointer py-2 text-sm font-semibold">{lookupDictionaryText(t, 'simplified.lookup_other_meanings', 'Other dictionary meanings')}</summary>{other.map(renderSense)}</details> : !selected && <div><p className="mt-2 text-xs">{lookupDictionaryText(t, 'simplified.lookup_choose_meaning', 'Choose the meaning that fits your passage.')}</p>{senses.map(renderSense)}</div>}
      {!!dict.synonyms?.length && <p className="my-2 text-xs">{lookupDictionaryText(t, 'simplified.lookup_all_synonyms', 'Dictionary synonyms (all meanings)') + ': ' + dict.synonyms.slice(0, 5).join(', ')}</p>}
      {sourceUrl && <a href={sourceUrl} target="_blank" rel="noopener noreferrer" className="text-xs text-emerald-800 underline">{lookupDictionaryText(t, 'common.resource', 'Source') + ': ' + (dict.source || 'Dictionary')}</a>}
    </div>;
  }

  // Lead with the accessible explanation students asked for, while clearly
  // distinguishing it from the sourced dictionary entry that follows.
  function renderReadingLevelExplanation(definitionData, t, renderFormattedText) {
    if (!definitionData || !definitionData.text) return null;
    return React.createElement('div', { role: "group",
      className: 'rounded-lg bg-indigo-50/60 border border-indigo-100 px-3 py-2.5',
      'aria-label': t('glossary.popups.reading_level_explanation') || 'Reading-level explanation'
    },
      React.createElement('div', { className: 'flex items-center gap-2 mb-1.5 flex-wrap' },
        React.createElement('span', { className: 'text-[10px] font-bold uppercase tracking-wide text-indigo-700' },
          t('glossary.popups.reading_level_explanation') || 'Reading-level explanation'),
        React.createElement('span', { className: 'text-[10px] font-semibold text-indigo-600 bg-white border border-indigo-200 rounded-full px-1.5 py-0.5' },
          t('glossary.popups.ai_generated') || 'AI-generated')),
      React.createElement('div', { className: 'text-sm text-slate-700 leading-relaxed' },
        renderFormattedText(definitionData.text, false)));
  }

  // Authoritative pronunciation row for the phonics popup: real Wiktionary recording
  // + authoritative IPA, shown quietly beside the AI phonics. Pure fn; null when absent.
  function renderPhonicsDictRow(phonicsData, t, renderRecording) {
    var dict = phonicsData?.dictionary;
    if (!dict || (!dict.phonetic && !dict.audio && !dict.pronunciations?.length)) return null;
    return <div><p className="text-xs font-bold text-emerald-800">{lookupDictionaryText(t, 'glossary.popups.dictionary', 'Dictionary')}</p>{renderDictionaryPronunciations(dict, t, renderRecording, 'phonics')}</div>;
  }
  var _lazyIcon = function (name) {
    return function (props) {
      var I = window.AlloIcons && window.AlloIcons[name];
      return I ? <I {...props} /> : null;
    };
  };
  var Heart = _lazyIcon('Heart');
  var CheckCircle = _lazyIcon('CheckCircle');
  var Volume2 = _lazyIcon('Volume2');
  var Mic = _lazyIcon('Mic');
  var Search = _lazyIcon('Search');
  var Ear = _lazyIcon('Ear');
  var Plus = _lazyIcon('Plus');
  var HelpCircle = _lazyIcon('HelpCircle');
  var PenTool = _lazyIcon('PenTool');
  var Gamepad2 = _lazyIcon('Gamepad2');
  var Pencil = _lazyIcon('Pencil');
  var GitCompare = _lazyIcon('GitCompare');
  var BookOpen = _lazyIcon('BookOpen');
  var Settings = _lazyIcon('Settings');
  var ChevronLeft = _lazyIcon('ChevronLeft');
  var ChevronRight = _lazyIcon('ChevronRight');
  var Copy = _lazyIcon('Copy');
  var RefreshCw = _lazyIcon('RefreshCw');
  var ShieldCheck = _lazyIcon('ShieldCheck');
  var Download = _lazyIcon('Download');
  var CheckCircle2 = _lazyIcon('CheckCircle2');
  var X = _lazyIcon('X');
  var Bold = _lazyIcon('Bold');
  var Italic = _lazyIcon('Italic');
  var Highlighter = _lazyIcon('Highlighter');
  var List = _lazyIcon('List');
  var ListOrdered = _lazyIcon('ListOrdered');
  var Trophy = _lazyIcon('Trophy');
  var ImageIcon = _lazyIcon('ImageIcon');
  var Sparkles = _lazyIcon('Sparkles');
  var AlertCircle = _lazyIcon('AlertCircle');
  var ArrowRight = _lazyIcon('ArrowRight');
  var Play = _lazyIcon('Play');
  var Pause = _lazyIcon('Pause');
  var StopCircle = _lazyIcon('StopCircle');
  var Trash2 = _lazyIcon('Trash2');
  var ChevronDown = _lazyIcon('ChevronDown');
  var ChevronUp = _lazyIcon('ChevronUp');
  function simplifiedBodyHasCitationMarkers(body) {
    var inFence = false;
    return String(body || '').split(/\r?\n/).some(function (line) {
      if (/^[ \t]*(?:\x60{3}|~~~)/.test(line)) {
        inFence = !inFence;
        return false;
      }
      if (inFence) return false;
      var prose = line.replace(/\x60[^\x60\n]*\x60/g, '');
      return /\[\s*\u207d[\u2070\u00b9\u00b2\u00b3\u2074\u2075\u2076\u2077\u2078\u2079]+\u207e\s*\]\s*\(|\u207d[\u2070\u00b9\u00b2\u00b3\u2074\u2075\u2076\u2077\u2078\u2079]+\u207e|\[Source[ \t]+\d+\]/i.test(prose);
    });
  }
  function resolveSimplifiedReferences(adaptedBody, adaptedReferences, inputReferences, citationAudit) {
    var ownedReferences = String(adaptedReferences || '');
    if (ownedReferences) return ownedReferences;
    var auditAllowsFallback = !citationAudit ||
      (citationAudit.enabled === true && Number(citationAudit.sourceCitationCount || 0) > 0);
    if (!auditAllowsFallback || !simplifiedBodyHasCitationMarkers(adaptedBody)) return '';
    return String(inputReferences || '');
  }

  // Reading resources keep their renderer type ("simplified") separate from
  // their instructional use.  These helpers intentionally live outside the
  // component so role changes and comparison-source selection remain pure and
  // can be regression tested without mounting the full reader.
  function getInstructionalContextApi() {
    try {
      return window.AlloModules && window.AlloModules.InstructionalContext
        ? window.AlloModules.InstructionalContext
        : null;
    } catch (_) {
      return null;
    }
  }

  function fallbackInstructionalText(item) {
    var resource = item && typeof item === 'object' ? item : {};
    var config = resource.config && typeof resource.config === 'object' ? resource.config : {};
    var raw = resource.instructionalText || config.instructionalText || {};
    var rawComplexity = raw.complexity && typeof raw.complexity === 'object' ? raw.complexity : {};
    var rawAuthorization = raw.replacementAuthorization && typeof raw.replacementAuthorization === 'object'
      ? raw.replacementAuthorization
      : {};
    var role = ['primary', 'supplemental', 'unspecified'].indexOf(raw.role) >= 0
      ? raw.role
      : 'unspecified';
    var form = ['original', 'same-text-supported', 'adapted'].indexOf(raw.form) >= 0
      ? raw.form
      : (resource.type === 'simplified' ? 'adapted' : 'original');
    var educatorAuthorized = rawAuthorization.authorized === true && rawAuthorization.source === 'educator';
    return {
      schemaVersion: 1,
      role: role,
      form: form,
      sourceArtifactId: raw.sourceArtifactId || null,
      primaryArtifactId: raw.primaryArtifactId || null,
      designationSource: ['educator', 'workflow-default', 'legacy-inferred'].indexOf(raw.designationSource) >= 0
        ? raw.designationSource
        : 'legacy-inferred',
      replacementAuthorization: {
        authorized: educatorAuthorized,
        source: educatorAuthorized ? 'educator' : 'none'
      },
      complexity: {
        requestedGrade: rawComplexity.requestedGrade || resource.targetGradeLevel || config.grade || '',
        calibrationTarget: rawComplexity.calibrationTarget || '',
        measuredGrade: rawComplexity.measuredGrade !== undefined
          ? rawComplexity.measuredGrade
          : (resource.localStats && resource.localStats.score !== undefined ? resource.localStats.score : null),
        method: rawComplexity.method || '',
        status: rawComplexity.status || 'unavailable',
        contentFingerprint: rawComplexity.contentFingerprint || '',
        measuredAt: rawComplexity.measuredAt || '',
        language: rawComplexity.language || config.language || 'English'
      }
    };
  }

  function getSimplifiedInstructionalText(item) {
    var api = getInstructionalContextApi();
    if (api && typeof api.getInstructionalText === 'function') {
      try { return api.getInstructionalText(item); } catch (_) {}
    }
    return fallbackInstructionalText(item);
  }

  function updateSimplifiedInstructionalRole(item, requestedRole) {
    var resource = item && typeof item === 'object' ? item : {};
    var role = ['primary', 'supplemental', 'unspecified'].indexOf(requestedRole) >= 0
      ? requestedRole
      : 'unspecified';
    var current = getSimplifiedInstructionalText(resource);
    var nextProfile = Object.assign({}, current, {
      role: role,
      form: current.form,
      designationSource: 'educator',
      replacementAuthorization: role === 'primary' && current.form === 'adapted'
        ? { authorized: true, source: 'educator' }
        : { authorized: false, source: 'none' }
    });
    var api = getInstructionalContextApi();
    if (api && typeof api.normalizeInstructionalText === 'function') {
      try { nextProfile = api.normalizeInstructionalText(nextProfile); } catch (_) {}
    }
    return Object.assign({}, resource, { instructionalText: nextProfile });
  }

  function artifactIdentityValues(item) {
    if (!item || typeof item !== 'object') return [];
    return [item.id, item.uiId, item.artifactId, item.resourceId]
      .filter(function (value) { return value !== undefined && value !== null && String(value).trim(); })
      .map(function (value) { return String(value); });
  }

  function artifactsMatch(left, right) {
    if (!left || !right) return false;
    var leftIds = artifactIdentityValues(left);
    var rightIds = artifactIdentityValues(right);
    if (leftIds.some(function (value) { return rightIds.indexOf(value) >= 0; })) return true;
    return left === right || (
      !leftIds.length && !rightIds.length &&
      left.type === right.type && left.data === right.data
    );
  }

  function findFullHistoryArtifact(history, item) {
    var safeHistory = Array.isArray(history) ? history : [];
    for (var index = safeHistory.length - 1; index >= 0; index -= 1) {
      if (artifactsMatch(safeHistory[index], item)) return safeHistory[index];
    }
    return item || {};
  }

  function upsertFullHistoryArtifact(history, previousItem, updatedItem) {
    var nextHistory = Array.isArray(history) ? history.slice() : [];
    for (var index = nextHistory.length - 1; index >= 0; index -= 1) {
      if (!artifactsMatch(nextHistory[index], previousItem)) continue;
      // Merge over the history record so a partially hydrated current view can
      // never erase provenance, config, or source-link fields.
      nextHistory[index] = Object.assign({}, nextHistory[index], updatedItem);
      return nextHistory;
    }
    nextHistory.push(updatedItem);
    return nextHistory;
  }

  function getArtifactReadingText(item) {
    if (!item || typeof item !== 'object') return '';
    var data = item.data;
    if (typeof data === 'string') return data;
    if (data && typeof data === 'object') {
      var dataText = data.originalText || data.rawEnglishText || data.sourceText || data.text || data.simplifiedText;
      if (dataText) return String(dataText);
    }
    return String(item.originalText || item.rawEnglishText || item.sourceText || '');
  }

  function resolveSimplifiedCompareSource(history, adaptedItem, fallbackText) {
    var safeHistory = Array.isArray(history) ? history : [];
    var api = getInstructionalContextApi();
    var snapshot = api && api.getSourceSnapshot && api.getSourceSnapshot(adaptedItem);
    if (snapshot) return { text: snapshot.text, artifact: { id: snapshot.sourceArtifactId, config: { language: snapshot.language }, data: snapshot.text }, selection: 'captured-source' };
    var profile = getSimplifiedInstructionalText(adaptedItem);
    var linkedIds = [profile.sourceArtifactId, profile.primaryArtifactId]
      .filter(function (value, index, values) {
        return value !== undefined && value !== null && String(value).trim() && values.indexOf(value) === index;
      })
      .map(function (value) { return String(value); });
    for (var linkIndex = 0; linkIndex < linkedIds.length; linkIndex += 1) {
      for (var historyIndex = safeHistory.length - 1; historyIndex >= 0; historyIndex -= 1) {
        var candidate = safeHistory[historyIndex];
        if (artifactIdentityValues(candidate).indexOf(linkedIds[linkIndex]) < 0) continue;
        if (!api?.sameReadingSourceFamily?.(candidate, adaptedItem)) continue;
        var linkedText = getArtifactReadingText(candidate);
        if (linkedText) return { text: linkedText, artifact: candidate, selection: 'linked-artifact' };
      }
    }
    return { text: '', artifact: null, selection: 'original-not-captured' };
  }

  // Identical passages can belong to different lessons or source families.
  // Both ownership and the complete captured text must agree before reusing supports.
  function sameSimplifiedReadingSnapshot(left, right) {
    return !!left && !!right && left.fingerprint === right.fingerprint && left.text === right.text;
  }

  function findSimplifiedReadingSupportOwner(history, owner, snapshot) {
    var api = getInstructionalContextApi();
    if (!owner || !snapshot || !api?.sameReadingSourceFamily || !api?.isSupportedOriginal || !api?.getSourceSnapshot) return null;
    if (getSimplifiedInstructionalText(owner).form === 'same-text-supported' && !api.isSupportedOriginal(owner)) return null;
    var candidates = [owner].concat((Array.isArray(history) ? history : []).slice().reverse());
    return candidates.find(function (item) {
      return api.isSupportedOriginal(item) && api.sameReadingSourceFamily(item, owner)
        && item.data === snapshot.text && sameSimplifiedReadingSnapshot(api.getSourceSnapshot(item), snapshot);
    }) || null;
  }

  function findSimplifiedComparisonSupportOwner(history, current, comparison, displayedText) {
    var api = getInstructionalContextApi();
    if (!api || !comparison || typeof displayedText !== 'string') return null;
    var owner = comparison.selection === 'captured-source' ? current : comparison.artifact;
    if (!owner) return null;
    var snapshot = api.getSourceSnapshot?.(owner);
    // A teacher may explicitly compare another saved original/analysis. Scope
    // glosses to that reading, never to the adaptation still open on the right.
    if ((!snapshot || snapshot.text !== comparison.text) && getSimplifiedInstructionalText(owner).form !== 'adapted') {
      snapshot = api.createSourceSnapshot?.(comparison.text, { sourceArtifactId: owner.id });
    }
    if (!snapshot || snapshot.text !== comparison.text || snapshot.text !== displayedText) return null;
    return findSimplifiedReadingSupportOwner(history, owner, snapshot);
  }

  function findSimplifiedReadingCompanion(history, original, snapshot) {
    var api = getInstructionalContextApi();
    if (!original || !snapshot || !api?.sameReadingSourceFamily || !api?.getSourceSnapshot) return null;
    if (getSimplifiedInstructionalText(original).form === 'same-text-supported' && !api.isSupportedOriginal?.(original)) return null;
    return (Array.isArray(history) ? history : []).slice().reverse().find(function (item) {
      return item?.type === 'simplified' && getSimplifiedInstructionalText(item).form === 'adapted'
        && api.sameReadingSourceFamily(item, original)
        && sameSimplifiedReadingSnapshot(api.getSourceSnapshot(item), snapshot);
    }) || null;
  }

  function getSimplifiedComplexityDisplay(item, ambientGrade) {
    var resource = item && typeof item === 'object' ? item : {};
    var resourceConfig = resource.config && typeof resource.config === 'object' ? resource.config : {};
    var hasCanonicalProfile = !!(
      resource.instructionalText || resource.textProfile ||
      resourceConfig.instructionalText || resourceConfig.textProfile
    );
    var profile = getSimplifiedInstructionalText(resource);
    var complexity = profile.complexity && typeof profile.complexity === 'object' ? profile.complexity : {};
    var rawMeasured = complexity.measuredGrade;
    var hasMeasured = rawMeasured !== null && rawMeasured !== '' && rawMeasured !== undefined;
    var measured = hasMeasured ? Number(rawMeasured) : NaN;
    if (!hasCanonicalProfile && !Number.isFinite(measured) &&
        resource.localStats && resource.localStats.score !== undefined) {
      rawMeasured = resource.localStats.score;
      measured = Number(rawMeasured);
    }
    var targetGrade = complexity.requestedGrade || resource.targetGradeLevel ||
      resourceConfig.grade || ambientGrade || '';
    var api = getInstructionalContextApi();
    var currentFingerprint = '';
    if (api && typeof api.fingerprintText === 'function' && typeof resource.data === 'string') {
      try { currentFingerprint = api.fingerprintText(resource.data); } catch (_) {}
    }
    if (complexity.contentFingerprint && currentFingerprint && complexity.contentFingerprint !== currentFingerprint) {
      return { measuredGrade: null, targetGrade: targetGrade, status: 'stale', target: null };
    }
    if (!Number.isFinite(measured)) {
      return { measuredGrade: null, targetGrade: targetGrade, status: complexity.status || 'unavailable', target: null };
    }
    var languageIsEnglish = true;
    if (api && typeof api.isEnglishLanguage === 'function') {
      try { languageIsEnglish = api.isEnglishLanguage(complexity.language || 'English'); } catch (_) {}
    }
    var status = !languageIsEnglish
      ? 'unavailable'
      : api && typeof api.complexityStatus === 'function'
        ? api.complexityStatus(measured, targetGrade)
        : (['below-target', 'within-target', 'above-target'].indexOf(complexity.status) >= 0
          ? complexity.status
          : 'unavailable');
    var target = null;
    if (api && typeof api.getComplexityTarget === 'function') {
      try { target = api.getComplexityTarget(targetGrade); } catch (_) {}
    }
    return { measuredGrade: measured, targetGrade: targetGrade, status: status, target: target };
  }

  async function checkSimplifiedAlignment(deps) {
    var options = deps || {};
    var generatedContent = options.generatedContent;
    var gradeLevel = options.gradeLevel;
    var leveledTextLanguage = options.leveledTextLanguage;
    var activeResolvedStandardsContext = options.activeResolvedStandardsContext;
    var standardsInput = options.standardsInput;
    var targetStandards = options.targetStandards;
    var alloBotRef = options.alloBotRef;
    var t = options.t;
    var addToast = options.addToast;
    var setIsCheckingAlignment = options.setIsCheckingAlignment;
    var callGemini = options.callGemini;
    var cleanJson = options.cleanJson;
    var setGeneratedContent = options.setGeneratedContent;
    var setHistory = options.setHistory;
    var speak = options.speak;
    var warnLog = options.warnLog;
    var setError = options.setError;
    if (!generatedContent || generatedContent.type !== 'simplified') return;
    var contextModule = window.AlloModules && window.AlloModules.InstructionalContext;
    var alignmentContext = contextModule && typeof contextModule.resolveArtifactContext === 'function'
      ? contextModule.resolveArtifactContext(generatedContent, {
          grade: gradeLevel,
          language: leveledTextLanguage,
          standardsContext: activeResolvedStandardsContext,
          standards: standardsInput || targetStandards || null
        })
      : {
          grade: generatedContent?.targetGradeLevel || generatedContent?.config?.grade || gradeLevel,
          standards: generatedContent?.config?.standardsContext
            || generatedContent?.config?.standards
            || activeResolvedStandardsContext
            || standardsInput
            || targetStandards
            || null
        };
    var alignmentGrade = alignmentContext.grade || gradeLevel;
    var alignmentStandardsValue = alignmentContext.standards;
    var alignmentStandardsText = (function () {
      if (!alignmentStandardsValue) return '';
      if (typeof alignmentStandardsValue === 'string') return alignmentStandardsValue.trim();
      if (typeof alignmentStandardsValue.promptText === 'string' && alignmentStandardsValue.promptText.trim()) {
        return alignmentStandardsValue.promptText.trim();
      }
      var entries = Array.isArray(alignmentStandardsValue.standards)
        ? alignmentStandardsValue.standards
        : (Array.isArray(alignmentStandardsValue) ? alignmentStandardsValue : []);
      return entries.map(function (entry) {
        return typeof entry === 'string'
          ? entry
          : [entry?.code || entry?.id, entry?.text || entry?.label].filter(Boolean).join(': ');
      }).filter(Boolean).join('; ');
    })().slice(0, 4000);
    if (alloBotRef && alloBotRef.current) {
      var contextMessage = t('bot_events.feedback_audit_start').replace('{standard}', alignmentStandardsText || 'Standard');
      alloBotRef.current.speak(contextMessage);
    }
    if (!alignmentStandardsText) {
      addToast(t('alignment.notifications.no_standard_error'), 'error');
      return;
    }
    setIsCheckingAlignment(true);
    try {
      var textToCheck = typeof generatedContent?.data === 'string' ? generatedContent.data : '';
      var prompt = `
            You are a curriculum specialist. Evaluate the rigor of the following text against ALL provided standards.
            Target Standards: "${alignmentStandardsText}"
            Target Grade Level: ${alignmentGrade}
            Text to Evaluate:
            "${textToCheck.substring(0, 3000)}",
            Task:
            1. Think step-by-step. Analyze the cognitive demand (verbs) and content (nouns) of the standards.
            2. Identify specific evidence in the text that matches these requirements.
            3. Determine if the text supports the full rigor required by the standards, or if simplification has removed necessary depth.
            Return ONLY JSON:
            {
                "evidence": "List specific phrases or sections from the text that serve as evidence of alignment...",
                "status": "Aligned" or "Partially Aligned" or "Not Aligned",
                "rigorReport": "Explanation of how the text meets or fails the cognitive demand based on the evidence...",
                "missingElements": "Specific concepts or structures from the standard that are absent (or 'None')...",
                "improvement": "One specific edit to increase rigor without breaking accessibility."
            }
        `;
      var result = await callGemini(prompt, true);
      var parsedAnalysis = JSON.parse(cleanJson(result));
      var fingerprintText = contextModule && typeof contextModule.fingerprintText === 'function'
        ? contextModule.fingerprintText(textToCheck)
        : String(textToCheck.length) + '|' + textToCheck.slice(0, 64) + '|' + textToCheck.slice(-64);
      var fingerprintStandards = contextModule && typeof contextModule.fingerprintValue === 'function'
        ? contextModule.fingerprintValue(alignmentStandardsValue)
        : '';
      var analysis = {
        ...parsedAnalysis,
        contentFingerprint: fingerprintText,
        checkedAt: new Date().toISOString(),
        contextSnapshot: {
          grade: alignmentGrade,
          standardsFingerprint: fingerprintStandards,
          standardsText: alignmentStandardsText
        }
      };
      var updatedContent = { ...generatedContent, alignmentCheck: analysis };
      setGeneratedContent(updatedContent);
      setHistory(function (previous) {
        return previous.map(function (item) { return item.id === generatedContent.id ? updatedContent : item; });
      });
      addToast(t('alignment.notifications.check_complete'), 'success');
      var feedbackKey = 'bot.rigor_feedback_misaligned';
      if (analysis.status === 'Aligned') feedbackKey = 'bot.rigor_feedback_aligned';
      else if (analysis.status === 'Partially Aligned') feedbackKey = 'bot.rigor_feedback_partial';
      speak(t(feedbackKey));
    } catch (error) {
      warnLog('Unhandled error:', error);
      setError(t('alignment.notifications.error_check'));
      addToast(t('alignment.notifications.check_failed'), 'error');
    } finally {
      setIsCheckingAlignment(false);
    }
  }

  async function regenerateSimplifiedWithRigor(deps) {
    var options = deps || {};
    var generatedContent = options.generatedContent;
    var setIsProcessing = options.setIsProcessing;
    var splitReferencesFromBody = options.splitReferencesFromBody;
    var extractSourceTextForProcessing = options.extractSourceTextForProcessing;
    var activeResolvedStandardsContext = options.activeResolvedStandardsContext;
    var standardsInput = options.standardsInput;
    var targetStandards = options.targetStandards;
    var gradeLevel = options.gradeLevel;
    var leveledTextLanguage = options.leveledTextLanguage;
    var translationTargetChoices = options.translationTargetChoices;
    var currentUiLanguage = options.currentUiLanguage;
    var selectedLanguages = options.selectedLanguages;
    var resolveTranslationPolicy = options.resolveTranslationPolicy;
    var translationMode = options.translationMode;
    var generateBilingualText = options.generateBilingualText;
    var callGemini = options.callGemini;
    var applySimplifiedTextMutation = options.applySimplifiedTextMutation;
    var setGeneratedContent = options.setGeneratedContent;
    var setHistory = options.setHistory;
    var addToast = options.addToast;
    var t = options.t;
    var warnLog = options.warnLog;
    var setError = options.setError;
    if (!generatedContent || !generatedContent.alignmentCheck || !generatedContent?.data || getSimplifiedInstructionalText(generatedContent).form === 'same-text-supported') return;
    setIsProcessing(true);
    try {
      var rawText = typeof generatedContent?.data === 'string' ? generatedContent.data : '';
      var isLeveledText = generatedContent.type === 'simplified';
      var originalParts = isLeveledText
        ? splitReferencesFromBody(rawText)
        : { body: rawText, references: '' };
      var sourceExtraction = extractSourceTextForProcessing(originalParts.body, false);
      var currentText = sourceExtraction.text;
      var countCitationMarkers = function (value) {
        return (String(value || '').match(/\[\u207d[\u2070\u00b9\u00b2\u00b3\u2074-\u2079]+\u207e\]\(/g) || []).length;
      };
      var validateRigorCitations = function (original, candidate) {
        var modules = typeof window !== 'undefined' && window.AlloModules;
        var beforeCountFallback = countCitationMarkers(original);
        var afterCountFallback = countCitationMarkers(candidate);
        var citationShaped = beforeCountFallback > 0 || afterCountFallback > 0;
        var unavailable = function (reason, error) {
          return {
            valid: !citationShaped,
            ok: !citationShaped,
            reason: reason,
            error: error ? String(error?.message || error) : undefined,
            beforeCount: beforeCountFallback,
            afterCount: afterCountFallback,
            orderChanged: false
          };
        };
        var normalizeDecision = function (result) {
          if (typeof result === 'boolean') return { known: true, valid: result };
          if (!result || typeof result !== 'object') return { known: false, valid: false };
          if (Object.prototype.hasOwnProperty.call(result, 'valid')) return { known: true, valid: result.valid === true };
          if (Object.prototype.hasOwnProperty.call(result, 'ok')) return { known: true, valid: result.ok === true };
          if (Object.prototype.hasOwnProperty.call(result, 'conserved')) return { known: true, valid: result.conserved === true };
          return { known: false, valid: false };
        };

        var dispatcherValidate = modules?.GenDispatcher?.validateAdaptationCitationConservation;
        if (typeof dispatcherValidate === 'function') {
          try {
            var dispatcherResult = dispatcherValidate(original, candidate);
            var dispatcherDecision = normalizeDecision(dispatcherResult);
            if (!dispatcherDecision.known) return unavailable('citation-validator-invalid-result');
            var dispatcherDetails = dispatcherResult && typeof dispatcherResult === 'object' ? dispatcherResult : {};
            return {
              ...dispatcherDetails,
              valid: dispatcherDecision.valid && !dispatcherDetails.orderChanged,
              ok: dispatcherDecision.valid && !dispatcherDetails.orderChanged,
              beforeCount: Number(dispatcherDetails.beforeCount ?? dispatcherDetails.originalLedger?.occurrences?.length ?? beforeCountFallback),
              afterCount: Number(dispatcherDetails.afterCount ?? dispatcherDetails.candidateLedger?.occurrences?.length ?? afterCountFallback),
              orderChanged: !!dispatcherDetails.orderChanged
            };
          } catch (error) {
            return unavailable('citation-validator-error', error);
          }
        }

        var pipeline = modules?.TextPipelineHelpers;
        var pipelineValidate = pipeline?.validateCitationConservation;
        var extractLedger = pipeline?.extractCitationLedger;
        if (typeof pipelineValidate !== 'function' || typeof extractLedger !== 'function') {
          return unavailable('citation-validator-unavailable');
        }
        try {
          var pipelineResult = pipelineValidate(original, candidate);
          var pipelineDecision = normalizeDecision(pipelineResult);
          if (!pipelineDecision.known) return unavailable('citation-validator-invalid-result');
          var originalOccurrences = extractLedger(original)?.occurrences || [];
          var candidateOccurrences = extractLedger(candidate)?.occurrences || [];
          var orderChanged = originalOccurrences.length !== candidateOccurrences.length ||
            originalOccurrences.some(function (entry, index) { return entry?.key !== candidateOccurrences[index]?.key; });
          var pipelineDetails = pipelineResult && typeof pipelineResult === 'object' ? pipelineResult : {};
          return {
            ...pipelineDetails,
            valid: pipelineDecision.valid && !orderChanged,
            ok: pipelineDecision.valid && !orderChanged,
            beforeCount: originalOccurrences.length,
            afterCount: candidateOccurrences.length,
            orderChanged: orderChanged
          };
        } catch (error) {
          return unavailable('citation-validator-error', error);
        }
      };

      var contextModule = typeof window !== 'undefined' && window.AlloModules
        ? window.AlloModules.InstructionalContext
        : null;
      var ambientStandardsContext = typeof activeResolvedStandardsContext !== 'undefined'
        ? activeResolvedStandardsContext
        : null;
      var ambientStandards = typeof standardsInput !== 'undefined'
        ? standardsInput
        : (typeof targetStandards !== 'undefined' ? targetStandards : null);
      var rigorContext = contextModule && typeof contextModule.resolveArtifactContext === 'function'
        ? contextModule.resolveArtifactContext(generatedContent, {
            grade: gradeLevel,
            language: leveledTextLanguage,
            standardsContext: ambientStandardsContext,
            standards: ambientStandards
          })
        : {
            grade: generatedContent?.instructionalText?.complexity?.requestedGrade
              || generatedContent?.targetGradeLevel || generatedContent?.config?.grade || gradeLevel,
            language: generatedContent?.instructionalText?.complexity?.language
              || generatedContent?.config?.language || leveledTextLanguage || 'English',
            standards: generatedContent?.config?.standardsContext
              || generatedContent?.config?.standards
              || ambientStandardsContext || ambientStandards || null
          };
      var rigorGrade = rigorContext.grade || gradeLevel;
      var rigorLanguage = rigorContext.language || leveledTextLanguage || 'English';
      var rigorStandardsValue = rigorContext.standards;
      var rigorStandards = (function () {
        if (!rigorStandardsValue) return '';
        if (typeof rigorStandardsValue === 'string') return rigorStandardsValue.trim();
        if (typeof rigorStandardsValue.promptText === 'string' && rigorStandardsValue.promptText.trim()) {
          return rigorStandardsValue.promptText.trim();
        }
        var entries = Array.isArray(rigorStandardsValue.standards)
          ? rigorStandardsValue.standards
          : (Array.isArray(rigorStandardsValue) ? rigorStandardsValue : []);
        return entries.map(function (entry) {
          return typeof entry === 'string'
            ? entry
            : [entry?.code || entry?.id, entry?.text || entry?.label].filter(Boolean).join(': ');
        }).filter(Boolean).join('; ');
      })().slice(0, 2400);
      var suggestion = generatedContent.alignmentCheck.improvement;
      var prompt = `
            Rewrite the following educational text to address specific feedback regarding standard alignment.
            Current Text:
            "${currentText}",
            Feedback/Suggestion to Implement:
            "${suggestion}",
            Target Audience: ${rigorGrade} students.
            ${rigorStandards ? `Standards Context: ${rigorStandards}` : ''}
            Instructions:
            - Incorporate the suggestion to increase rigor or alignment.
            - Maintain the appropriate reading level for ${rigorGrade}.
            - Preserve the disciplinary concepts and cognitive demand in the recorded standards context.
            - Write the rewritten text in ${rigorLanguage}.
            ${isLeveledText ? `- Preserve every inline Markdown citation exactly as written, including its superscript number, URL, occurrence count, and order.
            - Keep each citation attached to the same supported claim; never add, remove, duplicate, rename, reorder, or alter a citation.
            - Do not produce a Sources, References, Bibliography, or Works Cited section. AlloFlow appends the preserved reference trailer after validation.` : ''}
        `;
      var rigorTranslationChoices = typeof translationTargetChoices === 'function'
        ? translationTargetChoices(rigorLanguage, currentUiLanguage, typeof selectedLanguages !== 'undefined' ? selectedLanguages : [])
        : [];
      var rigorTranslationPolicy = typeof resolveTranslationPolicy === 'function'
        ? resolveTranslationPolicy(translationMode, rigorLanguage, currentUiLanguage, rigorTranslationChoices)
        : { enabled: false, target: 'English', mode: 'off' };
      var newText = await generateBilingualText(prompt, rigorLanguage, callGemini, rigorTranslationPolicy);
      var rigorCitationAudit = null;
      if (isLeveledText) {
        var candidateParts = splitReferencesFromBody(newText);
        var candidateBody = String(candidateParts.body || '').trim();
        var candidateExtraction = extractSourceTextForProcessing(candidateBody, false);
        var candidateTarget = candidateExtraction.targetLangBlock || candidateExtraction.text;
        var originalForValidation = sourceExtraction.isBilingual
          ? originalParts.body
          : currentText;
        var candidateForValidation = sourceExtraction.isBilingual
          ? candidateBody
          : candidateTarget;
        var conservation = validateRigorCitations(originalForValidation, candidateForValidation);
        var shouldValidateGeneratedEnglish = !sourceExtraction.isBilingual
          && (candidateExtraction.isBilingual || String(rigorLanguage || '').trim().toLowerCase() !== 'english');
        if (shouldValidateGeneratedEnglish) {
          var englishConservation = validateRigorCitations(
            candidateTarget,
            candidateExtraction.isBilingual ? candidateExtraction.englishBlock : ''
          );
          conservation = {
            ...conservation,
            valid: !!conservation.valid && !!englishConservation.valid,
            ok: !!conservation.valid && !!englishConservation.valid,
            beforeCount: Number(conservation.beforeCount || 0) + Number(englishConservation.beforeCount || 0),
            afterCount: Number(conservation.afterCount || 0) + Number(englishConservation.afterCount || 0),
            orderChanged: !!conservation.orderChanged || !!englishConservation.orderChanged,
            english: englishConservation
          };
        }
        rigorCitationAudit = {
          stage: 'rigor-regeneration',
          valid: !!conservation.valid,
          beforeCount: Number(conservation.beforeCount ?? conservation.originalLedger?.occurrences?.length ?? countCitationMarkers(originalForValidation)),
          afterCount: Number(conservation.afterCount ?? conservation.candidateLedger?.occurrences?.length ?? countCitationMarkers(candidateForValidation)),
          orderChanged: !!conservation.orderChanged,
          ...(conservation.reason ? { reason: conservation.reason } : {})
        };
        if (!conservation.valid) {
          var citationError = new Error(simplifiedText('simplified.rigor_rigor_regeneration_changed_or_could_not', 'Rigor regeneration changed or could not verify source citations.'));
          citationError.code = 'citation-conservation-failed';
          citationError.details = conservation;
          throw citationError;
        }
        newText = [candidateBody, originalParts.references].filter(Boolean).join('\n\n');
      }

      var priorConfig = generatedContent.config && typeof generatedContent.config === 'object'
        ? generatedContent.config
        : {};
      var priorAudit = priorConfig.citationAudit && typeof priorConfig.citationAudit === 'object'
        ? priorConfig.citationAudit
        : null;
      var updatedConfig = rigorCitationAudit ? {
        ...priorConfig,
        citationAudit: {
          ...(priorAudit || {
            version: 1,
            policy: 'exact-marker-order',
            enabled: rigorCitationAudit.beforeCount > 0,
            status: 'valid',
            fallbackCount: 0
          }),
          stages: [...(Array.isArray(priorAudit?.stages) ? priorAudit.stages : []), rigorCitationAudit]
        }
      } : generatedContent.config;
      var updatedContent = {
        ...generatedContent,
        data: newText,
        ...(rigorCitationAudit ? { config: updatedConfig } : {})
      };
      // Keep readability and AI-check evidence tied to the exact rewritten
      // bytes, just as manual edits and undo/redo do.
      if (isLeveledText && typeof applySimplifiedTextMutation === 'function') {
        updatedContent = applySimplifiedTextMutation(updatedContent, newText);
      } else {
        delete updatedContent.localStats;
        var fallbackContextModule = typeof window !== 'undefined' && window.AlloModules
          ? window.AlloModules.InstructionalContext
          : null;
        if (fallbackContextModule && typeof fallbackContextModule.getInstructionalText === 'function'
          && typeof fallbackContextModule.invalidateComplexityEvidence === 'function') {
          var baseInstructionalText = fallbackContextModule.getInstructionalText(updatedContent, {
            complexity: { requestedGrade: rigorGrade, language: rigorLanguage }
          });
          updatedContent.instructionalText = fallbackContextModule.invalidateComplexityEvidence(
            baseInstructionalText,
            newText,
            'stale'
          );
          updatedContent.targetGradeLevel = rigorGrade;
        }
        delete updatedContent.alignmentCheck;
        if (updatedContent.levelCheck) delete updatedContent.levelCheck;
      }
      setGeneratedContent(updatedContent);
      setHistory(function (previous) {
        return previous.map(function (item) { return item.id === generatedContent.id ? updatedContent : item; });
      });
      addToast(t('alignment.notifications.regenerated_success'), 'success');
    } catch (error) {
      if (error?.code === 'citation-conservation-failed') {
        warnLog('[CitationConservation] Rigor regeneration rejected; original resource retained.', error.details || error);
        addToast(simplifiedText('simplified.rigor_citations_kept', 'The rigor rewrite could not preserve and verify every source citation, so the original citation-safe version was retained.', undefined, t), 'warning');
        return;
      }
      warnLog('Unhandled error:', error);
      setError(t('errors.text_regeneration_failed'));
      addToast(t('alignment.notifications.regen_failed'), 'error');
    } finally {
      setIsProcessing(false);
    }
  }

  // Shared reading structure and word targets. All layouts use the same helpers.
  function simplifiedLanguageTag(language) {
    var value = String(language || '').trim();
    var names = { english: 'en', spanish: 'es', french: 'fr', german: 'de', italian: 'it', portuguese: 'pt', arabic: 'ar', hebrew: 'he', persian: 'fa', urdu: 'ur', hindi: 'hi', bengali: 'bn', punjabi: 'pa', tamil: 'ta', telugu: 'te', marathi: 'mr', gujarati: 'gu', russian: 'ru', ukrainian: 'uk', polish: 'pl', turkish: 'tr', vietnamese: 'vi', korean: 'ko', chinese: 'zh', 'mandarin chinese': 'zh', 'simplified chinese': 'zh-Hans', 'traditional chinese': 'zh-Hant', japanese: 'ja', thai: 'th', lao: 'lo', khmer: 'km', burmese: 'my', indonesian: 'id', malay: 'ms', swahili: 'sw', somali: 'so', haitian: 'ht', 'haitian creole': 'ht',
      // The rest of the app's language list, so screen readers pick the right voice.
      dutch: 'nl', malayalam: 'ml', kannada: 'kn', esperanto: 'eo', greek: 'el', latin: 'la', nepali: 'ne', mandarin: 'zh', cantonese: 'yue', tagalog: 'tl', filipino: 'fil', farsi: 'fa', pashto: 'ps', dari: 'fa-AF', hausa: 'ha', yoruba: 'yo', igbo: 'ig', amharic: 'am', tigrinya: 'ti', lingala: 'ln', kinyarwanda: 'rw', kirundi: 'rn', acholi: 'ach', karen: 'ksw', hmong: 'hmn', mongolian: 'mn', 'maay maay': 'ymm', marshallese: 'mh',
      'spanish (latin america)': 'es-419', 'spanish (castilian)': 'es-ES', 'french (canadian)': 'fr-CA', 'portuguese (brazil)': 'pt-BR', 'portuguese (angola)': 'pt-AO', 'chinese (simplified)': 'zh-Hans', 'chinese (traditional)': 'zh-Hant', 'chin (hakha)': 'cnh', 'chin (falam)': 'cfm' };
    var name = value.toLowerCase().replace(/\s+/g, ' '), base = name.replace(/\s*\(.*\)$/, '');
    if (names[name] || names[base]) return names[name] || names[base];
    if (!/^[a-z]{2,3}(?:-[a-z0-9]{2,8})*$/i.test(value)) return undefined;
    try { return Intl.getCanonicalLocales(value)[0]; } catch (_) { return undefined; }
  }
  function simplifiedWordSegments(text, language) {
    var value = String(text || '');
    try {
      if (typeof Intl.Segmenter === 'function') {
        return Array.from(new Intl.Segmenter(simplifiedLanguageTag(language), { granularity: 'word' }).segment(value), function (part) {
          return { text: part.segment, word: !!part.isWordLike };
        });
      }
    } catch (_) {}
    // Keep punctuation and spacing as text; unspaced scripts retain selectable
    // graphemes if the runtime cannot provide dictionary-based segmentation.
    return (value.match(/[\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Thai}\p{Script=Lao}\p{Script=Khmer}\p{Script=Myanmar}]\p{M}*|[\p{L}\p{N}]+(?:['’\-][\p{L}\p{N}]+)*|[^\p{L}\p{N}]+/gu) || []).map(function (part) {
      return { text: part, word: /[\p{L}\p{N}]/u.test(part) };
    });
  }
  // Word-level changes between two versions, for the adaptation preview. Null
  // when the texts are too long to compare quickly.
  function simplifiedWordDiff(before, after) {
    var oldTokens = String(before || '').split(/(\s+)/).filter(Boolean), newTokens = String(after || '').split(/(\s+)/).filter(Boolean);
    if (oldTokens.length * newTokens.length > 4000000) return null;
    var matrix = Array.from({ length: oldTokens.length + 1 }, () => new Uint32Array(newTokens.length + 1));
    for (var a = 1; a <= oldTokens.length; a++) for (var b = 1; b <= newTokens.length; b++) matrix[a][b] = oldTokens[a - 1] === newTokens[b - 1] ? matrix[a - 1][b - 1] + 1 : Math.max(matrix[a - 1][b], matrix[a][b - 1]);
    var parts = [], x = oldTokens.length, y = newTokens.length;
    while (x || y) {
      if (x && y && oldTokens[x - 1] === newTokens[y - 1]) { parts.push({ type: 'same', value: oldTokens[--x] }); --y; }
      else if (x && (!y || matrix[x - 1][y] >= matrix[x][y - 1])) parts.push({ type: 'del', value: oldTokens[--x] });
      else parts.push({ type: 'add', value: newTokens[--y] });
    }
    parts.reverse();
    // Group each changed stretch (spaces inside it too): all removed words, then all new ones.
    var grouped = [], del = '', add = '';
    var flush = () => { if (del) grouped.push({ type: 'del', value: del }); if (add) grouped.push({ type: 'add', value: add }); del = add = ''; };
    parts.forEach((part, index) => {
      var inside = part.type === 'same' && !part.value.trim() && (del || add) && parts.slice(index + 1).find(next => next.value.trim())?.type !== 'same';
      if (part.type === 'del' || inside) del += part.value;
      if (part.type === 'add' || inside) add += part.value;
      if (part.type === 'same' && !inside) { flush(); grouped.push(part); }
    });
    flush();
    return grouped;
  }
  function simplifiedPlainInline(text) {
    try { const shared = window.AlloModules?.TextPipelineHelpers?.readingText; if (shared) return shared.plain(String(text || '')); } catch (_) {}
    return String(text || '').replace(/\[([^\]]+)\]\([^\)]+\)/g, '$1').replace(/\*\*|__|~~|`/g, '').replace(/\*([^*]+)\*/g, '$1');
  }
  // Named as in formatInteractiveText (phase_n): "Source 1, opens in a new tab",
  // not "superscript one". The superscript digits and brackets are char codes.
  function simplifiedLinkLabel(label, href) {
    if (/^#allo-doc-[a-z0-9-]+$/.test(href || '')) return String(label || '') + ', inspect supplied document passage';
    var value = String(label || '').trim(), digits = [0x2070, 0xB9, 0xB2, 0xB3, 0x2074, 0x2075, 0x2076, 0x2077, 0x2078, 0x2079].map(code => String.fromCharCode(code));
    var inner = value.length > 2 && value.charCodeAt(0) === 0x207D && value.charCodeAt(value.length - 1) === 0x207E ? value.slice(1, -1).split('').map(ch => digits.indexOf(ch)) : null;
    var name = inner && inner.every(d => d >= 0) ? simplifiedText('common.source_number', 'Source {number}', { number: inner.join('') }) : value;
    return name + ', ' + simplifiedText('common.opens_new_tab', 'opens in a new tab');
  }
  function simplifiedInline(text, leaf, sourceOffset) {
    const shared = window.AlloModules?.TextPipelineHelpers?.readingText;
    if (shared && !Number.isInteger(sourceOffset) && !/!\[|\$/.test(String(text || ''))) {
      try {
        const render = (node, key, linkLabel = false) => {
          if (node.hidden) return null;
          if (node.text !== undefined) return <React.Fragment key={key}>{linkLabel ? node.text : leaf(node.text)}</React.Fragment>;
          const children = (node.children || []).map((child, index) => render(child, index, linkLabel || node.tag === 'a'));
          if (node.tag === 'body') return children;
          if (node.tag === 'a') return /^(https?:\/\/|mailto:|#|\/)/i.test(node.href || '')
            ? <a key={key} href={node.href} aria-label={simplifiedLinkLabel((function labelOf(value) { return value.hidden ? '' : value.text !== undefined ? value.text : (value.children || []).map(labelOf).join(''); })(node), node.href)} aria-haspopup={/^#allo-doc-[a-z0-9-]+$/.test(node.href || '') ? 'dialog' : undefined} target={/^#allo-doc-[a-z0-9-]+$/.test(node.href || '') ? undefined : '_blank'} rel="noopener noreferrer" onClick={e => e.stopPropagation()} className="underline decoration-2 underline-offset-2 rounded focus-visible:ring-2 focus-visible:ring-indigo-600">{children}</a>
            : <React.Fragment key={key}>{children}</React.Fragment>;
          return React.createElement(node.tag, { key }, ...children);
        };
        return render(shared.tree(text));
      } catch (_) { /* Unsupported formatting stays on the existing reader path. */ }
    }
    // Optional source offsets keep glosses anchored to the stored Markdown.
    var cursor = sourceOffset || 0, withOffsets = Number.isInteger(sourceOffset);
    return String(text || '').split(/(\\[\x21-\x2f\x3a-\x40\x5b-\x60\x7b-\x7e]|\*\*[^*]+\*\*|__[^_]+__|\*[^*]+\*|`[^`]+`|\[[^\]]+\]\([^\)]+\))/g).map(function (part, index) {
      var start = cursor; cursor += part.length;
      if (/^\\[\x21-\x2f\x3a-\x40\x5b-\x60\x7b-\x7e]$/.test(part)) return <React.Fragment key={index}>{leaf(part.slice(1), withOffsets ? start + 1 : undefined, false)}</React.Fragment>;
      if (/^(\*\*|__)/.test(part)) return <strong key={index}>{simplifiedInline(part.slice(2, -2), leaf, withOffsets ? start + 2 : undefined)}</strong>;
      if (/^\*[^*]/.test(part)) return <em key={index}>{simplifiedInline(part.slice(1, -1), leaf, withOffsets ? start + 1 : undefined)}</em>;
      if (/^`/.test(part)) return <code key={index}>{withOffsets ? leaf(part.slice(1, -1), start + 1, false) : part.slice(1, -1)}</code>;
      var link = part.match(/^\[([^\]]+)\]\(([^\)]+)\)$/);
      if (link) {
        var label = withOffsets ? leaf(link[1], start + 1, false) : link[1];
        return /^(https?:\/\/|mailto:|#|\/)/i.test(link[2]) ? <a key={index} href={link[2]} aria-label={simplifiedLinkLabel(link[1], link[2])} aria-haspopup={/^#allo-doc-[a-z0-9-]+$/.test(link[2]) ? "dialog" : undefined} target={/^#allo-doc-[a-z0-9-]+$/.test(link[2]) ? undefined : "_blank"} rel="noopener noreferrer" className="underline decoration-2 underline-offset-2 rounded focus-visible:ring-2 focus-visible:ring-indigo-600" onClick={e => e.stopPropagation()}>{label}</a> : <React.Fragment key={index}>{label}</React.Fragment>;
      }
      return <React.Fragment key={index}>{leaf(part, withOffsets ? start : undefined)}</React.Fragment>;
    });
  }
  function simplifiedExactBlocks(raw, formatted) {
    var chunks = String(raw || '').split(/(\r\n|\r|\n)/), cursor = 0, skipBlank = false;
    var blocks = [];
    for (var i = 0; i < chunks.length; i += 2) {
      var line = chunks[i], separator = chunks[i + 1] || '';
      var block = { type: 'line', raw: line, text: line, start: cursor, end: cursor + line.length, textStart: cursor, separator, lineIndex: i };
      cursor += line.length + separator.length;
      // A heading marker with no text ("#") showed as a lone "#"; it is hidden
      // with its line break, and with the blank line after it when one comes
      // before it, so no extra gap is left. Offsets are unchanged.
      if (formatted && /^[ \t]{0,3}#{1,6}[ \t]*$/.test(line)) {
        Object.assign(block, { type: 'hidden', text: '', textStart: block.end });
        blocks.push(block);
        var previous = blocks[blocks.length - 2];
        if (previous && !previous.raw && i + 2 < chunks.length && chunks[i + 2] === '') skipBlank = true;
        continue;
      }
      if (skipBlank) { skipBlank = false; if (!line) { Object.assign(block, { type: 'hidden' }); blocks.push(block); continue; } }
      var heading = formatted && line.match(/^([ \t]{0,3})(#{1,6})[ \t]+(.+)$/);
      var htmlHeading = formatted && !heading && line.match(/^([ \t]*<h([1-6])[^>]*>)(.*?)<\/h\2>[ \t]*$/i);
      var rule = formatted && /^[ \t]{0,3}([-*_])(?:[ \t]*\1){2,}[ \t]*$/.test(line);
      var item = formatted && !rule && line.match(/^([ \t]*)([-+*]|\d+[.)])[ \t]+(.+)$/);
      var quote = formatted && line.match(/^([ \t]*>[ \t]?)(.*)$/);
      if (heading) Object.assign(block, { type: 'heading', level: heading[2].length, text: heading[3], textStart: block.end - heading[3].length });
      else if (htmlHeading) Object.assign(block, { type: 'heading', level: Number(htmlHeading[2]), text: htmlHeading[3], textStart: block.start + htmlHeading[1].length });
      else if (rule) Object.assign(block, { type: 'rule', text: '', textStart: block.end });
      else if (item) Object.assign(block, { type: 'li', indent: item[1].replace(/\t/g, '    ').length, ordered: /^\d/.test(item[2]), value: parseInt(item[2], 10) || 1, text: item[3], textStart: block.end - item[3].length });
      else if (quote) Object.assign(block, { type: 'quote', text: quote[2], textStart: block.start + quote[1].length });
      blocks.push(block);
    }
    return blocks;
  }
  // As in renderFormattedText, a passage's top heading is h2 (the page owns h1)
  // and deeper headings keep their order. Font size still follows the source level.
  function simplifiedHeadingLevels(text) {
    return String(text || '').split('\n').map(line => line.match(/^\s{0,3}(#{1,6})\s+\S/) || line.match(/^\s*<h([1-6])[^>]*>.*?<\/h[1-6]>\s*$/i)).filter(Boolean).map(match => /^#/.test(match[1]) ? match[1].length : Number(match[1]));
  }
  function simplifiedHeadingTag(level, levels) {
    return 'h' + Math.max(2, Math.min(6, level + 2 - (levels.length ? Math.min.apply(null, levels) : level)));
  }
  // Immersive words come from the whole text, including table cells, references
  // and the translation divider, which are not sentences. Matching by running
  // character count let one table push every later highlight onto the wrong
  // sentence, so each word is matched to the sentence text it spells (-1: none).
  function alignImmersiveWords(words, sentences, clean) {
    var norm = value => String(value || '').toLowerCase().replace(/[^\p{L}\p{N}]+/gu, '');
    var targets = (sentences || []).map(sentence => norm(clean ? clean(sentence) : sentence));
    var list = Array.isArray(words) ? words : [];
    var assigned = list.map(() => -1), ends = [], idx = 0, pos = 0;
    // Whole lines that are never read: table rows, the divider, chart code.
    var skip = [], lineStart = 0;
    list.concat([{ pos: 'newline' }]).forEach(function (word, i) {
      if (word && word.pos !== 'newline') return;
      var line = list.slice(lineStart, i).map(w => (w && w.text) || '').join('');
      if (/^\s*(?:\||\[\[CHART:|-{3}\s*ENGLISH TRANSLATION\s*-{3}\s*$)/i.test(line)) for (var s = lineStart; s < i; s++) skip[s] = true;
      lineStart = i + 1;
    });
    var skipEmpty = () => { while (idx < targets.length && !targets[idx]) idx++; };
    skipEmpty();
    list.forEach(function (word, i) {
      var token = word && word.pos !== 'newline' && !skip[i] ? norm(word.text) : '';
      if (!token || idx >= targets.length) return;
      var at = targets[idx].indexOf(token, pos);
      if (at === -1 || at - pos > (pos ? 24 : 0)) {
        at = -1;
        for (var k = idx + 1; k < Math.min(targets.length, idx + 4) && at === -1; k++) if (targets[k].indexOf(token) === 0) { idx = k; at = 0; }
        if (at === -1) return;
      }
      pos = at + token.length; assigned[i] = idx;
      if (pos >= targets[idx].length) { ends[i] = true; idx++; pos = 0; skipEmpty(); }
    });
    // Spaces and marks inside a sentence go with it; after its last word only the
    // marks touching that word ("hot.") do, and the rest go with the next word.
    var previous = -1, afterSpace = false;
    list.forEach(function (word, i) {
      if (word && word.pos !== 'newline' && norm(word.text)) { previous = i; afterSpace = false; return; }
      if (!word || word.pos === 'newline') { afterSpace = true; return; }
      if (/^\s+$/.test(word.text || '')) afterSpace = true;
      if (previous >= 0 && (!ends[previous] || !afterSpace)) { assigned[i] = assigned[previous]; return; }
      for (var n = i + 1; n < list.length; n++) if (list[n] && list[n].pos !== 'newline' && norm(list[n].text)) { assigned[i] = assigned[n]; break; }
    });
    return assigned;
  }
  function simplifiedComparisonPlainText(raw) {
    return simplifiedExactBlocks(raw, true).map(block => block.type === 'hidden' ? '' : simplifiedPlainInline(block.text) + block.separator).join('');
  }
  function simplifiedParagraphBlocks(text) {
    var lines = String(text || '').split('\n');
    var output = [], paragraph = [];
    var flush = function () { if (paragraph.length) output.push({ type: 'p', raw: paragraph.join('\n') }); paragraph = []; };
    for (var i = 0; i < lines.length; i += 1) {
      var line = lines[i];
      if (/^\s{0,3}#{1,6}\s*$/.test(line)) { flush(); continue; }
      if (/^\s{0,3}([-*])(?:\s*\1){2,}\s*$/.test(line)) { flush(); output.push({ type: 'rule', raw: line, text: '' }); continue; }
      var heading = line.match(/^\s{0,3}(#{1,6})\s+(.+)$/) || line.match(/^\s*<h([1-6])[^>]*>(.*?)<\/h[1-6]>\s*$/i);
      var item = line.match(/^(\s*)([-+*]|\d+[.)])\s+(.+)$/);
      if (heading) { flush(); output.push({ type: 'heading', level: /^#/.test(heading[1]) ? heading[1].length : Number(heading[1]), raw: line, text: heading[2] }); }
      else if (item) {
        flush();
        output.push({ type: 'li', indent: item[1].replace(/\t/g, '    ').length, ordered: /^\d/.test(item[2]), value: parseInt(item[2], 10) || 1, raw: line, text: item[3] });
      } else if (/^\s*>\s?/.test(line)) { flush(); output.push({ type: 'quote', raw: line, text: line.replace(/^\s*>\s?/, '') }); }
      else if (output.length && output[output.length - 1].type === 'li' && /^\s+\S/.test(line)) {
        var previous = output[output.length - 1]; previous.raw += '\n' + line; previous.text += '\n' + line.trimStart();
      } else { paragraph.push(line); }
    }
    flush();
    return output;
  }
  function simplifiedNestLists(blocks, renderBlock) {
    var roots = [], stack = [];
    blocks.forEach(function (block, index) {
      if (block.type !== 'li') { stack = []; roots.push({ blockRoot: block, index: index }); return; }
      while (stack.length && (stack[stack.length - 1].indent > block.indent || (stack[stack.length - 1].indent === block.indent && stack[stack.length - 1].ordered !== block.ordered))) stack.pop();
      var current = stack[stack.length - 1];
      if (!current || current.indent < block.indent) {
        var list = { indent: block.indent, ordered: block.ordered, start: block.value, items: [], key: index };
        if (current && current.items.length) current.items[current.items.length - 1].children.push(list); else roots.push(list);
        stack.push(list); current = list;
      }
      current.items.push({ block: block, index: index, children: [] });
    });
    var materialize = function (entry) {
      if (entry.blockRoot) return renderBlock(entry.blockRoot, entry.index);
      var Tag = entry.ordered ? 'ol' : 'ul';
      return <Tag key={'list-' + entry.key} start={entry.ordered ? entry.start : undefined} className="my-3 space-y-2" style={{ paddingInlineStart: '1.6em', listStyleType: entry.ordered ? 'decimal' : 'disc' }}>{entry.items.map(function (item) {
        return <li key={item.index} value={entry.ordered ? item.block.value : undefined}>{renderBlock(item.block, item.index)}{item.children.map(materialize)}</li>;
      })}</Tag>;
    };
    return roots.map(materialize);
  }

  function simplifiedPopupStyle(point, widthRem) {
    var fontSize = 16;
    try { fontSize = parseFloat(window.getComputedStyle(document.documentElement).fontSize) || 16; } catch (_) {}
    var viewport = window.visualViewport;
    var viewportWidth = viewport && viewport.width > 0 ? viewport.width : window.innerWidth;
    var viewportHeight = viewport && viewport.height > 0 ? viewport.height : window.innerHeight;
    var offsetLeft = viewport && Number.isFinite(viewport.offsetLeft) ? viewport.offsetLeft : 0;
    var offsetTop = viewport && Number.isFinite(viewport.offsetTop) ? viewport.offsetTop : 0;
    var width = Math.min(widthRem * fontSize, Math.max(0, viewportWidth - 16));
    var top = Math.max(offsetTop + 8, Math.min(offsetTop + Math.max(8, (viewportHeight - 16) / 2), (Number(point.y) || 0) + 10));
    return {
      width: width + 'px', maxWidth: Math.max(0, viewportWidth - 16) + 'px',
      left: Math.max(offsetLeft + 8, Math.min(offsetLeft + viewportWidth - width - 8, (Number(point.x) || 0) - 20)) + 'px',
      top: top + 'px',
      maxHeight: Math.max(0, Math.min(viewportHeight / 2 - 8, offsetTop + viewportHeight - top - 8)) + 'px', overflowY: 'auto', overflowWrap: 'anywhere'
    };
  }

  function useSimplifiedPopupViewport(ref, point, widthRem) {
    React.useLayoutEffect(function () {
      if (!point) return undefined;
      var frame = null;
      var viewport = window.visualViewport;
      function position() {
        frame = null;
        if (ref.current) Object.assign(ref.current.style, simplifiedPopupStyle(point, widthRem));
      }
      function schedule() {
        if (frame == null) frame = window.requestAnimationFrame(position);
      }
      // Update only the popup DOM when the keyboard/zoom viewport moves; do not
      // rerender the reading passage on every viewport scroll event.
      position();
      window.addEventListener('resize', schedule);
      viewport?.addEventListener('resize', schedule);
      viewport?.addEventListener('scroll', schedule);
      return function () {
        if (frame != null) window.cancelAnimationFrame(frame);
        window.removeEventListener('resize', schedule);
        viewport?.removeEventListener('resize', schedule);
        viewport?.removeEventListener('scroll', schedule);
      };
    }, [ref, !!point, point?.x, point?.y, widthRem]);
  }

  // Sections for the reading outline and section prompts, addressed by the
  // paragraph numbers the adapted reader renders (data-reading-paragraph). With
  // headings, a section runs from one heading to the next; without, each
  // paragraph is one. Charts and tables are never their own section.
  function readingOutlineSections(text) {
    var headingOf = paragraph => { var match = paragraph.split('\n')[0].match(/^\s{0,3}#{1,6}\s+(.+?)\s*#*\s*$/); return match ? simplifiedPlainInline(match[1]).trim() : ''; };
    var entries = String(text || '').split(/\n{2,}/).map((paragraph, index) => ({ index, text: paragraph, heading: headingOf(paragraph) }))
      .filter(entry => entry.text.trim() && !/^\s*(?:\[\[CHART:|\|)/.test(entry.text));
    var hasHeadings = entries.some(entry => entry.heading);
    var sections = [];
    entries.forEach(entry => {
      var last = sections[sections.length - 1];
      if (hasHeadings && last && !entry.heading) { last.last = entry.index; last.text += '\n\n' + entry.text; return; }
      sections.push({ first: entry.index, last: entry.index, heading: entry.heading, text: entry.text });
    });
    return sections.map((section, index) => {
      var words = simplifiedPlainInline(section.text.replace(/^\s{0,3}#{1,6}\s+/gm, '')).split(/\s+/).filter(Boolean);
      return { ...section, index, label: section.heading || words.slice(0, 8).join(' ') + (words.length > 8 ? '…' : '') };
    });
  }
  // Where a learner is in a reading (last paragraph, bookmark, section answers).
  // Keyed by learner + reading + exact text version, so a revised passage never
  // reopens at an old place. Saved on the device only when the host names the
  // learner; otherwise kept for this page visit only.
  // Each reading's text when a teacher first opened it this visit ("Text changed").
  var readingFirstSeen = {};
  var readingPlaceStore = createReadingPlaceStore({ getStorage: () => window.localStorage, getLocks: () => window.navigator.locks });
  if (window.__alloReadingPlaceGuardCleanup) window.__alloReadingPlaceGuardCleanup();
  window.__alloReadingPlaceGuardCleanup = readingPlaceStore.watchPage(window);

  // Navigation ranges address the canonical string, never a formatted projection.
  function getReadingNavigationSections(text) {
    const source = typeof text === 'string' ? text : '';
    const sections = [];
    const breaks = /(?:\r\n|\n|\r(?!\n)|\u2028)[\t ]*(?:\r\n|\n|\r(?!\n)|\u2028)(?:[\t ]*(?:\r\n|\n|\r(?!\n)|\u2028))*|\u2029+/g;
    let start = 0, match;
    const append = end => {
      const sectionText = source.slice(start, end);
      if (sectionText.trim()) sections.push({ index: sections.length, start, end, text: sectionText });
    };
    while ((match = breaks.exec(source))) { append(match.index); start = match.index + match[0].length; }
    append(source.length);
    return sections;
  }

  function findRelatedOriginalPassage(sourceText, adaptedSectionText, options = {}) {
    const unavailable = reason => ({ status: 'unavailable', reason });
    if (options.sameLanguage !== true) return unavailable('different-or-unknown-language');
    if (typeof sourceText !== 'string' || typeof adaptedSectionText !== 'string' || !sourceText.trim() || !adaptedSectionText.trim()) return unavailable('empty-passage');
    // Fail closed rather than silently searching only the beginning of a source.
    if (sourceText.length > 120000 || adaptedSectionText.length > 12000) return unavailable('passage-too-long');
    const sections = getReadingNavigationSections(sourceText);
    if (sections.length > 300) return unavailable('too-many-sections');
    const stopWords = new Set(('a an the and or but if so than then that this these those to of in on at by for from with without as into upon over under ' +
      'is are was were be been being am do does did done have has had having will would shall should can could may might must not no nor ' +
      'i me my mine we us our ours you your yours he him his she her hers it its they them their theirs who whom whose which what when where why how ' +
      'all any both each every few more most other some such only own same too very just also there here now again still about after before during ' +
      'first second third one two three said says say text passage paragraph scene act chapter mr mrs ms').split(/\s+/));
    let segmenter;
    try { if (typeof Intl !== 'undefined' && Intl.Segmenter) segmenter = new Intl.Segmenter(undefined, { granularity: 'word' }); } catch (_) {}
    const tokenize = text => {
      const words = segmenter ? Array.from(segmenter.segment(text)).filter(part => part.isWordLike).map(part => part.segment)
        : (text.match(/[\p{L}\p{M}\p{N}]+(?:[’'-][\p{L}\p{M}\p{N}]+)*/gu) || []);
      return words.map(word => word.normalize('NFKC').toLowerCase().replace(/’/g, "'").replace(/'s$/, ''));
    };
    const informative = word => word.length >= 2 && /\p{L}/u.test(word) && !stopWords.has(word);
    const queryWords = tokenize(adaptedSectionText);
    if (queryWords.length > 1800) return unavailable('passage-too-long');
    const queryTerms = new Set(queryWords.filter(informative));
    if (queryTerms.size < 4) return unavailable('insufficient-content-evidence');
    let totalWords = 0;
    const prepared = sections.map(section => {
      const words = tokenize(section.text); totalWords += words.length;
      return { ...section, words, terms: new Set(words.filter(informative)) };
    });
    if (totalWords > 24000) return unavailable('passage-too-long');
    const frequency = new Map();
    prepared.forEach(section => section.terms.forEach(term => frequency.set(term, (frequency.get(term) || 0) + 1)));
    const weight = term => frequency.has(term) ? 1 + Math.log((prepared.length + 1) / (frequency.get(term) + 1)) : 1;
    const queryWeight = Array.from(queryTerms).reduce((sum, term) => sum + weight(term), 0);
    const queryPhrases = new Set();
    for (let index = 0; index + 2 < queryWords.length; index++) {
      const phrase = queryWords.slice(index, index + 3);
      if (phrase.filter(informative).length >= 2) queryPhrases.add(phrase.join(' '));
    }
    const candidates = [];
    for (let start = 0; start < prepared.length; start++) {
      for (let count = 1; count <= 3 && start + count <= prepared.length; count++) {
        const group = prepared.slice(start, start + count);
        const words = group.flatMap(section => section.words);
        if (words.length > 1200) break;
        const terms = new Set(group.flatMap(section => Array.from(section.terms)));
        const shared = Array.from(queryTerms).filter(term => terms.has(term));
        if (shared.length < 4) continue;
        // Each additional paragraph must contribute distinct evidence. Repetition
        // or a paragraph index never justifies enlarging the highlighted range.
        if (count > 1 && group.some((section, index) => {
          const elsewhere = new Set(group.filter((_, other) => other !== index).flatMap(other => Array.from(other.terms)));
          return shared.filter(term => section.terms.has(term) && !elsewhere.has(term)).length < 2;
        })) continue;
        const sharedWeight = shared.reduce((sum, term) => sum + weight(term), 0);
        const queryCoverage = sharedWeight / queryWeight;
        const sourceWeight = Array.from(terms).reduce((sum, term) => sum + weight(term), 0);
        const sourceCoverage = sharedWeight / Math.max(1, sourceWeight);
        const distinctive = shared.filter(term => (frequency.get(term) || 0) <= Math.max(1, Math.ceil(prepared.length * 0.65)));
        if (queryCoverage < 0.55 || sourceCoverage < 0.20) continue;
        const phrases = new Set();
        for (let index = 0; index + 2 < words.length; index++) {
          const phrase = words.slice(index, index + 3).join(' ');
          if (queryPhrases.has(phrase)) phrases.add(phrase);
        }
        if (distinctive.length < 2 && !(phrases.size >= 2 && queryCoverage >= 0.90)) continue;
        if (!phrases.size && (shared.length < 5 || queryCoverage < 0.65)) continue;
        const score = queryCoverage * 0.72 + Math.min(1, sourceCoverage / 0.55) * 0.22 + Math.min(0.10, phrases.size * 0.025) - (count - 1) * 0.045;
        candidates.push({ start: group[0].start, end: group[group.length - 1].end,
          sectionIndexes: group.map(section => section.index), score,
          evidence: { sharedTerms: shared.slice(0, 16), sharedPhrases: Array.from(phrases).slice(0, 6), queryCoverage: Math.round(queryCoverage * 100) / 100 } });
      }
    }
    if (!candidates.length) return unavailable('no-reliable-content-match');
    candidates.sort((left, right) => right.score - left.score || (left.end - left.start) - (right.end - right.start));
    const best = candidates[0];
    const nested = (left, right) => left.start <= right.start && left.end >= right.end || right.start <= left.start && right.end >= left.end;
    const alternatives = candidates.slice(1).filter(candidate => !nested(best, candidate) && (candidate.score >= best.score * 0.90 || best.score - candidate.score < 0.08));
    const project = candidate => ({ start: candidate.start, end: candidate.end, sectionIndexes: candidate.sectionIndexes, evidence: candidate.evidence });
    if (alternatives.length) return { status: 'ambiguous', reason: 'multiple-related-passages', candidates: [best, ...alternatives].slice(0, 3).map(project) };
    return { status: 'matched', ...project(best), text: sourceText.slice(best.start, best.end),
      confidence: best.evidence.queryCoverage >= 0.80 && best.evidence.sharedTerms.length >= 6 ? 'high' : 'moderate' };
  }

  function findReadingGlossOccurrences(text, query) {
    const source = String(text || ''), word = String(query || '').trim(), matches = [];
    const finish = truncated => { Object.defineProperty(matches, 'truncated', { value: truncated, enumerable: false }); return matches; };
    if (!word || word.length > 160) return finish(false);
    const letters = /[\p{L}\p{M}\p{N}_]/u, characters = Array.from(word);
    let segments;
    try { segments = typeof Intl.Segmenter === 'function' ? new Intl.Segmenter(undefined, { granularity: 'word' }).segment(source) : null; } catch (_) {}
    const boundary = (offset, first) => {
      if (!letters.test(first ? characters[0] : characters[characters.length - 1])) return true;
      const segment = segments?.containing?.(first ? offset : offset - 1);
      if (segment?.isWordLike) return first ? segment.index === offset : segment.index + segment.segment.length === offset;
      const adjacent = first ? Array.from(source.slice(Math.max(0, offset - 2), offset)).pop() : Array.from(source.slice(offset, offset + 2))[0];
      if (adjacent && letters.test(adjacent)) return false;
      if (adjacent && /['’]/u.test(adjacent)) {
        const beyond = first ? Array.from(source.slice(Math.max(0, offset - 3), offset - 1)).pop() : Array.from(source.slice(offset + 1, offset + 3))[0];
        if (beyond && letters.test(beyond)) return false;
      }
      return true;
    };
    let cursor = 0;
    while (cursor < source.length) {
      const start = source.indexOf(word, cursor);
      if (start < 0) break;
      const end = start + word.length;
      cursor = start + 1;
      if (!boundary(start, true) || !boundary(end, false)) continue;
      if (matches.length === 200) return finish(true);
      matches.push({ start, end, quote: source.slice(start, end), context: readingGlossContext(source, start, end).text });
    }
    return finish(false);
  }

  // The sentence around a word support, for the editor. It was a fixed window
  // of 35 characters before and 45 after, which cut words in half ("ike a
  // giant wheel ... into differe"). A long sentence is trimmed at word
  // boundaries and marked with an ellipsis. Display only: offsets are unused.
  function readingGlossContext(text, start, end, maxChars) {
    const source = String(text || ''), limit = maxChars || 240;
    const head = source.slice(0, start), tail = source.slice(end);
    const boundaryBefore = /[.!?]["'”’)\]]*\s+|\n/g;
    let from = 0;
    for (let found = boundaryBefore.exec(head); found; found = boundaryBefore.exec(head)) from = found.index + found[0].length;
    const next = tail.match(/[.!?]["'”’)\]]*(?=\s|$)|\n/);
    let to = next ? end + next.index + (next[0] === '\n' ? 0 : next[0].length) : source.length;
    let before = source.slice(from, start), after = source.slice(end, to), clippedBefore = false, clippedAfter = false;
    const room = Math.max(40, Math.floor((limit - (end - start)) / 2));
    if (before.length + (end - start) + after.length > limit) {
      if (before.length > room) { before = before.slice(before.length - room); before = before.slice(Math.max(0, before.search(/\s/) + 1)); clippedBefore = true; }
      if (after.length > room) { after = after.slice(0, room); after = after.slice(0, Math.max(0, after.search(/\s\S*$/))); clippedAfter = true; }
    }
    const tidy = value => value.replace(/^[ \t]*(?:#{1,6}|>|[-+*]|\d+[.)])[ \t]+/gm, '').replace(/\[([^\]]+)\]\([^)]+\)/g, '$1').replace(/\*\*|__|~~|`/g, '').replace(/\s+/g, ' ');
    const parts = { before: (clippedBefore ? '…' : '') + tidy(before).replace(/^\s+/, ''), quote: source.slice(start, end), after: tidy(after).replace(/\s+$/, '') + (clippedAfter ? '…' : '') };
    parts.text = parts.before + parts.quote + parts.after;
    return parts;
  }
  // Interface text. Parts outside SimplifiedView get no t prop, so they use the
  // host's window.__alloT; the English fallback shows until a key is translated.
  function simplifiedText(key, fallback, params, translate) {
    var value;
    try { value = (translate || (typeof window !== 'undefined' && window.__alloT) || (() => undefined))(key, params); } catch (_) {}
    var text = typeof value === 'string' && value && value !== key ? value : fallback;
    return params ? String(text).replace(/\{(\w+)\}/g, (match, name) => params[name] != null ? String(params[name]) : match) : text;
  }
  // A search box appears once the list is this long.
  var GLOSS_FILTER_MIN = 6;
  // embedded: the editor sits inside a panel that already has its own disclosure,
  // so it shows its list directly instead of adding a second toggle.
  function readingSupportDraftKey(item, adapted) {
    return JSON.stringify([item?.id, item?._artifactInstanceId || '', item?.sourceFamilyId || '', item?.unitId || '', !!adapted]);
  }
  function readingSupportImageSignature(image) {
    if (!image) return null;
    const clean = (value, limit) => String(value || '').replace(/\s+/g, ' ').trim().slice(0, limit);
    const credit = image.attribution || {};
    return { src: image.src, alt: clean(image.alt, 250), altSource: image.altSource === 'vision' ? 'vision' : 'author',
      source: ['mulberry', 'wikimedia'].includes(image.source) ? image.source : 'upload',
      attribution: ['set', 'author', 'license', 'via', 'url', 'title', 'licenseUrl'].map(key => clean(credit[key], key === 'author' || key === 'title' ? 160 : key.toLowerCase().includes('url') ? 2000 : 120)) };
  }
  function ReadingGlossEditor({ item, supports, request, onUpdate, disabled, adapted, snapshot: adaptedSnapshot, embedded, draftSession, supportsStale }) {
    // An adapted text's word help anchors to the adapted passage, never the original.
    const snapshot = adapted ? adaptedSnapshot : getInstructionalContextApi()?.getSourceSnapshot?.(item);
    const passageName = adapted ? 'adapted text' : 'original';
    const sourceText = snapshot?.text || '';
    const sourceKey = String(item?.id || '') + ':' + (snapshot?.fingerprint || '');
    const ownerKey = readingSupportDraftKey(item, adapted);
    const cached = draftSession?.records.get(ownerKey);
    const [open, setOpen] = React.useState(!!cached?.draft);
    const [draft, setDraft] = React.useState(cached?.draft || null);
    const [baseline, setBaseline] = React.useState(cached?.baseline || '');
    const [draftSource, setDraftSource] = React.useState(cached?.sourceText || sourceText);
    const [pendingAction, setPendingAction] = React.useState(null);
    const [notice, setNotice] = React.useState('');
    const [error, setError] = React.useState('');
    const [busy, setBusy] = React.useState(false);
    const [filterQuery, setFilterQuery] = React.useState('');
    const [filterKind, setFilterKind] = React.useState('all');
    const sourceKeyRef = React.useRef(sourceKey); sourceKeyRef.current = sourceKey;
    const termRef = React.useRef(null), definitionRef = React.useRef(null), addRef = React.useRef(null), toggleRef = React.useRef(null), keepRef = React.useRef(null);
    const editRefs = React.useRef({});
    const panelId = 'reading-gloss-editor-' + String(item?.id || 'current').replace(/[^a-z0-9_-]/gi, '-');
    const entries = supports?.annotations || [];
    const signature = value => value ? JSON.stringify({ query: value.query, start: value.start, text: value.text, priority: value.priority, pinned: value.pinned, image: readingSupportImageSignature(value.image) }) : '';
    const [pickingPicture, setPickingPicture] = React.useState(false);
    const [preparingPicture, setPreparingPicture] = React.useState(false);
    const pictureEpoch = React.useRef(0), mutationEpoch = React.useRef(0), mountedRef = React.useRef(true), ownerRef = React.useRef(ownerKey), pendingRef = React.useRef(null), focusRef = React.useRef(null), focusRequested = React.useRef(false), sectionRef = React.useRef(null);
    const pictureCallbackEpoch = pictureEpoch.current;
    pendingRef.current = pendingAction;
    // Removing, choosing or cancelling a picture removes the focused button; land on the picture button instead.
    const pictureButtonRef = React.useRef(null), refocusPicture = React.useRef(false);
    React.useEffect(() => { if (refocusPicture.current && pictureButtonRef.current) focusRequested.current = true; });
    const dirty = !!draft && signature(draft) !== baseline;
    const unresolvedRef = React.useRef(false);
    unresolvedRef.current = dirty || busy || pickingPicture || preparingPicture;
    const validGrowth = sourceText.startsWith(draftSource) && !(/[\p{L}\p{N}]$/u.test(draftSource) && /^[\p{L}\p{N}]/u.test(sourceText.slice(draftSource.length)));
    const staleDraft = !!draft && draftSource !== sourceText && !validGrowth;
    const cancelPicture = () => { pictureEpoch.current++; setPreparingPicture(false); };
    const dismissPending = () => { pendingRef.current?.cancel?.(); pendingRef.current = null; setPendingAction(null); };
    const reveal = () => { setOpen(true); const details = sectionRef.current?.closest('details'); if (details) details.open = true; };
    React.useLayoutEffect(() => {
      if (ownerRef.current !== ownerKey) {
        const saved = draftSession?.records.get(ownerKey);
        ownerRef.current = ownerKey; cancelPicture(); dismissPending();
        setDraft(saved?.draft || null); setBaseline(saved?.baseline || ''); setDraftSource(saved?.sourceText || sourceText);
        setOpen(!!saved?.draft); setPickingPicture(false); setNotice(''); setError(''); setBusy(false);
        return;
      }
      if (draftSession) {
        if (draft) draftSession.records.set(ownerKey, { draft, baseline, sourceText: draftSource, dirty });
        else draftSession.records.delete(ownerKey);
      }
    });
    React.useLayoutEffect(() => {
      if (!draftSession) return;
      return draftSession.register({ hasChanges: () => unresolvedRef.current,
        defer: action => { if (pendingRef.current) { action.cancel?.(); return; } reveal(); pendingRef.current = action; setPendingAction(action); } });
    }, [draftSession, ownerKey]);
    React.useEffect(() => { mountedRef.current = true; return () => { mountedRef.current = false; pictureEpoch.current++; mutationEpoch.current++; pendingRef.current?.cancel?.(); }; }, []);
    React.useEffect(() => {
      const protect = event => { if (unresolvedRef.current) { event.preventDefault(); event.returnValue = ''; } };
      window.addEventListener('beforeunload', protect);
      return () => window.removeEventListener('beforeunload', protect);
    }, []);
    const sameAnchor = (left, right) => !!left && !!right && left.start === right.start && left.end === right.end && left.quote === right.quote;
    const contextFor = entry => readingGlossContext(sourceText, entry.start, entry.end).text;
    const anchorFor = entry => ({ start: entry.start, end: entry.end, quote: entry.quote });
    const replaceDraft = value => { unresolvedRef.current = false; mutationEpoch.current++; cancelPicture(); dismissPending(); if (!value) draftSession?.records.delete(ownerKey); setDraft(value); setDraftSource(sourceText); setBaseline(signature(value)); setNotice(''); setError(''); setPickingPicture(false); };
    const clearDraft = () => replaceDraft(null);
    const applyEdit = entry => {
      const value = { id: entry.id, anchor: anchorFor(entry), query: entry.quote, start: String(entry.start),
        text: entry.definition || entry.explanation || entry.text || '', priority: entry.priority || 'helpful', pinned: entry.pinned === true, image: entry.image || null };
      value.originalTextLength = value.text.length;
      setOpen(true); replaceDraft(value);
    };
    const mutate = async (action, success) => {
      if (disabled || busy || typeof onUpdate !== 'function') return null;
      const key = sourceKeyRef.current;
      const epoch = ++mutationEpoch.current;
      const current = () => mountedRef.current && sourceKeyRef.current === key && mutationEpoch.current === epoch;
      focusRequested.current = true;
      setBusy(true); setNotice(''); setError('');
      try {
        const result = await onUpdate(item, action);
        if (!current()) return null;
        if (!result) throw new Error(simplifiedText('simplified.gloss_the_reading_changed_reopen_its_word', 'The reading changed. Reopen its word supports and try again.'));
        setNotice(success);
        return result;
      } catch (failure) {
        if (current()) setError(failure?.message || 'This word support could not be saved.');
        return null;
      } finally { if (current()) setBusy(false); }
    };
    const performAction = async action => {
      pendingRef.current = null;
      setPendingAction(null);
      if (action.type === 'transition') { clearDraft(); action.run(); return; }
      if (action.type === 'edit') { applyEdit(action.entry); return; }
      if (action.type === 'add') { setOpen(true); replaceDraft({ id: null, query: '', start: '', text: '', priority: 'essential', pinned: false }); return; }
      if (action.type === 'close' || action.type === 'finish') {
        const id = draft?.id; clearDraft();
        if (action.type === 'close') { setOpen(false); toggleRef.current?.focus(); }
        else (editRefs.current[id] || addRef.current)?.focus();
        return;
      }
      if (action.type === 'remove') {
        const current = entries.find(entry => sameAnchor(entry, action.entry));
        if (!current) { setNotice(''); setError(simplifiedText('simplified.gloss_this_word_support_is_no_longer', 'This word support is no longer available. Review the current supports before removing it.')); return; }
        const saved = await mutate({ type: 'remove', id: current.id }, 'Word support removed. It will stay removed when suggestions are refreshed.');
        if (saved) {
          if (sameAnchor(draft?.anchor, action.entry)) { setDraft(null); setBaseline(''); }
          addRef.current?.focus();
        }
      }
    };
    const requestAction = action => {
      if (disabled || busy) return;
      if (action.type === 'edit' && sameAnchor(draft?.anchor, action.entry)) { setOpen(true); definitionRef.current?.focus(); return; }
      const replacesDraft = action.type !== 'remove' || sameAnchor(draft?.anchor, action.entry);
      if ((dirty || pickingPicture || preparingPicture) && replacesDraft) { reveal(); pendingRef.current = action; setPendingAction(action); return; }
      performAction(action);
    };
    React.useLayoutEffect(() => { mutationEpoch.current++; cancelPicture(); dismissPending(); setBusy(false); setPickingPicture(false); setFilterQuery(''); setFilterKind('all'); }, [sourceKey]);
    const isOpen = !!embedded || open;
    const canFilter = entries.length >= GLOSS_FILTER_MIN;
    const needle = canFilter ? filterQuery.trim().toLocaleLowerCase() : '';
    const kind = canFilter ? filterKind : 'all';
    const listed = entries.filter(entry => (kind === 'all' || (kind === 'essential' ? entry.priority === 'essential' : kind === 'educator' ? entry.origin === 'educator' : entry.origin !== 'educator'))
      && (!needle || (entry.quote + ' ' + (entry.definition || entry.explanation || entry.text || '')).toLocaleLowerCase().includes(needle)));
    const filtering = listed.length !== entries.length;
    React.useEffect(() => {
      if (!request || request.ownerId !== item?.id) return;
      const entry = entries.find(value => value.id === request.id)
        || (draft?.id === request.id && entries.find(value => sameAnchor(value, draft.anchor)));
      if (entry) requestAction({ type: 'edit', entry });
    }, [request]);
    React.useEffect(() => {
      if (pendingAction) { focusRequested.current = false; keepRef.current?.focus(); }
      else if (draft) focusRequested.current = true;
    }, [!!draft, draft?.anchor?.start, pendingAction]);
    React.useEffect(() => {
      if (!focusRequested.current || pendingAction || busy || disabled || !draft) return;
      const previous = focusRef.current;
      const target = refocusPicture.current ? pictureButtonRef.current : previous?.isConnected && !previous.matches(':disabled') ? previous
        : pickingPicture ? sectionRef.current?.querySelector('[data-classroom-image-picker] input:not(:disabled)') : draft.anchor ? definitionRef.current : termRef.current;
      if (target) { target.focus(); focusRequested.current = false; refocusPicture.current = false; }
    });
    const matches = React.useMemo(() => {
      const anchor = draft?.anchor;
      if (anchor) return sourceText.slice(anchor.start, anchor.end) === anchor.quote
        ? [{ ...anchor, context: contextFor(anchor) }] : [];
      return findReadingGlossOccurrences(sourceText, draft?.query || '');
    }, [sourceText, draft?.query, draft?.anchor]);
    const selected = draft && (draft.start !== '' ? matches.find(value => String(value.start) === draft.start) : matches.length === 1 ? matches[0] : null);
    const updateDraft = fields => { setDraft(previous => ({ ...previous, ...fields })); setNotice(''); setError(''); };
    const save = async () => {
      if (disabled || busy || pickingPicture || preparingPicture) return false;
      setNotice(''); setError('');
      if (staleDraft || supportsStale) { setError('The passage changed. Your draft is retained. Review the current word supports and choose its occurrence again before saving.'); return false; }
      if (!selected || !draft?.text.trim()) { setError(simplifiedText('simplified.gloss_choose_the_exact_word_or_phrase', 'Choose the exact word or phrase and enter its explanation.')); return false; }
      if (draft.text.trim().length > 2400) { setError(simplifiedText('simplified.gloss_shorten_this_explanation_to_2_400', 'Shorten this explanation to 2,400 characters or fewer before saving.')); return false; }
      // IDs can change during a refresh. The exact source occurrence owns the
      // edit; an old ID reused for another range must never redirect it.
      const current = entries.find(entry => sameAnchor(entry, selected));
      let id = current?.id || draft.id || 'gloss-' + selected.start + '-' + selected.end;
      if (entries.some(entry => entry.id === id && !sameAnchor(entry, selected))) id = 'gloss-' + selected.start + '-' + selected.end;
      const baseId = id;
      for (let suffix = 1; entries.some(entry => entry.id === id && !sameAnchor(entry, selected)); suffix++) id = baseId + '-' + suffix;
      const annotation = { id, kind: current?.kind || 'gloss', ...anchorFor(selected), text: draft.text.trim(), priority: draft.priority, pinned: draft.pinned, image: draft.image || null };
      const saved = await mutate({ type: 'upsert', annotation }, 'Word support saved. Your wording will be kept when suggestions are refreshed.');
      // A matching anchor alone does not confirm the submitted values. Keep
      // unaccepted edits dirty against the actual save result so retry is safe.
      const savedSupports = saved && (Array.isArray(saved.annotations) ? saved : adapted ? saved.adaptedReadingSupports : saved.readingSupports);
      const accepted = savedSupports?.annotations?.find(entry => entry.id === id && sameAnchor(entry, selected));
      if (!accepted) { if (saved) { setNotice(''); setError('The save did not confirm this word support. Your draft is retained.'); } return false; }
      const next = { ...draft, id, anchor: anchorFor(selected), start: String(selected.start), text: annotation.text };
      const confirmed = { ...next, text: accepted.definition || accepted.explanation || accepted.text || '',
        priority: accepted.priority === 'essential' ? 'essential' : 'helpful', pinned: accepted.pinned === true, image: accepted.image || null };
      setBaseline(signature(confirmed)); setDraftSource(sourceText); setDraft(next);
      if (signature(next) !== signature(confirmed)) {
        const pictureOmitted = next.image && !confirmed.image && next.text === confirmed.text && next.priority === confirmed.priority && next.pinned === confirmed.pinned;
        setNotice(''); setError(pictureOmitted
          ? simplifiedText('simplified.gloss_the_explanation_was_saved_but_its', 'The explanation was saved, but its picture did not fit: this reading already has as many pictures as it can hold. Remove another picture first.')
          : simplifiedText('simplified.gloss_save_changes_unconfirmed', 'The save did not confirm all your changes. Your draft is retained. Try saving again.'));
        return false;
      }
      return true;
    };
    const saveAndContinue = async () => { const action = pendingRef.current; if (await save()) { if (mountedRef.current && action && pendingRef.current === action) performAction(action); } };
    const pin = async (entry, pinned) => {
      const saved = await mutate({ type: 'pin', id: entry.id, pinned }, pinned ? 'This support will stay visible in lighter view.' : 'This support now follows the lighter-view selection.');
      if (saved && sameAnchor(draft?.anchor, entry)) {
        setDraft(previous => previous && ({ ...previous, pinned }));
        setBaseline(previous => previous ? JSON.stringify({ ...JSON.parse(previous), pinned }) : previous);
      }
    };
    const occurrenceLabel = entry => {
      const quote = entry.quote.length > 80 ? entry.quote.slice(0, 80) + '…' : entry.quote;
      return simplifiedText('simplified.gloss_occurrence', '{word}, text position {start}–{end}: {context}', { word: quote, start: entry.start + 1, end: entry.end, context: contextFor(entry) });
    };
    return <section ref={sectionRef} data-reading-gloss-editor onFocusCapture={event => { if (event.target.closest('[data-gloss-draft]')) focusRef.current = event.target; }} className={embedded ? 'text-sm text-slate-800' : 'my-4 rounded-xl border border-indigo-200 bg-white p-3 text-sm text-slate-800'}>
      {!embedded && <button ref={toggleRef} type="button" aria-expanded={open} aria-controls={panelId} disabled={busy} onClick={() => open ? requestAction({ type: 'close' }) : setOpen(true)} className="flex min-h-11 w-full cursor-pointer items-center justify-between gap-3 rounded-lg px-2 text-left font-bold text-indigo-900 hover:bg-indigo-50 focus-visible:ring-2 focus-visible:ring-indigo-600 disabled:cursor-wait">
        <span>{simplifiedText('simplified.gloss_review_word_supports', 'Review word supports')}{' '}{entries.length ? '(' + entries.length + ')' : ''}</span>
        <svg aria-hidden="true" focusable="false" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="shrink-0"><path d={open ? 'm6 15 6-6 6 6' : 'm9 6 6 6-6 6'} /></svg>
      </button>}
      {isOpen && <div id={panelId} className={embedded ? 'space-y-3' : 'mt-2 space-y-3'}>
        <p className="text-sm leading-relaxed text-slate-600">{adapted ? simplifiedText('simplified.gloss_add_or_adjust_explanations_for_words', 'Add or adjust explanations for words in the adapted text.') : simplifiedText('simplified.gloss_add_or_adjust_explanations_beside_the', 'Add or adjust explanations beside the original words.')}{' '}{simplifiedText('simplified.gloss_teacher_edits_and_removed_supports_are', 'Teacher edits and removed supports are kept when AI suggestions are refreshed.')}</p>
        <button ref={addRef} type="button" disabled={disabled || busy || !!pendingAction} onClick={() => requestAction({ type: 'add' })} className="min-h-11 rounded-lg border border-indigo-300 px-3 text-indigo-900 disabled:opacity-50">{simplifiedText('simplified.gloss_add_a_word_or_phrase', 'Add a word or phrase')}</button>
        {pendingAction && <div role="alertdialog" aria-labelledby={panelId + '-discard-title'} aria-describedby={panelId + '-discard-description'} className="space-y-2 rounded-lg border border-amber-400 bg-amber-50 p-3" onKeyDown={event => { if (event.key === 'Escape') { event.preventDefault(); dismissPending(); } }}>
          <p id={panelId + '-discard-title'} className="font-bold">{simplifiedText('simplified.gloss_discard_unsaved_word_support_changes', 'Discard unsaved word support changes?')}</p><p id={panelId + '-discard-description'}>{pickingPicture || preparingPicture ? simplifiedText('simplified.gloss_picture_selection_pending', 'Your picture selection is still open. Keep editing to finish choosing or cancel the picture search, or discard it to continue.') : simplifiedText('simplified.gloss_unsaved_choices', 'Save these changes before continuing, keep editing, or discard them.')}</p>
          <div className="flex flex-wrap gap-2"><button ref={keepRef} type="button" className="min-h-11 rounded border border-indigo-300 px-3" onClick={dismissPending}>{simplifiedText('simplified.gloss_keep_editing', 'Keep editing')}</button><button type="button" disabled={disabled || busy || pickingPicture || preparingPicture || staleDraft || supportsStale} className="min-h-11 rounded border border-indigo-700 px-3 disabled:opacity-50" onClick={saveAndContinue}>{busy ? simplifiedText('common.saving', 'Saving…') : 'Save and continue'}</button><button type="button" disabled={busy} className="min-h-11 rounded border border-amber-700 px-3 disabled:opacity-50" onClick={() => { const action = pendingAction; cancelPicture(); setDraft(null); setBaseline(''); performAction(action); }}>{simplifiedText('simplified.gloss_discard_changes', 'Discard changes')}</button></div>
        </div>}
        {draft && <fieldset disabled={disabled || busy || !!pendingAction} data-gloss-draft aria-label={draft.anchor ? simplifiedText('simplified.gloss_edit_word_support', 'Edit word support') : simplifiedText('simplified.gloss_add_word_support', 'Add word support')} className="space-y-3 rounded-lg border border-indigo-200 bg-indigo-50 p-3">
          {(staleDraft || supportsStale) && <p role="status">The passage changed. Your draft is retained. Review the word supports, then <button type="button" disabled={supportsStale} onClick={() => { cancelPicture(); setDraftSource(sourceText); updateDraft({ anchor: null, start: '' }); }} className="underline">choose the occurrence in the current text</button> before saving.</p>}
          <label className="block font-semibold">{simplifiedText('simplified.gloss_word_from', 'Word or phrase from the {passage}', { passage: passageName })}<input ref={termRef} type="text" maxLength={draft.anchor ? undefined : 160} value={draft.query} readOnly={!!draft.anchor} onChange={event => updateDraft({ query: event.target.value, start: '' })} className="mt-1 min-h-11 w-full min-w-0 rounded border border-slate-400 bg-white px-2 font-normal" /></label>
          {!draft.anchor && matches.length > 1 && <label className="block font-semibold">{simplifiedText('simplified.gloss_which_occurrence', 'Which occurrence?')}<select value={draft.start} onChange={event => updateDraft({ start: event.target.value })} className="mt-1 min-h-11 w-full min-w-0 rounded border border-slate-400 bg-white px-2 font-normal"><option value="">{simplifiedText('simplified.gloss_choose_the_word_in_context', 'Choose the word in context')}</option>{matches.map((match, index) => <option key={match.start} value={String(match.start)}>{simplifiedText('simplified.gloss_occurrence_option', '{number}. Text position {start}–{end}: {context}', { number: index + 1, start: match.start + 1, end: match.end, context: match.context })}</option>)}</select></label>}
          {matches.truncated && <p role="status" className="text-amber-900">{simplifiedText('simplified.gloss_showing_the_first_200_matching_occurrenc', 'Showing the first 200 matching occurrences. Use a longer phrase to find a later occurrence.')}</p>}
          {!!draft.query.trim() && !matches.length && <p role="status" className="text-amber-900">{simplifiedText('simplified.gloss_no_exact_match', 'No exact whole-word or phrase match. Copy the word or phrase as it appears in the {passage}.', { passage: passageName })}</p>}
          {selected && (() => { const parts = readingGlossContext(sourceText, selected.start, selected.end); return <p data-gloss-context className="break-words text-slate-600"><span className="font-semibold">{simplifiedText('simplified.gloss_in_the_text', 'In the text:')}{' '}</span>{parts.before}<mark className="rounded bg-yellow-100 px-0.5 font-semibold text-slate-900">{parts.quote}</mark>{parts.after}</p>; })()}
          <label className="block font-semibold">{simplifiedText('simplified.gloss_explanation', 'Explanation')}<span id={panelId + '-explain-hint'} className="block text-xs font-normal text-slate-600">{simplifiedText('simplified.gloss_what_the_word_means_in_this', 'What the word means in this sentence, in a few words.')}{' '}{adapted ? simplifiedText('simplified.gloss_students_see_it_in_the_word', 'Students see it in the word-help list after the passage.') : simplifiedText('simplified.gloss_students_see_it_in_brackets_after', 'Students see it in brackets after the word.')}</span><textarea ref={definitionRef} rows={3} aria-describedby={panelId + '-explain-hint'} placeholder={simplifiedText('simplified.gloss_e_g_turning_around_and_around', 'e.g. turning around and around')} maxLength={Math.max(2400, draft.originalTextLength || 0)} value={draft.text} onChange={event => updateDraft({ text: event.target.value })} className="mt-1 w-full min-w-0 rounded border border-slate-400 bg-white p-2 font-normal" /></label>
          {/^\s*in (?:the )?(?:context|text)\s*:/i.test(draft.text) && <p role="status" data-gloss-context-warning className="text-amber-900">{simplifiedText('simplified.gloss_this_looks_like_the_sentence_around', 'This looks like the sentence around the word. Write what the word means here instead; the sentence already appears in the reading.')}</p>}
          {draft.text.length > 2400 && <p className="text-amber-900">{simplifiedText('simplified.gloss_this_saved_explanation_is_longer_than', 'This saved explanation is longer than the current limit. Shorten it to 2,400 characters or fewer to save an edit.')}</p>}
          <label className="block font-semibold">{simplifiedText('simplified.gloss_importance', 'Importance')}<select value={draft.priority} onChange={event => updateDraft({ priority: event.target.value })} className="mt-1 min-h-11 w-full min-w-0 rounded border border-slate-400 bg-white px-2 font-normal"><option value="essential">{simplifiedText('simplified.gloss_essential_to_understanding_this_passage', 'Essential to understanding this passage')}</option><option value="helpful">{simplifiedText('simplified.gloss_helpful_extra_explanation', 'Helpful extra explanation')}</option></select></label>
          {!adapted && <label className="flex min-h-11 items-center gap-2"><input type="checkbox" checked={draft.pinned} onChange={event => updateDraft({ pinned: event.target.checked })} />{simplifiedText('simplified.gloss_always_show_in_lighter_view', 'Always show in lighter view')}</label>}
          <div data-gloss-picture aria-busy={preparingPicture} className="space-y-2 rounded-lg border border-indigo-100 bg-white p-2">
            <p className="font-semibold">{simplifiedText('simplified.gloss_picture_optional', 'Picture (optional)')}<span className="block text-xs font-normal text-slate-600">{adapted ? simplifiedText('simplified.gloss_a_symbol_or_photo_shown_beside', 'A symbol or photo shown beside the word in the word-help list.') : simplifiedText('simplified.gloss_a_symbol_or_photo_shown_beside_2', 'A symbol or photo shown beside the word, in the reader and in student packs.')}{' '}{simplifiedText('simplified.gloss_live_sessions_carry_no_pictures_so', 'Live sessions carry no pictures, so students there see the explanation on its own.')}</span></p>
            {draft.image && <div className="flex flex-wrap items-center gap-2"><img src={draft.image.src} alt={draft.image.alt || ''} className="h-16 w-16 rounded border border-slate-200 bg-white object-contain" /><span className="min-w-0 flex-1 break-words text-xs text-slate-700">{draft.image.alt}{draft.image.attribution && window.AlloModules?.AltText ? ' · ' + window.AlloModules.AltText.openImageCreditLine(draft.image.attribution) : ''}</span><button type="button" onClick={() => { refocusPicture.current = true; updateDraft({ image: null }); }} className="min-h-11 rounded-lg border border-slate-300 px-3">{simplifiedText('simplified.gloss_remove_picture', 'Remove picture')}</button></div>}
            {!pickingPicture && <button ref={pictureButtonRef} type="button" onClick={() => { pictureEpoch.current++; setPickingPicture(true); }} className="min-h-11 rounded-lg border border-indigo-300 px-3 text-indigo-900">{draft.image ? simplifiedText('simplified.gloss_choose_a_different_picture', 'Choose a different picture') : simplifiedText('simplified.gloss_choose_a_picture', 'Choose a picture')}</button>}
            {pickingPicture && <>{window.AlloModules?.ClassroomImagePicker && window.AlloModules?.AltText
              ? React.createElement(window.AlloModules.ClassroomImagePicker, {
                  idPrefix: panelId + '-picture', initialQuery: draft.query, language: snapshot?.language, sources: ['symbols', 'photos'],
                  onChoose: async choice => {
                    if (!mountedRef.current || !pickingPicture || pictureCallbackEpoch !== pictureEpoch.current || ownerKey !== ownerRef.current || sourceKey !== sourceKeyRef.current) return;
                    const epoch = ++pictureEpoch.current, owner = ownerKey, key = sourceKey;
                    setPreparingPicture(true);
                    const A = window.AlloModules.AltText, contract = getInstructionalContextApi();
                    try {
                      const src = await A.shrinkImageDataUrl(choice.dataUrl, 200, { kind: choice.source === 'mulberry' ? 'symbol' : 'photo' });
                      if (!mountedRef.current || epoch !== pictureEpoch.current || owner !== ownerRef.current || key !== sourceKeyRef.current) return;
                      const budget = contract?.readingSupportPictureBudget ? contract.readingSupportPictureBudget(supports) : { remaining: Infinity, perPicture: Infinity };
                      const replacing = entries.find(entry => draft.anchor && sameAnchor(entry, draft.anchor))?.image?.src?.length || 0;
                      if (src.length > budget.perPicture || src.length > budget.remaining + replacing) {
                        setError(simplifiedText('simplified.gloss_this_reading_has_no_room_for', 'This reading has no room for another picture. Pictures share a small budget so the lesson stays light to save and share. Remove a picture from another word first.'));
                        return;
                      }
                      updateDraft({ image: { src, alt: choice.alt || '', altSource: choice.altSource || 'author', source: choice.source, attribution: choice.attribution || null } });
                      refocusPicture.current = true;
                      setPickingPicture(false);
                    } catch (_) { if (mountedRef.current && epoch === pictureEpoch.current) setError(simplifiedText('simplified.gloss_that_picture_could_not_be_added', 'That picture could not be added. Try another one.')); }
                    finally { if (mountedRef.current && epoch === pictureEpoch.current) setPreparingPicture(false); }
                  },
                })
              : <p role="status" className="text-slate-700">{simplifiedText('simplified.gloss_picture_search_is_still_loading_try', 'Picture search is still loading. Try again in a moment.')}</p>}
              {preparingPicture && <p role="status">{simplifiedText('simplified.gloss_preparing_picture', 'Preparing picture…')}</p>}
              <button type="button" onClick={() => { cancelPicture(); refocusPicture.current = true; setPickingPicture(false); }} className="min-h-11 rounded-lg border border-slate-300 px-3">{simplifiedText('common.cancel', 'Cancel')}</button>
            </>}
          </div>
          <div className="flex flex-wrap gap-2"><button type="button" disabled={disabled || busy || pickingPicture || preparingPicture || staleDraft || supportsStale || !selected || !draft.text.trim()} onClick={save} className="min-h-11 rounded-lg bg-indigo-700 px-3 text-white disabled:opacity-50">{busy ? simplifiedText('common.saving', 'Saving…') : simplifiedText('simplified.gloss_save_word_support', 'Save word support')}</button><button type="button" disabled={busy} onClick={() => requestAction({ type: 'finish' })} className="min-h-11 rounded-lg border border-slate-300 px-3">{simplifiedText('simplified.gloss_done_editing', 'Done editing')}</button></div>
        </fieldset>}
        {error && <p role="alert" className="rounded bg-red-50 p-2 text-red-900">{error}</p>}
        {/* Mounted empty so screen readers announce the text when it arrives. */}
        <p role="status" data-gloss-notice className={notice ? 'rounded bg-indigo-50 p-2 text-indigo-900' : 'sr-only'}>{notice}</p>
        {!entries.length && !draft && <p className="text-slate-600">{simplifiedText('simplified.gloss_no_word_supports_yet_add_your', 'No word supports yet. Add your own explanation or generate suggestions.')}</p>}
        {canFilter && <div data-gloss-filter role="search" aria-label={simplifiedText('simplified.gloss_find_a_word_support', 'Find a word support')} className="flex flex-wrap items-end gap-2">
          <label className="flex min-w-0 flex-1 flex-col font-semibold">{simplifiedText('simplified.gloss_find_a_word_support', 'Find a word support')}<input type="search" value={filterQuery} onChange={event => setFilterQuery(event.target.value)} className="mt-1 min-h-11 w-full min-w-0 rounded border border-slate-400 bg-white px-2 font-normal" /></label>
          <label className="flex flex-col font-semibold">{simplifiedText('simplified.gloss_filter_show', 'Show')}<select value={filterKind} onChange={event => setFilterKind(event.target.value)} className="mt-1 min-h-11 rounded border border-slate-400 bg-white px-2 font-normal"><option value="all">{simplifiedText('simplified.gloss_filter_all', 'All supports')}</option><option value="essential">{simplifiedText('simplified.gloss_essential', 'Essential')}</option><option value="educator">{simplifiedText('simplified.gloss_teacher_edited', 'Teacher edited')}</option><option value="suggested">{simplifiedText('simplified.gloss_suggested', 'Suggested')}</option></select></label>
          {filtering && <button type="button" onClick={() => { setFilterQuery(''); setFilterKind('all'); }} className="min-h-11 rounded-lg border border-slate-300 px-3">{simplifiedText('simplified.gloss_filter_clear', 'Show all')}</button>}
        </div>}
        {canFilter && <p role="status" data-gloss-filter-count className={filtering ? 'text-slate-700' : 'sr-only'}>{filtering ? (listed.length ? simplifiedText('simplified.gloss_filter_count', 'Showing {shown} of {total} word supports.', { shown: listed.length, total: entries.length }) : simplifiedText('simplified.gloss_filter_none', 'No word supports match. Choose Show all to see every support.')) : ''}</p>}
        <ul className="space-y-2">{listed.map(entry => <li key={entry.id} className="rounded-lg border border-slate-200 p-3"><p className="break-words">{entry.image && <img src={entry.image.src} alt={entry.image.alt || ''} className="mr-2 inline-block h-10 w-10 rounded bg-white object-contain align-middle" />}<strong>{entry.quote}</strong> — {entry.definition || entry.explanation || entry.text}</p><p className="mt-1 break-words text-xs text-slate-600">{occurrenceLabel(entry)}</p><p className="mt-1 text-xs text-slate-600">{entry.origin === 'educator' ? simplifiedText('simplified.gloss_teacher_edited', 'Teacher edited') : simplifiedText('simplified.gloss_suggested', 'Suggested')}{entry.priority === 'essential' ? ' · ' + simplifiedText('simplified.gloss_essential', 'Essential') : ''}</p><div className="mt-2 flex flex-wrap items-center gap-2"><button ref={element => { editRefs.current[entry.id] = element; }} type="button" disabled={disabled || busy || !!pendingAction} aria-label={simplifiedText('simplified.gloss_edit_for', 'Edit gloss for {item}', { item: occurrenceLabel(entry) })} onClick={() => requestAction({ type: 'edit', entry })} className="min-h-11 rounded-lg border border-indigo-300 px-3 text-indigo-900">{simplifiedText('common.edit', 'Edit')}</button><button type="button" disabled={disabled || busy || !!pendingAction} aria-label={simplifiedText('simplified.gloss_remove_for', 'Remove gloss for {item}', { item: occurrenceLabel(entry) })} onClick={() => requestAction({ type: 'remove', entry })} className="min-h-11 rounded-lg border border-slate-300 px-3">{simplifiedText('common.remove', 'Remove')}</button>{!adapted && <label className="flex min-h-11 items-center gap-2"><input type="checkbox" aria-label={simplifiedText('simplified.gloss_pin_for', 'Always show in lighter view: {item}', { item: occurrenceLabel(entry) })} checked={entry.pinned === true} disabled={disabled || busy || !!pendingAction} onChange={event => pin(entry, event.target.checked)} />{simplifiedText('simplified.gloss_always_show_in_lighter_view', 'Always show in lighter view')}</label>}</div></li>)}</ul>
      </div>}
    </section>;
  }

  // Keep a source position for every visible UTF-16 unit. Formatting can turn
  // two different raw phrases into identical visible phrases, so occurrence
  // ordinals in Markdown must never stand in for an exact annotation anchor.
  function preparedTextProjection(value, markdown, literalTables) {
    var text = '', offsets = [];
    var append = (part, start) => {
      for (var i = 0; i < part.length; i++) {
        var char = part[i];
        if (/\s/u.test(char)) { if (!text || text.endsWith(' ')) continue; char = ' '; }
        text += char; offsets.push(start + i);
      }
      return null;
    };
    value = String(value || '');
    if (!markdown) append(value, 0);
    else {
      // Chart payloads are not passage text. Blanking preserves source offsets.
      var raw = value.replace(/\[\[CHART:[\s\S]*?\]\]/g, match => ' '.repeat(match.length));
      simplifiedExactBlocks(raw, true).forEach(block => {
        if (block.type === 'hidden' || block.type === 'rule') return;
        if (!literalTables && /^\s*\|/.test(block.raw)) {
          if (!/^\s*\|[\s:|\-]+\|?\s*$/.test(block.raw)) {
            var cursor = block.start;
            block.raw.split('|').forEach(cell => { simplifiedInline(cell, append, cursor); append(' ', cursor + cell.length); cursor += cell.length + 1; });
          }
        } else simplifiedInline(block.text, append, block.textStart);
        append(' ', block.end);
      });
    }
    if (text.endsWith(' ')) { text = text.slice(0, -1); offsets.pop(); }
    return { text, offsets };
  }
  // The complete visible projection must agree before any range is attached.
  // Unknown rendering transformations fail closed; the prepared list remains
  // available. No approximate or nth-occurrence fallback can move a meaning.
  function locateWordHelp(passageText, entries, shownText) {
    const shown = preparedTextProjection(shownText, false);
    let source = preparedTextProjection(passageText, true, false);
    if (source.text !== shown.text) source = preparedTextProjection(passageText, true, true);
    if (!source.text || source.text !== shown.text) return [];
    const found = [];
    const edge = getInstructionalContextApi()?.isWordEdge;
    (entries || []).forEach(entry => {
      const end = entry.end == null ? entry.start + String(entry.quote || '').length : entry.end;
      if (!Number.isInteger(entry.start) || !entry.quote || String(passageText || '').slice(entry.start, end) !== entry.quote) return;
      const first = source.offsets.findIndex(offset => offset >= entry.start && offset < end);
      if (first < 0 || source.offsets[first] !== entry.start) return;
      let last = first;
      while (last + 1 < source.offsets.length && source.offsets[last + 1] < end) last++;
      if (edge && (!edge(source.text, first) || !edge(source.text, last + 1))) return;
      found.push({ entry, start: shown.offsets[first], end: shown.offsets[last] + 1 });
    });
    return found;
  }
  // The passage's visible text, as [text node, offset] segments, skipping any part
  // in another language (the English half of a bilingual text).
  function readingTextSegments(container, language) {
    const segments = [];
    let text = '';
    if (!container || typeof document === 'undefined') return { text, segments };
    const tagged = container.matches('[data-reading-language]') || !!container.querySelector('[data-reading-language]');
    const wanted = String(language || '').trim().toLowerCase();
    const walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT);
    // Text in different blocks or table cells never runs together on screen.
    const blockOf = element => element.closest('p, li, td, th, h1, h2, h3, h4, h5, h6, blockquote, dt, dd, pre, figcaption, div');
    let lastBlock = null;
    for (let node = walker.nextNode(); node; node = walker.nextNode()) {
      const owner = node.parentElement;
      if (!owner || owner.closest('button, [hidden], [inert], [aria-hidden="true"], [data-reading-ui], [data-adapted-word-help], [data-reading-chart], [role="status"], [role="alert"], script, style')) continue;
      if (tagged && wanted) {
        const own = owner.closest('[data-reading-language]');
        if (!own || String(own.getAttribute('data-reading-language') || '').trim().toLowerCase() !== wanted) continue;
      }
      const block = blockOf(owner);
      if (segments.length && block !== lastBlock) text += '\n';
      lastBlock = block;
      segments.push({ node, start: text.length });
      text += node.data;
    }
    return { text, segments };
  }
  function scrollReadingTarget(target, options) {
    if (!target) return;
    var preview = target.closest('[data-student-preview]');
    if (preview) {
      // A short fixed preview must never fall through to scrolling the page.
      preview.scrollTop += target.getBoundingClientRect().top - preview.getBoundingClientRect().top - (options?.block === 'center' ? preview.clientHeight / 2 : 0);
    } else if (typeof target.scrollIntoView === 'function') target.scrollIntoView(options);
  }
  function ensureWordHelpHighlightStyle() {
    if (typeof document === 'undefined' || document.getElementById('allo-word-help-highlights')) return;
    const style = document.createElement('style');
    style.id = 'allo-word-help-highlights';
    // currentColor keeps the underline visible in every reading theme.
    style.textContent = '::highlight(allo-word-help){text-decoration:underline dotted 2px currentColor}::highlight(allo-word-help-focus){background-color:#fde047;color:#111827}';
    document.head.appendChild(style);
  }
  function hasPreparedWordHighlights() {
    return typeof CSS !== 'undefined' && !!CSS.highlights && typeof Highlight === 'function';
  }
  function shareWordHelpMarks(registry, removed, added, name = 'allo-word-help') {
    let shared = registry.get(name);
    (removed || []).forEach(range => { if (shared) shared.delete(range); });
    if (added.length) {
      ensureWordHelpHighlightStyle();
      if (!shared) { shared = new Highlight(); registry.set(name, shared); }
      added.forEach(range => shared.add(range));
    }
    if (shared && !shared.size) registry.delete(name);
  }
  function rangesForOffsets(segments, start, end) {
    const ranges = [];
    if (typeof document === 'undefined') return ranges;
    // A phrase may span source paragraphs separated in the DOM by a translated
    // pane or reader controls. Highlight only the text nodes used for matching.
    segments.forEach(segment => {
      const from = Math.max(0, start - segment.start);
      const to = Math.min(segment.node.data.length, end - segment.start);
      if (from >= to) return;
      const range = document.createRange();
      range.setStart(segment.node, from);
      range.setEnd(segment.node, to);
      ranges.push(range);
    });
    return ranges;
  }
  // The shown word-help entry that covers a word the reader selected in the passage
  // on screen, or null. Same lookup as the passage marks, so a selected word opens
  // exactly the help its underline stands for.
  function adaptedWordHelpAt(item, container, language, wordNode) {
    const contract = getInstructionalContextApi();
    if (!item || !container || !wordNode || !container.contains(wordNode) || !contract?.isAdaptedReading?.(item) || !contract.validateAdaptedReadingSupports) return null;
    const help = contract.validateAdaptedReadingSupports(item, item.adaptedReadingSupports);
    if (!help.shown || help.status === 'stale' || !(help.annotations || []).length) return null;
    const passage = contract.getAdaptedSupportSnapshot(item, item.adaptedReadingSupports);
    if (!passage) return null;
    const { text, segments } = readingTextSegments(container, language);
    const segment = segments.find(value => wordNode === value.node || wordNode.contains(value.node));
    if (!segment) return null;
    const hit = locateWordHelp(passage.text, help.annotations, text).find(value => segment.start >= value.start && segment.start < value.end);
    return hit ? hit.entry : null;
  }

  // Word help for an ADAPTED text: its own supports (item.adaptedReadingSupports),
  // hidden from students until the teacher shows them, and listed after the
  // passage because the adapted reader does not keep character positions.
  function AdaptedWordHelp({ item, teacher, disabled, onUpdate, onGenerate, languageTag, direction, onListen, listening, renderCredits, originalSupports, passageSelector, language, markWords, quiet, draftSession, onOpen, supportView }) {
    const ownSupportView = useSimplifiedAdaptedSupportView(supportView ? null : item, null);
    supportView = supportView || ownSupportView;
    const contract = getInstructionalContextApi();
    const [busy, setBusy] = React.useState(false);
    const [notice, setNotice] = React.useState('');
    // The panel opens by itself when an edit leaves word help stale, and stays open
    // after Keep or Start again so their result is seen (and focused).
    const help = supportView.help, snapshot = supportView.snapshot;
    const staleNow = help?.status === 'stale';
    const [panelOpen, setPanelOpen] = React.useState(staleNow);
    React.useEffect(() => { if (staleNow) setPanelOpen(true); }, [staleNow]);
    const noticeRef = React.useRef(null), focusNotice = React.useRef(false);
    React.useEffect(() => { if (focusNotice.current && noticeRef.current) { focusNotice.current = false; noticeRef.current.focus(); } });
    // Words that have help, as they appear in the passage on screen (a CSS
    // highlight marks them, so the passage's own markup is never touched).
    const listRef = React.useRef(null), spotTimer = React.useRef(null), spotRangesRef = React.useRef([]);
    const helpInstanceId = React.useId();
    const [spotNotice, setSpotNotice] = React.useState('');
    const clearSpot = () => {
      if (spotTimer.current) clearTimeout(spotTimer.current);
      spotTimer.current = null;
      if (typeof CSS !== 'undefined' && CSS.highlights) shareWordHelpMarks(CSS.highlights, spotRangesRef.current, [], 'allo-word-help-focus');
      spotRangesRef.current = [];
    };
    // No marks where the passage on screen is not this word help's text (the
    // English side of a bilingual text in Both) - markWords is false there.
    const passageOnScreen = () => {
      const section = listRef.current;
      if (!section || markWords === false) return null;
      const surface = section.closest('[data-adapted-reader]') || section.ownerDocument;
      return (surface && surface.querySelector(passageSelector || '[data-reading-passage]')) || null;
    };
    const wordHelpOnScreen = onlyId => {
      const container = passageOnScreen();
      if (!container || !contract?.validateAdaptedReadingSupports) return [];
      const shownHelp = help;
      const passage = snapshot;
      if (!shownHelp?.shown || !passage) return [];
      const { text, segments } = readingTextSegments(container, language);
      const wanted = onlyId ? shownHelp.annotations.filter(entry => entry.id === onlyId) : shownHelp.annotations;
      return locateWordHelp(passage.text, wanted, text).map(hit => ({ ...hit, ranges: rangesForOffsets(segments, hit.start, hit.end) })).filter(hit => hit.ranges.length);
    };
    // Re-read the passage only when the text, the word help or where it is shown
    // changed, or the passage was redrawn (a mark's text node left the page); the
    // reader re-renders on every read-aloud word, and the marks stay valid then.
    const marksRef = React.useRef(null);
    React.useLayoutEffect(() => {
      const registry = typeof CSS !== 'undefined' && CSS.highlights;
      if (!registry || typeof Highlight !== 'function') return;
      // The text on screen can change in place (Fill in the blanks back to Read)
      // while old text nodes stay on the page, so compare the text itself too.
      const container = passageOnScreen();
      const shownText = container ? container.textContent : '';
      const last = marksRef.current;
      if (last && last.data === item.data && last.supports === item.adaptedReadingSupports && last.version === supportView.version && last.shownText === shownText && last.where === passageSelector + '|' + language
        && last.ranges.every(range => range.startContainer.isConnected && range.endContainer.isConnected)) return;
      clearSpot();
      const ranges = container ? wordHelpOnScreen().flatMap(hit => hit.ranges) : [];
      marksRef.current = { data: item.data, supports: item.adaptedReadingSupports, version: supportView.version, shownText, where: passageSelector + '|' + language, ranges };
      // One highlight shared by every reader on the page (a student preview is a
      // second reader): each adds and removes only its own ranges.
      shareWordHelpMarks(registry, last ? last.ranges : [], ranges);
    });
    React.useEffect(() => () => {
      clearSpot();
      if (typeof CSS !== 'undefined' && CSS.highlights) shareWordHelpMarks(CSS.highlights, marksRef.current ? marksRef.current.ranges : [], []);
    }, []);
    const showInText = entry => {
      clearSpot();
      const hit = wordHelpOnScreen(entry.id)[0];
      if (!hit) { setSpotNotice(simplifiedText('simplified.word_help_not_found_in_text', 'Could not find "{word}" in the passage on screen.', { word: entry.quote })); return; }
      const target = hit.ranges[0].startContainer.parentElement;
      const reduceMotion = typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      scrollReadingTarget(target, { block: 'center', behavior: reduceMotion ? 'auto' : 'smooth' });
      const registry = typeof CSS !== 'undefined' && CSS.highlights;
      if (registry && typeof Highlight === 'function') {
        ensureWordHelpHighlightStyle();
        shareWordHelpMarks(registry, spotRangesRef.current, hit.ranges, 'allo-word-help-focus');
        spotRangesRef.current = hit.ranges;
        spotTimer.current = setTimeout(clearSpot, 4000);
      }
      setSpotNotice(hasPreparedWordHighlights()
        ? simplifiedText('simplified.word_help_highlighted_in_text', '"{word}" is highlighted in the passage.', { word: entry.quote })
        : simplifiedText('simplified.word_help_located_in_text', 'Located "{word}" in the passage. Read its explanation in Word help.', { word: entry.quote }));
    };
    if (!contract?.isAdaptedReading?.(item) || !contract.validateAdaptedReadingSupports) return null;
    const stored = item.adaptedReadingSupports;
    const entries = help.annotations || [];
    const stale = help.status === 'stale';
    const retainedDraft = draftSession?.records.get(readingSupportDraftKey(item, true))?.draft;
    const editorSnapshot = stale ? retainedDraft && contract.getAdaptedSupportSnapshot(item, null) : snapshot;
    // After an edit, how many explanations are for words still in the passage.
    const staleCount = stale && Array.isArray(stored?.annotations) ? stored.annotations.length : 0;
    let keepable = 0;
    if (staleCount && contract.rebaseAdaptedReadingSupports) { try { keepable = contract.rebaseAdaptedReadingSupports(item, stored).annotations.length; } catch (_) {} }
    // The original's explanations for words this adapted text kept.
    const fromOriginal = teacher && !stale && Array.isArray(originalSupports?.annotations) ? originalSupports.annotations : [];
    let importable = 0;
    if (fromOriginal.length && contract.importOriginalSupportsIntoAdapted) { try { importable = contract.importOriginalSupportsIntoAdapted(item, stored, fromOriginal).annotations.length - entries.length; } catch (_) {} }
    const idBase = 'adapted-word-help-' + helpInstanceId;
    const explanation = entry => entry.definition || entry.explanation || entry.text || '';
    const run = async (work, message) => {
      if (busy || disabled) return;
      setBusy(true); setNotice('');
      try { setNotice(message(await work())); }
      catch (error) { setNotice(error?.message || simplifiedText('simplified.word_help_could_not_be_saved', 'Word help could not be saved. The adapted text is unchanged.')); }
      finally { setBusy(false); }
    };
    const list = !quiet && help.shown && entries.length > 0 && <section ref={listRef} data-adapted-word-help aria-labelledby={idBase + '-title'} className="mt-6 rounded-xl border border-indigo-200 bg-indigo-50 p-4 text-slate-900">
      <div className="flex flex-wrap items-center justify-between gap-2"><h3 id={idBase + '-title'} className="text-lg font-bold text-indigo-950">{simplifiedText('simplified.word_help_word_help', 'Word help')}</h3>{onListen && <button type="button" onClick={() => onListen(entries.map(entry => entry.quote + '. ' + explanation(entry)).join('. '))} className="min-h-11 rounded-lg border border-indigo-300 bg-white px-3 text-indigo-900">{listening ? simplifiedText('simplified.word_help_stop_word_help', 'Stop word help') : simplifiedText('simplified.word_help_listen_to_word_help', 'Listen to word help')}</button>}</div>
      {markWords !== false && <p data-adapted-word-help-tip className="mt-1 text-sm text-indigo-900">{(hasPreparedWordHighlights() ? simplifiedText('simplified.word_help_tip_select', 'Tip: choose Word meaning, then select an underlined word to open its help.') : simplifiedText('simplified.word_help_tip_no_marks', 'Prepared explanations are listed below. Choose Word meaning to open help from the passage.'))}</p>}
      <ul className="mt-2 space-y-4" lang={languageTag} dir={direction}>{entries.map(entry => <li key={entry.id} data-adapted-word-help-entry className="space-y-2 break-words text-base leading-relaxed" style={{ overflowWrap: 'anywhere' }}>
        <div className="flex flex-wrap items-start gap-3">
          {entry.image && <img src={entry.image.src} alt={entry.image.alt || ''} className="h-14 w-14 shrink-0 rounded bg-white object-contain" />}
          <span data-adapted-word-help-text className="min-w-0 flex-1 basis-48"><strong>{entry.quote}</strong>: {explanation(entry)}</span>
        </div>
        <div className="flex flex-wrap gap-2">
          {onOpen && <button type="button" data-prepared-help-open onClick={event => onOpen(event, entry)} aria-label={simplifiedText('simplified.word_help_open_help', 'Open help') + ': ' + simplifiedText('simplified.word_help_prepared_for', 'Prepared word help: {word}', { word: entry.quote })} className="min-h-11 min-w-0 max-w-full rounded-lg border border-indigo-300 bg-white px-3 text-sm text-indigo-900 focus-visible:ring-2 focus-visible:ring-indigo-600">{simplifiedText('simplified.word_help_open_help', 'Open help')}</button>}
          {markWords !== false && <button type="button" data-adapted-word-help-spot onClick={() => showInText(entry)} aria-label={simplifiedText('simplified.word_help_show_word_in_text', 'Show in text: {word}', { word: entry.quote })} className="min-h-11 min-w-0 max-w-full rounded-lg border border-indigo-300 bg-white px-3 text-sm text-indigo-900 focus-visible:ring-2 focus-visible:ring-indigo-600">{simplifiedText('simplified.word_help_show_in_text', 'Show in text')}</button>}
        </div>
      </li>)}</ul>
      <p role="status" data-adapted-word-help-spot-notice className={spotNotice ? 'mt-2 text-sm text-indigo-900' : 'sr-only'}>{spotNotice}</p>
      {renderCredits ? renderCredits(entries) : null}
    </section>;
    // Collapsed unless stale, so an optional tool does not crowd every adapted text.
    const panel = teacher && <details data-adapted-word-help-teacher open={panelOpen} onToggle={event => setPanelOpen(event.currentTarget.open)} className="my-4 space-y-3 rounded-xl border border-indigo-200 bg-white p-3 text-sm text-slate-800">
      <summary className="min-h-11 cursor-pointer rounded-lg px-2 py-2 font-bold text-indigo-900 focus-visible:ring-2 focus-visible:ring-indigo-600">{simplifiedText('simplified.word_help_word_help', 'Word help')}<span data-word-help-summary className="font-normal text-slate-700">{' · ' + (stale ? simplifiedText('simplified.word_help_summary_needs_review', 'Needs review after an edit') : !entries.length ? simplifiedText('simplified.word_help_summary_none', 'No supports yet') : (entries.length === 1 ? simplifiedText('simplified.word_help_summary_one', '1 support') : simplifiedText('simplified.word_help_summary_count', '{count} supports', { count: entries.length })) + ' · ' + (help.shown ? simplifiedText('simplified.word_help_summary_shown', 'Shown to students') : simplifiedText('simplified.word_help_summary_hidden', 'Hidden from students')))}</span></summary>
      <p className="leading-relaxed text-slate-600">{simplifiedText('simplified.word_help_optional_explanations_for_words_in_this', 'Optional explanations for words in this adapted text. Students see them as a list after the passage only when you show it. The original\'s word supports are kept separately.')}</p>
      {stale && <div role="status" className="space-y-2 rounded-lg border border-amber-400 bg-amber-50 p-2 text-amber-900"><p>{simplifiedText('simplified.word_help_this_adapted_text_was_edited_after', 'This adapted text was edited after its word help was made, so that word help is hidden. Keep the explanations whose words are still in the text, start again with an empty list, or suggest word help for the current text.')}</p>{keepable > 0 && <p data-adapted-word-help-keepable>{simplifiedText('simplified.word_help_still_matching', '{kept} of {total} explanations are for words that are still in the text.', { kept: keepable, total: staleCount })}</p>}{onUpdate && <div className="flex flex-wrap gap-2">{keepable > 0 && <button type="button" data-adapted-word-help-rebase disabled={disabled || busy} onClick={() => run(() => onUpdate(item, { type: 'rebase' }), result => (focusNotice.current = true) && simplifiedText('simplified.word_help_kept_check_fit', 'Kept the explanations that still match ({count}). Students will not see them until you check each one and show word help again.', { count: result?.annotations?.length || 0 }))} className="min-h-11 rounded-lg bg-amber-800 px-3 font-semibold text-white disabled:opacity-50">{simplifiedText('simplified.word_help_keep_matching', 'Keep the {count} that still match', { count: keepable })}</button>}<button type="button" data-adapted-word-help-clear disabled={disabled || busy} onClick={() => run(() => onUpdate(item, { type: 'clear' }), () => (focusNotice.current = true) && simplifiedText('simplified.word_help_cleared', 'Word help cleared. Add explanations for the current adapted text.'))} className="min-h-11 rounded-lg border border-amber-700 px-3 disabled:opacity-50">{simplifiedText('simplified.word_help_start_again', 'Start again')}</button></div>}</div>}
      <div className="flex flex-wrap items-center gap-3">
        {onUpdate && <label className="flex min-h-11 items-center gap-2"><input type="checkbox" data-adapted-word-help-show checked={help.shown} disabled={disabled || busy || stale || (!entries.length && !help.shown)} onChange={event => { const shown = event.target.checked; run(() => onUpdate(item, { type: 'show', shown }), result => result?.shown ? simplifiedText('simplified.word_help_students_now_see_this_word_help', 'Students now see this word help after the passage.') : simplifiedText('simplified.word_help_word_help_is_hidden_from_students', 'Word help is hidden from students.')); }} />{simplifiedText('simplified.word_help_show_word_help_to_students', 'Show word help to students')}</label>}
        {onGenerate && <button type="button" data-adapted-word-help-generate disabled={disabled || busy} onClick={() => run(() => onGenerate(item), result => result?.status === 'unavailable' ? simplifiedText('simplified.word_help_word_help_could_not_be_suggested', 'Word help could not be suggested. The adapted text is unchanged.') : result?.status === 'partial' ? simplifiedText('simplified.word_help_some_words_could_not_be_supported', 'Some words could not be supported. Review the suggestions before showing them.') : simplifiedText('simplified.word_help_suggested_word_help_is_ready_review', 'Suggested word help is ready. Review it, then show it to students.'))} className="min-h-11 rounded-lg border border-indigo-300 px-3 text-indigo-900 disabled:opacity-50">{busy ? simplifiedText('simplified.word_help_working', 'Working…') : entries.length ? simplifiedText('simplified.word_help_refresh_suggested_word_help', 'Refresh suggested word help') : simplifiedText('simplified.word_help_suggest_word_help', 'Suggest word help')}</button>}
        {onUpdate && importable > 0 && <button type="button" data-adapted-word-help-import disabled={disabled || busy} onClick={() => run(() => onUpdate(item, { type: 'import', annotations: fromOriginal }), result => (focusNotice.current = true) && simplifiedText('simplified.word_help_added_from_original', 'Added explanations from the original ({count}). Students will not see word help until you check them and show it again.', { count: Math.max(0, (result?.annotations?.length || 0) - entries.length) }))} className="min-h-11 rounded-lg border border-indigo-300 px-3 text-indigo-900 disabled:opacity-50">{simplifiedText('simplified.word_help_use_from_original', 'Reuse explanations from the original ({count})', { count: importable })}</button>}
      </div>
      <p ref={noticeRef} tabIndex={-1} role="status" data-word-help-notice className={notice ? 'rounded bg-indigo-50 p-2 text-indigo-900' : 'sr-only'}>{notice}</p>
      {editorSnapshot && onUpdate && <ReadingGlossEditor key={readingSupportDraftKey(item, true)} item={item} supports={help} snapshot={editorSnapshot} adapted embedded onUpdate={onUpdate} disabled={disabled || busy} draftSession={draftSession} supportsStale={stale} />}
    </details>;
    if (!list && !panel) return null;
    return <>{list}{panel}</>;
  }

  // Preview receives a frozen data snapshot and an explicit presentation-only
  // contract. Never copy host renderers, callbacks, refs or media components.
  function captureReadingPreview(props, appearance) {
    var snapshot = { previewAppearance: {
      readingColumn: [40, 56, 72].includes(appearance?.readingColumn) ? appearance.readingColumn : 72,
      displayOpen: !!appearance?.displayOpen,
      showComparisonChanges: !!appearance?.showComparisonChanges
    } };
    ['generatedContent', 'history', 'inputText', 'gradeLevel', 'leveledTextLanguage', 'studentInterests', 'standardsInput', 'sourceTopic', 'latestGlossary', 'isSideBySide', 'readingTheme', 'theme'].forEach(function (key) {
      if (props[key] !== undefined) snapshot[key] = JSON.parse(JSON.stringify(props[key]));
    });
    ['t', 'splitTextToSentences', 'getSideBySideContent', 'splitReferencesFromBody', 'parseReferenceItems', 'getContentDirection', 'isRtlLang'].forEach(function (key) { snapshot[key] = props[key]; });
    return snapshot;
  }
  function SimplifiedPreviewReferences({ referencesText }) {
    if (!referencesText) return null;
    return <section data-preview-references className="mt-4 whitespace-pre-wrap text-sm">{simplifiedInline(referencesText, function (text) { return text; })}</section>;
  }
  function SimplifiedPreviewReader({ snapshot, limitsId }) {
    var [mode, setMode] = React.useState('read');
    var [compare, setCompare] = React.useState(false);
    var [theme, setTheme] = React.useState(snapshot.readingTheme || 'default');
    var [focusedParagraph, setFocusedParagraph] = React.useState(null);
    var inline = function (text) { return simplifiedInline(String(text || ''), function (value) { return value; }); };
    var formatted = function (text) {
      var raw = String(text || '');
      if (/^\s*\[\[CHART:/.test(raw)) return <p role="note">{simplifiedText('simplified.layout_preview_chart', 'Charts are unavailable in this layout preview. View the main reading to inspect the chart.', null, snapshot.t)}</p>;
      var lines = raw.trim().split(/\r?\n/);
      if (lines.length > 1 && /^\s*\|/.test(lines[0]) && /^\s*\|?[ :|\-]+\|\s*$/.test(lines[1])) {
        var cells = line => line.trim().replace(/^\||\|$/g, '').split('|');
        return <table className="w-full border-collapse text-left"><thead><tr>{cells(lines[0]).map((cell, i) => <th key={i} scope="col" className="border border-slate-300 p-2">{inline(cell.trim())}</th>)}</tr></thead><tbody>{lines.slice(2).map((line, i) => <tr key={i}>{cells(line).map((cell, j) => <td key={j} className="border border-slate-300 p-2">{inline(cell.trim())}</td>)}</tr>)}</tbody></table>;
      }
      return inline(raw);
    };
    // No audio capability is granted. The host retains its playback ownership;
    // preview mount, navigation and cleanup must not play, cancel or capture it.
    return <SimplifiedView {...snapshot} isTeacherMode={false} isStudentPreview={true} readingLearnerKey="" previewLimitId={limitsId} focusedParagraphIndex={focusedParagraph} setFocusedParagraphIndex={setFocusedParagraph}
      interactionMode={mode} setInteractionMode={setMode} isCompareMode={compare} setIsCompareMode={setCompare}
      readingTheme={theme} setReadingTheme={setTheme} playbackState={{ currentIdx: -1 }} SourceReferencesPanel={SimplifiedPreviewReferences}
      formatInteractiveText={inline} highlightGlossaryTerms={inline} renderFormattedText={formatted} />;
  }

  function SimplifiedPopupStatus({ message }) {
    const [announcement, setAnnouncement] = React.useState('');
    React.useEffect(function () {
      const timer = setTimeout(function () { setAnnouncement(message); }, 0);
      return function () { clearTimeout(timer); };
    }, [message]);
    return <p role="status" aria-live="polite" aria-atomic="true" data-reader-popup-status className="sr-only">{announcement}</p>;
  }

  function SimplifiedView(props) {
    const liveReaderProps = React.useRef(props); liveReaderProps.current = props;
    const localDraftSessionRef = React.useRef(null);
    const supportDraftSessionRef = props.supportDraftSessionRef || localDraftSessionRef;
    if (!supportDraftSessionRef.current) supportDraftSessionRef.current = window.AlloModules?.ReaderSupportDrafts?.createSession();
    const supportDraftSession = props.isStudentPreview ? null : supportDraftSessionRef.current;
    const requestSupportTransition = work => supportDraftSession ? supportDraftSession.request(work) : work();
    React.useEffect(() => {
      if (!supportDraftSession || props.supportDraftSessionRef) return;
      const protect = event => supportDraftSession.protectUnload(event);
      window.addEventListener('beforeunload', protect);
      return () => window.removeEventListener('beforeunload', protect);
    }, [supportDraftSession, props.supportDraftSessionRef]);
    var previewInstanceId = React.useId();
    var readerId = function (name) { return !props.isStudentPreview && /^sentence-/.test(name) ? name : name + '-' + previewInstanceId.replace(/:/g, ''); };
    var [studentPreview, setStudentPreview] = React.useState(null);
    var studentPreviewRef = React.useRef(null), studentPreviewCloseRef = React.useRef(null), studentPreviewOpener = React.useRef(null);
    var studentPreviewRefreshRef = React.useRef(null);
    var previewSessionRef = React.useRef(0);
    var previewOpenRef = React.useRef(false); previewOpenRef.current = !!studentPreview;
    var viewText = (key, fallback, params) => simplifiedText(key, fallback, params, props.t);
    // State reads
    var t = props.t;
    var simplifiedAudioEditLabel = viewText('simplified.manage_narration', 'Manage narration');
    var simplifiedAudioSaveLabel = t('common.save') || '';
    var simplifiedAudioStopLabel = t('common.stop') || '';
    var simplifiedAudioPlayLabel = t('common.play') || '';
    var simplifiedAudioPauseLabel = t('common.pause') || '';
    var simplifiedAudioLoadingLabel = t('common.loading') || '';
    var simplifiedAudioGenerateLabel = t('common.generate') || '';
    var simplifiedAudioRegenerateLabel = t('common.regenerate') || '';
    var simplifiedAudioRemoveLabel = t('common.remove') || '';
    var simplifiedAudioRecordLabel = t('word_sounds.voice_pack_tab_record') || t('common.microphone') || '';
    var simplifiedAudioSavedLabel = viewText('simplified.audio_ready_short', 'ready for playback');
    var simplifiedAudioMissingLabel = t('simplified.missing_label') || '';
    var simplifiedAudioErrorLabel = t('common.error') || '';
    var simplifiedAudioStorageLimitLabel = t('errors.storage_full') || simplifiedAudioErrorLabel;
    var simplifiedAudioSettingsChangedLabel = t('ui_common.unsaved_changes') || simplifiedAudioErrorLabel;
    var simplifiedAudioCopiedLabel = t('common.copy') || '';
    var simplifiedAudioDiagnosticsLabel = t('common.error_analysis') || simplifiedAudioErrorLabel;
    var simplifiedActivityCompleteLabel = t('word_sounds.session_complete') || simplifiedAudioSavedLabel;
    var simplifiedReadingSelectionLabel = t('common.selection') || t('common.resource') || '';
    var simplifiedReadingThemeLabel = t('header.reading_theme_aria') || '';
    var simplifiedTeacherRecordingLabel = t('word_sounds.voice_pack_kind_teacher') || simplifiedAudioRecordLabel;
    var simplifiedStudentRecordingLabel = t('word_sounds.voice_pack_kind_student') || simplifiedAudioRecordLabel;
    var simplifiedHumanRecordingLabel = t('word_sounds.real_recording') || simplifiedAudioRecordLabel;
    var simplifiedHearPhonicsLabel = t('common.click_hear_phonics') || '';
    var simplifiedDefineLabel = t('text_tools.define') || '';
    var simplifiedReadSentenceLabel = t('common.read') || '';
    var simplifiedGeneratingMoreLabel = t('word_sounds.generating_more') || '';
    var readingTranslationLanguage = window.AlloModules?.TextPipelineHelpers?.getArtifactTranslationTarget?.(props.generatedContent) || 'English';
    var simplifiedEnglishTranslationLabel = /^english$/i.test(readingTranslationLanguage)
      ? viewText('common.english_translation', 'English translation')
      : viewText('simplified.translation_language', '{language} translation', { language: readingTranslationLanguage });
    var simplifiedStopAudioDownloadLabel = t('common.audio_stop') || simplifiedAudioStopLabel;
    var generatedContent = props.generatedContent;
    var readingContract = getInstructionalContextApi();
    var protectedOriginal = getSimplifiedInstructionalText(generatedContent).form === 'same-text-supported';
    var capturedSource = readingContract?.getSourceSnapshot?.(generatedContent) || null;
    var verifiedOriginal = !!readingContract?.isSupportedOriginal?.(generatedContent);
    var inputText = props.inputText;
    var gradeLevel = props.gradeLevel;
    var leveledTextLanguage = generatedContent?.config?.language || generatedContent?.instructionalText?.complexity?.language || props.leveledTextLanguage;
    var studentInterests = props.studentInterests;
    var standardsInput = props.standardsInput;
    var sourceTopic = props.sourceTopic;
    var isTeacherMode = props.isTeacherMode;
    // Explain mode (2026-09-14): every action in its selection menu (Explain,
    // Simplify, Custom) is an AI call, so the mode is withheld from a student
    // whose AI is hidden. Word meaning stays: it has a dictionary path.
    var studentAiFeaturesHidden = !isTeacherMode && !!props.studentAiFeaturesHidden;
    var isProcessing = props.isProcessing;
    var isPlaying = props.isPlaying;
    // Guard stale authoring state immediately when switching to student view.
    var interactionMode = !isTeacherMode && (['revise', 'add-glossary'].includes(props.interactionMode) || (studentAiFeaturesHidden && props.interactionMode === 'explain')) ? 'read' : props.interactionMode;
    var isCompareMode = !!props.isCompareMode;
    if ((protectedOriginal || isCompareMode) && interactionMode === 'cloze') interactionMode = 'read';
    var isFluencyMode = props.isFluencyMode;
    var isEditingLeveledText = isTeacherMode && !protectedOriginal && props.isEditingLeveledText;
    // Narration belongs to the active reading, independently of text editing.
    var canManageNarration = isTeacherMode && !props.isZenMode && !props.isStudentPreview;
    var isImmersiveReaderActive = props.isImmersiveReaderActive;
    var immersiveSettings = props.immersiveSettings;
    var immersiveRulerY = props.immersiveRulerY;
    var isFocusReaderActive = props.isFocusReaderActive;
    var isChunkReaderActive = props.isChunkReaderActive;
    var chunkReaderIdx = props.chunkReaderIdx;
    var chunkReaderAutoPlay = props.chunkReaderAutoPlay;
    var chunkReaderSpeed = props.chunkReaderSpeed;
    var chunkReaderReadAlong = props.chunkReaderReadAlong;
    var chunkReaderSweepPct = props.chunkReaderSweepPct;
    var chunkReaderMood = props.chunkReaderMood || 'highlight';
    var setChunkReaderMood = props.setChunkReaderMood;
    var chunkTypewriterCharIdx = props.chunkTypewriterCharIdx || 0;
    var isCrawlReaderActive = props.isCrawlReaderActive;
    var isKaraokeOverlayActive = props.isKaraokeOverlayActive;
    var isAnalyzingPos = props.isAnalyzingPos;
    var isCheckingLevel = props.isCheckingLevel;
    // Automatic level check preference (read by the generation dispatcher).
    // Stored per browser, never on the resource; default ON for teachers.
    var _autoLevelPref = React.useState(function () {
      try { return localStorage.getItem('alloflow_auto_level_check') !== 'off'; } catch (_) { return true; }
    });
    var autoLevelCheckOn = _autoLevelPref[0];
    var setAutoLevelCheckOn = function (next) {
      _autoLevelPref[1](!!next);
      try { localStorage.setItem('alloflow_auto_level_check', next ? 'on' : 'off'); } catch (_) {}
    };
    var isCheckingAlignment = props.isCheckingAlignment;
    var isLineFocusMode = props.isLineFocusMode;
    var focusedParagraphIndex = props.focusedParagraphIndex;
    var isZenMode = props.isZenMode;
    var definitionData = props.definitionData;
    var phonicsData = props.phonicsData;
    var revisionData = isTeacherMode || props.revisionData?.type === 'explain' ? props.revisionData : null;
    var selectionMenu = interactionMode === props.interactionMode ? props.selectionMenu : null;
    var isCustomReviseOpen = isTeacherMode && props.isCustomReviseOpen;
    var customReviseInstruction = props.customReviseInstruction;
    var latestGlossary = props.latestGlossary;
    // Fill in the blanks makes blanks from glossary terms. With none it showed
    // the passage without blanks under "Fill in the missing words".
    var hasClozeTerms = Array.isArray(latestGlossary) && latestGlossary.some(function (item) { return item && item.term && item.isSelected !== false; });
    // "Complete" means every blank on the page is solved. The host's check
    // counted a term after one of its blanks and waited on terms that never
    // appear in the passage, so it could not fire.
    // Read-aloud in Fill in the blanks says "blank" for each term, so listening
    // stays available without reading the answers out.
    var maskClozeTerms = function (text) {
      var blank = t('simplified.cloze_blank_spoken');
      blank = blank && blank !== 'simplified.cloze_blank_spoken' ? blank : 'blank';
      var language = props.leveledTextLanguage, terms = [];
      (latestGlossary || []).forEach(function (item) {
        if (!item || !item.term || item.isSelected === false) return;
        terms.push(String(item.term));
        var translated = item.translations && language && item.translations[language];
        if (translated) terms.push(String(translated).split(':')[0].trim());
      });
      terms = terms.filter(Boolean).sort(function (a, b) { return b.length - a.length; });
      if (!terms.length) return text;
      var escaped = terms.map(function (term) { return term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); });
      var pattern = new RegExp('(^|[^\\p{L}\\p{N}])(' + escaped.join('|') + ')(?=$|[^\\p{L}\\p{N}])', 'giu');
      return String(text).replace(pattern, function (_match, lead) { return lead + blank; });
    };
    var clozeBodyRef = React.useRef(null);
    var [clozeAllSolved, setClozeAllSolved] = React.useState(false);
    React.useEffect(function () {
      var root = clozeBodyRef.current;
      var blanks = props.interactionMode === 'cloze' && root ? root.querySelectorAll('[data-cloze-blank]') : [];
      var done = blanks.length > 0 && Array.prototype.every.call(blanks, function (node) { return node.getAttribute('data-cloze-solved') === 'true'; });
      if (done !== clozeAllSolved) setClozeAllSolved(done);
    });
    var history = props.history;
    var complexityLevel = props.complexityLevel;
    var saveOriginalOnAdjust = props.saveOriginalOnAdjust;
    var playbackState = props.playbackState;
    var playbackRate = props.playbackRate;
    var selectedVoice = props.selectedVoice;
    var voiceSpeed = props.voiceSpeed;
    var lineHeight = props.lineHeight;
    var letterSpacing = props.letterSpacing;
    var readingTheme = props.readingTheme;
    var theme = props.theme;
    var isTeacherToolbarExpanded = props.isTeacherToolbarExpanded;
    var downloadingContentId = props.downloadingContentId;
    var playingContentId = props.playingContentId;
    var isSimplifiedAudioDownloading = downloadingContentId === 'dl-simplified-main';
    var isClozeComplete = props.isClozeComplete;
    var isSideBySide = props.isSideBySide;
    var cursorStyles = props.cursorStyles;
    // Setters
    var setInteractionMode = props.setInteractionMode;
    var setIsCompareMode = props.setIsCompareMode;
    var setIsFluencyMode = props.setIsFluencyMode;
    var setSelectionMenu = props.setSelectionMenu;
    var setRevisionData = props.setRevisionData;
    var setPhonicsData = props.setPhonicsData;
    var setIsImmersiveReaderActive = props.setIsImmersiveReaderActive;
    var setImmersiveSettings = props.setImmersiveSettings;
    var setImmersiveRulerY = props.setImmersiveRulerY;
    var setIsFocusReaderActive = props.setIsFocusReaderActive;
    var setIsChunkReaderActive = props.setIsChunkReaderActive;
    var setChunkReaderIdx = props.setChunkReaderIdx;
    var setChunkReaderAutoPlay = props.setChunkReaderAutoPlay;
    var setChunkReaderSpeed = props.setChunkReaderSpeed;
    var setChunkReaderReadAlong = props.setChunkReaderReadAlong;
    var setChunkReaderSweepPct = props.setChunkReaderSweepPct;
    var setIsCrawlReaderActive = props.setIsCrawlReaderActive;
    var setIsKaraokeOverlayActive = props.setIsKaraokeOverlayActive;
    var setPlaybackRate = props.setPlaybackRate;
    var setLineHeight = props.setLineHeight;
    var setLetterSpacing = props.setLetterSpacing;
    var setFocusedParagraphIndex = props.setFocusedParagraphIndex;
    // Line Focus follows keyboard focus as well as the pointer. Keep a
    // focused response visible when the mouse leaves or moves between words.
    var lineFocusParagraphProps = function (paragraphId) {
      var clearFocus = function () {
        setFocusedParagraphIndex(current => current === paragraphId ? null : current);
      };
      return {
        'data-line-focus-paragraph': String(paragraphId),
        tabIndex: isLineFocusMode ? 0 : undefined,
        onFocus: function () { setFocusedParagraphIndex(paragraphId); },
        onBlur: function (event) {
          if (!event.currentTarget.contains(event.relatedTarget)) clearFocus();
        },
        onMouseEnter: function () { setFocusedParagraphIndex(paragraphId); },
        onMouseLeave: function (event) {
          if (!event.currentTarget.contains(event.currentTarget.ownerDocument.activeElement)) clearFocus();
        }
      };
    };
    var setIsCustomReviseOpen = props.setIsCustomReviseOpen;
    var setCustomReviseInstruction = props.setCustomReviseInstruction;
    var setComplexityLevel = props.setComplexityLevel;
    var setSaveOriginalOnAdjust = props.setSaveOriginalOnAdjust;
    var setReadingTheme = props.setReadingTheme;
    var setGeneratedContent = props.setGeneratedContent;
    var setHistory = props.setHistory;
    // Refs
    var chunkReaderSweepAudioRef = props.chunkReaderSweepAudioRef;
    var chunkReaderSweepRafRef = props.chunkReaderSweepRafRef;
    var textEditorRef = props.textEditorRef;
    // Handlers
    var handleCloseImmersiveReader = props.handleCloseImmersiveReader;
    var handleGeneratePOSData = props.handleGeneratePOSData;
    var handleCloseSpeedReader = props.handleCloseSpeedReader;
    var handleSpeak = props.handleSpeak;
    var handleWordClick = props.handleWordClick;
    var handlePhonicsClick = props.handlePhonicsClick;
    var handleFormatText = props.handleFormatText;
    var handleSimplifiedTextChange = props.handleSimplifiedTextChange;
    var handleReviseSelection = props.handleReviseSelection;
    var handleQuickAddGlossary = props.handleQuickAddGlossary;
    var handleDefineSelection = props.handleDefineSelection;
    var handleTextMouseUp = props.handleTextMouseUp;
    var handleSetIsSyntaxGameToTrue = props.handleSetIsSyntaxGameToTrue;
    var handleAnalyzePOS = props.handleAnalyzePOS;
    var handleCheckLevel = props.handleCheckLevel;
    var handleCheckAlignment = props.handleCheckAlignment;
    var handleDuplicateResource = props.handleDuplicateResource;
    var handleDownloadAudio = props.handleDownloadAudio;
    var handleToggleIsTeacherToolbarExpanded = props.handleToggleIsTeacherToolbarExpanded;
    var editFocusRequestedRef = React.useRef(false);
    // Comparison renders before the editor. Both Edit entry points must leave
    // Both view, while retaining the guard for unfinished word-support drafts.
    var handleToggleIsEditingLeveledText = typeof props.handleToggleIsEditingLeveledText === 'function' ? (() => requestSupportTransition(() => {
      if (!isTeacherMode || protectedOriginal) return;
      editFocusRequestedRef.current = !isEditingLeveledText;
      if (typeof props.stopPlayback === 'function') props.stopPlayback();
      if (typeof props.setIsCompareMode === 'function') props.setIsCompareMode(false);
      if (typeof props.setIsFluencyMode === 'function') props.setIsFluencyMode(false);
      if (typeof props.setInteractionMode === 'function') props.setInteractionMode('read');
      if (typeof props.closeDefinition === 'function') props.closeDefinition();
      if (typeof props.closePhonics === 'function') props.closePhonics();
      if (typeof props.closeRevision === 'function') props.closeRevision();
      if (typeof props.setSelectionMenu === 'function') props.setSelectionMenu(null);
      if (typeof props.setIsCustomReviseOpen === 'function') props.setIsCustomReviseOpen(false);
      props.handleToggleIsEditingLeveledText();
    })) : undefined;
    React.useEffect(function () {
      if (!isTeacherMode || protectedOriginal) { editFocusRequestedRef.current = false; return; }
      if (editFocusRequestedRef.current && isEditingLeveledText && !isCompareMode && textEditorRef?.current) {
        editFocusRequestedRef.current = false;
        textEditorRef.current.focus();
      }
    }, [isTeacherMode, protectedOriginal, isEditingLeveledText, isCompareMode, textEditorRef]);
    var handleSetIsCustomReviseOpenToFalse = props.handleSetIsCustomReviseOpenToFalse;
    var closeDefinition = props.closeDefinition;
    var closePhonics = props.closePhonics;
    var closeRevision = props.closeRevision;
    var handleFetchWordImage = props.handleFetchWordImage;
    var applyTextRevision = props.applyTextRevision;
    var stopPlayback = props.stopPlayback;
    var handleComplexityAdjustment = props.handleComplexityAdjustment;
    var handleRegenerateWithRigor = props.handleRegenerateWithRigor;
    // Pure helpers
    var splitTextToSentences = props.splitTextToSentences;
    var getSideBySideContent = props.getSideBySideContent;
    var formatInteractiveText = props.formatInteractiveText;
    var renderFormattedText = props.renderFormattedText;
    var splitReferencesFromBody = props.splitReferencesFromBody;
    var parseReferenceItems = props.parseReferenceItems;
    var highlightGlossaryTerms = props.highlightGlossaryTerms;
    var diffWords = props.diffWords;
    var callTTS = props.callTTS;
    var copyToClipboard = props.copyToClipboard;
    var isRtlLang = props.isRtlLang;
    var getContentDirection = props.getContentDirection;
    // Components
    var ImmersiveToolbar = props.ImmersiveToolbar;
    var ImmersiveWord = props.ImmersiveWord;
    var ErrorBoundary = props.ErrorBoundary;
    var FocusReaderOverlay = props.FocusReaderOverlay;
    var PerspectiveCrawlOverlay = props.PerspectiveCrawlOverlay;
    var KaraokeReaderOverlay = props.KaraokeReaderOverlay;
    var [comparisonKaraoke, setComparisonKaraoke] = React.useState(null);
    var listenAlongOpenerRef = React.useRef(null);
    // The same playback-only reader serves a single passage and either Both
    // pane. It does not need immersive word preparation or mutate the lesson.
    function openListenAlong(text, language, event) {
      if (props.isStudentPreview || isEditingLeveledText || !KaraokeReaderOverlay) return;
      var entries = getReadAloudSentenceEntriesForText(text, language);
      if (!entries.length) return;
      if (typeof props.stopPlayback === 'function') props.stopPlayback();
      if (typeof props.closeDefinition === 'function') props.closeDefinition();
      if (typeof props.closePhonics === 'function') props.closePhonics();
      if (typeof props.closeRevision === 'function') props.closeRevision();
      if (typeof props.setSelectionMenu === 'function') props.setSelectionMenu(null);
      listenAlongOpenerRef.current = event && event.currentTarget;
      setComparisonKaraoke({ text, language, scope: listenAlongScope, entries, sentences: entries.map(entry => entry.text), languages: entries.map(entry => simplifiedLanguageTag(entry.language)) });
    }
    function closeListenAlong() {
      setComparisonKaraoke(null);
      var opener = listenAlongOpenerRef.current;
      listenAlongOpenerRef.current = null;
      if (opener?.isConnected) opener.focus();
    }
    var ConfettiExplosion = props.ConfettiExplosion;
    var ComplexityGauge = props.ComplexityGauge;
    var SourceReferencesPanel = props.SourceReferencesPanel;
    // The immersive reader is a z-[200] full-screen overlay. Word-level popups
    // (Define / Phonics / selection / revise) default to z-[100]/z-[90], so when
    // immersive is open they render BEHIND it — the definition appears to land in
    // the standard view. Lift them above the overlay while immersive is active
    // (backdrop just under the popup, still above the overlay).
    const _popupZ = isImmersiveReaderActive ? 'z-[220]' : 'z-[100]';
    const _popupBackdropZ = isImmersiveReaderActive ? 'z-[210]' : 'z-[90]';
    // Build the exact text contract shared by visible sentence indexes,
    // in-view playback, karaoke preparation, and Edit Audio.
    var buildSimplifiedContentParts = function (rawText) {
      var fullText = typeof rawText === 'string' ? rawText : String(rawText || '');
      var split = { body: fullText, references: '' };
      try {
        if (typeof splitReferencesFromBody === 'function') split = splitReferencesFromBody(fullText) || split;
      } catch (_) {}
      var normalizedBody = String(split.body || '').replace(/\r\n?/g, '\n').replace(/^[ \t]*<h([1-6])[^>]*>(.*?)<\/h[1-6]>[ \t]*$/gmi, (_match, level, text) => '#'.repeat(Number(level)) + ' ' + text).replace(/^[ \t]*(\*\*)([^*\n]+?)\1[ \t]*$/gm, function (_match, _stars, inner) {
        // Only a bold line is a label heading. An italic line is a poem line or a
        // caption ("*Figure 2*"), and became a section heading.
        if (/[.!?。！？؟:：]$/.test(inner.trim())) return _match;
        return '## ' + inner.trim();
      });
      // A chart directive gets its own paragraph, so it is drawn as a chart and
      // never read aloud; it was shown and spoken as raw JSON.
      normalizedBody = normalizedBody.replace(/\[\[CHART:([\s\S]*?)\]\]/g, (_m, body) => '\n\n[[CHART: ' + body.replace(/\s*\n\s*/g, ' ').trim() + ']]\n\n');
      // A table gets its own paragraph too. Read-aloud skips table paragraphs, so a
      // line written directly above one ("Look at this:") was never read or clickable.
      normalizedBody = normalizedBody.replace(/^([ \t]*[^|\s][^\n]*)\n(?=[ \t]*\|)/gm, '$1\n\n').replace(/^([ \t]*\|[^\n]*)\n(?=[ \t]*[^|\s])/gm, '$1\n\n');
      return { body: normalizedBody, references: String(split.references || '') };
    };
    var preparedContentParts = React.useMemo(function () {
      return protectedOriginal ? { body: typeof generatedContent?.data === 'string' ? generatedContent.data : '', references: '' } : buildSimplifiedContentParts(generatedContent?.data);
    }, [protectedOriginal, generatedContent?.data, splitReferencesFromBody]);
    var simplifiedContentParts = { ...preparedContentParts };
    var simplifiedDisplayBody = simplifiedContentParts.body;
    // Immersive words are used only for the text they were built from; an edit
    // copies the item, so the overlays kept reading the old words.
    var immersiveFresh = Array.isArray(generatedContent?.immersiveData) && (generatedContent.immersiveSource == null || generatedContent.immersiveSource === String(generatedContent.data || ''));
    function openReadingReflection() {
      if (!props.onReadReflect) return;
      rememberPlace(true);
      props.onReadReflect({ text: simplifiedDisplayBody, title: sourceTopic || 'Adapted reading', language: leveledTextLanguage || '',
        anchor: { kind: 'adapted', resourceId: String(generatedContent.id || sourceTopic || 'adapted'), section: 'body' } });
    }
    // The adapted document owns its citation registry. Falling back to the
    // source document is only safe when the adapted document has no reference
    // trailer at all; choosing whichever list is longer can pair adapted body
    // markers with a different source list.
    var simplifiedInputReferences = '';
    try {
      if (inputText && typeof splitReferencesFromBody === 'function')
        simplifiedInputReferences = String((splitReferencesFromBody(inputText) || {}).references || '');
    } catch (_) {}
    var adaptedCitationAudit = generatedContent && generatedContent.config && generatedContent.config.citationAudit;
    var simplifiedReferences = resolveSimplifiedReferences(simplifiedDisplayBody, simplifiedContentParts.references, simplifiedInputReferences, adaptedCitationAudit);
    simplifiedContentParts.references = simplifiedReferences;
    var simplifiedReadAloudText = protectedOriginal ? simplifiedDisplayBody : simplifiedDisplayBody.trim();
    var ttsPrepState_state = React.useState({ busy: false, done: 0, total: 0 });
    var ttsPrepState = ttsPrepState_state[0];
    var setTtsPrepState = ttsPrepState_state[1];
    var ttsPrepNoticeState = React.useState('');
    var ttsPrepNotice = ttsPrepNoticeState[0], setTtsPrepNotice = ttsPrepNoticeState[1];
    var [ttsPrepFailure, setTtsPrepFailure] = React.useState(null);
    var [ttsPrepRecovery, setTtsPrepRecovery] = React.useState(null);
    var [audioRecoveryTarget, setAudioRecoveryTarget] = React.useState(null);
    var ttsPrepRequestRef = React.useRef(null);
    var audioProfileRevision = typeof window !== 'undefined' ? window.__alloReadAloudProfileRevision : null;
    var ttsPrepContext = JSON.stringify([generatedContent && generatedContent.id, simplifiedReadAloudText, selectedVoice, voiceSpeed, leveledTextLanguage, audioProfileRevision]);
    var ttsPrepContextRef = React.useRef(ttsPrepContext);
    ttsPrepContextRef.current = ttsPrepContext;
    React.useEffect(function () {
      setTtsPrepNotice('');
      setTtsPrepFailure(null);
      setTtsPrepState({ busy: false, done: 0, total: 0 });
      return function () {
        var request = ttsPrepRequestRef.current;
        ttsPrepRequestRef.current = null;
        if (request && request.controller) request.controller.abort();
      };
    }, [ttsPrepContext]);
    var ownsTtsPreparation = function (request) {
      return ttsPrepRequestRef.current === request && ttsPrepContextRef.current === request.context;
    };
    var saveTtsAsPlayed_state = React.useState(function () {
      // Default ON (2026-07-09): capture-as-you-play costs no extra synthesis;
      // '0' is the explicit per-device opt-out via the checkbox below.
      try { return localStorage.getItem('allo_save_karaoke_audio') !== '0'; } catch (_) { return true; }
    });
    var saveTtsAsPlayed = saveTtsAsPlayed_state[0];
    var setSaveTtsAsPlayed = saveTtsAsPlayed_state[1];
    // "Copy diagnostics" for the IN-VIEW read-aloud (playSequence path): the
    // karaoke overlay has its own button, but leveled-text playback happens
    // right here — surface the shared window.__alloTtsTrace ring where the
    // teacher is actually looking when audio gets stuck.
    var ttsDiagCopied_state = React.useState(false);
    var ttsDiagCopied = ttsDiagCopied_state[0];
    var setTtsDiagCopied = ttsDiagCopied_state[1];
    var _fallbackCopyTtsDiag = function (text) {
      try {
        var scratch = document.createElement('textarea');
        scratch.setAttribute('aria-label', 'Temporary field for copying read-aloud diagnostics');
        scratch.value = text;
        scratch.setAttribute('readonly', '');
        scratch.style.position = 'fixed';
        scratch.style.opacity = '0';
        document.body.appendChild(scratch);
        scratch.select();
        var ok = document.execCommand('copy');
        scratch.remove();
        return ok;
      } catch (e) { return false; }
    };
    var copyTtsDiagnostics = function () {
      var payload;
      try {
        payload = JSON.stringify({
          at: new Date().toISOString(),
          surface: 'leveled-text',
          userAgent: typeof navigator !== 'undefined' ? String(navigator.userAgent || '').substring(0, 120) : '',
          flags: {
            geminiQuotaFailed: !!window.__ttsGeminiQuotaFailed,
            geminiAuthFailed: !!window.__ttsGeminiAuthFailed,
            kokoroPresent: !!window._kokoroTTS,
            kokoroReady: !!(window._kokoroTTS && window._kokoroTTS.ready),
            sharedResolver: typeof window.__alloResolveReadAloudAudio === 'function',
          },
          lastRoute: window.__ttsLastRoute || null,
          trace: (window.__alloTtsTrace || []).slice(-120),
        }, null, 2);
      } catch (e) { payload = 'diagnostics-serialize-failed: ' + String((e && e.message) || e); }
      var done = function (ok) {
        if (!ok) return;
        setTtsDiagCopied(true);
        setTimeout(function () { setTtsDiagCopied(false); }, 2000);
      };
      try {
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(payload).then(function () { done(true); }, function () { done(_fallbackCopyTtsDiag(payload)); });
          return;
        }
      } catch (e) {}
      done(_fallbackCopyTtsDiag(payload));
    };
    var savingAudioKeys_state = React.useState({});
    var savingAudioKeys = savingAudioKeys_state[0];
    var setSavingAudioKeys = savingAudioKeys_state[1];
    var captureAudioErrors_state = React.useState({});
    var captureAudioErrors = captureAudioErrors_state[0];
    var setCaptureAudioErrors = captureAudioErrors_state[1];
    var regenAudioKey_state = React.useState(null);
    var editAudioPlaybackErrors_state = React.useState({});
    var editAudioPlaybackErrors = editAudioPlaybackErrors_state[0];
    var setEditAudioPlaybackErrors = editAudioPlaybackErrors_state[1];
    var regenAudioKey = regenAudioKey_state[0];
    var setRegenAudioKey = regenAudioKey_state[1];
    var [audioStatusTick, setAudioStatusTick] = React.useState(0);
    var editAudioOpen_state = React.useState(false);
    var editAudioOpen = editAudioOpen_state[0];
    var setEditAudioOpen = editAudioOpen_state[1];
    var editAudioToggleRef = React.useRef(null);
    var editAudioPlayingKey_state = React.useState(null);
    var editAudioPlayingKey = editAudioPlayingKey_state[0];
    var setEditAudioPlayingKey = editAudioPlayingKey_state[1];
    var editAudioLoadingKey_state = React.useState(null);
    var editAudioLoadingKey = editAudioLoadingKey_state[0];
    var setEditAudioLoadingKey = editAudioLoadingKey_state[1];
    var editAudioMicRequestKey_state = React.useState(null);
    var editAudioMicRequestKey = editAudioMicRequestKey_state[0];
    var setEditAudioMicRequestKey = editAudioMicRequestKey_state[1];
    var editAudioRecordingKey_state = React.useState(null);
    var editAudioRecordingKey = editAudioRecordingKey_state[0];
    var setEditAudioRecordingKey = editAudioRecordingKey_state[1];
    var editAudioRecordingSaveKey_state = React.useState(null);
    var editAudioRecordingSaveKey = editAudioRecordingSaveKey_state[0];
    var setEditAudioRecordingSaveKey = editAudioRecordingSaveKey_state[1];
    var removeAudioKey_state = React.useState(null);
    var removeAudioKey = removeAudioKey_state[0];
    var setRemoveAudioKey = removeAudioKey_state[1];
    var editAudioNotice_state = React.useState('');
    var editAudioNotice = editAudioNotice_state[0];
    var setEditAudioNotice = editAudioNotice_state[1];
    var editAudioPlayerRef = React.useRef(null);
    var editAudioPlayTokenRef = React.useRef(0);
    var editAudioRecordTokenRef = React.useRef(0);
    var editAudioMediaRecorderRef = React.useRef(null);
    var editAudioMediaStreamRef = React.useRef(null);
    var editAudioChunksRef = React.useRef([]);
    var editAudioRecordingTimerRef = React.useRef(null);
    var editAudioRecordingStartedAtRef = React.useRef(0);
    var EDIT_AUDIO_MAX_RECORDING_MS = 120000;
    var immersiveDialogRef = React.useRef(null);
    var [immersiveToolbarBottom, setImmersiveToolbarBottom] = React.useState(0);
    React.useEffect(function () {
      if (!isImmersiveReaderActive || !immersiveSettings?.lineFocus) return;
      var toolbar = immersiveDialogRef.current?.querySelector("[data-immersive-toolbar]");
      var update = function () {
        var bottom = toolbar?.getBoundingClientRect().bottom || 0;
        setImmersiveToolbarBottom(bottom);
        setImmersiveRulerY(previous => Math.max(previous, bottom + immersiveSettings.textSize * 2.5));
      };
      update();
      var observer = typeof ResizeObserver !== "undefined" ? new ResizeObserver(update) : null;
      if (toolbar) observer?.observe(toolbar);
      window.addEventListener("resize", update);
      return function () { observer?.disconnect(); window.removeEventListener("resize", update); };
    }, [isImmersiveReaderActive, immersiveSettings?.lineFocus, immersiveSettings?.textSize, setImmersiveRulerY]);
    var phonicsDialogRef = React.useRef(null);
    var phonicsCloseRef = React.useRef(null);
    var definitionDialogRef = React.useRef(null);
    var definitionCloseRef = React.useRef(null);
    var revisionDialogRef = React.useRef(null);
    var revisionCloseRef = React.useRef(null);
    var stopEditAudioPlayback = function () {
      editAudioPlayTokenRef.current += 1;
      try {
        if (editAudioPlayerRef.current) {
          editAudioPlayerRef.current.onended = null;
          editAudioPlayerRef.current.onerror = null;
          editAudioPlayerRef.current.pause();
        }
      } catch (_) {}
      editAudioPlayerRef.current = null;
      setEditAudioPlayingKey(null);
      setEditAudioLoadingKey(null);
    };
    var getReadAloudAudioKey = function (sentence, identityOptions) {
      var baseKey = '';
      try {
        var KS = window.AlloModules && window.AlloModules.KaraokeAudioStore;
        if (KS && typeof KS.keyFor === 'function') baseKey = KS.keyFor(sentence);
      } catch (_) {}
      if (!baseKey) baseKey = String(sentence || '').toLowerCase().replace(/\s+/g, ' ').trim();
      var occurrence = identityOptions && Number.isInteger(Number(identityOptions.occurrence)) ? Number(identityOptions.occurrence) : 0;
      return baseKey ? baseKey + '\u241f' + occurrence : '';
    };
    var updateEditAudioPlaybackIssue = function (sentence, issue, identityOptions) {
      var audioKey = getReadAloudAudioKey(sentence, identityOptions);
      if (!audioKey) return;
      setEditAudioPlaybackErrors(function (prev) {
        var next = Object.assign({}, prev);
        if (issue) next[audioKey] = issue;
        else delete next[audioKey];
        return next;
      });
    };
    var getEditAudioPlaybackIssue = function (sentence, identityOptions) {
      var issue = editAudioPlaybackErrors[getReadAloudAudioKey(sentence, identityOptions)];
      if (issue && issue.url) {
        var currentUrl = getStoredReadAloudAudioUrl(sentence, identityOptions);
        if (currentUrl && currentUrl !== issue.url) return null;
      }
      return issue;
    };
    var reportEditAudioPlaybackFailure = function (sentence, sentenceNumber, error, identityOptions, failedUrl) {
      if (error && error.name === 'AbortError') return;
      if (error && error.name === 'NotAllowedError') {
        setEditAudioNotice(viewText('simplified.audio_audio_playback_was_blocked_press_play', 'Audio playback was blocked. Press Play again.'));
        return;
      }
      var currentUrl = getStoredReadAloudAudioUrl(sentence, identityOptions);
      // A late rejection from the old element must not quarantine its replacement.
      if (failedUrl && currentUrl && currentUrl !== failedUrl) return;
      updateEditAudioPlaybackIssue(sentence, {
        code: error && error.name ? error.name : 'playback-failed',
        reason: 'The saved audio could not be decoded or loaded.',
        url: failedUrl || currentUrl || null
      }, identityOptions);
      setEditAudioNotice('Saved audio for sentence ' + sentenceNumber + ' could not be played. Rebuild or replace it.');
      // Share a confirmed decoder/load failure with preparation and every reader.
      // Autoplay denial above is not evidence that the saved clip is corrupt.
      try {
        if (typeof window.__alloQuarantineReadAloudAudio === 'function') {
          Promise.resolve(window.__alloQuarantineReadAloudAudio(sentence, {
            code: 'media-playback-failed', reason: 'The saved audio could not be decoded or loaded.'
          }, identityOptions || {})).then(function () { setAudioStatusTick(function (n) { return n + 1; }); }).catch(function () {});
        }
      } catch (_) {}
    };
    var setSaveTtsAsPlayedEnabled = function (value) {
      var next = !!value;
      setSaveTtsAsPlayed(next);
      try { localStorage.setItem('allo_save_karaoke_audio', next ? '1' : '0'); } catch (_) {}
    };
    React.useEffect(function () {
      if (props.isStudentPreview || typeof window === 'undefined') return;
      var onAudioUpdate = function (event) {
        var resourceId = event && event.detail && event.detail.resourceId;
        if (resourceId && generatedContent && generatedContent.id && resourceId !== generatedContent.id) return;
        setAudioStatusTick(function (n) { return n + 1; });
      };
      var onAudioCapture = function (event) {
        var detail = event && event.detail ? event.detail : {};
        if (generatedContent && generatedContent.id && detail.resourceId && detail.resourceId !== generatedContent.id) return;
        var key = getReadAloudAudioKey(detail.sentence, detail);
        if (!key) return;
        if (detail.status === 'saving') {
          setSavingAudioKeys(function (prev) { return Object.assign({}, prev, { [key]: true }); });
          setCaptureAudioErrors(function (prev) {
            var next = Object.assign({}, prev);
            delete next[key];
            return next;
          });
        } else {
          setSavingAudioKeys(function (prev) {
            var next = Object.assign({}, prev);
            delete next[key];
            return next;
          });
          setCaptureAudioErrors(function (prev) {
            var next = Object.assign({}, prev);
            if (detail.status === 'error' || detail.status === 'limit') {
              next[key] = {
                status: detail.status,
                code: detail.code || 'capture-failed',
                reason: detail.reason || 'Played TTS could not be saved.'
              };
            } else {
              delete next[key];
            }
            return next;
          });
          if (detail.status === 'error' || detail.status === 'limit') {
            setEditAudioNotice(detail.reason || 'Played TTS could not be saved. Generate that sentence again to retry.');
          } else {
            updateEditAudioPlaybackIssue(detail.sentence, null, detail);
          }
          setAudioStatusTick(function (n) { return n + 1; });
        }
      };
      window.addEventListener('alloflow:karaoke-audio-updated', onAudioUpdate);
      window.addEventListener('alloflow:karaoke-audio-capture', onAudioCapture);
      window.addEventListener('alloflow:read-aloud-reconciled', onAudioUpdate);
      window.addEventListener('alloflow:module-registry-changed', onAudioUpdate);
      return function () {
        window.removeEventListener('alloflow:karaoke-audio-updated', onAudioUpdate);
        window.removeEventListener('alloflow:karaoke-audio-capture', onAudioCapture);
        window.removeEventListener('alloflow:read-aloud-reconciled', onAudioUpdate);
        window.removeEventListener('alloflow:module-registry-changed', onAudioUpdate);
      };
    }, [generatedContent && generatedContent.id]);
    React.useEffect(function () { setSavingAudioKeys({}); setCaptureAudioErrors({}); setEditAudioPlaybackErrors({}); }, [generatedContent && generatedContent.id]);
    React.useEffect(function () {
      if (canManageNarration) return;
      setEditAudioOpen(false);
      stopEditAudioPlayback();
      editAudioRecordTokenRef.current += 1;
      setEditAudioMicRequestKey(null);
      var recorder = editAudioMediaRecorderRef.current;
      try { if (recorder && recorder.state !== 'inactive') recorder.stop(); } catch (_) {}
    }, [canManageNarration]);
    React.useEffect(function () {
      setEditAudioOpen(false);
      stopEditAudioPlayback();
      setEditAudioMicRequestKey(null);
      setEditAudioRecordingKey(null);
      setEditAudioRecordingSaveKey(null);
      setRemoveAudioKey(null);
      setEditAudioNotice('');
      return function () {
        editAudioPlayTokenRef.current += 1;
        editAudioRecordTokenRef.current += 1;
        try {
          if (editAudioPlayerRef.current) {
            editAudioPlayerRef.current.onended = null;
            editAudioPlayerRef.current.onerror = null;
            editAudioPlayerRef.current.pause();
          }
        } catch (_) {}
        editAudioPlayerRef.current = null;
        if (editAudioRecordingTimerRef.current) clearTimeout(editAudioRecordingTimerRef.current);
        editAudioRecordingTimerRef.current = null;
        var recorder = editAudioMediaRecorderRef.current;
        try {
          if (recorder && recorder.state !== 'inactive') {
            recorder.onstop = null;
            recorder.stop();
          }
        } catch (_) {}
        editAudioMediaRecorderRef.current = null;
        var stream = editAudioMediaStreamRef.current;
        try { if (stream) stream.getTracks().forEach(function (track) { track.stop(); }); } catch (_) {}
        editAudioMediaStreamRef.current = null;
        editAudioChunksRef.current = [];
      };
    }, [generatedContent && generatedContent.id]);
    var cleanSentenceForAudio = function (sentence) {
      // Must mirror playSequence's textToSpeak cleaning (phase_k) — the store
      // key is derived from the cleaned sentence on BOTH sides, so a rule
      // present in one place but not the other orphans that sentence's audio.
      // Delegate to THE shared sanitizer when the phase_k module is loaded
      // (2026-07-17) so the two can never drift; the inline chain below is
      // the standalone fallback and must stay rule-identical to it.
      try {
        var _pk = window.AlloModules && window.AlloModules.PhaseKHelpers;
        if (_pk && typeof _pk.toSpokenText === 'function') return _pk.toSpokenText(sentence);
      } catch (_) {}
      return String(sentence || '').replace(/\[([^\]]+)\]\([^\)]+\)/g, '$1').replace(/\[?⁽[⁰¹²³⁴⁵⁶⁷⁸⁹]+⁾\]?/g, '').replace(/\[Source\s+\d+\]/gi, '').replace(/\[\d+\]/g, '').replace(/^#{1,6}\s+/gm, '').replace(/\*\*/g, '').replace(/\*/g, '').replace(/__|_/g, '').replace(/~~/g, '').replace(/`/g, '').replace(/^>\s?/gm, '').replace(/^[-*+]\s/gm, '').replace(/^\d+\.\s/gm, '').replace(/\s+/g, ' ').trim();
    };
    var getReadAloudStore = function () {
      try {
        return window.AlloModules && window.AlloModules.KaraokeAudioStore && window.AlloModules.KaraokeAudioStore.current;
      } catch (_) {
        return null;
      }
    };
    var readAloudStore = getReadAloudStore();
    var readAloudStoreRevision = readAloudStore && typeof readAloudStore.getRevision === 'function' ? readAloudStore.getRevision() : 0;
    React.useEffect(function () {
      // Summary/host hydration may initialize or replace the store during
      // render. Subscribe to the committed store, then close that timing gap.
      var store = getReadAloudStore();
      if (!store || typeof store.subscribe !== 'function') return;
      var active = true, queued = false;
      var refresh = function () {
        if (!active || queued) return;
        queued = true;
        // Legacy inspection can promote a clip during render. Defer the
        // React update and coalesce synchronous batches of saved sentences.
        Promise.resolve().then(function () {
          queued = false;
          if (active) setAudioStatusTick(function (n) { return n + 1; });
        });
      };
      var unsubscribe = store.subscribe(refresh);
      if (store !== readAloudStore || (typeof store.getRevision === 'function' && store.getRevision() !== readAloudStoreRevision)) refresh();
      return function () { active = false; if (typeof unsubscribe === 'function') unsubscribe(); };
    }, [readAloudStore, readAloudStoreRevision, audioStatusTick, generatedContent?.id, generatedContent?.karaokeAudio]);
    var getStoredReadAloudAudioUrl = function (sentence, identityOptions) {
      try {
        var sharedInspect = typeof window !== 'undefined' && window.__alloInspectReadAloudAudio;
        if (typeof sharedInspect === 'function') {
          var inspection = sharedInspect(sentence, 'reference', identityOptions);
          if (inspection && inspection.storedUrl) return inspection.storedUrl;
          if (inspection && inspection.status === 'ready' && inspection.url) return inspection.url;
        }
      } catch (_) {}
      var st = getReadAloudStore();
      try {
        return st && typeof st.get === 'function' ? st.get(sentence, identityOptions || {}) : null;
      } catch (_) {
        return null;
      }
    };
    // The host can refresh callTTS while modules finish loading. Keep the
    // resolver identity tied only to the actual voice profile so capture-status
    // renders do not repeatedly invalidate karaoke's warm cache.
    var karaokeCallTTSRef = React.useRef(callTTS);
    karaokeCallTTSRef.current = callTTS;
    var getKaraokeAudioUrl = React.useCallback(function (sentenceText, requestOptions, languageOverride) {
      var voice = selectedVoice || (typeof window !== 'undefined' && window.__alloSelectedVoice) || 'Kore';
      var speed = typeof voiceSpeed === 'number' && voiceSpeed > 0 ? voiceSpeed : 1;
      var language = languageOverride || leveledTextLanguage || 'English';
      var options = Object.assign({
        language: language,
        maxRetries: 1,
        priority: 'interactive'
      }, requestOptions || {});
      options.language = language;
      // Snapshot the synthesis profile with the request. The shared service uses
      // it for compatibility and provider resolution, so a settings change
      // mid-request cannot relabel the voice the learner actually heard.
      options.profile = Object.assign({}, options.profile || {}, {
        voice: voice,
        speed: speed,
        synthesisRate: speed,
        language: language,
        voiceResolverVersion: 2
      });
      try {
        var sharedResolver = typeof window !== 'undefined' && window.__alloResolveReadAloudAudio;
        if (typeof sharedResolver === 'function') {
          return Promise.resolve(sharedResolver(sentenceText, options)).catch(function () { return null; });
        }
      } catch (_) {}
      // Direct store/callTTS compatibility path while the shared host module loads.
      try {
        var st = window.AlloModules && window.AlloModules.KaraokeAudioStore && window.AlloModules.KaraokeAudioStore.current;
        if (st) {
          // Stored-clip compatibility guard (2026-07-17): this resolver used
          // to return st.get() blind, bypassing the voice guard the main
          // playSequence path applies — so an older Puck AI clip kept playing
          // after the teacher selected Kore. The store's shared getCompatible
          // enforces voice/speed/language for AI takes; human recordings
          // remain voice-independent and always play.
          if (typeof st.getCompatible === 'function') {
            var compatibleUrl = st.getCompatible(sentenceText, { voice: voice, speed: speed, language: language });
            if (compatibleUrl) return Promise.resolve(compatibleUrl);
          } else {
            var storedUrl = st.get(sentenceText);
            if (storedUrl) return Promise.resolve(storedUrl);
          }
        }
      } catch (_) {}
      var resolver = karaokeCallTTSRef.current;
      if (typeof resolver !== 'function') return Promise.resolve(null);
      return Promise.resolve(resolver(sentenceText, voice, speed, options, language)).catch(function () { return null; });
    }, [selectedVoice, voiceSpeed, leveledTextLanguage]);
    var getComparisonKaraokeAudioUrl = React.useCallback(function (sentence, options) {
      var occurrence = options && options.occurrence || 0;
      var entry = comparisonKaraoke?.entries.find(item => item.text === sentence && item.occurrence === occurrence);
      return getKaraokeAudioUrl(sentence, options, entry?.language || comparisonKaraoke?.language);
    }, [getKaraokeAudioUrl, comparisonKaraoke]);
    var getReadAloudAudioProvenance = function (sentence, identityOptions) {
      var inspection = null;
      try {
        var sharedInspect = typeof window !== 'undefined' && window.__alloInspectReadAloudAudio;
        if (typeof sharedInspect === 'function') inspection = sharedInspect(sentence, 'reference', identityOptions);
      } catch (_) {}
      var st = getReadAloudStore();
      var source = inspection && inspection.source != null ? inspection.source : null;
      var metadata = inspection && inspection.metadata ? inspection.metadata : null;
      if (!inspection) {
        try {
          if (st && typeof st.sourceOf === 'function') source = st.sourceOf(sentence, identityOptions || {});
          if (st && typeof st.metadataOf === 'function') metadata = st.metadataOf(sentence, identityOptions || {});
        } catch (_) {}
      }
      if (source === 'human-teacher') return { source: source, label: simplifiedTeacherRecordingLabel, metadata: metadata, stale: false };
      if (source === 'human-student') return { source: source, label: simplifiedStudentRecordingLabel, metadata: metadata, stale: false };
      if (source && String(source).indexOf('human') === 0) return { source: source, label: simplifiedHumanRecordingLabel, metadata: metadata, stale: false };
      var currentVoice = selectedVoice || (typeof window !== 'undefined' && window.__alloSelectedVoice) || 'Kore';
      var currentSpeed = typeof voiceSpeed === 'number' && voiceSpeed > 0 ? voiceSpeed : 1;
      var currentLanguage = identityOptions && identityOptions.language ? identityOptions.language : (leveledTextLanguage || 'English');
      var stale = inspection
        ? inspection.status === 'stale'
        : (!metadata || Number(metadata.voiceResolverVersion) !== 2 || !!(
          (metadata.voice && String(metadata.voice).toLowerCase() !== String(currentVoice).toLowerCase()) ||
          (metadata.speed && Math.abs(Number(metadata.speed) - currentSpeed) > 0.001) ||
          (metadata.language && String(metadata.language).toLowerCase() !== String(currentLanguage).toLowerCase())
        ));
      var details = ['AI voice'];
      if (metadata && metadata.voice) details.push(metadata.voice);
      if (metadata && metadata.speed) details.push(Number(metadata.speed) + '×');
      if (metadata && metadata.language) details.push(metadata.language);
      return { source: source || 'ai', label: details.join(' · '), metadata: metadata, stale: stale };
    };
    var hasStoredReadAloudAudio = function (sentence, identityOptions) {
      try {
        var sharedInspect = typeof window !== 'undefined' && window.__alloInspectReadAloudAudio;
        if (typeof sharedInspect === 'function') {
          var inspection = sharedInspect(sentence, 'reference', identityOptions);
          if (inspection && inspection.status) return inspection.status === 'ready' || inspection.status === 'stale';
        }
      } catch (_) {}
      var st = getReadAloudStore();
      try { return !!(st && st.has(sentence, identityOptions || {})); } catch (_) { return false; }
    };
    var getReadAloudIdentityOptions = function (entry) {
      var language = entry && entry.language ? entry.language : (leveledTextLanguage || 'English');
      var speed = typeof voiceSpeed === 'number' && voiceSpeed > 0 ? voiceSpeed : 1;
      var voice = selectedVoice || (typeof window !== 'undefined' && window.__alloSelectedVoice) || 'Kore';
      return {
        occurrence: entry && Number.isInteger(Number(entry.occurrence)) ? Number(entry.occurrence) : 0,
        identity: entry && entry.identity ? entry.identity : null,
        language: language,
        profile: { voice: voice, speed: speed, synthesisRate: speed, language: language, voiceResolverVersion: 2 }
      };
    };
    var getReadAloudAudioSummary = function (sentences) {
      var list = Array.isArray(sentences) ? sentences : [];
      var entries = list.map(function (item, index) {
        return item && typeof item === 'object' ? item : { text: String(item || ''), occurrence: 0, identity: 'legacy:' + index };
      });
      var sharedSummary = null;
      try {
        var summaryResolver = typeof window !== 'undefined' && window.__alloGetReadAloudAudioSummary;
        if (typeof summaryResolver === 'function') {
          sharedSummary = summaryResolver(entries.map(function (entry) { return entry.text; }), 'reference', { entries: entries, profile: getReadAloudIdentityOptions().profile });
        }
      } catch (_) {}
      // Raw storage presence is useful in Edit Audio but is not readiness.
      // A missing bridge cannot establish current segment/profile compatibility.
      var count = function (value) { return Number.isFinite(Number(value)) ? Math.max(0, Math.min(entries.length, Math.floor(Number(value)))) : 0; };
      var ready = count(sharedSummary && sharedSummary.ready);
      var stale = count(sharedSummary && sharedSummary.stale);
      var corrupt = count(sharedSummary && sharedSummary.corrupt);
      var missing = Math.max(count(sharedSummary && sharedSummary.missing), entries.length - ready - stale - corrupt);
      var unverifiedFailure = false;
      entries.forEach(function (entry) {
        var options = getReadAloudIdentityOptions(entry);
        if (!getEditAudioPlaybackIssue(entry.text, options)) return;
        var inspection = null;
        try { inspection = window.__alloInspectReadAloudAudio && window.__alloInspectReadAloudAudio(entry.text, 'reference', options); } catch (_) {}
        if (inspection && inspection.status === 'ready') { ready = Math.max(0, ready - 1); corrupt += 1; }
        else if (!inspection || !['stale', 'corrupt', 'missing'].includes(inspection.status)) unverifiedFailure = true;
      });
      // Fail closed if an editor failure cannot be matched to the shared summary.
      var unavailable = !sharedSummary || unverifiedFailure;
      if (unavailable) { ready = 0; missing = Math.max(0, entries.length - stale - corrupt); }
      var saved = sharedSummary ? count(sharedSummary.ready) + stale
        : entries.reduce(function (n, entry) { return n + (hasStoredReadAloudAudio(entry.text, getReadAloudIdentityOptions(entry)) ? 1 : 0); }, 0);
      var bytes = sharedSummary ? Number(sharedSummary.estimatedBytes || 0) : 0;
      var maxBytes = 0;
      try {
        var st = getReadAloudStore();
        if (!sharedSummary && st && typeof st.estimateBytes === 'function') bytes = st.estimateBytes();
        if (st && typeof st.limits === 'function') maxBytes = st.limits().maxBytes || 0;
      } catch (_) {}
      var unverified = Math.min(stale, count(sharedSummary && sharedSummary.unverified));
      return { saved: saved, ready: ready, stale: stale, corrupt: corrupt, missing: missing, unverified: unverified, unavailable: unavailable, total: entries.length, bytes: bytes, maxBytes: maxBytes };
    };
    var getReadAloudSentenceEntriesForText = function (rawText, sourceLanguage) {
      var text = typeof rawText === 'string' ? rawText : String(rawText || '');
      var isTableText = function (p) { return p.trim().startsWith('|') || p.indexOf('\n|') !== -1; };
      var splitForReadAloud = function (part) {
        try {
          var KS = window.AlloModules && window.AlloModules.KaraokeAudioStore;
          if (KS && typeof KS.splitSentences === 'function') return KS.splitSentences(part);
        } catch (_) {}
        return splitTextToSentences(part);
      };
      var splitBlock = function (block) {
        return String(block || '').split(/\n{2,}/).flatMap(function (p) { return isTableText(p) ? [] : splitForReadAloud(p); });
      };
      var parts = getSideBySideContent(text);
      var sourceList = [];
      var targetList = [];
      if (parts) {
        sourceList = parts.source.flatMap(function (p) { return isTableText(p) ? [] : splitForReadAloud(p); });
        targetList = parts.target.flatMap(function (p) { return isTableText(p) ? [] : splitForReadAloud(p); });
      } else {
        var marker = '--- ENGLISH TRANSLATION ---';
        var markerIndex = text.indexOf(marker);
        if (markerIndex >= 0) {
          sourceList = splitBlock(text.slice(0, markerIndex));
          targetList = splitBlock(text.slice(markerIndex + marker.length));
        } else {
          sourceList = splitBlock(text);
        }
      }
      var counts = new Map();
      var makeEntries = function (list, language, scope) {
        return list.map(function (sentence, index) {
          var cleaned = cleanSentenceForAudio(sentence);
          if (!cleaned || !cleaned.trim()) return null;
          // Match Phase K and the shared service exactly: occurrence is scoped
          // to identical spoken text. Case-folding here made distinct spoken
          // sentences consume each other's duplicate slot.
          var countKey = cleaned;
          var occurrence = counts.get(countKey) || 0;
          counts.set(countKey, occurrence + 1);
          return {
            text: cleaned,
            language: language || 'English',
            occurrence: occurrence,
            identity: scope + ':' + index + ':' + occurrence
          };
        }).filter(Boolean);
      };
      return makeEntries(sourceList, sourceLanguage || leveledTextLanguage || 'English', 'source')
        .concat(makeEntries(targetList, readingTranslationLanguage, 'target'));
    };
    var narrationSentences = React.useMemo(function () {
      return canManageNarration ? getReadAloudSentenceEntriesForText(simplifiedReadAloudText) : [];
    }, [canManageNarration, simplifiedReadAloudText, leveledTextLanguage, readingTranslationLanguage]);
    var narrationSummary = React.useMemo(function () {
      if (!canManageNarration) return null;
      return getReadAloudAudioSummary(narrationSentences);
    }, [canManageNarration, narrationSentences, generatedContent?.id, generatedContent?.karaokeAudio, selectedVoice, voiceSpeed, leveledTextLanguage, audioProfileRevision, audioStatusTick, readAloudStore, readAloudStoreRevision, editAudioPlaybackErrors, ttsPrepState.done, ttsPrepState.busy, isPlaying]);
    // The sentences Immersive highlights and the chunk reader counts: the list
    // playback speaks (phase_k handleSpeak), with every table paragraph skipped.
    // Computed once per text: the read-along sweep re-renders every animation frame.
    var immersiveSentences = React.useMemo(function () {
      if (!isImmersiveReaderActive) return [];
      var isTable = p => p.trim().startsWith('|') || p.includes('\n|');
      var sideBySide = getSideBySideContent(simplifiedReadAloudText);
      var paragraphs = sideBySide ? [...(sideBySide.source || []), ...(sideBySide.target || [])] : simplifiedReadAloudText.split(/\n{2,}/);
      return paragraphs.flatMap(p => isTable(p) ? [] : splitTextToSentences(p));
    }, [isImmersiveReaderActive, simplifiedReadAloudText]);
    var immersiveSentenceOfWord = React.useMemo(function () {
      return isImmersiveReaderActive && Array.isArray(generatedContent?.immersiveData) ? alignImmersiveWords(generatedContent.immersiveData, immersiveSentences, cleanSentenceForAudio) : [];
    }, [isImmersiveReaderActive, generatedContent?.immersiveData, immersiveSentences]);
    var immersiveWordGroups = React.useMemo(function () {
      if (!isImmersiveReaderActive || !Array.isArray(generatedContent?.immersiveData)) return [];
      var groups = [];
      generatedContent.immersiveData.forEach(function (wordData, index) {
        var sentence = immersiveSentenceOfWord[index], last = groups[groups.length - 1];
        // Newlines do not reset the active sentence's character clock.
        if (!last || (wordData.pos !== 'newline' && last.sentence !== sentence)) {
          last = { sentence: sentence, sweepWeight: Math.max(1, cleanSentenceForAudio(immersiveSentences[sentence] || '').replace(/\s+/g, '').length), words: [] };
          groups.push(last);
        }
        last.words.push({ wordData: wordData, index: index });
      });
      return groups;
    }, [isImmersiveReaderActive, generatedContent?.id, generatedContent?.data, generatedContent?.immersiveData, immersiveSentenceOfWord, immersiveSentences, props.readingLearnerKey, props.isStudentPreview]);
    // Give memoized words a fresh settings object even if a host edits settings in place.
    var immersiveSettingsVersion = JSON.stringify(immersiveSettings);
    var immersiveWordSettings = React.useMemo(() => ({ ...immersiveSettings }), [immersiveSettings, immersiveSettingsVersion]);
    var immersiveInteractionRef = React.useRef(null);
    React.useLayoutEffect(function () {
      immersiveInteractionRef.current = { words: generatedContent?.immersiveData, sentenceOfWord: immersiveSentenceOfWord,
        interactionMode, isChunkReaderActive, setChunkReaderIdx, handleWordClick, handlePhonicsClick, handleSpeak };
    });
    var handleImmersiveWordClick = React.useCallback(function (event) {
      event.stopPropagation();
      var current = immersiveInteractionRef.current;
      var index = Number(event.currentTarget.closest('[data-immersive-word-index]')?.getAttribute('data-immersive-word-index'));
      var word = current?.words?.[index];
      if (!word) return;
      if (current.interactionMode === 'define') return current.handleWordClick(word.text, event);
      if (current.interactionMode === 'phonics') return current.handlePhonicsClick(word.text, event, { audioPlayback: 'reader' });
      if (current.isChunkReaderActive) {
        var sentence = current.sentenceOfWord[index];
        if (sentence >= 0) current.setChunkReaderIdx(sentence);
      } else {
        var spoken = String(word.text || '').replace(/\s+/g, ' ').trim();
        if (spoken && typeof current.handleSpeak === 'function') current.handleSpeak(spoken, 'immersive-word-' + (word.id || index), 0, true);
      }
    }, []);
    var getReadAloudSentencesForText = function (rawText) {
      return getReadAloudSentenceEntriesForText(rawText).map(function (entry) { return entry.text; });
    };
    var karaokeReaderSentences = React.useMemo(function () {
      return getReadAloudSentencesForText(simplifiedReadAloudText);
    }, [generatedContent && generatedContent.data]);
    // Announcing every sentence again, in English, talked over the voice that
    // was reading it. Say only that read-aloud started.
    var activeReadAloudStatus = React.useMemo(function () {
      if (!isPlaying || (playingContentId && playingContentId !== 'simplified-main')) return '';
      var label = t('simplified.read_aloud_status');
      return label && label !== 'simplified.read_aloud_status' ? label : 'Reading aloud';
    }, [isPlaying, playingContentId]);
    var handlePrepareReadAloudAudio = async function () {
      if (ttsPrepRequestRef.current) return;
      if (typeof window.__alloPrepareReadAloud !== 'function') {
        setTtsPrepNotice(viewText('simplified.audio_audio_tools_are_still_loading_please', 'Audio tools are still loading. Please try again.'));
        return;
      }
      var entries = getReadAloudSentenceEntriesForText(simplifiedReadAloudText);
      var sentences = entries.map(function (entry) { return entry.text; });
      if (!sentences.length) return;
      // Note: prep saves every sentence regardless of the capture toggle, and
      // capture now defaults ON — no longer force-enable it here, so a
      // teacher's explicit opt-out survives pressing Save TTS.
      var request = { context: ttsPrepContext, controller: typeof AbortController === 'function' ? new AbortController() : null };
      ttsPrepRequestRef.current = request;
      setTtsPrepNotice('');
      setTtsPrepFailure(null);
      setTtsPrepRecovery(null);
      setTtsPrepState({ busy: true, done: 0, total: sentences.length });
      try {
        var result = await window.__alloPrepareReadAloud(sentences, function (done, total) {
          if (ownsTtsPreparation(request)) setTtsPrepState({ busy: true, done: done, total: total || sentences.length });
        }, { entries: entries, signal: request.controller && request.controller.signal });
        if (!ownsTtsPreparation(request)) return;
        var failures = (Array.isArray(result?.failures) ? result.failures : []).filter(function (failure) {
          return Number.isInteger(failure.index) && entries[failure.index]?.text === failure.text;
        });
        setTtsPrepRecovery(failures.length ? { context: request.context, failures: failures } : null);
        if (result && result.cancelled) {
          setTtsPrepNotice(viewText('simplified.offline_audio_stopped', 'Audio preparation stopped. Completed clips are kept; prepare missing audio to continue.'));
        } else if (result && result.remaining) {
          setTtsPrepFailure(result.failure || { code: 'preparation-incomplete' });
          setTtsPrepNotice(failures.length
            ? viewText('simplified.audio_recovery_remaining', 'Last preparation: {count} clips needed attention. Review any remaining sentences below.', { count: result.remaining })
            : (result.failure && result.failure.reason) || (result.remaining + ' sentence audio clips remain. Run Save TTS again to retry only missing clips.'));
        } else if (result && result.ok) {
          setTtsPrepNotice(viewText('simplified.offline_audio_prepared_checking', 'Audio is prepared. Checking whether it is saved on this device.'));
        }
      } catch (error) {
        if (ownsTtsPreparation(request) && !request.controller?.signal.aborted) setTtsPrepFailure({ code: error?.code || 'preparation-failed' });
        if (ownsTtsPreparation(request)) setTtsPrepNotice(request.controller && request.controller.signal.aborted
          ? 'Audio saving stopped. Save TTS again to finish any missing clips.'
          : 'Audio could not be saved. Please try again.');
      } finally {
        if (ownsTtsPreparation(request)) {
          ttsPrepRequestRef.current = null;
          setTtsPrepState({ busy: false, done: 0, total: 0 });
          setAudioStatusTick(function (n) { return n + 1; });
          if (deviceAudioRefreshRef.current) deviceAudioRefreshRef.current();
        }
      }
    };
    var handleRegenerateReadAloudSentence = async function (sentence, key, sentenceNumber, identityOptions) {
      if (!sentence || regenAudioKey) return;
      if (typeof window.__alloRegenerateSentenceAudio !== 'function') {
        setEditAudioNotice(viewText('simplified.audio_sentence_audio_tools_are_still_loading', 'Sentence audio tools are still loading. Please try again.'));
        return;
      }
      var wasSaved = hasStoredReadAloudAudio(sentence, identityOptions);
      if (editAudioPlayerRef.current && editAudioPlayerRef.current._alloSentenceKey === key) stopEditAudioPlayback();
      setRegenAudioKey(key);
      setEditAudioNotice((wasSaved ? 'Regenerating' : 'Generating') + ' sentence ' + sentenceNumber + ' audio...');
      try {
        var url = await window.__alloRegenerateSentenceAudio(sentence, identityOptions || {});
        if (!url) throw new Error(viewText('simplified.audio_no_audio_was_returned', 'No audio was returned'));
        updateEditAudioPlaybackIssue(sentence, null, identityOptions);
        setAudioStatusTick(function (n) { return n + 1; });
        setEditAudioNotice((wasSaved ? 'Regenerated' : 'Generated') + ' audio for sentence ' + sentenceNumber + '.');
      } catch (_) {
        setEditAudioNotice('Could not generate audio for sentence ' + sentenceNumber + '. Please try again.');
      } finally {
        setRegenAudioKey(null);
      }
    };
    var handlePlayEditAudioSentence = async function (sentence, key, sentenceNumber, identityOptions) {
      if (!sentence || editAudioLoadingKey) return;
      var current = editAudioPlayerRef.current;
      var storedUrl = getStoredReadAloudAudioUrl(sentence, identityOptions);
      // A store replacement/deletion must not replay the old decoded element.
      // Blob URLs are immutable: a changed URL means a different artifact.
      if (current && current._alloSentenceKey === key && storedUrl && current._alloStoredUrl === storedUrl) {
        if (!current.paused) {
          try { current.pause(); } catch (_) {}
          setEditAudioPlayingKey(null);
          setEditAudioNotice('Paused sentence ' + sentenceNumber + '.');
          return;
        }
        try {
          if (isFinite(current.duration) && current.currentTime >= current.duration) current.currentTime = 0;
          await current.play();
          updateEditAudioPlaybackIssue(sentence, null, identityOptions);
          setEditAudioPlayingKey(key);
          setEditAudioNotice('Playing sentence ' + sentenceNumber + '.');
        } catch (error) {
          reportEditAudioPlaybackFailure(sentence, sentenceNumber, error, identityOptions, current._alloStoredUrl);
        }
        return;
      }
      if (current) stopEditAudioPlayback();
      if (!hasStoredReadAloudAudio(sentence, identityOptions)) {
        setEditAudioNotice('Generate or record audio for sentence ' + sentenceNumber + ' before playing it.');
        return;
      }
      stopEditAudioPlayback();
      var token = ++editAudioPlayTokenRef.current;
      setEditAudioLoadingKey(key);
      setEditAudioNotice('Loading sentence ' + sentenceNumber + ' audio...');
      try {
        var url = getStoredReadAloudAudioUrl(sentence, identityOptions);
        if (token !== editAudioPlayTokenRef.current) return;
        if (!url) throw new Error(viewText('simplified.audio_no_saved_audio_url', 'No saved audio URL'));
        var audio = new Audio(url);
        audio._alloSentenceKey = key;
        audio._alloStoredUrl = url;
        audio.preload = 'auto';
        // Preview the stored artifact exactly as students receive it.
        audio.playbackRate = 1;
        audio.onended = function () {
          if (editAudioPlayerRef.current === audio) {
            setEditAudioPlayingKey(null);
            setEditAudioNotice('Finished sentence ' + sentenceNumber + '.');
          }
        };
        audio.onerror = function () {
          if (editAudioPlayerRef.current === audio) {
            editAudioPlayerRef.current = null;
            setEditAudioPlayingKey(null);
            reportEditAudioPlaybackFailure(sentence, sentenceNumber, audio.error, identityOptions, audio._alloStoredUrl);
          }
        };
        editAudioPlayerRef.current = audio;
        await audio.play();
        if (token !== editAudioPlayTokenRef.current) {
          try { audio.pause(); } catch (_) {}
          return;
        }
        updateEditAudioPlaybackIssue(sentence, null, identityOptions);
        setEditAudioPlayingKey(key);
        setEditAudioNotice('Playing sentence ' + sentenceNumber + '.');
      } catch (error) {
        if (token === editAudioPlayTokenRef.current) {
          editAudioPlayerRef.current = null;
          setEditAudioPlayingKey(null);
          reportEditAudioPlaybackFailure(sentence, sentenceNumber, error, identityOptions, url);
        }
      } finally {
        if (token === editAudioPlayTokenRef.current) setEditAudioLoadingKey(null);
      }
    };
    var releaseEditAudioStream = function () {
      if (editAudioRecordingTimerRef.current) clearTimeout(editAudioRecordingTimerRef.current);
      editAudioRecordingTimerRef.current = null;
      var stream = editAudioMediaStreamRef.current;
      try { if (stream) stream.getTracks().forEach(function (track) { track.stop(); }); } catch (_) {}
      editAudioMediaStreamRef.current = null;
    };
    var handleRecordEditAudioSentence = async function (sentence, key, sentenceNumber, identityOptions) {
      var activeRecorder = editAudioMediaRecorderRef.current;
      if (activeRecorder && activeRecorder._alloSentenceKey === key && activeRecorder.state !== 'inactive') {
        try {
          activeRecorder.stop();
          setEditAudioNotice('Finishing the recording for sentence ' + sentenceNumber + '...');
        } catch (_) {}
        return;
      }
      if (!sentence || editAudioRecordingKey || editAudioMicRequestKey || editAudioRecordingSaveKey) return;
      if (typeof window.__alloStoreRecordedSentenceAudio !== 'function') {
        setEditAudioNotice(viewText('simplified.audio_recorded_audio_storage_is_still_loading', 'Recorded-audio storage is still loading. Please try again.'));
        return;
      }
      if (typeof navigator === 'undefined' || !navigator.mediaDevices || typeof navigator.mediaDevices.getUserMedia !== 'function' || typeof window.MediaRecorder === 'undefined') {
        setEditAudioNotice(viewText('simplified.audio_microphone_recording_is_not_supported_in', 'Microphone recording is not supported in this browser.'));
        return;
      }
      stopEditAudioPlayback();
      var requestToken = ++editAudioRecordTokenRef.current;
      setEditAudioMicRequestKey(key);
      setEditAudioNotice('Opening the microphone for sentence ' + sentenceNumber + '...');
      var stream = null;
      try {
        stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        if (requestToken !== editAudioRecordTokenRef.current) {
          try { stream.getTracks().forEach(function (track) { track.stop(); }); } catch (_) {}
          return;
        }
        editAudioMediaStreamRef.current = stream;
        var MediaRecorderCtor = window.MediaRecorder;
        var preferredTypes = ['audio/webm;codecs=opus', 'audio/webm', 'audio/ogg;codecs=opus', 'audio/mp4'];
        var mimeType = '';
        if (typeof MediaRecorderCtor.isTypeSupported === 'function') {
          for (var typeIdx = 0; typeIdx < preferredTypes.length; typeIdx++) {
            if (MediaRecorderCtor.isTypeSupported(preferredTypes[typeIdx])) { mimeType = preferredTypes[typeIdx]; break; }
          }
        }
        var recorder = mimeType ? new MediaRecorderCtor(stream, { mimeType: mimeType }) : new MediaRecorderCtor(stream);
        recorder._alloSentenceKey = key;
        editAudioChunksRef.current = [];
        recorder.ondataavailable = function (event) {
          if (event && event.data && event.data.size > 0) editAudioChunksRef.current.push(event.data);
        };
        recorder.onerror = function () {
          recorder._alloFailed = true;
          editAudioChunksRef.current = [];
          if (editAudioMediaRecorderRef.current === recorder) editAudioMediaRecorderRef.current = null;
          releaseEditAudioStream();
          setEditAudioMicRequestKey(null);
          setEditAudioRecordingKey(null);
          setEditAudioRecordingSaveKey(null);
          setEditAudioNotice('The microphone stopped unexpectedly. Please record sentence ' + sentenceNumber + ' again.');
        };
        recorder.onstop = async function () {
          var chunks = editAudioChunksRef.current.slice();
          editAudioChunksRef.current = [];
          if (editAudioMediaRecorderRef.current === recorder) editAudioMediaRecorderRef.current = null;
          releaseEditAudioStream();
          setEditAudioRecordingKey(null);
          var durationMs = Math.max(0, Date.now() - (recorder._alloStartedAt || editAudioRecordingStartedAtRef.current || Date.now()));
          if (recorder._alloFailed) return;
          if (!chunks.length) {
            setEditAudioNotice('No audio was captured for sentence ' + sentenceNumber + '.');
            return;
          }
          var recordedBlob = new Blob(chunks, { type: recorder.mimeType || mimeType || 'audio/webm' });
          setEditAudioRecordingSaveKey(key);
          setEditAudioNotice('Saving the teacher recording for sentence ' + sentenceNumber + ' as MP3...');
          try {
            var saved = await window.__alloStoreRecordedSentenceAudio(sentence, recordedBlob, 'human-teacher', Object.assign({}, identityOptions || {}, { durationMs: durationMs }));
            if (saved === false) throw new Error(viewText('simplified.audio_recording_was_not_saved', 'Recording was not saved'));
            setAudioStatusTick(function (n) { return n + 1; });
            updateEditAudioPlaybackIssue(sentence, null, identityOptions);
            setEditAudioNotice('Teacher recording saved for sentence ' + sentenceNumber + '.');
          } catch (_) {
            setEditAudioNotice('Could not save the recording for sentence ' + sentenceNumber + '. Please try again.');
          } finally {
            setEditAudioRecordingSaveKey(null);
          }
        };
        editAudioMediaRecorderRef.current = recorder;
        recorder._alloFailed = false;
        recorder._alloStartedAt = Date.now();
        editAudioRecordingStartedAtRef.current = recorder._alloStartedAt;
        recorder.start(250);
        editAudioRecordingTimerRef.current = setTimeout(function () {
          if (editAudioMediaRecorderRef.current === recorder && recorder.state !== 'inactive') {
            setEditAudioNotice('The two-minute recording limit was reached. Finishing sentence ' + sentenceNumber + '...');
            try { recorder.stop(); } catch (_) { recorder.onerror(); }
          }
        }, EDIT_AUDIO_MAX_RECORDING_MS);
        setEditAudioMicRequestKey(null);
        setEditAudioRecordingKey(key);
        setEditAudioNotice('Recording sentence ' + sentenceNumber + '. Press Stop when finished.');
      } catch (_) {
        editAudioMediaRecorderRef.current = null;
        editAudioChunksRef.current = [];
        releaseEditAudioStream();
        if (stream) {
          try { stream.getTracks().forEach(function (track) { track.stop(); }); } catch (_err) {}
        }
        if (requestToken === editAudioRecordTokenRef.current) {
          setEditAudioMicRequestKey(null);
          setEditAudioRecordingKey(null);
          setEditAudioNotice(viewText('simplified.audio_microphone_access_was_not_available_chec', 'Microphone access was not available. Check permission and try again.'));
        }
      }
    };
    var handleRemoveReadAloudSentence = async function (sentence, key, sentenceNumber, identityOptions) {
      if (!sentence || removeAudioKey) return;
      if (typeof window.__alloRemoveSentenceAudio !== 'function') {
        setEditAudioNotice(viewText('simplified.audio_sentence_audio_removal_is_still_loading', 'Sentence audio removal is still loading. Please try again.'));
        return;
      }
      if (editAudioPlayerRef.current && editAudioPlayerRef.current._alloSentenceKey === key) stopEditAudioPlayback();
      setRemoveAudioKey(key);
      setEditAudioNotice('Removing saved audio for sentence ' + sentenceNumber + '...');
      try {
        var removed = await window.__alloRemoveSentenceAudio(sentence, identityOptions || {});
        if (removed === false) throw new Error(viewText('simplified.audio_audio_was_not_removed', 'Audio was not removed'));
        setAudioStatusTick(function (n) { return n + 1; });
        updateEditAudioPlaybackIssue(sentence, null, identityOptions);
        setEditAudioNotice('Saved audio removed from sentence ' + sentenceNumber + '.');
      } catch (_) {
        setEditAudioNotice('Could not remove the audio for sentence ' + sentenceNumber + '.');
      } finally {
        setRemoveAudioKey(null);
      }
    };
    var handleToggleEditAudioPanel = function () {
      var next = !editAudioOpen;
      if (!next) {
        stopEditAudioPlayback();
        editAudioRecordTokenRef.current += 1;
        setEditAudioMicRequestKey(null);
        var recorder = editAudioMediaRecorderRef.current;
        try { if (recorder && recorder.state !== 'inactive') recorder.stop(); } catch (_) {}
      }
      setEditAudioOpen(next);
    };
    var closeNarrationPanel = function () {
      if (editAudioOpen) handleToggleEditAudioPanel();
      editAudioToggleRef.current?.focus();
    };
    React.useEffect(function () {
      if (!audioRecoveryTarget) return;
      if (audioRecoveryTarget.context !== ttsPrepContext) { setAudioRecoveryTarget(null); return; }
      if (!editAudioOpen) return;
      var panelId = editAudioToggleRef.current?.getAttribute('aria-controls');
      var sentenceRow = panelId && document.getElementById(panelId)?.querySelector('[data-audio-sentence-index="' + audioRecoveryTarget.index + '"]');
      var control = sentenceRow?.querySelector('button:not([disabled])');
      if (control) { control.focus(); control.scrollIntoView?.({ block: 'nearest' }); }
      setAudioRecoveryTarget(null);
    }, [audioRecoveryTarget, editAudioOpen, ttsPrepContext]);
    function renderAudioPreparationIssues() {
      if (!isTeacherMode || !ttsPrepRecovery || ttsPrepRecovery.context !== ttsPrepContext) return null;
      var entries = getReadAloudSentenceEntriesForText(simplifiedReadAloudText);
      var unresolved = ttsPrepRecovery.failures.filter(function (failure) {
        try {
          var options = getReadAloudIdentityOptions(entries[failure.index]);
          var inspection = window.__alloInspectReadAloudAudio?.(failure.text, 'reference', options);
          return inspection?.status !== 'ready' || !!getEditAudioPlaybackIssue(failure.text, options);
        } catch (_) { return true; }
      });
      if (!unresolved.length) return null;
      return <div data-audio-preparation-issues role="region" aria-label={viewText('simplified.audio_recovery_title', 'Sentences needing audio')} className="my-3 rounded-lg border border-amber-300 bg-amber-50 p-3 text-sm text-slate-900">
        <p className="font-bold">{viewText('simplified.audio_recovery_title', 'Sentences needing audio')}</p>
        <ul className="mt-2 space-y-3">{unresolved.map(function (failure) {
          var hint = failure.action === 'review-recording'
            ? viewText('simplified.audio_recovery_recording', 'This recording is protected. Review it and choose whether to record again or generate a replacement.')
            : failure.action === 'review-storage'
              ? viewText('simplified.audio_recovery_storage', 'Audio exceeded a storage limit. Review this sentence before retrying.')
              : viewText('simplified.audio_recovery_retry', 'Preparation failed. Retry this sentence or try preparing the remaining audio again.');
          return <li key={failure.index} data-audio-recovery-index={failure.index}>
            <p className="font-semibold">{failure.index + 1}. {failure.text}</p><p>{hint}</p>
            <button type="button" className="mt-1 min-h-11 rounded-md border border-amber-700 bg-white px-3 py-2 font-semibold text-amber-900 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600" onClick={function () {
              setEditAudioOpen(true); setAudioRecoveryTarget({ context: ttsPrepContext, index: failure.index });
            }}>{viewText('simplified.audio_recovery_sentence', 'Review sentence {number}', { number: failure.index + 1 })}</button>
          </li>;
        })}</ul>
      </div>;
    }
    // One owned player for pronunciation and dictionary recordings. A request
    // token prevents delayed synthesis or play() completions reopening dismissed help.
    var helpAudioRef = React.useRef(null);
    var helpAudioTokenRef = React.useRef(0);
    var [helpAudioState, setHelpAudioState] = React.useState({ key: null, status: 'idle' });
    var releaseHelpUrl = function (url) {
      if (typeof url === 'string' && url.startsWith('blob:') && !(typeof window.__alloTtsCacheOwnsUrl === 'function' && window.__alloTtsCacheOwnsUrl(url))) {
        try { URL.revokeObjectURL(url); } catch (_) {}
      }
    };
    var stopHelpAudio = function (reset) {
      helpAudioTokenRef.current += 1;
      var current = helpAudioRef.current;helpAudioRef.current = null;
      clearTimeout(current?.timer);
      current?.cancel?.();
      if (current?.audio) { current.audio.onended = null;current.audio.onerror = null;current.audio.pause(); }
      if (current?.ownedUrl) releaseHelpUrl(current.ownedUrl);
      if (reset !== false) setHelpAudioState({ key: null, status: 'idle' });
    };
    var playHelpAudio = async function (key, recordingUrl, word, language) {
      if (helpAudioRef.current?.key === key) { stopHelpAudio();return; }
      stopHelpAudio();
      if (typeof stopPlayback === 'function') stopPlayback();
      var token = helpAudioTokenRef.current;
      var current = { key: key, audio: null, ownedUrl: null, timer: null, cancel: null };helpAudioRef.current = current;
      var cancelled = new Promise(resolve => { current.cancel = resolve; });
      var configuredMs = Number(window.AlloFlowConfig?.timeouts?.readingAudioStartupMs);
      var timeoutMs = Number.isFinite(configuredMs) && configuredMs > 0 ? Math.min(120000, Math.max(1000, configuredMs)) : 30000;
      var fail = function (reason) {
        if (token !== helpAudioTokenRef.current) return;
        stopHelpAudio(false);setHelpAudioState({ key: key, status: 'error', reason: reason });
      };
      setHelpAudioState({ key: key, status: 'loading' });
      current.timer = setTimeout(() => fail('timeout'), timeoutMs);
      try {
        // Keep the shared TTS cache/API contract. Only this popup's wait is cancelled.
        var work = (async function () {
          var url = recordingUrl || await callTTS(word, selectedVoice, voiceSpeed || 1, 2, language || generatedContent?.config?.language || leveledTextLanguage || 'English');
          if (token !== helpAudioTokenRef.current) { if (!recordingUrl) releaseHelpUrl(url);return; }
          if (!url) throw new Error(viewText('simplified.word_audio_no_pronunciation_audio', 'No pronunciation audio'));
          if (!recordingUrl) current.ownedUrl = url;
          var audio = new Audio(url);current.audio = audio;audio.playbackRate = voiceSpeed || 1;
          audio.onended = function () { if (token === helpAudioTokenRef.current) stopHelpAudio(); };
          audio.onerror = function () { fail('playback'); };
          await audio.play();
          if (token !== helpAudioTokenRef.current) { audio.pause();return; }
          clearTimeout(current.timer);current.timer = null;
          setHelpAudioState({ key: key, status: 'playing' });
        })();
        await Promise.race([work, cancelled]);
      } catch (_) { fail('failed'); }
    };
    React.useEffect(function () {
      setHelpAudioState({ key: null, status: 'idle' });
      return function () { stopHelpAudio(false); };
    }, [phonicsData?.word, definitionData?.word, phonicsData?.lookupRequest, definitionData?.lookupRequest, generatedContent?.id, generatedContent?.data, interactionMode]);
    React.useEffect(function () { if (isPlaying && helpAudioRef.current) stopHelpAudio(); }, [isPlaying, playingContentId]);
    var helpText = function (key, fallback) { var value = t(key);return value && value !== key ? value : fallback; };
    var renderHelpAudioButton = function (key, recordingUrl, word, language, idleLabel) {
      var current = helpAudioState.key === key;
      var active = current && (helpAudioState.status === 'loading' || helpAudioState.status === 'playing');
      var label = active ? helpText('simplified.word_audio_stop', 'Stop audio') : current && helpAudioState.status === 'error' ? helpText('simplified.word_audio_retry', 'Try audio again') : recordingUrl ? helpText('simplified.word_recording', 'Hear recording') : helpText('simplified.word_audio_listen', 'Hear word');
      if (idleLabel && !active && !(current && helpAudioState.status === 'error')) label = idleLabel;
      return <button key={key} type="button" data-word-help-audio={key} aria-busy={current && helpAudioState.status === 'loading'} aria-label={label} onClick={() => playHelpAudio(key, recordingUrl, word, language)} className="min-h-11 inline-flex items-center justify-center gap-2 rounded-lg border border-emerald-300 bg-white px-3 py-2 text-sm font-semibold text-emerald-900 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600">{active ? <StopCircle size={16} aria-hidden="true" /> : <Volume2 size={16} aria-hidden="true" />}<span>{label}</span></button>;
    };
    var renderHelpAudioNotice = function (prefix) {
      if (!helpAudioState.key?.startsWith(prefix) || !['loading', 'error'].includes(helpAudioState.status)) return null;
      return <p role="status" className="mb-3 text-sm text-slate-700">{helpAudioState.status === 'loading' ? helpText('simplified.word_audio_loading', 'Preparing audio…') : helpAudioState.reason === 'timeout' ? helpText('simplified.word_audio_timeout', 'Audio took too long to start. You can try again.') : helpText('simplified.word_audio_error', 'Audio could not play. Try again when you are ready.')}</p>;
    };
    // Read-aloud for the Define and Explain popups. Both go through the host's
    // handleSpeak, the same path the sentence reader, the immersive word
    // speaker and the glossary use, so voice, speed, provider fallback and
    // the global play state all match the rest of the app. Calling handleSpeak
    // again with the same content id while that id is playing stops it, so one
    // button serves as both play and stop.
    // Session identity, not word spelling, owns dismissal and pending audio.
    var lookupCloseRef = React.useRef(null);
    lookupCloseRef.current = { definition: props.closeDefinition, phonics: props.closePhonics };
    React.useEffect(function () {
      return function () {
        lookupCloseRef.current?.definition?.();
        lookupCloseRef.current?.phonics?.();
      };
    }, [isCompareMode]);
    var dictionaryFailureText = function (data) {
      if (data.dictionaryReason === 'not_found') return helpText('simplified.lookup_dictionary_not_found', 'The dictionary has no entry for this word.');
      if (data.dictionaryReason === 'timeout') return helpText('simplified.lookup_dictionary_timeout', 'The dictionary took too long to respond. You can try again.');
      if (data.dictionaryReason === 'request_failed' || data.dictionaryReason === 'not_available') return helpText('simplified.lookup_dictionary_connection', 'The dictionary could not be reached. Any available help is still shown.');
      if (data.dictionaryReason === 'invalid_response') return helpText('simplified.lookup_dictionary_invalid', 'The dictionary returned an unusable entry. You can try again.');
      return helpText('simplified.lookup_dictionary_unavailable', 'No dictionary entry is available.');
    };
    var renderLookupStatus = function (data, kind) {
      var preparedText = simplifiedAiText(data.preparedText);
      var status = data.aiStatus || (kind === 'definition' ? data.text ? 'ready' : 'loading' : data.isLoading ? 'loading' : data.data ? 'ready' : 'error');
      // A past attempt does not determine today's policy or provider availability.
      var lookupAvailability = typeof data.getAiAvailability === 'function' ? data.getAiAvailability() : null;
      var blocked = studentAiFeaturesHidden || window.__alloStudentAiDisabled === true
        || lookupAvailability === 'disabled' || (lookupAvailability == null && status === 'disabled');
      var canRetry = !blocked && lookupAvailability !== 'unavailable' && (status === 'error' || status === 'disabled');
      var availabilityRestored = lookupAvailability === 'ready' && (status === 'disabled' || data.aiErrorReason === 'not_available');
      return <div data-lookup-status={kind}>
        <p role="status" className="sr-only">{status === 'ready' ? helpText('simplified.lookup_ready', 'Word help ready') : ''}{data.dictionaryStatus === 'ready' ? ' ' + helpText('simplified.lookup_dictionary_ready', 'Dictionary entry ready') : ''}</p>
        {preparedText && <div className="mb-3 rounded-lg border border-indigo-200 bg-indigo-50 p-3"><p className="text-xs font-bold">{helpText('simplified.word_help_card_prepared', 'Word help from your teacher')}</p><p>{preparedText}</p></div>}
        {(blocked || status === 'error' || status === 'loading' || status === 'disabled') && <p role="status" className="my-2 text-sm text-slate-700">{blocked ? helpText('simplified.lookup_ai_disabled', 'AI explanations are off. You can still use any available word help.') : status === 'loading' ? helpText('simplified.lookup_loading', 'Preparing word help…') : availabilityRestored ? helpText('simplified.lookup_ai_available', 'AI word help is available. You can try again.') : data.aiErrorReason === 'not_available' ? helpText('simplified.lookup_ai_unavailable', 'AI word help is unavailable right now. Any available help is still shown.') : data.aiErrorReason === 'timeout' ? helpText('simplified.lookup_ai_timeout', 'AI word help took too long. Any available help is still shown. You can try again.') : helpText('simplified.lookup_ai_failed', 'AI word help could not load. Any available help is still shown.')}</p>}
        {!blocked && (status === 'error' || status === 'disabled' || data.aiRetryAvailable) && typeof data.retry === 'function' && <button type="button" data-lookup-retry={kind} aria-disabled={!canRetry} aria-busy={status === 'loading'} onClick={() => { if (!canRetry) return; stopHelpAudio(); data.retry(); }} className="min-h-11 rounded-lg border border-indigo-300 px-3 py-2 text-sm text-indigo-900">{status === 'loading' ? helpText('simplified.lookup_retrying', 'Trying again…') : status === 'ready' ? helpText('simplified.lookup_ready', 'Word help ready') : helpText('simplified.lookup_retry', 'Try word help again')}</button>}
        {data.dictionaryStatus === 'loading' && <p role="status" className="my-2 text-sm text-slate-700">{helpText('simplified.lookup_dictionary_loading', 'Looking for a dictionary entry…')}</p>}
        {data.dictionaryStatus === 'unavailable' && <p role="status" className="my-2 text-sm text-slate-700">{dictionaryFailureText(data)}</p>}
        {data.dictionaryStatus === 'unsupported' && <p className="my-2 text-sm text-slate-700">{helpText('simplified.lookup_dictionary_english_words', 'Dictionary entries are available for individual English words. Any other available word help is still shown.')}</p>}
        {(data.dictionaryStatus === 'unavailable' || data.dictionaryRetryAvailable) && typeof data.retryDictionary === 'function' && <button type="button" data-dictionary-retry={kind} aria-disabled={data.dictionaryStatus !== 'unavailable'} aria-busy={data.dictionaryStatus === 'loading'} onClick={() => { if (data.dictionaryStatus === 'unavailable') data.retryDictionary(); }} className="min-h-11 rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600">{data.dictionaryStatus === 'loading' ? helpText('simplified.lookup_retrying', 'Trying again…') : data.dictionaryStatus === 'ready' ? helpText('simplified.lookup_dictionary_ready', 'Dictionary entry ready') : helpText('simplified.lookup_dictionary_retry', 'Try dictionary again')}</button>}
      </div>;
    };
    var renderLookupPicture = function (data) {
      var ready = !!data.imageUrl, busy = !ready && !!data.imageLoading;
      var blocked = studentAiFeaturesHidden || window.__alloStudentAiDisabled === true;
      var label = busy ? helpText('simplified.lookup_picture_loading', 'Preparing picture…')
        : ready ? helpText('simplified.lookup_picture_ready', 'Picture ready')
        : data.imageError ? helpText('simplified.lookup_picture_retry', 'Try picture again')
        : helpText('glossary.popups.show_picture', 'Show picture');
      return <div data-lookup-picture>
        {ready && <img src={data.imageUrl} alt={data.word} className="h-32 w-full rounded-lg border border-slate-400 object-contain" />}
        <p role="status" className="my-1 text-xs text-slate-700">{ready ? helpText('simplified.lookup_picture_ready', 'Picture ready') : busy ? helpText('simplified.lookup_picture_loading', 'Preparing picture…') : blocked ? helpText('simplified.lookup_picture_disabled', 'New AI pictures are off.') : data.imageError ? data.imageErrorReason === 'timeout' ? helpText('simplified.lookup_picture_timeout', 'The picture took too long to load. You can try again.') : helpText('glossary.popups.image_error', 'Could not load picture.') : ''}</p>
        {!blocked && typeof handleFetchWordImage === 'function' && <button type="button" data-lookup-picture-retry aria-disabled={busy || ready} aria-busy={busy} onClick={() => { if (!busy && !ready) handleFetchWordImage(data.word); }} className="min-h-11 w-full rounded-lg border border-indigo-300 px-3 py-2 text-sm text-indigo-900 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600">{label}</button>}
      </div>;
    };
    var renderDefinitionSpeech = function (data) {
      var dictionaryText = dictionarySenseForLookup(data)?.definition || '';
      var preparedText = simplifiedAiText(data.preparedText);
      var spoken = data.text || preparedText || dictionaryText;
      if (!spoken) return null;
      var language = data.text || preparedText ? data.language : 'English';
      var translation = language && language !== 'English' ? spoken.match(/\n\s*(?:\*\*)?English:(?:\*\*)?\s*/i) : null;
      var primary = translation ? spoken.slice(0, translation.index) : spoken;
      var english = translation ? spoken.slice(translation.index + translation[0].length) : '';
      return <>{renderSimplifiedPopupSpeaker(SIMPLIFIED_DEFINE_AUDIO_ID, [data.word, primary], language)}{english.trim() && renderSimplifiedPopupSpeaker(SIMPLIFIED_DEFINE_AUDIO_ID + '-english', english, 'English', helpText('simplified.lookup_listen_english', 'Listen in English'))}</>;
    };
    var SIMPLIFIED_DEFINE_AUDIO_ID = 'simplified-define-popup';
    var SIMPLIFIED_REVISION_AUDIO_ID = 'simplified-revision-popup';
    var simplifiedPopupReadAloudLabel = t('common.read_aloud') || 'Read this aloud';
    var simplifiedPopupStopReadingLabel = t('common.stop_reading') || 'Stop reading aloud';
    var simplifiedPopupListenLabel = t('common.listen') || 'Listen';
    var simplifiedPopupStopLabel = t('common.stop') || 'Stop';
    var simplifiedPopupSpokenText = function (parts) {
      return (Array.isArray(parts) ? parts : [parts])
        .map(function (part) { return String(part == null ? '' : part).replace(/\s+/g, ' ').trim(); })
        .filter(Boolean)
        .join('. ');
    };
    var renderSimplifiedPopupSpeaker = function (contentId, spokenText, language, label) {
      if (typeof handleSpeak !== 'function') return null;
      var text = simplifiedPopupSpokenText(spokenText);
      if (!text) return null;
      var active = !!isPlaying && playingContentId === contentId;
      return <button type="button" data-simplified-popup-speaker={contentId} onClick={function () { stopHelpAudio(); if (language) handleSpeak(text, contentId, 0, false, language); else handleSpeak(text, contentId, 0); }} aria-label={active ? simplifiedPopupStopLabel : label || simplifiedPopupListenLabel} title={active ? simplifiedPopupStopReadingLabel : label || simplifiedPopupReadAloudLabel} className={`min-h-11 flex items-center gap-1.5 rounded-full px-3 text-xs font-bold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 focus-visible:ring-offset-2 ${active ? 'bg-indigo-700 text-white hover:bg-indigo-800' : 'bg-indigo-50 text-indigo-700 hover:bg-indigo-100'}`}>{active ? <StopCircle size={14} aria-hidden="true" /> : <Volume2 size={14} aria-hidden="true" />}<span>{active ? simplifiedPopupStopLabel : label || simplifiedPopupListenLabel}</span></button>;
    };
    // Closing a popup should not leave its audio running with nothing on
    // screen to stop it. The ref carries the live id into the effect cleanup.
    var simplifiedPlayingContentIdRef = React.useRef(null);
    simplifiedPlayingContentIdRef.current = playingContentId;
    var stopSimplifiedPopupAudio = function (contentId) {
      if (simplifiedPlayingContentIdRef.current === contentId && typeof stopPlayback === 'function') stopPlayback();
    };
    function containSimplifiedModalFocus(e, container, onEscape) {
      if (!e || !container) return;
      var nearestDialog = e.target && typeof e.target.closest === 'function' ? e.target.closest('[role="dialog"]') : null;
      if (nearestDialog && nearestDialog !== container && nearestDialog.getAttribute('aria-modal') === 'true') return;
      if (e.key === 'Escape') {
        e.preventDefault();
        e.stopPropagation();
        if (typeof onEscape === 'function') onEscape(e);
        return;
      }
      if (e.key !== 'Tab' || typeof container.querySelectorAll !== 'function') return;
      var focusable = Array.prototype.slice.call(container.querySelectorAll('button:not([disabled]), textarea:not([disabled]), input:not([disabled]):not([type="hidden"]), select:not([disabled]), a[href], summary, [tabindex]:not([tabindex="-1"])')).filter(function (el) {
        if (!el || el.tabIndex < 0 || el.matches(':disabled') || el.closest('[hidden], [inert], [aria-hidden="true"]')) return false;
        // Details summaries are keyboard controls too. Content of a collapsed
        // disclosure, or any visually hidden ancestor, must stay out of the loop.
        for (var parent = el; parent && parent !== container; parent = parent.parentElement) {
          var style = window.getComputedStyle(parent);
          if (style.display === 'none' || style.visibility === 'hidden' || style.visibility === 'collapse') return false;
          if (parent.tagName === 'DETAILS' && !parent.open) {
            var summary = Array.prototype.find.call(parent.children, function (child) { return child.tagName === 'SUMMARY'; });
            if (!summary || (el !== summary && !summary.contains(el))) return false;
          }
        }
        return true;
      });
      if (!focusable.length) { e.preventDefault(); container.focus(); return; }
      var first = focusable[0];
      var last = focusable[focusable.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      else if (!focusable.includes(document.activeElement)) { e.preventDefault(); (e.shiftKey ? last : first).focus(); }
    }
    React.useEffect(function () {
      if (!isImmersiveReaderActive || !generatedContent?.immersiveData) return undefined;
      var previouslyFocused = document.activeElement;
      var timer = setTimeout(function () {
        var closeButton = immersiveDialogRef.current && immersiveDialogRef.current.querySelector('button[aria-label]');
        if (closeButton) closeButton.focus();
        else if (immersiveDialogRef.current) immersiveDialogRef.current.focus();
      }, 0);
      return function () {
        clearTimeout(timer);
        if (previouslyFocused && typeof previouslyFocused.focus === 'function') previouslyFocused.focus();
      };
    }, [isImmersiveReaderActive]);
    React.useEffect(function () {
      if (!phonicsData) return undefined;
      var previouslyFocused = document.activeElement;
      var timer = setTimeout(function () { if (phonicsCloseRef.current) phonicsCloseRef.current.focus(); }, 0);
      return function () {
        clearTimeout(timer);
        if (previouslyFocused && typeof previouslyFocused.focus === 'function') previouslyFocused.focus();
      };
    }, [!!phonicsData]);
    React.useEffect(function () {
      if (!definitionData) return undefined;
      var previouslyFocused = document.activeElement;
      var timer = setTimeout(function () { if (definitionCloseRef.current) definitionCloseRef.current.focus(); }, 0);
      return function () {
        clearTimeout(timer);
        stopSimplifiedPopupAudio(SIMPLIFIED_DEFINE_AUDIO_ID);
        stopSimplifiedPopupAudio(SIMPLIFIED_DEFINE_AUDIO_ID + '-english');
        if (previouslyFocused && typeof previouslyFocused.focus === 'function' && document.contains(previouslyFocused)) previouslyFocused.focus();
      };
    }, [!!definitionData, definitionData?.lookupRequest]);
    React.useEffect(function () {
      if (!revisionData) return undefined;
      var previouslyFocused = document.activeElement;
      var timer = setTimeout(function () { if (revisionCloseRef.current) revisionCloseRef.current.focus(); }, 0);
      return function () {
        clearTimeout(timer);
        stopSimplifiedPopupAudio(SIMPLIFIED_REVISION_AUDIO_ID);
        if (previouslyFocused && typeof previouslyFocused.focus === 'function' && document.contains(previouslyFocused)) previouslyFocused.focus();
      };
    }, [!!revisionData]);

    var renderEditAudioSentenceTools = function () {
      if (!canManageNarration) return null;
      var sentences = narrationSentences;
      if (!sentences.length) return null;
      var summary = narrationSummary;
      var savingCount = Object.keys(savingAudioKeys || {}).length;
      var captureErrorCount = Object.keys(captureAudioErrors || {}).length;
      var panelId = 'allo-edit-audio-' + previewInstanceId.replace(/[^a-z0-9_-]/gi, '-') + '-' + String((generatedContent && generatedContent.id) || 'current').replace(/[^a-z0-9_-]/gi, '-');
      var anyRecordingWork = !!editAudioMicRequestKey || !!editAudioRecordingKey || !!editAudioRecordingSaveKey;
      return <div data-narration-tools className="mt-2 w-full min-w-0 rounded-xl border border-orange-100 bg-orange-50/80"><p id={panelId + '-scope'} className="px-3 pt-3 text-sm font-semibold text-slate-800">{protectedOriginal ? viewText('simplified.narration_original_scope', 'Original narration. Recording or saving audio leaves the original text unchanged.') : viewText('simplified.narration_adapted_scope', 'Adapted text narration. Use Edit text to change the passage.')}</p><div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 p-2.5"><button ref={editAudioToggleRef} type="button" data-manage-narration aria-describedby={panelId + '-scope'} onClick={handleToggleEditAudioPanel} aria-expanded={editAudioOpen} aria-controls={panelId} className="min-h-11 min-w-0 flex-wrap inline-flex items-center justify-center sm:justify-start gap-2 px-3 py-2 rounded-lg text-xs font-bold bg-white text-orange-800 border border-orange-200 hover:bg-orange-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-orange-500 transition-colors"><Volume2 size={14} /><span>{simplifiedAudioEditLabel}</span>{' '}<span className="rounded-full bg-orange-100 text-orange-800 px-2 py-0.5 normal-case">{summary.saved}/{summary.total} {simplifiedAudioSavedLabel.toLowerCase()}{summary.maxBytes ? ` · ${Math.round(summary.bytes / 104857.6) / 10}/${Math.round(summary.maxBytes / 104857.6) / 10} MB` : ''}</span>{editAudioOpen ? <ChevronUp size={14} /> : <ChevronDown size={14} />}</button><div className="flex items-center justify-center sm:justify-end gap-2 flex-wrap">{savingCount > 0 && <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-indigo-700 bg-indigo-50 border border-indigo-200 rounded-full px-2 py-1"><RefreshCw size={10} className="animate-spin motion-reduce:animate-none" /> {simplifiedAudioSaveLabel} {savingCount}</span>}{captureErrorCount > 0 && <span role="alert" className="inline-flex items-center gap-1 text-[11px] font-semibold text-red-700 bg-red-50 border border-red-200 rounded-full px-2 py-1"><AlertCircle size={10} /> {captureErrorCount} {simplifiedAudioErrorLabel}</span>}<button type="button" onClick={copyTtsDiagnostics} title={viewText('simplified.audio_copies_a_technical_trace_of_recent', 'Copies a technical trace of recent read-aloud attempts — paste it into a bug report if audio gets stuck.')} className="inline-flex items-center gap-1 text-[11px] font-semibold text-slate-700 bg-white border border-slate-200 rounded-full px-2 py-1 hover:border-slate-400 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-orange-500">{ttsDiagCopied ? '✓ ' + simplifiedAudioCopiedLabel : '🩺 ' + simplifiedAudioDiagnosticsLabel}</button><label className="inline-flex items-center gap-1.5 text-[11px] text-slate-700 font-semibold cursor-pointer"><input type="checkbox" checked={saveTtsAsPlayed} onChange={function (event) { setSaveTtsAsPlayedEnabled(event.target.checked); }} className="accent-orange-600" aria-label={simplifiedAudioSaveLabel} /><span>{simplifiedAudioSaveLabel}</span></label></div></div>{editAudioOpen && <div id={panelId} role="region" aria-label={simplifiedAudioEditLabel} onKeyDown={event => { if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); closeNarrationPanel(); } }} className="border-t border-orange-100 bg-white p-3"><div className="flex items-start gap-2 mb-3 text-xs text-slate-600"><Mic size={14} className="mt-0.5 shrink-0 text-orange-700" /><p>{viewText('simplified.audio_preview_saved_audio_generate_a_new', 'Preview saved audio, generate a new AI voice, or record your own teacher narration for each sentence. Recordings replace that sentence only.')}</p></div><div role="status" aria-live="polite" data-edit-audio-status className={editAudioNotice ? 'mb-3 rounded-lg border border-indigo-100 bg-indigo-50 px-3 py-2 text-xs font-semibold text-indigo-800' : 'sr-only'}>{editAudioNotice}</div><div className="space-y-2 max-h-[34rem] overflow-y-auto pr-1 custom-scrollbar">{sentences.map(function (entry, i) {
        var sentence = entry.text;
        var identityOptions = getReadAloudIdentityOptions(entry);
        var key = 'simplified-' + i;
        var sentenceNumber = i + 1;
        var audioKey = getReadAloudAudioKey(sentence, identityOptions);
        var isSaving = !!savingAudioKeys[audioKey];
        var isSaved = hasStoredReadAloudAudio(sentence, identityOptions);
        var provenance = isSaved ? getReadAloudAudioProvenance(sentence, identityOptions) : { source: null, label: simplifiedAudioMissingLabel, stale: false };
        var captureIssue = captureAudioErrors[audioKey];
        var playbackIssue = getEditAudioPlaybackIssue(sentence, identityOptions);
        var needsRebuild = !!(isSaved && (provenance.stale || playbackIssue));
        var isGenerating = regenAudioKey === key;
        var isLoading = editAudioLoadingKey === key;
        var isPlayingSentence = editAudioPlayingKey === key;
        var isMicRequest = editAudioMicRequestKey === key;
        var isRecording = editAudioRecordingKey === key;
        var isRecordingSave = editAudioRecordingSaveKey === key;
        var isRemoving = removeAudioKey === key;
        var statusLabel = isMicRequest ? simplifiedAudioEditLabel + ': ' + simplifiedAudioRecordLabel : isRecording ? simplifiedAudioRecordLabel : isRecordingSave ? simplifiedAudioSaveLabel : isGenerating ? (isSaved ? simplifiedAudioRegenerateLabel : simplifiedAudioGenerateLabel) : isRemoving ? simplifiedAudioRemoveLabel : isSaving ? simplifiedAudioSaveLabel : captureIssue ? (captureIssue.status === 'limit' ? simplifiedAudioStorageLimitLabel : simplifiedAudioErrorLabel) : playbackIssue ? simplifiedAudioSavedLabel + ' · ' + simplifiedAudioErrorLabel : provenance.stale ? simplifiedAudioSavedLabel + ' · ' + simplifiedAudioSettingsChangedLabel : isSaved ? simplifiedAudioSavedLabel : simplifiedAudioMissingLabel;
        var statusClass = isRecording ? 'bg-red-50 text-red-700 border-red-200' : isMicRequest || isRecordingSave || isGenerating || isRemoving || isSaving || isLoading ? 'bg-indigo-50 text-indigo-700 border-indigo-200' : captureIssue ? (captureIssue.status === 'limit' ? 'bg-amber-50 text-amber-800 border-amber-200' : 'bg-red-50 text-red-700 border-red-200') : playbackIssue ? 'bg-red-50 text-red-700 border-red-200' : provenance.stale ? 'bg-amber-50 text-amber-800 border-amber-200' : isSaved ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-amber-50 text-amber-800 border-amber-200';
        var controlsBlocked = isSaving || isGenerating || isRemoving || ttsPrepState.busy;
        var recordDisabled = !isRecording && (anyRecordingWork || !!regenAudioKey || !!removeAudioKey || isSaving || ttsPrepState.busy);
        var actionClass = 'min-h-11 inline-flex items-center justify-center gap-1.5 rounded-md border px-2.5 py-1.5 text-[11px] font-bold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 disabled:opacity-45 disabled:cursor-not-allowed';
        return <div key={key} data-audio-sentence-index={i} className="rounded-xl border border-slate-200 bg-slate-50/70 p-3"><div className="flex items-start gap-2"><span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-orange-100 text-[11px] font-black text-orange-800" aria-hidden="true">{sentenceNumber}</span><div className="min-w-0 flex-1"><p dir="auto" style={{ overflowWrap: 'anywhere' }} className="text-sm font-medium leading-relaxed text-slate-800">{sentence}</p><div role="group" className="mt-1.5 flex items-center gap-1.5 flex-wrap" aria-label={`${simplifiedAudioEditLabel} ${sentenceNumber}: ${statusLabel}. ${provenance.label}.`}><span className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-bold ${statusClass}`}>{isMicRequest || isRecordingSave || isGenerating || isRemoving || isSaving || isLoading ? <RefreshCw size={9} className="animate-spin motion-reduce:animate-none" /> : isRecording ? <span className="h-1.5 w-1.5 rounded-full bg-red-500 animate-pulse motion-reduce:animate-none" /> : captureIssue || needsRebuild ? <AlertCircle size={9} /> : isSaved ? <CheckCircle2 size={9} /> : <AlertCircle size={9} />}{statusLabel}</span><span className="text-[10px] font-semibold text-slate-500">{provenance.label}</span></div></div></div><div role="group" aria-label={`${simplifiedAudioEditLabel} ${sentenceNumber}`} className="mt-2.5 flex items-center gap-1.5 flex-wrap"><button type="button" onClick={function () { handlePlayEditAudioSentence(sentence, key, sentenceNumber, identityOptions); }} disabled={!isSaved || isLoading || controlsBlocked || anyRecordingWork || (!!editAudioLoadingKey && !isLoading)} aria-pressed={isPlayingSentence} aria-label={`${isPlayingSentence ? simplifiedAudioPauseLabel : simplifiedAudioPlayLabel} ${sentenceNumber}`} title={!isSaved ? simplifiedAudioGenerateLabel : isPlayingSentence ? simplifiedAudioPauseLabel : simplifiedAudioPlayLabel} className={`${actionClass} bg-white text-indigo-700 border-indigo-200 hover:bg-indigo-50`}>{isLoading ? <RefreshCw size={12} className="animate-spin motion-reduce:animate-none" /> : isPlayingSentence ? <Pause size={12} /> : <Play size={12} />}<span>{isLoading ? simplifiedAudioLoadingLabel : isPlayingSentence ? simplifiedAudioPauseLabel : simplifiedAudioPlayLabel}</span></button><button type="button" onClick={function () { handleRegenerateReadAloudSentence(sentence, key, sentenceNumber, identityOptions); }} disabled={!!regenAudioKey || isSaving || isRemoving || anyRecordingWork || ttsPrepState.busy} aria-label={`${needsRebuild ? simplifiedAudioRegenerateLabel : isSaved ? simplifiedAudioRegenerateLabel : simplifiedAudioGenerateLabel} ${sentenceNumber}`} title={isSaved ? simplifiedAudioRegenerateLabel : simplifiedAudioGenerateLabel} className={`${actionClass} bg-white text-emerald-700 border-emerald-200 hover:bg-emerald-50`}>{isGenerating ? <RefreshCw size={12} className="animate-spin motion-reduce:animate-none" /> : <Volume2 size={12} />}<span>{isGenerating ? (isSaved ? simplifiedAudioRegenerateLabel : simplifiedAudioGenerateLabel) : needsRebuild ? simplifiedAudioRegenerateLabel : isSaved ? simplifiedAudioRegenerateLabel : simplifiedAudioGenerateLabel}</span></button><button type="button" onClick={function () { handleRecordEditAudioSentence(sentence, key, sentenceNumber, identityOptions); }} disabled={recordDisabled} aria-pressed={isRecording} aria-label={`${isRecording ? simplifiedAudioStopLabel : simplifiedAudioRecordLabel} ${sentenceNumber}`} title={isRecording ? simplifiedAudioStopLabel : simplifiedAudioRecordLabel} className={`${actionClass} ${isRecording ? 'bg-red-600 text-white border-red-700 hover:bg-red-700' : 'bg-white text-fuchsia-700 border-fuchsia-200 hover:bg-fuchsia-50'}`}>{isMicRequest || isRecordingSave ? <RefreshCw size={12} className="animate-spin motion-reduce:animate-none" /> : isRecording ? <StopCircle size={12} /> : <Mic size={12} />}<span>{isMicRequest ? simplifiedAudioRecordLabel : isRecording ? simplifiedAudioStopLabel : isRecordingSave ? simplifiedAudioSaveLabel : simplifiedAudioRecordLabel}</span></button>{isSaved && <button type="button" onClick={function () { handleRemoveReadAloudSentence(sentence, key, sentenceNumber, identityOptions); }} disabled={!!removeAudioKey || isSaving || !!regenAudioKey || anyRecordingWork || ttsPrepState.busy} aria-label={`${simplifiedAudioRemoveLabel} ${sentenceNumber}`} className={`${actionClass} bg-white text-rose-700 border-rose-200 hover:bg-rose-50`}>{isRemoving ? <RefreshCw size={12} className="animate-spin motion-reduce:animate-none" /> : <Trash2 size={12} />}<span>{isRemoving ? simplifiedAudioRemoveLabel : simplifiedAudioRemoveLabel}</span></button>}</div></div>;
      })}</div><button type="button" data-close-narration onClick={closeNarrationPanel} className="mt-3 min-h-11 rounded-lg border border-orange-300 bg-white px-3 py-2 text-sm font-semibold text-orange-900 focus-visible:ring-2 focus-visible:ring-indigo-600">{viewText('simplified.close_narration', 'Close narration')}</button></div>}</div>;
    };
    var instructionalTextProfile = getSimplifiedInstructionalText(generatedContent);
    var instructionalRole = instructionalTextProfile.role || 'unspecified';
    var replacementIsEducatorAuthorized = !!(
      instructionalTextProfile.replacementAuthorization &&
      instructionalTextProfile.replacementAuthorization.authorized === true &&
      instructionalTextProfile.replacementAuthorization.source === 'educator'
    );
    var instructionalFormLabel = protectedOriginal ? (verifiedOriginal ? 'Original with supports' : 'Saved source — preservation unverified') : instructionalTextProfile.form === 'original' ? 'Original text' : 'Adapted text';
    var studentRoleText = function (key, fallback) { var value = t(key); return value && value !== key ? value : fallback; };
    var instructionalStudentLabel = protectedOriginal
      ? studentRoleText('simplified.student_role_original', 'This is the original text.')
      : instructionalRole === 'primary'
        ? studentRoleText('simplified.student_role_main', 'This is your reading for this lesson.')
        : studentRoleText('simplified.student_role_companion', 'This is an easier version to help you read the original.');
    var instructionalRoleLabel = instructionalRole === 'primary' ? (instructionalTextProfile.form === 'adapted' && !replacementIsEducatorAuthorized ? 'Main reading — needs review' : 'Main reading') : instructionalRole === 'supplemental' ? 'Supporting reading' : 'Not designated';
    var instructionalRoleTone = instructionalRole === 'supplemental'
      ? 'bg-blue-50 text-blue-900 border-blue-200'
      : instructionalRole === 'primary' && replacementIsEducatorAuthorized
        ? 'bg-violet-50 text-violet-900 border-violet-200'
        : instructionalRole === 'primary'
          ? 'bg-red-50 text-red-900 border-red-200'
          : 'bg-amber-50 text-amber-900 border-amber-200';
    var isSupplementalSourceUnlinked = instructionalRole === 'supplemental' &&
      !instructionalTextProfile.sourceArtifactId && !instructionalTextProfile.primaryArtifactId;
    var saveInstructionalRole = function (nextRole) {
      if (typeof props.onInstructionalRoleChange === 'function') {
        return props.onInstructionalRoleChange(generatedContent, nextRole, { authorizeReplacement: instructionalTextProfile.form === 'adapted' && nextRole === 'primary' });
      }
      var fullBase = findFullHistoryArtifact(history, generatedContent);
      // The open item wins for mutable display fields, while the history copy
      // supplies any metadata omitted by an older hydration path.
      fullBase = Object.assign({}, fullBase || {}, generatedContent || {});
      var updated = updateSimplifiedInstructionalRole(fullBase, nextRole);
      if (typeof setGeneratedContent === 'function') setGeneratedContent(updated);
      if (typeof setHistory === 'function') {
        setHistory(function (previousHistory) {
          return upsertFullHistoryArtifact(previousHistory, generatedContent, updated);
        });
      }
    };
    var instructionalRoleControl = generatedContent ? <SimplifiedReadingRoleControl
      key={generatedContent.id || generatedContent.data}
      role={instructionalRole} roleLabel={instructionalRoleLabel} formLabel={instructionalFormLabel} studentLabel={instructionalStudentLabel}
      needsAuthorization={instructionalTextProfile.form === 'adapted' && !replacementIsEducatorAuthorized}
      isTeacherMode={isTeacherMode} disabled={isProcessing} onSave={saveInstructionalRole}
      onSelectSource={props.onSelectReadingSource && (!protectedOriginal || verifiedOriginal) ? () => props.onSelectReadingSource(generatedContent) : null}
      showCompanionNote={!protectedOriginal && instructionalRole !== 'primary'}
      missingOriginal={!protectedOriginal && !capturedSource}
    /> : null;
    var simplifiedComplexityDisplay = getSimplifiedComplexityDisplay(generatedContent, gradeLevel);
    var readingColumnState = React.useState(function () {
      // The preview starts from current appearance, including unsaved choices.
      if (props.isStudentPreview) return [40, 56, 72].includes(props.previewAppearance?.readingColumn) ? props.previewAppearance.readingColumn : 72;
      try {
        var saved = Number(localStorage.getItem('alloflow_reading_width'));
        return [40, 56, 72].includes(saved) ? saved : 72;
      } catch (_) { return 72; }
    });
    var readingColumn = readingColumnState[0], setReadingColumn = readingColumnState[1];
    function updateReadingColumn(value) {
      var width = Number(value);
      if (![40, 56, 72].includes(width)) return;
      setReadingColumn(width);
      // Layout preference only: never store passage content or reading position.
      try { if (!props.isStudentPreview) localStorage.setItem('alloflow_reading_width', String(width)); } catch (_) {}
    }
    var readingStartRef = React.useRef(null);
    // Immersive Reader covers the passage, and its read-along sweep re-renders
    // this view every animation frame. The hidden passage is reused instead of
    // rebuilt (about 40 ms a frame for 300 sentences); it rebuilds on close.
    var hiddenPassageRef = React.useRef(null);
    // Display (Aa): Immersive Reader, reading theme and width in one panel, so fewer
    // controls sit above the text. It remembers whether it was left open.
    var [displayOpen, setDisplayOpenState] = React.useState(function () { if (props.isStudentPreview) return !!props.previewAppearance?.displayOpen; try { return localStorage.getItem('alloflow_reader_display_open') === '1'; } catch (_) { return false; } });
    var setDisplayOpen = function (open) { setDisplayOpenState(open); try { if (!props.isStudentPreview) localStorage.setItem('alloflow_reader_display_open', open ? '1' : '0'); } catch (_) {} };
    var displayToggleRef = React.useRef(null);
    var focusViewButtonRef = React.useRef(null);
    var wasFocusViewRef = React.useRef(!!isZenMode);
    React.useEffect(function () {
      // The global exit button unmounts on exit. Return keyboard focus to the
      // reader toggle only when that leaves focus on the document body.
      if (wasFocusViewRef.current && !isZenMode && document.activeElement === document.body) {
        focusViewButtonRef.current?.focus({ preventScroll: true });
      }
      wasFocusViewRef.current = !!isZenMode;
    }, [isZenMode]);
    var [practiceOpen, setPracticeOpen] = React.useState(false);
    var priorReadingRef = React.useRef({ id: generatedContent?.id, text: generatedContent?.data });
    React.useEffect(function () {
      var previous = priorReadingRef.current;
      priorReadingRef.current = { id: generatedContent?.id, text: generatedContent?.data };
      if (previous.id === generatedContent?.id && previous.text === generatedContent?.data) return;
      if (typeof stopPlayback === 'function') stopPlayback();
      if (typeof props.closeDefinition === 'function') props.closeDefinition();
      if (typeof props.closePhonics === 'function') props.closePhonics();
      if (typeof props.closeRevision === 'function') props.closeRevision();
      if (typeof setSelectionMenu === 'function') setSelectionMenu(null);
      if (typeof setFocusedParagraphIndex === 'function') setFocusedParagraphIndex(null);
    }, [generatedContent?.id, generatedContent?.data]);
    var selectionActionRef = React.useRef(null);
    var selectionDialogRef = React.useRef(null);
    React.useEffect(function () {
      if (!selectionMenu) return;
      var opener = document.activeElement;
      selectionDialogRef.current?.querySelector('button, input')?.focus();
      return function () { if (opener && document.contains(opener)) opener.focus(); };
    }, [!!selectionMenu]);
    // Session-only reading bookmarks are scoped to an exact artifact and source.
    var readerSurfaceRef = React.useRef(null);
    var navigationRef = React.useRef({ positions: new Map(), companions: [], pending: null });
    var [comparisonPreferences, setComparisonPreferences] = React.useState({});
    var [comparisonReturn, setComparisonReturn] = React.useState(null);
    var [linkPassages, setLinkPassages] = React.useState(false);
    var [linkedSection, setLinkedSection] = React.useState(0);
    var [relatedPassage, setRelatedPassage] = React.useState(null);
    var readingFingerprint = value => readingContract?.fingerprintSourceText ? readingContract.fingerprintSourceText(String(value || '')) : String(value || '');
    function readingScopeIdentity(item) {
      var snapshot = readingContract?.getSourceSnapshot?.(item);
      return JSON.stringify([readingContract?.getReadingSourceFamilyId?.(item), item?.unitId !== undefined ? item.unitId : item?.config?.unitId, snapshot?.sourceArtifactId, snapshot?.fingerprint, snapshot?.language, item?.config?.language, item?.instructionalText?.complexity?.language]);
    }
    var rememberedCompanion = protectedOriginal && navigationRef.current.companions.slice().reverse().map(id => (history || []).find(item => item.id === id)).find(item => item && findSimplifiedReadingCompanion([item], generatedContent, capturedSource));
    var companion = !protectedOriginal ? generatedContent : rememberedCompanion || findSimplifiedReadingCompanion(history, generatedContent, capturedSource);
    React.useEffect(function () {
      if (protectedOriginal || !generatedContent?.id || getSimplifiedInstructionalText(generatedContent).form !== 'adapted') return;
      var ids = navigationRef.current.companions.filter(id => id !== generatedContent.id);
      navigationRef.current.companions = ids.concat(generatedContent.id).slice(-30);
    }, [generatedContent?.id, protectedOriginal]);
    var currentReadingFingerprint = React.useMemo(() => readingFingerprint(generatedContent?.data), [generatedContent?.data, readingContract?.fingerprintSourceText]);
    var comparisonPreferenceKey = JSON.stringify([companion?.id || generatedContent?.id, readingScopeIdentity(companion || generatedContent), companion?.data === generatedContent?.data ? currentReadingFingerprint : readingFingerprint(companion?.data)]);
    var pairPreferences = comparisonPreferences[comparisonPreferenceKey] || {};
    var comparisonLanguage = pairPreferences.language || 'auto';
    var requestedComparisonSource = pairPreferences.source || 'linked';
    var selectedComparisonArtifact = isTeacherMode && (history || []).find(item => String(item.id) === requestedComparisonSource && item.id !== generatedContent?.id && ['analysis', 'simplified'].includes(item.type) && getArtifactReadingText(item));
    var comparisonSourceId = selectedComparisonArtifact ? requestedComparisonSource : 'linked';
    var listenAlongScope = [generatedContent?.id, generatedContent?.data, leveledTextLanguage, isCompareMode, !!isTeacherMode, props.readingLearnerKey, !!props.isStudentPreview, comparisonSourceId, comparisonLanguage];
    var listenAlongIsCurrent = comparisonKaraoke?.scope.every((value, index) => value === listenAlongScope[index]);
    React.useEffect(function () { setComparisonKaraoke(null); listenAlongOpenerRef.current = null; }, [...listenAlongScope, isEditingLeveledText]);
    function updateComparisonPreference(field, value) {
      if (supportDraftSession?.blocked()) return requestSupportTransition(() => updateComparisonPreference(field, value));
      if (typeof stopPlayback === 'function') stopPlayback();
      prepareReadingNavigation(null, false);
      setRelatedPassage(null); setLinkedSection(0);
      setComparisonPreferences(previous => {
        var entries = Object.entries(previous).filter(entry => entry[0] !== comparisonPreferenceKey).slice(-29);
        return Object.assign(Object.fromEntries(entries), { [comparisonPreferenceKey]: Object.assign({}, pairPreferences, { [field]: value }) });
      });
    }
    var navigationViewKey = JSON.stringify([generatedContent?.id, currentReadingFingerprint, readingScopeIdentity(generatedContent), isCompareMode ? readingScopeIdentity(selectedComparisonArtifact) : '', isCompareMode ? 'both' : protectedOriginal ? 'original' : 'adapted', isCompareMode ? comparisonSourceId : '', isCompareMode ? readingFingerprint(getArtifactReadingText(selectedComparisonArtifact)) : '', isCompareMode ? comparisonLanguage : '', !!isTeacherMode]);
    function readingOuterScroller() {
      var surface = readerSurfaceRef.current;
      if (props.isStudentPreview) return surface?.closest('[data-student-preview]') || surface;
      for (var parent = surface?.parentElement; parent; parent = parent.parentElement) {
        var overflow = window.getComputedStyle(parent).overflowY;
        if (/(auto|scroll)/.test(overflow) && parent.scrollHeight > parent.clientHeight) return parent;
      }
      return document.scrollingElement || document.documentElement;
    }
    function rememberReadingPosition() {
      var surface = readerSurfaceRef.current;
      if (!surface) return;
      var outer = readingOuterScroller();
      var panes = {};
      surface.querySelectorAll('[data-compare-version]').forEach(node => { panes[node.dataset.compareVersion] = node.scrollTop; });
      var top = outer === document.scrollingElement ? 0 : outer.getBoundingClientRect().top;
      var anchors = Array.from(surface.querySelectorAll('[data-reading-passage] [data-reading-paragraph]'));
      var anchor = anchors.find(node => node.getBoundingClientRect().bottom > top);
      var bookmark = { outer: outer.scrollTop, panes, anchor: anchor?.getAttribute('data-reading-paragraph'), offset: anchor ? anchor.getBoundingClientRect().top - top : null };
      var positions = navigationRef.current.positions;
      positions.delete(navigationViewKey); positions.set(navigationViewKey, bookmark);
      if (positions.size > 60) positions.delete(positions.keys().next().value);
    }
    function prepareReadingNavigation(version, focusPassage) {
      rememberReadingPosition();
      navigationRef.current.pending = { from: navigationViewKey, version, focusPassage: !!focusPassage };
    }
    React.useLayoutEffect(function () {
      var pending = navigationRef.current.pending;
      if (!pending || pending.from === navigationViewKey) return;
      navigationRef.current.pending = null;
      var surface = readerSurfaceRef.current, outer = readingOuterScroller();
      if (!surface || !outer) return;
      var saved = navigationRef.current.positions.get(navigationViewKey);
      var focus = pending.focusPassage ? surface.querySelector('[data-reading-passage], [data-compare-version]') : surface.querySelector('[data-reading-version="' + pending.version + '"]');
      if (focus) focus.focus({ preventScroll: true });
      if (saved) {
        surface.querySelectorAll('[data-compare-version]').forEach(node => { node.scrollTop = saved.panes[node.dataset.compareVersion] || 0; });
        outer.scrollTop = saved.outer;
        var anchor = saved.anchor && Array.from(surface.querySelectorAll('[data-reading-passage] [data-reading-paragraph]')).find(node => node.getAttribute('data-reading-paragraph') === saved.anchor);
        if (anchor) outer.scrollTop += anchor.getBoundingClientRect().top - (outer === document.scrollingElement ? 0 : outer.getBoundingClientRect().top) - saved.offset;
      } else if (isCompareMode) {
        surface.querySelectorAll('[data-compare-version]').forEach(node => { node.scrollTop = 0; });
      } else if (pending.focusPassage && focus) {
        outer.scrollTop += focus.getBoundingClientRect().top - (outer === document.scrollingElement ? 0 : outer.getBoundingClientRect().top) - 12;
      }
    }, [navigationViewKey]);
    function openOriginalReading(item, expectedText, focusPassage) {
      if (protectedOriginal && !isCompareMode && item?.id === generatedContent?.id) return;
      if (supportDraftSession?.blocked()) return requestSupportTransition(() => openOriginalReading(item, expectedText, focusPassage));
      prepareReadingNavigation('original', focusPassage);
      var requestedSnapshot = item?.type === 'simplified' ? readingContract?.getSourceSnapshot?.(item) : null;
      if (isCompareMode) setComparisonReturn({ id: generatedContent.id, fingerprint: readingFingerprint(generatedContent.data), scope: readingScopeIdentity(generatedContent), expectedText: requestedSnapshot?.text || expectedText || capturedSource?.text || '', sourceItem: item });
      if (typeof stopPlayback === 'function') stopPlayback();
      props.onReadOriginal?.(item);
    }
    function focusReadingOffset(pane, offset, focus) {
      var region = readerSurfaceRef.current?.querySelector('[data-compare-version="' + pane + '"]');
      var node = region && Array.from(region.querySelectorAll('[data-reading-offset-start]')).find(element => Number(element.dataset.readingOffsetEnd) > offset);
      if (!node) return;
      region.scrollTop += node.getBoundingClientRect().top - region.getBoundingClientRect().top;
      if (focus) {
        node.tabIndex = -1; node.focus({ preventScroll: true });
        var outer = readingOuterScroller();
        var top = outer === document.scrollingElement ? 0 : outer.getBoundingClientRect().top;
        var bottom = outer === document.scrollingElement ? window.innerHeight : outer.getBoundingClientRect().bottom;
        if (node.getBoundingClientRect().top < top || node.getBoundingClientRect().bottom > bottom) outer.scrollTop += node.getBoundingClientRect().top - top - 12;
      }
    }
    var readerText = function (key, fallback) { var value = t(key); return value && value !== key ? value : fallback; };
    function chooseReadingMode(mode) {
      if (isCompareMode && !['read', 'define', 'phonics', 'explain'].includes(mode) && supportDraftSession?.blocked()) return requestSupportTransition(() => chooseReadingMode(mode));
      if (props.isStudentPreview && !['read', 'define'].includes(mode)) return;
      if (typeof stopPlayback === 'function') stopPlayback();
      if (typeof props.closeDefinition === 'function') props.closeDefinition();
      if (typeof props.closePhonics === 'function') props.closePhonics();
      if (typeof props.closeRevision === 'function') props.closeRevision();
      if (typeof setSelectionMenu === 'function') setSelectionMenu(null);
      if (typeof setRevisionData === 'function') setRevisionData(null);
      if (typeof setPhonicsData === 'function') setPhonicsData(null);
      if (typeof setIsCustomReviseOpen === 'function') setIsCustomReviseOpen(false);
      // Both panes support reading, word meaning, word sounds and explain, so
      // those keep the comparison; choosing one used to drop the original.
      if (!['read', 'define', 'phonics', 'explain'].includes(mode) && typeof setIsCompareMode === 'function') setIsCompareMode(false);
      if (isEditingLeveledText && typeof props.handleToggleIsEditingLeveledText === 'function') props.handleToggleIsEditingLeveledText();
      if (typeof setIsFluencyMode === 'function') setIsFluencyMode(mode === 'fluency');
      if (typeof setInteractionMode === 'function') setInteractionMode(mode === 'fluency' ? 'read' : mode);
    }
    React.useEffect(function () {
      if (isTeacherMode) return;
      // Student comparison is read-only; retain it when changing role.
      if (props.isEditingLeveledText && typeof props.handleToggleIsEditingLeveledText === 'function') props.handleToggleIsEditingLeveledText();
      if (['revise', 'add-glossary'].includes(props.interactionMode)) chooseReadingMode('read');
      if (props.revisionData && props.revisionData.type !== 'explain' && typeof props.closeRevision === 'function') props.closeRevision();
      if (props.isCustomReviseOpen && typeof setIsCustomReviseOpen === 'function') setIsCustomReviseOpen(false);
    }, [isTeacherMode, props.isCompareMode, props.isEditingLeveledText, props.interactionMode, props.revisionData?.type, props.isCustomReviseOpen]);
    var readingLanguage = generatedContent?.config?.language || generatedContent?.instructionalText?.complexity?.language || leveledTextLanguage || 'English';
    // Teacher-prepared word help students can see on this adapted text.
    var learnerScope = JSON.stringify([props.readingLearnerKey, isTeacherMode, !!props.isStudentPreview]);
    var adaptedSupportView = useSimplifiedAdaptedSupportView(generatedContent, learnerScope);
    var shownWordHelpCount = adaptedSupportView.help?.shown && adaptedSupportView.help.status !== 'stale' ? adaptedSupportView.help.annotations.length : 0;
    var hiddenPassageIdentityRef = React.useRef(null);
    var hiddenPassageIdentity = [generatedContent?.id, generatedContent?.data, learnerScope, adaptedSupportView, capturedSource?.text,
      JSON.stringify([generatedContent?.sourceSnapshot, generatedContent?.sourceFamilyId, generatedContent?.unitId, generatedContent?.config?.unitId, generatedContent?.instructionalText]),
      JSON.stringify(generatedContent?.readingSupports || null), JSON.stringify(latestGlossary || []), readingLanguage, interactionMode];
    if (!hiddenPassageIdentityRef.current || hiddenPassageIdentity.some((value, index) => value !== hiddenPassageIdentityRef.current[index])) hiddenPassageRef.current = null;
    hiddenPassageIdentityRef.current = hiddenPassageIdentity;
    // The active mode, named, with what to do in it: the banner under the reading tools.
    function readingModeStatus() {
      if (props.isStudentPreview && interactionMode === 'define') return { mode: 'define', label: viewText('simplified.word_help_word_help', 'Word help'), hint: hasPreparedWordHighlights() ? viewText('simplified.layout_preview_word_help', 'Select an underlined word to see prepared help. Other words have no help in this preview.') : viewText('simplified.define_hint_prepared_no_marks', 'Prepared explanations are available in Word help after the passage.') };
      var arrows = ' ' + viewText('simplified.word_arrows_hint', 'Use Left and Right arrows to move between words.');
      if (isCompareMode) return { mode: 'compare', hint: isTeacherMode ? readerText('simplified.compare_hint', 'Review the source and adapted versions below.') : readerText('simplified.compare_hint_student', 'Read the original and the easier version side by side.') };
      if (isEditingLeveledText) return { mode: 'edit', label: viewText('simplified.mode_editing', 'Editing'), hint: readerText('simplified.edit_hint', 'Edit the passage below. Choose Read to return to reading.') };
      if (isFluencyMode) return { mode: 'fluency', label: readerText('simplified.record_my_reading', 'Record my reading'), hint: readerText('simplified.fluency_hint', 'Use the read-along panel to practice at your own pace.') };
      if (interactionMode === 'define') return { mode: 'define', label: readerText('simplified.word_meaning', 'Word meaning'), hint: viewText('simplified.define_hint', 'Select a word to see what it means.') + (shownWordHelpCount && !protectedOriginal ? ' ' + (hasPreparedWordHighlights() ? viewText('simplified.define_hint_prepared', 'Underlined words open the word help your teacher prepared.') : viewText('simplified.define_hint_prepared_no_marks', 'Prepared explanations are available in Word help after the passage.')) : '') + arrows };
      if (interactionMode === 'phonics') return { mode: 'phonics', label: readerText('simplified.word_sounds', 'Word sounds'), hint: viewText('simplified.phonics_hint', 'Select a word to hear its sounds.') + arrows };
      if (interactionMode === 'add-glossary') return { mode: 'add-glossary', label: readerText('simplified.add_term', 'Add term'), hint: viewText('simplified.add_term_hint', 'Select a word to add it to the glossary.') + arrows };
      if (interactionMode === 'explain') return { mode: 'explain', label: readerText('simplified.explain_mode', 'Explain'), hint: readerText('simplified.explain_hint', 'Choose a sentence for an explanation, or select a longer passage.') };
      if (interactionMode === 'revise') return { mode: 'revise', label: readerText('simplified.revise_mode', 'Revise'), hint: readerText('simplified.revise_hint', 'Select the words you want to revise.') };
      if (interactionMode === 'cloze') return { mode: 'cloze', label: readerText('simplified.practice_blanks', 'Fill in the blanks'), hint: readerText('simplified.cloze_hint', 'Fill in the missing words. Choose Read to see the complete passage.') };
      if (props.isStudentPreview) return { mode: 'read', hint: viewText('simplified.layout_preview_read_hint', 'Read at your own pace. Display changes the appearance of this preview.') };
      return { mode: 'read', hint: protectedOriginal ? readerText('simplified.original_read_hint', 'Read at your own pace. Use Listen to hear the original.') : readerText('simplified.read_hint', 'Read at your own pace. Choose any sentence to listen from there.') };
    }
    // Add term and Revise work on adapted text only; on an original they did nothing.
    // They edit the text, so they sit with the teacher's editing tools, not the reading tools.
    var teacherReadingModes = isTeacherMode && !protectedOriginal ? [['add-glossary', 'simplified.add_term', 'Add term', Plus], ['revise', 'simplified.revise_mode', 'Revise', Pencil]] : [];
    function renderReadingModeButton(entry) {
      var mode = entry[0], Icon = entry[3], active = interactionMode === mode && !isFluencyMode && !isEditingLeveledText;
      return <button type="button" key={mode} aria-describedby={props.isStudentPreview && !['read', 'define'].includes(mode) ? props.previewLimitId : undefined} disabled={props.isStudentPreview && !['read', 'define'].includes(mode)} data-reading-mode={mode} data-help-key={mode === 'add-glossary' ? 'simplified_add_term' : 'simplified_' + mode + '_mode'} onClick={() => chooseReadingMode(mode)} aria-pressed={active} className={'min-h-11 rounded-xl border-2 px-3 py-2 text-sm font-bold inline-flex items-center gap-2 focus-visible:ring-2 focus-visible:ring-indigo-600 focus-visible:ring-offset-2 ' + (active ? 'border-indigo-700 bg-indigo-100 text-indigo-900' : 'border-transparent text-slate-700 hover:bg-slate-100')}><Icon size={16} aria-hidden="true" />{readerText(entry[1], entry[2])}</button>;
    }
    // Selecting an underlined word in Word meaning opens the word help the teacher
    // prepared for it beside the passage, before any AI definition.
    var [wordHelpCard, setWordHelpCard] = React.useState(null);
    var wordHelpInstanceId = React.useId().replace(/[^a-z0-9_-]/gi, '');
    var wordHelpDialogId = 'prepared-word-help-' + wordHelpInstanceId;
    var wordHelpOwnerRef = React.useRef(null), wordHelpSequenceRef = React.useRef(0);
    var wordHelpStopRef = React.useRef(stopPlayback); wordHelpStopRef.current = stopPlayback;
    var wordHelpCardRef = React.useRef(null), wordHelpCardOpener = React.useRef(null);
    useSimplifiedPopupViewport(wordHelpCardRef, wordHelpCard, 20);
    useSimplifiedPopupViewport(definitionDialogRef, definitionData, 16);
    useSimplifiedPopupViewport(phonicsDialogRef, phonicsData, 18);
    useSimplifiedPopupViewport(selectionDialogRef, selectionMenu, 20);
    useSimplifiedPopupViewport(revisionDialogRef, revisionData, 18);
    React.useEffect(() => () => { stopPreparedCardAudio(wordHelpOwnerRef.current); }, []);
    React.useEffect(function () { if (wordHelpCard && wordHelpCardRef.current) wordHelpCardRef.current.focus(); }, [wordHelpCard]);
    function stopPreparedCardAudio(owner) {
      if (!owner || owner.closed) return;
      owner.closed = true;
      if (Object.values(owner.audioIds).includes(simplifiedPlayingContentIdRef.current) && typeof wordHelpStopRef.current === 'function') wordHelpStopRef.current();
    }
    function closeWordHelpCard(restoreFocus) {
      stopPreparedCardAudio(wordHelpOwnerRef.current);
      wordHelpOwnerRef.current = null;
      var opener = wordHelpCardOpener.current;
      wordHelpCardOpener.current = null;
      setWordHelpCard(null);
      if (restoreFocus !== false && opener && opener.isConnected && !opener.closest('[hidden], [inert], [aria-hidden="true"]')) opener.focus();
    }
    function showPreparedWordHelp(event, entry, language, container) {
      var current = readingContract?.validateAdaptedReadingSupports?.(generatedContent, generatedContent.adaptedReadingSupports);
      entry = current?.shown && current.status !== 'stale' && current.annotations.find(value => value.id === entry?.id);
      if (!entry || interactionMode === 'cloze') return false;
      stopPreparedCardAudio(wordHelpOwnerRef.current);
      if (typeof props.closeDefinition === 'function') props.closeDefinition();
      var word = event.currentTarget, rect = word.getBoundingClientRect ? word.getBoundingClientRect() : null;
      var prefix = 'reading-' + generatedContent.id + '-word-help-' + wordHelpInstanceId + '-' + (++wordHelpSequenceRef.current);
      var owner = { entry, language, context: preparedHelpContext, supports: generatedContent.adaptedReadingSupports, supportVersion: adaptedSupportView.version, container,
        audioIds: { word: prefix + '-word', help: prefix + '-card' },
        x: event.clientX || rect?.left || 0, y: event.clientY || rect?.bottom || 0 };
      wordHelpCardOpener.current = word;
      wordHelpOwnerRef.current = owner;
      setWordHelpCard(owner);
      return true;
    }
    function openWordHelpCard(event, container, language) {
      var entry = container ? adaptedWordHelpAt(generatedContent, container, language, event.currentTarget) : null;
      if (!entry) { if (wordHelpCard) closeWordHelpCard(false); return false; }
      return showPreparedWordHelp(event, entry, language, container);
    }
    // Reading place (outline, bookmark, continue, section prompts). Adapted
    // single-language readings only: their paragraphs carry stable numbers.
    var placeLearner = props.isStudentPreview ? '' : props.readingLearnerKey != null ? String(props.readingLearnerKey) : isTeacherMode ? 'teacher' : '';
    var placeItemId = String(generatedContent?.id || '');
    var placeFingerprint = currentReadingFingerprint;
    var placeParagraphs = React.useMemo(() => simplifiedReadAloudText.split(/\n{2,}/), [simplifiedReadAloudText]);
    var placePreview = !!props.isStudentPreview;
    var placeAvailable = !protectedOriginal && !isCompareMode && !isEditingLeveledText && !!placeItemId && typeof generatedContent?.data === 'string'
      && !(typeof getSideBySideContent === 'function' && getSideBySideContent(simplifiedReadAloudText));
    var outlineSections = React.useMemo(() => placeAvailable ? readingOutlineSections(simplifiedReadAloudText) : [], [placeAvailable, simplifiedReadAloudText]);
    var placeScope = { learner: placeLearner, itemId: placeItemId, fingerprint: placeFingerprint, text: generatedContent?.data };
    var placeScopeKey = JSON.stringify([placeLearner, placeItemId, placeFingerprint, generatedContent?.data, placePreview]);
    var [readingPlaceState, setReadingPlaceState] = React.useState(null);
    var [placePersistenceState, setPlacePersistenceState] = React.useState(null);
    // Never render the previous learner/version's data while the load effect is pending.
    var readingPlace = readingPlaceState?.key === placeScopeKey ? readingPlaceState.place : null;
    var placePersistence = placePersistenceState?.key === placeScopeKey ? placePersistenceState.state : null;
    var setReadingPlace = place => setReadingPlaceState({ key: placeScopeKey, place });
    var setPlacePersistence = state => setPlacePersistenceState({ key: placeScopeKey, state });
    var [placeOfferState, setPlaceOfferState] = React.useState(null);
    var [placeNoticeState, setPlaceNoticeState] = React.useState(null);
    var placeOffer = placeOfferState?.key === placeScopeKey ? placeOfferState.offer : null;
    var placeNotice = placeNoticeState?.key === placeScopeKey ? placeNoticeState.notice : '';
    var setPlaceOffer = offer => setPlaceOfferState({ key: placeScopeKey, offer });
    var setPlaceNotice = notice => setPlaceNoticeState({ key: placeScopeKey, notice });
    var [outlineOpen, setOutlineOpen] = React.useState(false);
    var previewPlaceStoreRef = React.useRef(null);
    if (!previewPlaceStoreRef.current) previewPlaceStoreRef.current = createReadingPlaceStore({});
    var placeStore = placePreview ? previewPlaceStoreRef.current : readingPlaceStore;
    React.useEffect(function () { if (placePreview) return placeStore.watchPage(window); }, [placePreview, placeStore]);
    var placeRef = React.useRef({}); placeRef.current = { scope: placeScope, key: placeScopeKey, store: placeStore, available: placeAvailable, offerPending: !!placeOffer && placeOffer.kind === 'continue' };
    var placeMountedRef = React.useRef(true);
    React.useEffect(function () { placeMountedRef.current = true; return function () { placeMountedRef.current = false; }; }, []);
    var paragraphSnippet = index => { var words = simplifiedPlainInline(String(placeParagraphs[index] || '').replace(/^\s{0,3}#{1,6}\s+/gm, '')).split(/\s+/).filter(Boolean); return words.slice(0, 10).join(' ') + (words.length > 10 ? '…' : ''); };
    var [placeReviewState, setPlaceReviewState] = React.useState(null);
    var [placeReviewBusyState, setPlaceReviewBusyState] = React.useState(null);
    var placeReview = placeReviewState?.key === placeScopeKey ? placeReviewState.review : null;
    var placeReviewBusy = placeReviewBusyState?.key === placeScopeKey && placeReviewBusyState.busy;
    var placeReviewRef = React.useRef(null), placeStatusRef = React.useRef(null), priorPlaceReviewRef = React.useRef(null);
    React.useEffect(function () {
      if (placeReview) placeReviewRef.current?.focus();
      else if (priorPlaceReviewRef.current === placeScopeKey) placeStatusRef.current?.focus();
      priorPlaceReviewRef.current = placeReview ? placeScopeKey : null;
    }, [placeReview, placeScopeKey]);
    function applyPlacePersistence(current) {
      if (!placeMountedRef.current || placeRef.current.key !== current.key || !placeRef.current.available) return;
      var state = current.store.peek(current.scope);
      setReadingPlace(state.place); setPlacePersistence(state);
    }
    function storeReadingPlace(update, saveOptions) {
      var current = placeRef.current;
      if (!current.available || previewOpenRef.current) return null;
      var pending = current.store.save(current.scope, update, saveOptions);
      applyPlacePersistence(current);
      return pending.then(function (result) { applyPlacePersistence(current); return result; });
    }
    function reviewReadingConflict() {
      var current = placeRef.current;
      if (!current.available) return;
      var review = current.store.review(current.scope);
      applyPlacePersistence(current);
      setPlaceReviewState(review ? { key: current.key, review } : null);
    }
    async function resolveReadingConflict(choice) {
      var current = placeRef.current;
      if (!current.available || !placeReview || placeReviewBusy) return;
      setPlaceReviewBusyState({ key: current.key, busy: true });
      await current.store.resolve(current.scope, placeReview, choice);
      if (!placeMountedRef.current || placeRef.current.key !== current.key) return;
      applyPlacePersistence(current);
      setPlaceReviewBusyState(null); setPlaceReviewState(null);
    }
    function readingRecoveryText(place, sourceText) {
      var recoverySections = sourceText === undefined ? outlineSections : readingOutlineSections(sourceText);
      var lines = [], answers = place?.responses || {};
      if (place?.bookmark) lines.push(viewText('simplified.place_recovery_bookmark', 'Bookmark') + ': ' + place.bookmark.snippet, '');
      Object.keys(answers).forEach(first => {
        var answer = answers[first];
        if (!['mainIdea', 'support', 'confusing', 'confusingNote'].some(field => !!answer[field])) return;
        var section = recoverySections.find(entry => String(entry.first) === first);
        lines.push(section ? section.label : viewText('simplified.place_recovery_paragraph', 'Paragraph {number}', { number: Number(first) + 1 }));
        var labels = [
          ['mainIdea', viewText('simplified.prompt_main_idea', 'What is the main idea?')],
          ['support', viewText('simplified.prompt_support', 'Which sentence supports it?')],
          ['confusing', viewText('simplified.prompt_confusing', 'Mark a confusing part.')],
          ['confusingNote', viewText('simplified.prompt_confusing_note', 'What is confusing about it? (optional)')]
        ];
        labels.forEach(([field, label]) => { if (answer[field]) lines.push(label, answer[field], ''); });
      });
      return lines.join('\n').trim() || viewText('simplified.place_recovery_empty', 'No bookmarks or answers yet.');
    }
    var [placeStorageState, setPlaceStorageState] = React.useState(null);
    var [placeDownloadState, setPlaceDownloadState] = React.useState(null);
    var [placeBackupOpenState, setPlaceBackupOpenState] = React.useState(null);
    var placeStorage = placeStorageState?.key === placeScopeKey ? placeStorageState : null;
    var placeDownloadNotice = placeDownloadState?.key === placeScopeKey ? placeDownloadState.text : '';
    var placeStorageRef = React.useRef(null), priorPlaceStorageRef = React.useRef(null);
    React.useEffect(function () {
      if (placeStorage?.review) placeStorageRef.current?.focus();
      else if (priorPlaceStorageRef.current === placeScopeKey) placeStatusRef.current?.focus();
      priorPlaceStorageRef.current = placeStorage?.review ? placeScopeKey : null;
    }, [placeStorage?.review, placeScopeKey]);
    function reviewReadingStorage() {
      var current = placeRef.current;
      if (!current.available) return;
      var review = current.store.inspectSaved(current.scope);
      applyPlacePersistence(current);
      setPlaceStorageState({ key: current.key, review, checked: false, busy: false });
    }
    async function changeReadingStorage(action) {
      var current = placeRef.current;
      if (!current.available || !placeStorage?.review || !placeStorage.checked || placeStorage.busy) return;
      setPlaceStorageState({ ...placeStorage, busy: true });
      await current.store.manageSaved(current.scope, placeStorage.review, action);
      if (!placeMountedRef.current || placeRef.current.key !== current.key) return;
      applyPlacePersistence(current); setPlaceStorageState(null);
    }
    function downloadReadingRecovery() {
      var current = placeRef.current, url = null, link = null;
      try {
        var exported = current.store.exportSession(current.scope.learner), lines = [viewText('simplified.place_backup_title', 'Reading work recovery copy'), ''];
        exported.readings.forEach((reading, index) => {
          lines.push(viewText('simplified.place_backup_reading', 'Reading {number}', { number: index + 1 }),
            viewText('simplified.place_backup_passage', 'Exact reading text:'), reading.scope.text || '', '',
            viewText('simplified.place_review_local', 'This page’s draft'), readingRecoveryText(reading.place, reading.scope.text), '');
          reading.recoveryCopies.forEach((saved, savedIndex) => {
            lines.push(viewText('simplified.place_backup_copy', 'Recovery copy {number}', { number: savedIndex + 1 }), readingRecoveryText(saved.place, reading.scope.text), '');
            if (saved.rawRow) lines.push(viewText('simplified.place_backup_original', 'Original saved record for recovery:'), saved.rawRow, '');
          });
        });
        if (placeStorage?.review) lines.push(viewText('simplified.place_backup_original', 'Original saved record for recovery:'), placeStorage.review.token, '');
        url = URL.createObjectURL(new Blob([lines.join('\n')], { type: 'text/plain;charset=utf-8' }));
        link = document.createElement('a'); link.href = url; link.download = 'reading-work-recovery.txt'; document.body.appendChild(link); link.click();
        setPlaceDownloadState({ key: current.key, text: viewText('simplified.place_download_requested', 'Download requested. Check that the file contains the work you need before closing this page.') });
      } catch (_) {
        setPlaceDownloadState({ key: current.key, text: viewText('simplified.place_download_failed', 'The download could not start. Keep this page open and use the selectable recovery text below.') });
      } finally {
        link?.remove();
        if (url) window.setTimeout(() => URL.revokeObjectURL(url), 30000);
      }
    }
    function readingStorageProblem(state) {
      var problem = state.problem;
      if (problem?.kind === 'answer-size') {
        var labels = { mainIdea: viewText('simplified.prompt_main_idea', 'What is the main idea?'), support: viewText('simplified.prompt_support', 'Which sentence supports it?'),
          confusing: viewText('simplified.prompt_confusing', 'Mark a confusing part.'), confusingNote: viewText('simplified.prompt_confusing_note', 'What is confusing about it? (optional)') };
        var section = outlineSections.find(entry => String(entry.first) === String(problem.section));
        return viewText('simplified.place_answer_limit', '{section} — {question} This answer is too long to save. Copy or download it before shortening it.', {
          section: section?.label || viewText('simplified.place_recovery_paragraph', 'Paragraph {number}', { number: Number(problem.section) + 1 }),
          question: labels[problem.field] });
      }
      if (problem?.kind === 'store-size') return viewText('simplified.place_store_limit', 'The saved reading collection is too large. Download work you need, then open a reading you no longer need and remove its saved work.');
      if (state.reason === 'quota') return viewText('simplified.place_browser_quota', 'The browser could not make room for this save. Download your work, free browser storage if appropriate, then retry.');
      if (state.reason === 'capacity') return viewText('simplified.place_capacity_recovery', 'Open a saved reading you no longer need. Download its work, then use Saved reading storage to remove that reading before retrying here.');
      if (state.reason === 'retry-needed') return viewText('simplified.place_repair_retry', 'The readable saved fields have been repaired. Your newer draft is still here; retry saving it.');
      return '';
    }
    function renderReadingRecoveryActions(state, hasCopyableWork, button, textArea) {
      var backupOpen = placeBackupOpenState?.key === placeScopeKey && placeBackupOpenState.open;
      var session = backupOpen ? placeStore.exportSession(placeLearner) : { readings: [] }, hasSessionWork = placeStore.hasSessionWork(placeLearner);
      return <>
        {!!readingStorageProblem(state) && <p data-reading-storage-problem>{readingStorageProblem(state)}</p>}
        {(hasSessionWork || (placeLearner && state.status === 'failed')) && <details data-reading-storage-tools className="mt-2" open={!!backupOpen} onToggle={event => { var open = event.currentTarget.open; if (open !== !!backupOpen) setPlaceBackupOpenState({ key: placeScopeKey, open }); }}>
          <summary className="min-h-11 cursor-pointer py-2">{viewText('simplified.place_backup_tools', 'Backup and saved reading storage')}</summary>
          <p>{viewText('simplified.place_backup_scope', 'The download includes work opened on this page for this learner, with each exact reading and any recovery copies. Work for other learners is excluded.')}</p>
          <div className="my-2 flex flex-wrap gap-2">
            {hasSessionWork && <button type="button" data-reading-download onClick={downloadReadingRecovery} className={button}>{viewText('simplified.place_download', 'Download recovery copy')}</button>}
            {!!placeLearner && <button type="button" data-reading-storage-review onClick={reviewReadingStorage} disabled={!!placeStorage?.busy} className={button}>{viewText('simplified.place_storage_manage', 'Saved reading storage')}</button>}
          </div>
          {!!placeDownloadNotice && <p role="status">{placeDownloadNotice}</p>}
          {hasSessionWork && <details><summary className="min-h-11 cursor-pointer py-2">{viewText('simplified.place_backup_selectable', 'Select recovery text if download is unavailable')}</summary>
            {session.readings.map((reading, index) => <label key={index} className="my-2 block">{viewText('simplified.place_backup_reading', 'Reading {number}', { number: index + 1 })}<textarea data-reading-session-copy readOnly rows={6} className={textArea} onFocus={event => event.target.select()} value={[reading.scope.text, readingRecoveryText(reading.place, reading.scope.text), ...reading.recoveryCopies.map(saved => readingRecoveryText(saved.place, reading.scope.text) + (saved.rawRow ? '\n' + saved.rawRow : ''))].join('\n\n')} /></label>)}
          </details>}
          {placeStorage && !placeStorage.review && <p role="status">{viewText('simplified.place_storage_unavailable', 'There is no safely readable saved record for this exact reading. Your draft remains available above. A damaged collection cannot be reset here because it may contain other learners’ work.')}</p>}
          {placeStorage?.review && <section data-reading-storage-panel ref={placeStorageRef} tabIndex={-1} aria-busy={placeStorage.busy} aria-label={viewText('simplified.place_storage_manage', 'Saved reading storage')} className="mt-2 space-y-2 rounded border p-3">
            <p>{viewText('simplified.place_storage_scope', 'Only this learner’s saved work for this exact reading will change. Removing it clears its bookmark and answers here. Recovery copies stay on this page until it closes.')}</p>
            <label>{viewText('simplified.place_review_saved', 'Saved work')}<textarea readOnly rows={5} className={textArea} value={readingRecoveryText(placeStorage.review.place)} onFocus={event => event.target.select()} /></label>
            {placeStorage.review.corrupt && <p>{viewText('simplified.place_storage_repair_help', 'This record contains damaged fields. Repair keeps readable fields and retains the original record in a recovery copy. Other damaged records may still prevent saving.')}</p>}
            <button type="button" data-reading-storage-download className={button} onClick={downloadReadingRecovery}>{viewText('simplified.place_download', 'Download recovery copy')}</button>
            <label className="flex min-h-11 items-center gap-2"><input type="checkbox" data-reading-storage-confirm checked={placeStorage.checked} disabled={placeStorage.busy} onChange={event => setPlaceStorageState({ ...placeStorage, checked: event.target.checked })} />{viewText('simplified.place_storage_confirm', 'I have kept a copy of the work I need.')}</label>
            <div className="flex flex-wrap gap-2">
              <button type="button" data-reading-storage-remove disabled={!placeStorage.checked || placeStorage.busy} onClick={() => changeReadingStorage('remove')} className={button}>{viewText('simplified.place_storage_remove', 'Remove this reading’s saved work')}</button>
              {placeStorage.review.corrupt && <button type="button" data-reading-storage-repair disabled={!placeStorage.checked || placeStorage.busy} onClick={() => changeReadingStorage('repair')} className={button}>{viewText('simplified.place_storage_repair', 'Repair readable fields')}</button>}
              <button type="button" disabled={placeStorage.busy} onClick={() => setPlaceStorageState(null)} className={button}>{viewText('common.cancel', 'Cancel')}</button>
            </div>
          </section>}
        </details>}
      </>;
    }

    var [placeCopyReviewState, setPlaceCopyReviewState] = React.useState(null);
    var placeCopyReview = placeCopyReviewState?.key === placeScopeKey ? placeCopyReviewState : null;
    var placeCopyReviewRef = React.useRef(null), priorPlaceCopyReviewRef = React.useRef(null);
    React.useEffect(function () {
      if (placeCopyReview) placeCopyReviewRef.current?.focus();
      else if (priorPlaceCopyReviewRef.current === placeScopeKey) placeStatusRef.current?.focus();
      priorPlaceCopyReviewRef.current = placeCopyReview ? placeScopeKey : null;
    }, [placeCopyReview?.review, placeScopeKey]);
    function reviewRecoveryCopy(index) {
      var current = placeRef.current;
      if (!current.available || previewOpenRef.current) return;
      var review = current.store.reviewRecovery(current.scope, index);
      setPlaceCopyReviewState(review ? { key: current.key, review, confirmed: false } : null);
    }
    function changeRecoveryCopy(action) {
      var current = placeRef.current;
      if (!current.available || previewOpenRef.current || !placeCopyReview || (action === 'remove' && !placeCopyReview.confirmed)) return;
      current.store.changeRecovery(current.scope, placeCopyReview.review, action);
      applyPlacePersistence(current); setPlaceCopyReviewState(null);
    }
    function renderRecoveryCopyReview(button, textArea) {
      if (!placeCopyReview) return null;
      var review = placeCopyReview.review;
      return <section data-reading-copy-panel ref={placeCopyReviewRef} tabIndex={-1} aria-label={viewText('simplified.place_copy_review_title', 'Review a recovery copy')} className="my-3 space-y-3 rounded border border-amber-600 bg-white p-3">
        <h4 className="font-bold">{viewText('simplified.place_copy_review_title', 'Review a recovery copy')}</h4>
        <p>{viewText('simplified.place_copy_restore_help', 'Restoring replaces this page’s answers and bookmark with the copy below. Your current work is kept in another recovery copy. Review the restored draft before saving it.')}</p>
        <div className="grid gap-3 md:grid-cols-2">
          <label>{viewText('simplified.place_review_local', 'This page’s draft')}<textarea data-reading-copy-current readOnly rows={6} className={textArea} value={readingRecoveryText(review.local)} onFocus={event => event.target.select()} /></label>
          <label>{viewText('simplified.place_copy_selected', 'Selected recovery copy')}<textarea data-reading-copy-selected readOnly rows={6} className={textArea} value={readingRecoveryText(review.recovered)} onFocus={event => event.target.select()} /></label>
        </div>
        {!review.canRestore && <p>{viewText('simplified.place_copy_no_readable_work', 'This copy has no readable answers or bookmark to restore. Its original record is still available in the recovery download.')}</p>}
        <button type="button" data-reading-copy-restore disabled={!review.canRestore} onClick={() => changeRecoveryCopy('restore')} className={button}>{viewText('simplified.place_copy_restore', 'Restore as a draft')}</button>
        <p>{viewText('simplified.place_copy_remove_help', 'Removing this copy only removes it from this page. It does not change your current answers, bookmark, or saved work.')}</p>
        <label className="flex min-h-11 items-center gap-2"><input data-reading-copy-confirm type="checkbox" checked={placeCopyReview.confirmed} onChange={event => setPlaceCopyReviewState({ ...placeCopyReview, confirmed: event.target.checked })} />{viewText('simplified.place_copy_remove_confirm', 'I have kept this copy or no longer need it.')}</label>
        <div className="flex flex-wrap gap-2">
          <button type="button" data-reading-copy-remove disabled={!placeCopyReview.confirmed} onClick={() => changeRecoveryCopy('remove')} className={button}>{viewText('simplified.place_copy_remove', 'Remove this recovery copy')}</button>
          <button type="button" data-reading-copy-cancel onClick={() => setPlaceCopyReviewState(null)} className={button}>{viewText('common.cancel', 'Cancel')}</button>
        </div>
      </section>;
    }

    function renderPlacePersistence() {
      var state = placePersistence;
      if (!state) return null;
      var label = state.reason === 'recovered-draft' ? viewText('simplified.place_copy_restored', 'Recovery copy restored on this page. Review it, then choose Save restored work. Reloading will discard unsaved changes.')
        : state.status === 'saved' ? viewText('simplified.place_saved_device', 'Saved on this device for this version of the reading.')
        : state.status === 'saving' ? viewText('simplified.place_saving', 'Saving on this device…')
        : state.status === 'session-only' ? (placePreview ? viewText('simplified.place_preview_only', 'Kept only while this preview is open.') : viewText('simplified.place_page_only', 'Kept only while this page is open. Reloading will clear this work.'))
        : state.status === 'failed' ? viewText('simplified.place_save_failed', 'Couldn’t save on this device. Your work is still here while this page stays open. Reloading may lose these changes.')
        : viewText('simplified.place_save_ready', 'Optional. Answers will be saved on this device when storage is available.');
      var reasons = {
        conflict: ['simplified.place_save_conflict', 'This reading’s saved work changed in another tab. Your draft is still here. Review both versions before choosing which to use.'],
        'review-changed': ['simplified.place_review_changed', 'Your draft or the saved work changed after this review. Review both versions again before choosing.'],
        'version-conflict': ['simplified.place_save_version_conflict', 'The saved work belongs to different text. Your bookmark and answers have not been moved.'],
        'corrupt-store': ['simplified.place_save_corrupt', 'Some saved reading data could not be read. Existing saved data has been left unchanged.'],
        'too-large': ['simplified.place_save_large', 'This work is too large to save. Copy your answers before shortening them.'],
        capacity: ['simplified.place_save_capacity', 'Reading storage is full. Existing bookmarks and answers have been kept.'],
        'coordination-unavailable': ['simplified.place_save_coordination', 'This browser cannot safely save reading work across tabs. Keep this page open or copy your answers.']
      };
      reasons['recovery-changed'] = ['simplified.place_copy_changed', 'The draft or recovery copy changed. Review it again before continuing.'];
      reasons['recovery-empty'] = ['simplified.place_copy_empty', 'This recovery copy has no readable answers or bookmark to restore.'];
      var reason = reasons[state.reason];
      var hasCopyableWork = !!readingPlace?.bookmark || Object.values(readingPlace?.responses || {}).some(answer => ['mainIdea', 'support', 'confusing', 'confusingNote'].some(field => !!answer[field]));
      var textArea = 'block w-full rounded border border-slate-400 bg-white p-2';
      var button = 'min-h-11 rounded-lg border border-amber-700 bg-white px-3 disabled:opacity-50';
      return <div data-reading-persistence={state.status} className={'my-2 rounded-lg p-2 text-sm ' + (state.status === 'failed' ? 'border border-amber-500 bg-amber-50 text-amber-950' : 'text-slate-700')}>
        <p role="status" ref={placeStatusRef} tabIndex={-1}>{label}{reason ? ' ' + viewText(reason[0], reason[1]) : ''}</p>
        {state.status === 'failed' && <div className="mt-2 flex flex-wrap gap-2">
          <button type="button" data-reading-save-retry disabled={placeReviewBusy} onClick={() => storeReadingPlace({}, { confirmRecovery: true })} className={button}>{state.reason === 'recovered-draft' ? viewText('simplified.place_copy_save', 'Save restored work') : viewText('simplified.place_retry', 'Retry saving')}</button>
          {['conflict', 'review-changed'].includes(state.reason) && <button type="button" data-reading-conflict-review disabled={placeReviewBusy} onClick={reviewReadingConflict} className={button}>{viewText('simplified.place_review_versions', 'Review both versions')}</button>}
        </div>}
        {renderReadingRecoveryActions(state, hasCopyableWork, button, textArea)}
        {renderRecoveryCopyReview(button, textArea)}
        {placeReview && <section data-reading-conflict-panel ref={placeReviewRef} tabIndex={-1} aria-label={viewText('simplified.place_review_title', 'Choose which work to use')} aria-busy={!!placeReviewBusy} className="mt-3 space-y-3 rounded border border-amber-600 bg-white p-3">
          <h4 className="font-bold">{viewText('simplified.place_review_title', 'Choose which work to use')}</h4>
          <p>{viewText('simplified.place_review_retained', 'A copy of the version you replace stays available below while this page is open.')}</p>
          <div className="grid gap-3 md:grid-cols-2">
            <label>{viewText('simplified.place_review_local', 'This page’s draft')}<textarea data-reading-conflict-local readOnly rows={6} value={readingRecoveryText(placeReview.local)} onFocus={event => event.target.select()} className={textArea} /></label>
            <label>{viewText('simplified.place_review_saved', 'Saved work')}<textarea data-reading-conflict-saved readOnly rows={6} value={placeReview.saved ? readingRecoveryText(placeReview.saved) : viewText('simplified.place_review_removed', 'No saved work remains for this reading.')} onFocus={event => event.target.select()} className={textArea} /></label>
          </div>
          <div className="flex flex-wrap gap-2">
            <button type="button" data-reading-conflict-keep disabled={placeReviewBusy} onClick={() => resolveReadingConflict('local')} className={button}>{viewText('simplified.place_review_keep', 'Save this page’s draft instead')}</button>
            <button type="button" data-reading-conflict-use disabled={placeReviewBusy} onClick={() => resolveReadingConflict('saved')} className={button}>{viewText('simplified.place_review_use', 'Use the saved work')}</button>
            <button type="button" data-reading-conflict-cancel disabled={placeReviewBusy} onClick={() => setPlaceReviewState(null)} className={button}>{viewText('common.cancel', 'Cancel')}</button>
          </div>
        </section>}
        {hasCopyableWork && ['failed', 'session-only'].includes(state.status) && <details className="mt-2"><summary className="min-h-11 cursor-pointer py-2">{viewText('simplified.place_copy_work', 'Copy your work')}</summary><label className="block">{viewText('simplified.place_work_to_copy', 'Work to copy')}<textarea data-reading-work-copy readOnly rows={6} value={readingRecoveryText(readingPlace)} onFocus={event => event.target.select()} className={textArea} /></label></details>}
        {!!state.recoveryCopies?.length && <details data-reading-recovery-copies className="mt-2"><summary className="min-h-11 cursor-pointer py-2">{viewText('simplified.place_recovery_copies', 'Recovery copies for this page')}</summary>
          <p>{viewText('simplified.place_recovery_lifetime', 'These copies are temporary. Copy any work you need before closing or reloading this page.')}</p>
          {state.recoveryCopies.map((entry, index) => <div key={index} className="my-2"><label className="block">{entry.source === 'local' ? viewText('simplified.place_recovery_local', 'Your earlier draft') : viewText('simplified.place_recovery_saved', 'Previously saved work')}{' ' + (index + 1)}<textarea data-reading-recovery-copy readOnly rows={6} value={readingRecoveryText(entry.place)} onFocus={event => event.target.select()} className={textArea} /></label><button type="button" data-reading-copy-review onClick={() => reviewRecoveryCopy(index)} className={button}>{viewText('simplified.place_copy_review_action', 'Review copy {number}', { number: index + 1 })}</button></div>)}
        </details>}
      </div>;
    }

    function passageParagraphNodes() {
      var surface = readerSurfaceRef.current;
      return surface ? Array.from(surface.querySelectorAll('[data-reading-passage] [data-reading-paragraph]')).filter(node => /^\d+$/.test(node.getAttribute('data-reading-paragraph'))) : [];
    }
    // The paragraph being read: the focused one, else the first one on screen.
    function currentReadingParagraph() {
      var nodes = passageParagraphNodes();
      if (!nodes.length) return null;
      var active = document.activeElement && document.activeElement.closest ? document.activeElement.closest('[data-reading-paragraph]') : null;
      if (active && nodes.includes(active)) return Number(active.getAttribute('data-reading-paragraph'));
      var outer = readingOuterScroller();
      var top = outer === document.scrollingElement ? 0 : outer.getBoundingClientRect().top;
      var visible = nodes.find(node => node.getBoundingClientRect().bottom > top + 4);
      return Number((visible || nodes[0]).getAttribute('data-reading-paragraph'));
    }
    function goToReadingParagraph(index) {
      var node = passageParagraphNodes().find(element => Number(element.getAttribute('data-reading-paragraph')) === Number(index));
      if (!node) return false;
      var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      scrollReadingTarget(node, { block: 'start', behavior: reduceMotion ? 'auto' : 'smooth' });
      if (!node.hasAttribute('tabindex')) node.setAttribute('tabindex', '-1');
      node.focus({ preventScroll: true });
      return true;
    }
    function rememberPlace(resume) {
      var paragraph = currentReadingParagraph();
      if (paragraph == null || !placeRef.current.available) return;
      storeReadingPlace({ paragraph, snippet: paragraphSnippet(paragraph), resume: !!resume });
    }
    React.useEffect(function () {
      setPlaceOffer(null); setPlaceNotice(''); setOutlineOpen(false);
      if (!placeAvailable) { setReadingPlace(null); setPlacePersistence(null); return undefined; }
      var loaded = placeStore.load(placeScope);
      var place = loaded.place;
      setReadingPlace(place); setPlacePersistence(loaded);
      // Back from reflection or another tool in the same visit: return quietly.
      if (!placePreview && place && place.resume && place.paragraph > 0 && place.snippet === paragraphSnippet(place.paragraph) && Date.now() - (place.at || 0) < 7200000) {
        var previewSession = previewSessionRef.current;
        var timer = setTimeout(function () {
          if (previewOpenRef.current || previewSession !== previewSessionRef.current) return;
          if (goToReadingParagraph(place.paragraph)) setPlaceNotice(viewText('simplified.place_returned', 'Back where you were reading.'));
          storeReadingPlace({ resume: false });
        }, 0);
        return function () { clearTimeout(timer); };
      }
      // Never jump on its own: offer, and only for this exact version.
      if (place && place.paragraph > 0 && place.snippet === paragraphSnippet(place.paragraph)) setPlaceOffer({ kind: 'continue', paragraph: place.paragraph, snippet: place.snippet });
      else if (loaded.revised) setPlaceOffer({ kind: 'revised' });
      return undefined;
    }, [placeScopeKey, placeAvailable]);
    React.useEffect(function () {
      if (!placeAvailable || placePreview || !placeLearner) return undefined;
      var refresh = function (event) {
        if (event.key !== null && event.key !== placeStore.key) return;
        var state = placeStore.load(placeScope);
        setReadingPlace(state.place); setPlacePersistence(state);
      };
      window.addEventListener('storage', refresh);
      return function () { window.removeEventListener('storage', refresh); };
    }, [placeScopeKey, placeAvailable]);
    React.useEffect(function () {
      if (!placeAvailable || placePreview || studentPreview || typeof document === 'undefined') return undefined;
      var timer = null;
      // An open Continue offer keeps the saved place until the reader answers it.
      var onScroll = function () { if (timer) return; timer = setTimeout(function () { timer = null; if (!placeRef.current.offerPending) rememberPlace(false); }, 800); };
      document.addEventListener('scroll', onScroll, true);
      return function () { document.removeEventListener('scroll', onScroll, true); if (timer) clearTimeout(timer); };
    }, [placeLearner, placeItemId, placeFingerprint, placeAvailable, !!studentPreview]);
    // Optional prompts about one section, answered beside the passage so the
    // reading place and the answers stay put across reading and listening.
    var [promptsOpen, setPromptsOpen] = React.useState(false);
    var [promptSection, setPromptSection] = React.useState(0);
    React.useEffect(function () { setPromptsOpen(false); setPromptSection(0); }, [placeItemId, placeFingerprint]);
    function sectionAtParagraph(paragraph) { return outlineSections.find(section => paragraph != null && paragraph >= section.first && paragraph <= section.last) || outlineSections[0] || null; }
    function openSectionPrompts() {
      var section = sectionAtParagraph(currentReadingParagraph());
      setPromptSection(section ? section.index : 0);
      setPromptsOpen(true);
    }
    function saveSectionResponse(section, field, value) {
      storeReadingPlace({ responses: { [section.first]: { [field]: value } } });
    }
    function renderSectionPrompts() {
      var section = outlineSections[promptSection] || outlineSections[0];
      if (!section) return null;
      var answers = ((readingPlace && readingPlace.responses) || {})[section.first] || {};
      var plain = simplifiedPlainInline(section.text.replace(/^\s{0,3}#{1,6}\s+.*$/gm, '')).trim();
      var sentences = (typeof splitTextToSentences === 'function' ? splitTextToSentences(plain) : [plain]).map(sentence => String(sentence).trim()).filter(Boolean);
      var field = 'mt-1 min-h-11 w-full min-w-0 rounded-lg border border-slate-400 bg-white px-2 font-normal';
      var sentencePicker = (name, value) => <select value={value || ''} onChange={event => saveSectionResponse(section, name, event.target.value)} className={field}><option value="">{viewText('simplified.prompt_choose_sentence', 'Choose a sentence')}</option>{sentences.map((sentence, index) => <option key={index} value={sentence}>{sentence.length > 140 ? sentence.slice(0, 140) + '…' : sentence}</option>)}{value && !sentences.includes(value) ? <option value={value}>{value}</option> : null}</select>;
      return <section id={readerId('simplified-section-prompts')} data-section-prompts aria-labelledby={readerId('simplified-section-prompts-title')} className="mt-3 space-y-3 rounded-xl border border-indigo-200 bg-white p-3 text-base text-slate-900">
        <div className="flex flex-wrap items-center justify-between gap-2"><h3 id={readerId('simplified-section-prompts-title')} className="text-lg font-bold text-indigo-950">{viewText('simplified.prompt_title', 'Think about a section')}</h3><button type="button" onClick={event => { var toggle = event.currentTarget.closest('[data-section-prompts-area]')?.querySelector('[data-section-prompts-toggle]'); setPromptsOpen(false); toggle?.focus(); }} className="min-h-11 rounded-lg border border-slate-300 bg-white px-3 text-sm">{viewText('common.close', 'Close')}</button></div>
        {renderPlacePersistence()}
        <label className="block font-semibold">{viewText('simplified.prompt_section', 'Section')}<select data-section-prompts-section value={section.index} onChange={event => setPromptSection(Number(event.target.value))} className={field}>{outlineSections.map(entry => <option key={entry.index} value={entry.index}>{entry.label}</option>)}</select></label>
        <div className="flex flex-wrap gap-2"><button type="button" onClick={() => goToReadingParagraph(section.first)} className="min-h-11 rounded-lg border border-indigo-300 bg-white px-3 text-sm text-indigo-900">{viewText('simplified.prompt_go_to_section', 'Go to this section')}</button><button type="button" aria-describedby={props.isStudentPreview ? props.previewLimitId : undefined} disabled={!!props.isStudentPreview} onClick={() => speakExactPassage(plain, 'section-' + section.first, readingLanguage)} className="min-h-11 rounded-lg border border-indigo-300 bg-white px-3 text-sm text-indigo-900">{isExactPassagePlaying('section-' + section.first) ? viewText('common.stop', 'Stop') : viewText('simplified.prompt_listen_section', 'Listen to this section')}</button></div>
        <label className="block font-semibold">{viewText('simplified.prompt_main_idea', 'What is the main idea?')}<textarea data-section-prompt="mainIdea" rows={2} value={answers.mainIdea || ''} onChange={event => saveSectionResponse(section, 'mainIdea', event.target.value)} className={field + ' py-2'} /></label>
        <label className="block font-semibold">{viewText('simplified.prompt_support', 'Which sentence supports it?')}{sentencePicker('support', answers.support)}</label>
        <label className="block font-semibold">{viewText('simplified.prompt_confusing', 'Mark a confusing part.')}{sentencePicker('confusing', answers.confusing)}</label>
        {answers.confusing && <label className="block font-semibold">{viewText('simplified.prompt_confusing_note', 'What is confusing about it? (optional)')}<textarea data-section-prompt="confusingNote" rows={2} value={answers.confusingNote || ''} onChange={event => saveSectionResponse(section, 'confusingNote', event.target.value)} className={field + ' py-2'} /></label>}
      </section>;
    }
    function renderReadingPlaceControls() {
      if (!placeAvailable || interactionMode === 'cloze') return null;
      var button = 'min-h-11 rounded-lg border border-indigo-200 bg-white px-3 py-2 text-indigo-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600';
      return <>
        {outlineSections.length >= 3 && <button type="button" data-reading-outline-toggle aria-expanded={outlineOpen} aria-controls={outlineOpen ? readerId('simplified-reading-outline') : undefined} onClick={() => setOutlineOpen(!outlineOpen)} className={button}>{viewText('simplified.outline_toggle', 'Sections & bookmark')}{outlineOpen ? <ChevronUp size={14} className="inline ml-1" aria-hidden="true" /> : <ChevronDown size={14} className="inline ml-1" aria-hidden="true" />}</button>}
      </>;
    }
    function renderReadingPlacePanels() {
      if (!placeAvailable || interactionMode === 'cloze') return null;
      var current = sectionAtParagraph(readingPlace ? readingPlace.paragraph : null);
      var small = 'min-h-11 rounded-lg border border-indigo-300 bg-white px-3 text-sm text-indigo-900 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600';
      return <>
        {placeOffer && placeOffer.kind === 'continue' && <div data-reading-continue className="mb-4 flex flex-wrap items-center gap-2 rounded-xl border border-indigo-200 bg-indigo-50 p-3 text-base text-indigo-950"><p className="min-w-0 flex-1">{viewText('simplified.place_continue', 'Continue where you left off: {snippet}', { snippet: placeOffer.snippet })}</p><button type="button" data-reading-continue-go onClick={() => { var target = placeOffer.paragraph; setPlaceOffer(null); if (goToReadingParagraph(target)) setPlaceNotice(viewText('simplified.place_continuing', 'Continuing where you left off.')); }} className="min-h-11 rounded-lg bg-indigo-700 px-3 font-semibold text-white">{viewText('simplified.place_continue_button', 'Continue')}</button><button type="button" data-reading-continue-restart onClick={() => { setPlaceOffer(null); storeReadingPlace({ paragraph: 0, snippet: paragraphSnippet(0) }); }} className="min-h-11 rounded-lg border border-indigo-300 bg-white px-3 text-indigo-900">{viewText('simplified.place_start_over', 'Start from the beginning')}</button></div>}
        {placeOffer && placeOffer.kind === 'revised' && <div data-reading-revised className="mb-4 flex flex-wrap items-center gap-2 rounded-xl border border-amber-300 bg-amber-50 p-3 text-base text-amber-950"><p className="min-w-0 flex-1">{viewText('simplified.place_revised', 'This reading was changed since you last read it, so it starts at the beginning. Earlier bookmarks and answers belong to the old version.')}</p><button type="button" onClick={() => setPlaceOffer(null)} className="min-h-11 rounded-lg border border-amber-700 bg-white px-3">{viewText('simplified.place_ok', 'OK')}</button></div>}
        <p role="status" data-reading-place-notice className={placeNotice ? 'mb-3 text-sm text-indigo-900' : 'sr-only'}>{placeNotice}</p>
        {!promptsOpen && renderPlacePersistence()}
        {outlineOpen && outlineSections.length >= 3 && <nav id={readerId('simplified-reading-outline')} data-reading-outline aria-label={viewText('simplified.outline_label', 'Sections of this reading')} className="mb-4 space-y-2 rounded-xl border border-indigo-100 bg-white p-2 text-base">
          {<ol className="space-y-1">{outlineSections.map(section => <li key={section.index}><button type="button" aria-current={current && current.index === section.index ? 'location' : undefined} onClick={() => goToReadingParagraph(section.first)} className={'min-h-11 w-full rounded-lg px-3 py-2 text-left hover:bg-indigo-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 ' + (current && current.index === section.index ? 'font-bold text-indigo-950' : 'text-slate-800')}>{section.label}</button></li>)}</ol>}
          <div className="flex flex-wrap gap-2 px-1 pb-1">
            <button type="button" data-reading-bookmark onClick={saveBookmark} className={small}>{readingPlace && readingPlace.bookmark ? viewText('simplified.place_move_bookmark', 'Move bookmark here') : viewText('simplified.place_bookmark', 'Bookmark this spot')}</button>
            {readingPlace && readingPlace.bookmark && <button type="button" data-reading-bookmark-open onClick={openBookmark} className={small}>{viewText('simplified.place_go_to_bookmark', 'Go to bookmark')}</button>}
          </div>
        </nav>}
      </>;
    }
    // After the passage, where reflecting comes naturally; the panel opens in place.
    function renderSectionPromptsArea() {
      if (!placeAvailable || interactionMode === 'cloze' || !outlineSections.length) return null;
      return <div data-section-prompts-area className="mt-6">
        <button type="button" data-section-prompts-toggle aria-expanded={promptsOpen} aria-controls={promptsOpen ? readerId('simplified-section-prompts') : undefined} onClick={() => promptsOpen ? setPromptsOpen(false) : openSectionPrompts()} className="min-h-11 rounded-lg border border-indigo-200 bg-white px-3 py-2 text-base text-indigo-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600">{viewText('simplified.prompt_title', 'Think about a section')}</button>
        {promptsOpen && renderSectionPrompts()}
      </div>;
    }
    async function saveBookmark() {
      var paragraph = currentReadingParagraph();
      if (paragraph == null) return;
      var key = placeRef.current.key, snippet = paragraphSnippet(paragraph);
      var result = await storeReadingPlace({ bookmark: { paragraph, snippet } });
      if (!placeMountedRef.current || placeRef.current.key !== key || !result) return;
      setPlaceNotice(result.status === 'saved'
        ? viewText('simplified.place_bookmark_saved', 'Bookmark saved at: {snippet}', { snippet })
        : viewText('simplified.place_bookmark_temporary', 'Bookmark kept for this visit at: {snippet}', { snippet }));
    }
    function openBookmark() {
      var mark = readingPlace && readingPlace.bookmark;
      if (!mark) return;
      if (mark.snippet !== paragraphSnippet(mark.paragraph) || !goToReadingParagraph(mark.paragraph)) { setPlaceNotice(viewText('simplified.place_bookmark_missing', 'That bookmark is no longer in this reading.')); return; }
      setPlaceNotice(viewText('simplified.place_at_bookmark', 'Moved to your bookmark.'));
    }
    // Teacher review summary: text, word help and audio at a glance, with the
    // action for each, and a disposable preview of the local reading layout.
    var showReviewSummary = canManageNarration && generatedContent?.type === 'simplified' && typeof generatedContent.data === 'string';
    if (showReviewSummary && placeItemId && !(placeItemId in readingFirstSeen)) readingFirstSeen[placeItemId] = placeFingerprint;
    var reviewAudio = showReviewSummary ? narrationSummary : null;
    // Device durability is checked independently of the in-memory preparation
    // summary. Never promote a store-presence count into a saved-device claim.
    var [deviceAudioResult, setDeviceAudioResult] = React.useState(null);
    var [deviceAudioSaveState, setDeviceAudioSaveState] = React.useState(null);
    var deviceAudioSaveBusy = deviceAudioSaveState?.context === ttsPrepContext && deviceAudioSaveState.busy;
    var deviceAudioSaveNotice = deviceAudioSaveState?.context === ttsPrepContext ? deviceAudioSaveState.notice || '' : '';
    var deviceAudioRefreshRef = React.useRef(null), deviceAudioSaveRef = React.useRef(null);
    // Retrying writes only the current resource. A later resource or hidden
    // author controls must not inherit this request's busy state or notices.
    React.useEffect(function () {
      setDeviceAudioSaveState(null);
      return function () {
        var request = deviceAudioSaveRef.current;
        if (request) {
          deviceAudioSaveRef.current = null;
          request.controller?.abort();
        }
      };
    }, [ttsPrepContext, showReviewSummary]);
    function ownsDeviceAudioSave(request) {
      return deviceAudioSaveRef.current === request && ttsPrepContextRef.current === request.context;
    }
    var deviceAudio = deviceAudioResult && deviceAudioResult.context === ttsPrepContext && deviceAudioResult.payload === generatedContent?.karaokeAudio && deviceAudioResult.store === readAloudStore && deviceAudioResult.revision === readAloudStoreRevision ? deviceAudioResult.value : null;
    React.useEffect(function () {
      if (!showReviewSummary) return;
      var alive = true, sequence = 0;
      var resourceId = String(generatedContent.id), payload = generatedContent.karaokeAudio;
      var entries = getReadAloudSentenceEntriesForText(simplifiedReadAloudText);
      var profile = getReadAloudIdentityOptions().profile;
      async function refresh(event) {
        if (event?.detail?.resourceId && String(event.detail.resourceId) !== resourceId) return;
        var request = ++sequence, result = null;
        try {
          if (typeof window.__alloGetReadAloudReadiness === 'function') result = await window.__alloGetReadAloudReadiness(entries.map(entry => entry.text), 'reference', { entries, profile, failure: ttsPrepFailure });
        } catch (_) {}
        if (!alive || request !== sequence) return;
        if (result && String(result.resourceId) !== resourceId) result = null;
        setDeviceAudioResult({ context: ttsPrepContext, payload, store: readAloudStore, revision: readAloudStoreRevision, value: result });
        return result;
      }
      deviceAudioRefreshRef.current = refresh;
      var events = ['alloflow:offline-media-persistence', 'alloflow:karaoke-audio-updated', 'alloflow:karaoke-audio-capture', 'alloflow:read-aloud-reconciled', 'alloflow:module-registry-changed', 'focus', 'pageshow'];
      events.forEach(name => window.addEventListener(name, refresh));
      function visible() { if (document.visibilityState === 'visible') refresh(); }
      document.addEventListener('visibilitychange', visible);
      refresh();
      return function () {
        alive = false; sequence++;
        events.forEach(name => window.removeEventListener(name, refresh));
        document.removeEventListener('visibilitychange', visible);
        if (deviceAudioRefreshRef.current === refresh) deviceAudioRefreshRef.current = null;
      };
    }, [showReviewSummary, ttsPrepContext, generatedContent?.karaokeAudio, ttsPrepState.busy, ttsPrepFailure, readAloudStore, readAloudStoreRevision, editAudioPlaybackErrors, audioStatusTick]);
    async function retryDeviceAudioSave() {
      if (!showReviewSummary || deviceAudioSaveRef.current) return;
      var request = { context: ttsPrepContext, controller: typeof AbortController === 'function' ? new AbortController() : null };
      deviceAudioSaveRef.current = request;
      setDeviceAudioSaveState({ context: request.context, busy: true, notice: '' });
      try {
        if (typeof window.__alloRetryReadAloudPersistence !== 'function') throw new Error('Audio save tools are still loading.');
        var result = await window.__alloRetryReadAloudPersistence('reference', { signal: request.controller?.signal });
        if (!ownsDeviceAudioSave(request)) return;
        if (result !== true && !(result?.status === 'saved' && result.verified === true)) {
          setDeviceAudioSaveState({ context: request.context, busy: true, notice: viewText('simplified.offline_audio_save_unconfirmed', 'Audio saving was not confirmed on this device. Keep this page open and try saving again.') });
        }
      } catch (_) {
        if (ownsDeviceAudioSave(request)) setDeviceAudioSaveState({ context: request.context, busy: true, notice: viewText('simplified.offline_audio_save_failed', 'Audio could not be saved on this device. Keep this page open and try saving again.') });
      } finally {
        if (ownsDeviceAudioSave(request) && deviceAudioRefreshRef.current) await deviceAudioRefreshRef.current();
        if (ownsDeviceAudioSave(request)) {
          deviceAudioSaveRef.current = null;
          setDeviceAudioSaveState(previous => previous?.context === request.context ? { ...previous, busy: false } : previous);
        }
      }
    }
    var reviewAudioFocusRef = React.useRef(null);
    React.useLayoutEffect(function () {
      const previous = reviewAudioFocusRef.current;
      if (previous && !previous.isConnected) {
        reviewAudioFocusRef.current = null;
        if (!document.activeElement || document.activeElement === document.body) editAudioToggleRef.current?.focus();
      }
    });
    function deviceAudioReviewRow() {
      var state = ttsPrepState.busy ? 'preparing' : deviceAudio?.state || 'unverified';
      var playbackLabel = reviewAudio?.unavailable ? viewText('simplified.review_audio_unavailable', 'Audio status unavailable') : reviewAudio?.ready === reviewAudio?.total ? viewText('simplified.review_audio_ready', 'Audio prepared') : reviewAudio?.ready ? viewText('simplified.review_audio_partial', 'Audio partly prepared') : viewText('simplified.review_audio_none', 'Audio not prepared');
      var playbackDetail = viewText('simplified.review_audio_current_detail', '{ready} of {total} sentence clips ready for these settings on this device.', { ready: reviewAudio?.ready || 0, total: reviewAudio?.total || 0 });
      if (reviewAudio && !reviewAudio.unavailable && reviewAudio.ready < reviewAudio.total) playbackDetail += ' ' + viewText('simplified.review_audio_breakdown', 'To update: {stale}; unknown settings: {unverified}; damaged: {corrupt}; missing: {missing}.', {
        stale: Math.max(0, reviewAudio.stale - reviewAudio.unverified), unverified: reviewAudio.unverified, corrupt: reviewAudio.corrupt, missing: reviewAudio.missing
      });
      var labels = { ready: ['saved', 'Audio saved on this device'], partial: ['partial', 'Audio partly prepared'], preparing: ['preparing', 'Preparing audio'], failed: ['failed', 'Audio needs recovery'], 'session-only': ['session', 'Audio available for this session'], unverified: ['unverified', 'Device audio not verified'] };
      var label = labels[state] || labels.unverified;
      var detail = deviceAudio ? viewText('simplified.offline_audio_counts', '{saved} of {total} clips saved on this device; {remaining} still need preparation.', { saved: deviceAudio.durableReady, total: deviceAudio.total, remaining: deviceAudio.remaining }) : viewText('simplified.offline_audio_check', 'Check device storage before relying on saved audio.');
      if (deviceAudio?.sessionOnly) detail += ' ' + viewText('simplified.offline_audio_session_count', '{count} usable clips have not been verified in device storage.', { count: deviceAudio.sessionOnly });
      var omitted = deviceAudio?.pictureOmissions?.length || 0;
      if (omitted) detail += ' ' + viewText('simplified.offline_audio_pictures', 'Support pictures omitted from the device save: {count}.', { count: omitted });
      var notice = state === 'ready' ? '' : deviceAudioSaveNotice;
      // Keep actions outside the live region and avoid talking over read-aloud.
      // Preparation gets one stable announcement instead of a count per clip.
      var announcement = deviceAudioSaveBusy ? viewText('simplified.offline_audio_saving', 'Saving audio on this device…')
        : state === 'preparing' ? viewText('simplified.offline_audio_preparing_announcement', 'Preparing audio. Use Stop saving audio to cancel.')
        : notice || (isPlaying ? '' : viewText('simplified.offline_audio_' + label[0], label[1]) + '. ' + detail);
      return { key: 'audio', tone: state === 'ready' && !omitted ? 'ok' : state === 'session-only' || state === 'failed' || omitted ? 'attention' : 'neutral',
        label: playbackLabel + ' · ' + viewText('simplified.offline_audio_' + label[0], label[1]), detail: playbackDetail + ' ' + detail, notice, announcement,
        actions: [
          state === 'preparing' && ['audio', viewText('simplified.save_audio_stop', 'Stop saving audio'), () => { ttsPrepRequestRef.current?.controller?.abort(); window.__alloCancelPrepareReadAloud?.(); }],
          state !== 'preparing' && (deviceAudio?.nextActions?.includes('prepare-missing') || reviewAudio?.unavailable || reviewAudio?.ready < reviewAudio?.total) && ['audio', viewText('simplified.offline_audio_prepare_missing', 'Prepare missing audio'), handlePrepareReadAloudAudio],
          state !== 'preparing' && deviceAudio?.sessionOnly > 0 && ['audio-retry-save', deviceAudioSaveBusy ? viewText('simplified.offline_audio_saving', 'Saving audio on this device…') : viewText('simplified.offline_audio_retry_save', 'Retry saving audio'), retryDeviceAudioSave],
          state !== 'preparing' && !deviceAudio && ['audio-check', viewText('simplified.offline_audio_check_again', 'Check device save'), () => deviceAudioRefreshRef.current?.()],
          deviceAudio?.protectedRecordings > 0 && ['audio-recordings', viewText('simplified.offline_audio_review_recordings', 'Review recordings'), () => { if (!editAudioOpen) handleToggleEditAudioPanel(); editAudioToggleRef.current?.focus(); }],
          omitted > 0 && ['audio-pictures', viewText('simplified.review_open_help', 'Review word help'), openWordHelpReview],
        ] };
    }
    React.useEffect(function () {
      if (!studentPreview || !studentPreviewRef.current) return;
      var modal = studentPreviewRef.current, opener = studentPreviewOpener.current;
      var background = [];
      // The modal is a sibling of the reader. Hide every sibling on the path to
      // body so toolbar/sidebar controls outside the reader are isolated too.
      for (var branch = modal; branch && branch !== document.body; branch = branch.parentElement) {
        Array.from(branch.parentElement?.children || []).forEach(function (node) {
          if (node === branch) return;
          background.push([node, node.getAttribute('inert'), node.getAttribute('aria-hidden')]);
          node.setAttribute('inert', ''); node.setAttribute('aria-hidden', 'true');
        });
      }
      var containFocus = function (event) { if (!modal.contains(event.target)) studentPreviewCloseRef.current?.focus(); };
      document.addEventListener('focusin', containFocus, true);
      studentPreviewCloseRef.current?.focus();
      // Let host engagement timers exclude this local preview without copying
      // lesson data or granting host callbacks to the preview reader.
      window.dispatchEvent(new CustomEvent('alloflow:reading-preview', { detail: { owner: previewInstanceId, active: true } }));
      return function () {
        window.dispatchEvent(new CustomEvent('alloflow:reading-preview', { detail: { owner: previewInstanceId, active: false } }));
        document.removeEventListener('focusin', containFocus, true);
        background.forEach(function (entry) {
          ['inert', 'aria-hidden'].forEach(function (attribute, index) {
            if (entry[index + 1] === null) entry[0].removeAttribute(attribute);
            else entry[0].setAttribute(attribute, entry[index + 1]);
          });
        });
        if (opener && opener.isConnected) opener.focus({ preventScroll: true });
      };
    }, [!!studentPreview]);
    function closeStudentPreview() { setStudentPreview(null); }
    function captureCurrentReadingPreview() {
      return captureReadingPreview(props, { readingColumn, displayOpen, showComparisonChanges });
    }
    var canRefreshStudentPreview = !protectedOriginal && generatedContent?.type === 'simplified' && typeof generatedContent.data === 'string';
    function refreshStudentPreview() {
      if (!studentPreview || !canRefreshStudentPreview) return;
      var next = captureCurrentReadingPreview();
      next.previewRefreshed = true;
      previewSessionRef.current += 1;
      setStudentPreview(next);
    }
    React.useEffect(function () {
      if (!studentPreview?.previewRefreshed) return;
      // Remount only the disposable reader; keep the modal and its owner active.
      if (studentPreviewRef.current) studentPreviewRef.current.scrollTop = 0;
      studentPreviewRefreshRef.current?.focus({ preventScroll: true });
    }, [studentPreview]);
    function openWordHelpReview() {
      var panel = readerSurfaceRef.current && readerSurfaceRef.current.querySelector('[data-adapted-word-help-teacher]');
      if (!panel) return;
      panel.open = true;
      var summary = panel.querySelector('summary');
      if (typeof panel.scrollIntoView === 'function') panel.scrollIntoView({ block: 'start' });
      if (summary) summary.focus();
    }
    function renderTeacherReviewSummary() {
      if (!showReviewSummary) return null;
      var contract = readingContract;
      var help = adaptedSupportView.help;
      var helpCount = help && help.annotations ? help.annotations.length : 0;
      var textChanged = readingFirstSeen[placeItemId] !== placeFingerprint;
      var rows = [
        !protectedOriginal && { key: 'text', tone: textChanged ? 'attention' : 'ok',
          label: textChanged ? viewText('simplified.review_text_changed', 'Text changed') : viewText('simplified.review_text_unchanged', 'Text unchanged'),
          detail: textChanged ? viewText('simplified.review_text_changed_detail', 'Edited since you opened it. Check word help and audio.') : viewText('simplified.review_text_unchanged_detail', 'No edits since you opened it.'),
          actions: [capturedSource && typeof setIsCompareMode === 'function' && ['compare', viewText('simplified.review_compare', 'Compare with original'), () => requestSupportTransition(() => { chooseReadingMode('read'); setIsCompareMode(true); })],
            typeof handleToggleIsEditingLeveledText === 'function' && ['edit', isEditingLeveledText ? t('common.done_editing') : viewText('simplified.review_edit', 'Edit text'), handleToggleIsEditingLeveledText]] },
        help && { key: 'help', tone: help.status === 'stale' || (helpCount && !help.shown) ? 'attention' : helpCount ? 'ok' : 'neutral',
          label: help.status === 'stale' || (helpCount && !help.shown) ? viewText('simplified.review_help_needs_review', 'Word help needs review') : helpCount ? viewText('simplified.review_help_shown', 'Word help shown to students') : viewText('simplified.review_help_none', 'No word help'),
          detail: help.status === 'stale' ? viewText('simplified.review_help_stale_detail', 'The text changed after word help was made, so students do not see it.') : helpCount ? (helpCount === 1 ? viewText('simplified.word_help_summary_one', '1 support') : viewText('simplified.word_help_summary_count', '{count} supports', { count: helpCount })) + (help.shown ? '' : ' · ' + viewText('simplified.word_help_summary_hidden', 'Hidden from students')) : viewText('simplified.review_help_none_detail', 'Optional explanations for hard words.'),
          actions: [['help', viewText('simplified.review_open_help', 'Review word help'), openWordHelpReview]] },
        reviewAudio && reviewAudio.total > 0 && deviceAudioReviewRow()
      ].filter(Boolean);
      var tones = { ok: 'border-emerald-300 bg-emerald-50 text-emerald-900', attention: 'border-amber-400 bg-amber-50 text-amber-950', neutral: 'border-slate-300 bg-slate-50 text-slate-800' };
      return <section data-teacher-review-summary aria-labelledby={readerId('simplified-review-summary-title')} className="mt-2 w-full rounded-2xl border border-slate-200 bg-white p-3 text-left text-sm text-slate-800">
        <div className="flex flex-wrap items-center justify-between gap-2"><h3 id={readerId('simplified-review-summary-title')} className="text-base font-bold text-slate-900">{viewText('simplified.review_title', 'Before you share')}</h3><button type="button" data-student-preview-open onClick={event => { studentPreviewOpener.current = event.currentTarget; previewSessionRef.current += 1; setStudentPreview(captureCurrentReadingPreview()); }} className="min-h-11 rounded-lg bg-indigo-700 px-3 font-semibold text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 focus-visible:ring-offset-2">{viewText('simplified.layout_preview_open', 'Preview reading layout')}</button></div>
        <ul className="mt-2 grid gap-2 sm:grid-cols-3">{rows.map(row => <li key={row.key} data-review-state={row.key} data-review-tone={row.tone} className={'rounded-xl border p-2 ' + tones[row.tone]}><p className="font-bold">{row.label}</p><p className="mt-0.5 text-xs">{row.detail}</p>{row.notice && <p data-device-audio-notice className="mt-2 text-sm font-semibold">{row.notice}</p>}{row.key === 'audio' && <p role="status" aria-live="polite" aria-atomic="true" data-device-audio-status className="sr-only">{row.announcement}</p>}<div className="mt-1 flex flex-wrap gap-x-3">{row.actions.filter(Boolean).map(([key, label, run]) => <button key={key} type="button" data-review-action={key} onFocus={event => { if (row.key === 'audio') reviewAudioFocusRef.current = event.currentTarget; }} aria-busy={key === 'audio-retry-save' && deviceAudioSaveBusy ? true : undefined} aria-disabled={key === 'audio-retry-save' && deviceAudioSaveBusy ? true : undefined} onClick={event => { if (row.key === 'audio' && document.activeElement === event.currentTarget) reviewAudioFocusRef.current = event.currentTarget; run(); }} className="min-h-11 rounded px-1 text-sm font-semibold underline underline-offset-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600">{label}</button>)}</div></li>)}</ul>
      </section>;
    }
    // A local layout snapshot; delivered-lesson fidelity belongs to packet preview.
    function renderStudentPreview() {
      if (!studentPreview) return null;
      return <div ref={studentPreviewRef} role="dialog" aria-modal="true" aria-labelledby={readerId('simplified-student-preview-title')} data-student-preview data-help-ignore
        onClick={event => event.stopPropagation()} onDoubleClick={event => event.stopPropagation()}
        onPointerDown={event => event.stopPropagation()} onMouseMove={event => event.stopPropagation()}
        onWheel={event => event.stopPropagation()} onTouchStart={event => event.stopPropagation()} onTouchMove={event => event.stopPropagation()}
        onPaste={event => event.stopPropagation()} onKeyDown={event => { event.stopPropagation(); containSimplifiedModalFocus(event, studentPreviewRef.current, closeStudentPreview); }} onKeyUp={event => event.stopPropagation()} className="fixed inset-0 z-[150] overflow-y-auto bg-slate-900/60 p-2 sm:p-6">
        <div className="mx-auto w-full max-w-4xl rounded-2xl bg-white shadow-2xl">
          <div className="flex flex-wrap items-center justify-between gap-2 rounded-t-2xl border-b border-slate-200 bg-white p-3"><div className="min-w-0"><h2 id={readerId('simplified-student-preview-title')} className="text-lg font-bold text-slate-900">{viewText('simplified.layout_preview_title', 'Reading layout preview')}</h2><p className="text-sm text-slate-700">{viewText('simplified.layout_preview_note', 'Try appearance, navigation and prepared word help. This snapshot stays the same until you refresh or reopen it. It does not preview a delivered lesson.')}</p><p id={previewInstanceId + '-limits'} className="text-sm text-slate-700">{viewText('simplified.layout_preview_limits', 'Listening, recording, AI help and scored practice are unavailable. Any current playback remains controlled by the main reader.')}</p></div><button ref={studentPreviewCloseRef} type="button" data-student-preview-close onClick={closeStudentPreview} className="min-h-11 rounded-lg border border-slate-300 bg-white px-3 font-semibold focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600">{viewText('simplified.preview_close', 'Close preview')}</button></div>
          <div className="space-y-2 border-b border-slate-200 p-3">
            <p id={previewInstanceId + '-refresh-hint'} className="text-sm text-slate-700">{viewText('simplified.layout_preview_refresh_hint', 'Refresh uses the current reading and appearance. Changes made in this preview are discarded when you refresh or close it.')}</p>
            {!canRefreshStudentPreview && <p id={previewInstanceId + '-refresh-unavailable'} role="status" className="text-sm text-slate-700">{viewText('simplified.layout_preview_refresh_unavailable', 'A current adapted reading is needed to refresh. Close preview to choose one.')}</p>}
            <button ref={studentPreviewRefreshRef} type="button" data-student-preview-refresh disabled={!canRefreshStudentPreview} aria-describedby={previewInstanceId + '-refresh-hint' + (canRefreshStudentPreview ? '' : ' ' + previewInstanceId + '-refresh-unavailable')} onClick={refreshStudentPreview} className="min-h-11 rounded-lg border border-slate-300 bg-white px-3 font-semibold focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 disabled:opacity-50">{viewText('simplified.layout_preview_refresh', 'Refresh preview')}</button>
            <p role="status" aria-live="polite" data-preview-refresh-status className="sr-only"><span key={previewSessionRef.current}>{studentPreview.previewRefreshed ? viewText('simplified.layout_preview_refreshed', 'Preview refreshed.') : ''}</span></p>
          </div>
          <div className="p-2 sm:p-4"><SimplifiedPreviewReader key={previewSessionRef.current} snapshot={studentPreview} limitsId={previewInstanceId + '-limits'} /></div>
        </div>
      </div>;
    }
    // Precise adaptation choices, previewed before they change the text, with a
    // route back to the version before the change.
    var [adaptOptions, setAdaptOptions] = React.useState({ shorterSentences: false, explainVocabulary: false, keepTerms: '' });
    var [adaptPreview, setAdaptPreview] = React.useState(null);
    var [adaptUndo, setAdaptUndo] = React.useState(null);
    var [adaptNoticeRecord, setAdaptNoticeRecord] = React.useState(null);
    var adaptPreviewRef = React.useRef(null);
    var adaptPreviewTriggerRef = React.useRef(null), adaptUndoButtonRef = React.useRef(null), adaptFocusRecoveryRef = React.useRef(null), adaptApplyInFlightRef = React.useRef(false);
    function dismissAdaptationPreview(destination) {
      if (adaptPreviewRef.current?.contains(document.activeElement)) adaptFocusRecoveryRef.current = destination || adaptFocusRecoveryRef.current || 'preview';
      setAdaptPreview(null);
    }
    function restoreAdaptationFocus() {
      if (!adaptFocusRecoveryRef.current || adaptPreviewRef.current || isProcessing || adaptApplyInFlightRef.current) return;
      // Do not move focus back if the user has already moved to another control.
      var active = document.activeElement;
      if (active && active !== document.body && active.isConnected && active !== adaptPreviewTriggerRef.current && active !== adaptUndoButtonRef.current) {
        adaptFocusRecoveryRef.current = null;
        return;
      }
      var target = adaptFocusRecoveryRef.current === 'undo' ? adaptUndoButtonRef.current : adaptPreviewTriggerRef.current;
      if (!target || target.disabled || !target.isConnected) target = readingStartRef.current || readerSurfaceRef.current?.querySelector('[data-reader-skip]');
      adaptFocusRecoveryRef.current = null;
      target?.focus();
    }
    React.useLayoutEffect(restoreAdaptationFocus);
    var adaptTermsRef = React.useRef(null), adaptPreviewButtonRef = adaptPreviewTriggerRef;
    var adaptRequestRef = React.useRef(0), adaptMountedRef = React.useRef(true), adaptPendingCommitRef = React.useRef(null);
    var [adaptBusy, setAdaptBusy] = React.useState(false), [adaptCommitRevision, setAdaptCommitRevision] = React.useState(0);
    var [adaptFocus, setAdaptFocus] = React.useState(null);
    var adaptationKeyFor = content => JSON.stringify([content?.id, content?.data, content?.type, content?.instructionalText?.form,
      content?.config, content?.translationTarget, content?.translationPolicy, complexityLevel, saveOriginalOnAdjust, adaptOptions, props.translationMode, props.currentUiLanguage, leveledTextLanguage]);
    var adaptKey = adaptationKeyFor(generatedContent);
    var adaptNotice = adaptNoticeRecord?.key === adaptKey ? adaptNoticeRecord.message : '';
    function setAdaptNotice(message, key) { setAdaptNoticeRecord({ message, key: key || adaptLiveRef.current.key }); }
    var adaptLiveRef = React.useRef(null);
    adaptLiveRef.current = { key: adaptKey, content: generatedContent };
    React.useEffect(function () { adaptMountedRef.current = true; return () => {
      adaptMountedRef.current = false; adaptRequestRef.current++;
      const pending = adaptPendingCommitRef.current;
      if (pending) { pending.cancelled = true; pending.resolve(false); adaptPendingCommitRef.current = null; }
    }; }, []);
    React.useEffect(function () { dismissAdaptationPreview(); setAdaptBusy(false); setAdaptNoticeRecord(current => current?.key === adaptKey ? current : null); }, [adaptKey]);
    React.useEffect(function () { if (adaptPreview && adaptPreviewRef.current) adaptPreviewRef.current.focus(); }, [!!adaptPreview]);
    React.useEffect(function () {
      if (!adaptFocus || isProcessing) return;
      (adaptFocus === 'terms' ? adaptTermsRef : adaptPreviewButtonRef).current?.focus(); setAdaptFocus(null);
    }, [adaptFocus, isProcessing, adaptBusy]);
    React.useLayoutEffect(function () {
      const pending = adaptPendingCommitRef.current;
      if (!pending) return;
      adaptPendingCommitRef.current = null;
      // The host retains the exact candidate object (artifact identity is added in place).
      // Equal text alone cannot acknowledge a declined no-op rewrite.
      const accepted = !pending.cancelled && generatedContent === pending.item;
      pending.cancelled = !accepted;
      if (accepted && typeof setHistory === 'function') setHistory(previous => pending.keepOriginal
        ? (previous.some(item => item.id === pending.baseId && item.data === pending.baseData) && !previous.some(item => item.id === pending.item.id) ? [...previous, pending.item] : previous)
        : previous.map(item => item.id === pending.baseId && item.data === pending.baseData ? pending.item : item));
      pending.resolve(accepted);
    }, [generatedContent, adaptCommitRevision]);
    var adaptVocabulary = window.AlloModules?.GenerationHelpers?.preservedVocabulary;
    var adaptTermInput = React.useMemo(() => adaptVocabulary?.parseInput ? adaptVocabulary.parseInput(adaptOptions.keepTerms) : { valid: !adaptOptions.keepTerms.trim(), terms: [] }, [adaptVocabulary, adaptOptions.keepTerms]);
    var adaptTerms = adaptTermInput.terms;
    var adaptTermCheck = React.useMemo(() => adaptTermInput.valid && adaptVocabulary?.normalize ? adaptVocabulary.normalize(adaptTerms) : null, [adaptVocabulary, adaptTermInput]);
    var adaptReadinessKey = JSON.stringify([generatedContent?.id, generatedContent?.data, adaptOptions.keepTerms]);
    var [adaptReadinessRecord, setAdaptReadinessRecord] = React.useState(null);
    var adaptSplitReferences = window.AlloModules?.TextPipelineHelpers?.splitReferencesFromBody || window.AlloModules?.GenDispatcher?.splitAdaptationReferences;
    var adaptNeedsReadiness = !!(adaptTermCheck?.valid && adaptTermCheck.terms.length);
    var adaptReadiness = adaptReadinessRecord?.key === adaptReadinessKey ? adaptReadinessRecord.audit : null;
    var adaptReadinessPending = adaptNeedsReadiness && !adaptReadiness;
    React.useEffect(function () {
      if (!adaptNeedsReadiness) return;
      // Debounce typing; never render an audit for another source or term list.
      const timer = setTimeout(() => setAdaptReadinessRecord({ key: adaptReadinessKey, audit: adaptVocabulary?.prepare
        ? adaptVocabulary.prepare(generatedContent?.data, adaptTerms, adaptSplitReferences)
        : { valid: false, reason: 'preview-validation-unavailable' } }), 200);
      return () => clearTimeout(timer);
    }, [adaptReadinessKey, adaptNeedsReadiness, adaptVocabulary, adaptSplitReferences]);
    var adaptTermError = !adaptTermInput.valid ? (adaptVocabulary?.feedback ? adaptVocabulary.feedback(adaptTermInput, t) : viewText('simplified.adapt_validation_unavailable', 'Essential-term validation is unavailable. Reload before previewing.'))
      : adaptTermCheck && !adaptTermCheck.valid ? adaptVocabulary.feedback(adaptTermCheck, t)
      : adaptReadiness && !adaptReadiness.valid ? adaptVocabulary.feedback(adaptReadiness, t) : '';
    var currentAdaptOptions = () => ({ shorterSentences: adaptOptions.shorterSentences, explainVocabulary: adaptOptions.explainVocabulary, keepTerms: adaptTerms });
    var adaptHasOptions = adaptOptions.shorterSentences || adaptOptions.explainVocabulary || adaptTerms.length > 0;
    var adaptUndoAvailable = !!adaptUndo && (adaptUndo.keptOriginal ? generatedContent?.id === adaptUndo.newId : generatedContent?.id === adaptUndo.previousId && generatedContent?.data !== adaptUndo.previousData && (adaptUndo.appliedData == null || generatedContent?.data === adaptUndo.appliedData));
    function startAdaptRequest() {
      const serial = ++adaptRequestRef.current, key = adaptKey;
      setAdaptBusy(true);
      return () => adaptMountedRef.current && adaptRequestRef.current === serial && adaptLiveRef.current.key === key;
    }
    function adaptationFailure(result) {
      setAdaptPreview(null);
      setAdaptNotice(result?.message || viewText('simplified.adapt_not_applied', 'The change was not applied. Review the current text and preview again.'));
      setAdaptFocus(result?.status === 'rejected' && result?.recovery !== 'preview' ? 'terms' : 'preview');
    }
    async function prepareAdaptation() {
      if (typeof handleComplexityAdjustment !== 'function' || adaptBusy) return;
      if (adaptReadinessPending) return;
      if (adaptTermError) { setAdaptNotice(adaptTermError); setAdaptFocus('terms'); return; }
      const isCurrent = startAdaptRequest();
      setAdaptNotice(''); setAdaptPreview(null);
      try {
        const result = await handleComplexityAdjustment({ preview: true, options: currentAdaptOptions(), isCurrent });
        if (!isCurrent()) return;
        if (result?.status !== 'preview') { adaptationFailure(result); return; }
        if (adaptTerms.length && (!result.vocabulary?.valid || result.vocabulary.version !== 1)) {
          adaptationFailure({ status: 'rejected', message: viewText('simplified.adapt_preview_unverified', 'Current text kept. Essential terms could not be verified. Reload and preview again.') }); return;
        }
        setAdaptPreview(result);
      } catch (_) { if (isCurrent()) adaptationFailure(); }
      finally { if (isCurrent()) setAdaptBusy(false); }
    }
    async function applyAdaptation() {
      if (supportDraftSession?.blocked()) return requestSupportTransition(applyAdaptation);
      if (adaptBusy || !adaptPreview) return;
      const previousData = generatedContent.data, isCurrent = startAdaptRequest();
      if (adaptPreviewRef.current?.contains(document.activeElement)) adaptFocusRecoveryRef.current = 'undo';
      adaptApplyInFlightRef.current = true;
      let committed = false;
      const commit = transaction => {
        if (!isCurrent() || typeof setGeneratedContent !== 'function' || typeof setHistory !== 'function') return Promise.resolve(false);
        return new Promise(resolve => {
          const pending = { ...transaction, resolve: value => { committed = value; resolve(value); }, cancelled: false };
          adaptPendingCommitRef.current = pending;
          setGeneratedContent(previous => !pending.cancelled && isCurrent() && previous?.id === pending.baseId && previous?.data === pending.baseData
            && !['original', 'same-text-supported'].includes(previous.instructionalText?.form || previous.config?.instructionalText?.form) ? pending.item : previous);
          setAdaptCommitRevision(value => value + 1);
        });
      };
      try {
        const result = await handleComplexityAdjustment({ apply: adaptPreview, options: currentAdaptOptions(), isCurrent, commit });
        if (!adaptMountedRef.current) return;
        if (result?.status === 'applied' && committed && adaptLiveRef.current.content?.id === result.newId && adaptLiveRef.current.content?.data === result.data) {
          setAdaptUndo({ previousId: result.previousId, previousData, newId: result.newId, keptOriginal: result.newId !== result.previousId, appliedData: result.data });
          dismissAdaptationPreview('undo');
          setAdaptNotice(viewText('simplified.adapt_applied', 'Change applied. You can go back to the previous version.'));
        } else if (isCurrent()) adaptationFailure(result);
      } catch (_) { if (isCurrent()) adaptationFailure(); }
      finally { adaptApplyInFlightRef.current = false; if (adaptMountedRef.current && (isCurrent() || committed)) setAdaptBusy(false); if (!committed) restoreAdaptationFocus(); }
    }
    function undoAdaptation() {
      if (supportDraftSession?.blocked()) return requestSupportTransition(undoAdaptation);
      var undo = adaptUndo;
      if (!undo) return;
      if (document.activeElement === adaptUndoButtonRef.current) adaptFocusRecoveryRef.current = 'preview';
      if (undo.keptOriginal) {
        var previous = (props.history || []).find(item => item && item.id === undo.previousId);
        if (previous && typeof setGeneratedContent === 'function') setGeneratedContent(previous);
      } else if (typeof handleSimplifiedTextChange === 'function') handleSimplifiedTextChange(undo.previousData);
      setAdaptUndo(null);
      setAdaptNotice(viewText('simplified.adapt_undone', 'Back to the previous version.'), adaptationKeyFor(undo.keptOriginal ? previous : { ...generatedContent, data: undo.previousData }));
    }
    function renderAdaptationControls() {
      var check = (field, label) => <label className="flex min-h-11 min-w-0 items-center gap-2 text-sm text-slate-800"><input type="checkbox" data-adapt-option={field} checked={!!adaptOptions[field]} disabled={isProcessing || adaptBusy} onChange={event => setAdaptOptions(current => ({ ...current, [field]: event.target.checked }))} className="h-4 w-4 shrink-0 accent-indigo-600" /><span className="min-w-0">{label}</span></label>;
      var diff = adaptPreview ? simplifiedWordDiff(generatedContent.data, adaptPreview.data) : null;
      return <div data-adaptation-controls aria-busy={isProcessing || adaptBusy} className="min-w-0 max-w-full space-y-3 text-left" style={{ overflowWrap: 'anywhere' }}>
        <fieldset className="min-w-0 max-w-full rounded-lg border border-slate-200 p-2 sm:p-3"><legend className="max-w-full whitespace-normal px-1 text-xs font-bold uppercase tracking-wide text-indigo-700">{viewText('simplified.adapt_also', 'Also change')}</legend>
          {check('shorterSentences', viewText('simplified.adapt_shorter', 'Shorter sentences'))}
          {check('explainVocabulary', viewText('simplified.adapt_explain_vocab', 'Explain unfamiliar vocabulary'))}
          <label className="mt-1 block text-sm font-semibold text-slate-800">{viewText('simplified.adapt_keep_terms', 'Preserve these essential terms')}<span id={readerId('simplified-adapt-terms-hint')} className="block text-xs font-normal text-slate-600">{viewText('simplified.adapt_exact_terms_hint', 'Separate terms with commas or semicolons; quote a term containing either. Up to 30 distinct terms. Terms must already occur in the text. We check that each remains at least once, with exact spelling, case, and punctuation, in its source reading pane.')}</span><input ref={adaptTermsRef} type="text" data-adapt-keep-terms aria-describedby={[readerId('simplified-adapt-terms-hint'), readerId('simplified-adapt-terms-error'), readerId('simplified-adapt-terms-readiness')].join(' ')} aria-invalid={!!adaptTermError} value={adaptOptions.keepTerms} disabled={isProcessing || adaptBusy} onChange={event => setAdaptOptions(current => ({ ...current, keepTerms: event.target.value }))} className="mt-1 min-h-11 w-full min-w-0 rounded border border-slate-400 bg-white px-2 font-normal" /></label>
          <div id={readerId('simplified-adapt-terms-readiness')} data-adapt-term-readiness role="status" aria-live="polite" aria-atomic="true" className="space-y-1 text-xs text-slate-700">
            {adaptTermCheck && <p>{viewText('simplified.adapt_terms_remaining', '{remaining} of {limit} term slots available.', { remaining: Math.max(0, adaptTermCheck.limits.terms - adaptTermCheck.terms.length), limit: adaptTermCheck.limits.terms })}</p>}
            {adaptTermCheck?.duplicates.length > 0 && <p>{viewText('simplified.adapt_terms_duplicates', 'Repeated entries count once: {terms}.', { terms: [...new Set(adaptTermCheck.duplicates.map(entry => entry.term))].join('; ') })}</p>}
            {adaptReadinessPending && <p>{viewText('simplified.adapt_terms_checking', 'Checking terms in the current reading…')}</p>}
            {adaptReadiness?.terms?.length > 0 && adaptReadiness.status !== 'unverified' && <ul className="list-inside list-disc">{adaptReadiness.terms.map(term => {
              const found = adaptReadiness.required?.find(entry => entry.term === term);
              const panes = found?.panes.map(entry => viewText(entry.pane === 'translation' ? 'simplified.adapt_terms_translation' : 'simplified.adapt_terms_primary', entry.pane === 'translation' ? 'translation' : 'primary reading')).join(', ');
              return <li key={term}>{found ? viewText('simplified.adapt_term_found', '“{term}”: found in {panes}.', { term, panes }) : viewText('simplified.adapt_term_absent', '“{term}”: not found exactly. Check spelling and case.', { term })}</li>;
            })}</ul>}
          </div>
          <p id={readerId('simplified-adapt-terms-error')} role={adaptTermError ? 'alert' : undefined} className={adaptTermError ? 'text-sm text-red-800' : 'sr-only'}>{adaptTermError}</p>
        </fieldset>
        <div className="text-center"><button ref={adaptPreviewButtonRef} type="button" data-apply-complexity onClick={prepareAdaptation} disabled={isProcessing || adaptBusy || adaptReadinessPending || !!adaptTermError || (Number(complexityLevel) === 5 && !adaptHasOptions)} className="min-h-11 rounded-lg bg-indigo-700 px-4 py-2 text-sm font-bold text-white disabled:opacity-50">{isProcessing ? readerText('simplified.applying_change', 'Updating text…') : viewText('simplified.adapt_preview', 'Preview change')}</button></div>
        {adaptPreview && <section ref={adaptPreviewRef} tabIndex={-1} data-adaptation-preview aria-labelledby={readerId('simplified-adapt-preview-title')} className="space-y-2 rounded-lg border border-indigo-200 bg-indigo-50 p-3 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600">
          <h4 id={readerId('simplified-adapt-preview-title')} className="font-bold text-indigo-950">{viewText('simplified.adapt_preview_title', 'Preview of the change')}</h4>
          <p className="text-xs text-slate-700">{diff ? viewText('simplified.adapt_preview_hint', 'Removed words are struck through and new words are underlined. Nothing changes until you apply it.') : viewText('simplified.adapt_preview_plain', 'The proposed text is shown below. Nothing changes until you apply it.')}</p>
          <div role="region" tabIndex={0} aria-label={viewText('simplified.adapt_proposed', 'Proposed text')} data-adaptation-diff className="max-h-80 overflow-y-auto whitespace-pre-wrap rounded border border-indigo-100 bg-white p-3 text-base leading-relaxed text-slate-900" style={{ overflowWrap: 'anywhere' }}>{diff ? diff.map((part, index) => part.type === 'same' ? <React.Fragment key={index}>{part.value}</React.Fragment> : part.type === 'del' ? <del key={index} className="bg-red-100 text-red-900">{part.value}</del> : <ins key={index} className="bg-green-100 text-green-900">{part.value}</ins>) : String(adaptPreview.data || '')}</div>
          <p className="text-xs text-slate-700">{saveOriginalOnAdjust ? viewText('simplified.adapt_apply_keeps', 'Applying saves this as a new version and keeps the current one.') : viewText('simplified.adapt_apply_replaces', 'Applying replaces the current text. You can go back afterward.')}</p>
          <div className="flex flex-wrap justify-center gap-2"><button type="button" data-adaptation-apply onClick={applyAdaptation} disabled={isProcessing || adaptBusy} className="min-h-11 rounded-lg bg-indigo-700 px-3 font-semibold text-white disabled:opacity-50">{viewText('simplified.adapt_apply', 'Apply this version')}</button><button type="button" data-adaptation-discard onClick={() => { dismissAdaptationPreview('preview'); setAdaptNotice(viewText('simplified.adapt_discarded', 'Preview discarded. The text is unchanged.')); }} disabled={isProcessing || adaptBusy} className="min-h-11 rounded-lg border border-slate-300 bg-white px-3">{viewText('simplified.adapt_discard', 'Discard')}</button></div>
        </section>}
        <p role="status" data-adaptation-notice className={adaptNotice ? 'text-center text-sm text-indigo-900' : 'sr-only'}>{adaptNotice}</p>
        {adaptUndoAvailable && <div className="text-center"><button ref={adaptUndoButtonRef} type="button" data-adaptation-undo onClick={undoAdaptation} className="min-h-11 rounded-lg border border-indigo-300 bg-white px-3 text-sm font-semibold text-indigo-900">{viewText('simplified.adapt_back', 'Back to previous version')}</button></div>}
      </div>;
    }
    var [showComparisonChanges, setShowComparisonChanges] = React.useState(function () { if (props.isStudentPreview) return !!props.previewAppearance?.showComparisonChanges; try { return localStorage.getItem('alloflow_reading_show_changes') === 'on'; } catch (_) { return false; } });
    var [showReadingGlosses, setShowReadingGlosses] = React.useState(true);
    var preparedHelpContext = JSON.stringify([generatedContent?.id, generatedContent?.data, readingLanguage, interactionMode, isCompareMode, comparisonLanguage, showComparisonChanges, showReadingGlosses, isEditingLeveledText, isImmersiveReaderActive, isSideBySide, learnerScope]);
    // A classification or validation change can withdraw help without changing
    // the passage or envelope. Only a currently accepted entry may keep a card.
    var currentWordHelpCard = wordHelpCard && wordHelpCard.context === preparedHelpContext
      && wordHelpCard.supports === generatedContent?.adaptedReadingSupports && wordHelpCard.supportVersion === adaptedSupportView.version
      && adaptedSupportView.help?.shown && adaptedSupportView.help.status !== 'stale'
      && adaptedSupportView.help.annotations.some(entry => entry.id === wordHelpCard.entry.id) ? wordHelpCard : null;
    React.useEffect(function () { if (wordHelpCard && !currentWordHelpCard) closeWordHelpCard(false); }, [wordHelpCard, currentWordHelpCard]);
    // Resolve prepared availability before paint, using the same exact ranges
    // as activation. Restore only attributes this reader effect still owns.
    React.useLayoutEffect(function () {
      if (!readerSurfaceRef.current) return;
      var restore = [], surface = readerSurfaceRef.current;
      var decorate = (word, attributes) => {
        var expanded = !!currentWordHelpCard && wordHelpCardOpener.current === word;
        Object.entries({ ...attributes, 'aria-haspopup': 'dialog', 'aria-controls': expanded ? wordHelpDialogId : null, 'aria-expanded': String(expanded) }).forEach(([name, value]) => {
          var previous = word.getAttribute(name);
          if (value == null) word.removeAttribute(name); else word.setAttribute(name, value);
          restore.push(() => { if (word.getAttribute(name) === value) { if (previous == null) word.removeAttribute(name); else word.setAttribute(name, previous); } });
        });
      };
      surface.querySelectorAll('[data-prepared-help-open]').forEach(button => {
        if (button.closest('[data-adapted-reader]') === surface) decorate(button, {});
      });
      var panes = interactionMode === 'define' ? surface.querySelectorAll('[data-reading-passage], [data-word-help-language]') : [];
      panes.forEach(container => {
        if (container.hasAttribute('data-original-source') || container.closest('[data-adapted-reader]') !== readerSurfaceRef.current) return;
        var language = container.getAttribute('data-word-help-language') || readingLanguage;
        var help = readingContract?.validateAdaptedReadingSupports?.(generatedContent, generatedContent.adaptedReadingSupports);
        var snapshot = readingContract?.getAdaptedSupportSnapshot?.(generatedContent, generatedContent.adaptedReadingSupports);
        if (!help?.shown || help.status === 'stale' || !snapshot) return;
        var visible = readingTextSegments(container, language), hits = locateWordHelp(snapshot.text, help.annotations, visible.text);
        var wordSegments = new Map();
        visible.segments.forEach(segment => {
          var word = segment.node.parentElement.closest('[data-reading-word], [data-exact-word]');
          if (word && !wordSegments.has(word)) wordSegments.set(word, segment);
        });
        container.querySelectorAll('[data-reading-word], [data-exact-word]').forEach(word => {
          var segment = wordSegments.get(word);
          var hit = segment && hits.find(value => segment.start >= value.start && segment.start < value.end);
          if (!hit) return;
          var label = viewText('simplified.word_help_prepared_for', 'Prepared word help: {word}', { word: hit.entry.quote });
          decorate(word, { 'aria-label': label, title: label, 'data-prepared-word-help': hit.entry.id });
        });
      });
      return () => restore.forEach(reset => reset());
    }, [preparedHelpContext, generatedContent?.adaptedReadingSupports, adaptedSupportView, wordHelpCard, props.t]);
    var [glossDensity, setGlossDensity] = React.useState('all');
    var [glossBusy, setGlossBusy] = React.useState(false);
    var [glossNotice, setGlossNotice] = React.useState('');
    var [glossEditorRequest, setGlossEditorRequest] = React.useState(null);
    var currentGlossSourceRef = React.useRef(''); currentGlossSourceRef.current = generatedContent?.id + ':' + (capturedSource?.fingerprint || '');
    var supportOwner = findSimplifiedReadingSupportOwner(history, generatedContent, capturedSource);
    var checkedSupports = capturedSource && readingContract?.validateReadingSupports ? readingContract.validateReadingSupports(supportOwner || generatedContent, supportOwner?.readingSupports) : null;
    var audioGlosses = readingContract?.selectReadingSupports ? readingContract.selectReadingSupports(supportOwner || generatedContent, checkedSupports, { density: glossDensity }) : (checkedSupports?.annotations || []);
    var activeGlosses = showReadingGlosses ? audioGlosses : [];
    function renderSimplifiedComparison() {
      var resolved = resolveSimplifiedCompareSource(history, generatedContent, inputText);
      var candidates = (history || []).filter(item => item.id !== generatedContent.id && ['analysis', 'simplified'].includes(item.type) && getArtifactReadingText(item));
      var selected = isTeacherMode ? candidates.find(item => String(item.id) === comparisonSourceId) : null;
      var original = selected ? { text: getArtifactReadingText(selected), artifact: selected, selection: 'educator-selected' } : resolved;
      var originalLanguage = original.artifact?.config?.language || original.artifact?.instructionalText?.complexity?.language || '';
      var adaptedParts = getSideBySideContent(simplifiedDisplayBody);
      // The canonical source is complete, including any bilingual blocks.
      var sourceParts = original.selection === 'captured-source' ? null : getSideBySideContent(original.text);
      var effectiveLanguage = comparisonLanguage === 'auto' ? (adaptedParts && simplifiedLanguageTag(originalLanguage) && simplifiedLanguageTag(originalLanguage) === simplifiedLanguageTag(readingTranslationLanguage) ? 'english' : 'adapted') : comparisonLanguage;
      var targetText = adaptedParts ? effectiveLanguage === 'english' ? adaptedParts.targetFull : adaptedParts.sourceFull : simplifiedDisplayBody;
      var sourceText = sourceParts ? effectiveLanguage === 'english' ? sourceParts.targetFull : sourceParts.sourceFull : original.text;
      var targetLanguage = effectiveLanguage === 'english' && adaptedParts ? readingTranslationLanguage : readingLanguage;
      if (sourceParts && effectiveLanguage === 'english') originalLanguage = window.AlloModules?.TextPipelineHelpers?.getArtifactTranslationTarget?.(original.artifact) || 'English';
      var stripReferences = value => { try { return splitReferencesFromBody ? splitReferencesFromBody(String(value || '')).body : String(value || ''); } catch (_) { return String(value || ''); } };
      if (original.selection !== 'captured-source') sourceText = stripReferences(sourceText);
      targetText = stripReferences(targetText);
      var comparisonSupportOwner = findSimplifiedComparisonSupportOwner(history, generatedContent, original, sourceText);
      var comparisonSupports = comparisonSupportOwner ? readingContract.validateReadingSupports(comparisonSupportOwner, comparisonSupportOwner.readingSupports) : null;
      var comparisonGlosses = showReadingGlosses ? (readingContract?.selectReadingSupports ? readingContract.selectReadingSupports(comparisonSupportOwner, comparisonSupports, { density: glossDensity }) : (comparisonSupports?.annotations || [])) : [];
      // Tokenize whitespace too, so comparison preserves paragraphs and line breaks.
      // Bound the quadratic work; long texts use complete, unchanged source panels.
      var oldTokens = simplifiedComparisonPlainText(sourceText).match(/\s+|\S+/g) || [], newTokens = simplifiedComparisonPlainText(targetText).match(/\s+|\S+/g) || [];
      var tooLarge = oldTokens.length * newTokens.length > 1000000;
      var mismatch = simplifiedLanguageTag(originalLanguage) && simplifiedLanguageTag(targetLanguage) && simplifiedLanguageTag(originalLanguage).split('-')[0] !== simplifiedLanguageTag(targetLanguage).split('-')[0];
      var showDiff = showComparisonChanges && !tooLarge && !mismatch && sourceText && targetText;
      var passageKey = JSON.stringify([navigationViewKey, readingFingerprint(sourceText), readingFingerprint(targetText)]);
      var sameLanguage = !(original.selection === 'captured-source' && getSideBySideContent(original.text)) && !!(generatedContent?.config?.language || generatedContent?.instructionalText?.complexity?.language || (adaptedParts && effectiveLanguage === 'english')) && !!originalLanguage && !!targetLanguage && !!simplifiedLanguageTag(originalLanguage) && !!simplifiedLanguageTag(targetLanguage) && !mismatch && !/[+&/]|bilingual|multilingual/i.test(originalLanguage + targetLanguage);
      var sections = linkPassages ? getReadingNavigationSections(targetText) : [];
      var chosenSection = sections[Math.min(linkedSection, Math.max(0, sections.length - 1))];
      var related = relatedPassage?.key === passageKey ? relatedPassage : null;
      var linkedRange = linkPassages && !showDiff && related?.status === 'matched' ? related : null;
      function showRelatedOriginal() {
        if (!chosenSection || showDiff || !sameLanguage) return;
        var result = findRelatedOriginalPassage(sourceText, chosenSection.text, { sameLanguage: true });
        setRelatedPassage(Object.assign({ key: passageKey }, result));
        focusReadingOffset('adapted', chosenSection.start, false);
        if (result.status === 'matched') focusReadingOffset('source', result.start, true);
      }
      var diff = [];
      if (showDiff) {
        var matrix = Array.from({ length: oldTokens.length + 1 }, () => new Uint32Array(newTokens.length + 1));
        for (var a = 1; a <= oldTokens.length; a++) for (var b = 1; b <= newTokens.length; b++) matrix[a][b] = oldTokens[a - 1] === newTokens[b - 1] ? matrix[a - 1][b - 1] + 1 : Math.max(matrix[a - 1][b], matrix[a][b - 1]);
        var x = oldTokens.length, y = newTokens.length;
        while (x || y) {
          if (x && y && oldTokens[x - 1] === newTokens[y - 1]) { diff.push({ type: 'same', value: oldTokens[--x] }); --y; }
          else if (x && (!y || matrix[x - 1][y] >= matrix[x][y - 1])) diff.push({ type: 'del', value: oldTokens[--x] });
          else diff.push({ type: 'add', value: newTokens[--y] });
        }
        diff.reverse();
      }
      var count = text => simplifiedWordSegments(simplifiedPlainInline(text), targetLanguage).filter(part => part.word).length;
      var renderVersion = (kind, raw) => showDiff ? diff.filter(part => part.type !== (kind === 'source' ? 'add' : 'del')).map((part, i) => part.type === 'same' ? <React.Fragment key={i}>{part.value}</React.Fragment> : part.type === 'del' ? <del key={i} className="bg-red-100 text-red-900">{part.value}</del> : <ins key={i} className="bg-green-100 text-green-900">{part.value}</ins>) : renderExactPassage(raw, kind, kind === 'source' ? originalLanguage : targetLanguage, kind === 'source' ? comparisonGlosses : [], kind === 'source' ? comparisonSupportOwner : null, kind === 'source' ? linkedRange : null, true);
      return <div data-reading-comparison="true" className="space-y-4">
        <div className="flex flex-wrap gap-3 rounded-xl bg-white p-4 border border-slate-200">
          <label className="inline-flex min-h-11 items-center gap-2"><input type="checkbox" aria-label={viewText('simplified.compare_show_changes', 'Show changes')} checked={showComparisonChanges} disabled={!!tooLarge || !!mismatch || !sourceText} onChange={event => { const next = event.target.checked; setShowComparisonChanges(next); try { if (!props.isStudentPreview) localStorage.setItem('alloflow_reading_show_changes', next ? 'on' : 'off'); } catch (_) {} }} />{viewText('simplified.compare_show_changes', 'Show changes')}</label>
          {comparisonSupports?.annotations?.length > 0 && <><label className="inline-flex min-h-11 items-center gap-2"><input type="checkbox" aria-label={viewText('simplified.compare_show_glosses', 'Show glosses')} checked={showReadingGlosses} disabled={!!showDiff} onChange={event => setShowReadingGlosses(event.target.checked)} />{viewText('simplified.compare_show_glosses', 'Show glosses')}</label><label>{viewText('simplified.compare_gloss_density', 'Gloss density')}{' '}<select aria-label={viewText('simplified.compare_gloss_density', 'Gloss density')} value={glossDensity} disabled={!!showDiff} onChange={event => setGlossDensity(event.target.value)} className="min-h-11 rounded border p-2"><option value="all">{viewText('simplified.compare_all_supports', 'All supports')}</option><option value="light">{viewText('simplified.compare_lighter', 'Lighter')}</option></select></label>{showDiff && <span className="self-center text-sm text-slate-600">{viewText('simplified.compare_turn_off_show_changes_to_read', 'Turn off Show changes to read inline glosses.')}</span>}</>}
          {isTeacherMode && <label className="min-w-0 basis-full sm:basis-48 flex-1 text-sm font-semibold">{readerText('simplified.compare_source', 'Source version')}<select value={comparisonSourceId} onChange={e => updateComparisonPreference('source', e.target.value)} className="mt-1 block w-full min-w-0 rounded border border-slate-300 p-2"><option value="linked">{readerText('simplified.linked_source', 'Linked source / original')}</option>{candidates.map(item => <option key={item.id} value={String(item.id)}>{item.title || item.topic || item.id}</option>)}</select></label>}
          {adaptedParts && <label className="min-w-0 basis-full sm:basis-48 flex-1 text-sm font-semibold">{readerText('simplified.compare_language', 'Adapted version')}<select value={comparisonLanguage} onChange={e => updateComparisonPreference('language', e.target.value)} className="mt-1 block w-full rounded border border-slate-300 p-2"><option value="auto">{readerText('simplified.compare_auto', 'Match source language when known')}</option><option value="adapted">{readingLanguage}</option><option value="english">{simplifiedEnglishTranslationLabel}</option></select></label>}
          <label className="inline-flex min-h-11 items-center gap-2"><input type="checkbox" aria-label={viewText('simplified.compare_link_passages', 'Link passages')} checked={linkPassages} onChange={event => { setLinkPassages(event.target.checked); setRelatedPassage(null); }} />{viewText('simplified.compare_link_passages', 'Link passages')}</label>
        </div>
        {linkPassages && <div data-reading-passage-links className="rounded-xl border border-indigo-200 bg-indigo-50 p-4 space-y-3">
          <p className="text-sm text-indigo-950">{viewText('simplified.compare_choose_a_passage_from_the_adaptation', 'Choose a passage from the adaptation to look for related wording in the original. A link suggests a place to read; it does not verify the adaptation.')}</p>
          {showDiff ? <p role="status">{viewText('simplified.compare_turn_off_show_changes_to_link', 'Turn off Show changes to link passages.')}</p> : !sameLanguage ? <p role="status">{viewText('simplified.compare_passage_links_need_two_versions_in', 'Passage links need two versions in the same known language.')}</p> : <div className="flex flex-wrap items-end gap-3"><label className="min-w-0 basis-full sm:basis-48 flex-1 text-sm font-semibold">{viewText('simplified.compare_adapted_passage', 'Adapted passage')}<select aria-label={viewText('simplified.compare_adapted_passage', 'Adapted passage')} value={chosenSection?.index || 0} onChange={event => { setLinkedSection(Number(event.target.value)); setRelatedPassage(null); }} className="mt-1 block w-full min-w-0 rounded border border-slate-300 p-2">{sections.map(section => <option key={section.index} value={section.index}>{section.index + 1}. {section.text.replace(/\s+/g, ' ').slice(0, 85)}</option>)}</select></label><button type="button" onClick={showRelatedOriginal} disabled={!chosenSection || !sourceText} className="min-h-11 rounded-lg border border-indigo-300 bg-white px-3 text-indigo-900 disabled:opacity-50">{viewText('simplified.compare_show_related_original', 'Show related original')}</button></div>}
          {!showDiff && related && <p role="status" aria-live="polite">{related.status === 'matched' ? viewText('simplified.compare_related_wording_highlighted_in_the_origi', 'Related wording highlighted in the original. Read the surrounding passage to check meaning.') : related.status === 'ambiguous' ? viewText('simplified.compare_more_than_one_original_passage_has', 'More than one original passage has similar wording. Read the original to choose the right context.') : viewText('simplified.compare_no_reliable_passage_link_was_found', 'No reliable passage link was found. You can still read both complete versions.')}</p>}
        </div>}
        {original.selection === 'original-not-captured' && <p role="status" className="rounded bg-amber-50 p-3 text-sm text-amber-900">{readerText('simplified.compare_fallback', 'Original not captured. Open or attach the matching source; another lesson will not be substituted.')}</p>}
        {(tooLarge || mismatch) && <p role="status" className="rounded bg-indigo-50 p-3 text-sm text-indigo-900">{mismatch ? readerText('simplified.compare_different_languages', 'These versions use different languages. Read them side by side; word change highlighting is unavailable.') : readerText('simplified.compare_long_text', 'For this long reading, complete versions are shown without word change highlighting.')}</p>}
        {isTeacherMode && <p className="text-sm text-slate-600">{readerText('simplified.compare_word_count', 'Word counts')}: {count(sourceText)} → {count(targetText)}. {readerText('simplified.compare_review_hint', 'Check key ideas, terminology, examples, and citations before sharing. Word changes alone do not establish accuracy.')}</p>}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">{[{ key: 'source', title: t('simplified.diff_original'), text: sourceText, language: originalLanguage }, { key: 'adapted', title: t('simplified.diff_adapted'), text: targetText, language: targetLanguage }].map(version => <section key={version.key} className="min-w-0 rounded-xl border border-slate-300 bg-white p-4"><h3 className="mb-3 font-bold">{version.title}{version.language ? ' · ' + version.language : ''}</h3><div className="mb-3 flex flex-wrap gap-2"><button type="button" data-comparison-karaoke={version.key} aria-describedby={props.isStudentPreview ? props.previewLimitId : undefined} disabled={!!props.isStudentPreview || !version.text || !KaraokeReaderOverlay} className="min-h-11 inline-flex items-center gap-2 rounded-lg bg-indigo-700 px-4 py-2 font-bold text-white disabled:opacity-50 focus-visible:ring-2 focus-visible:ring-indigo-600 focus-visible:ring-offset-2" aria-label={version.key === 'source' ? readerText('simplified.listen_along_original', 'Listen along to the original') : readerText('simplified.listen_along_adapted', 'Listen along to the adapted text')} onClick={event => openListenAlong(version.text, version.language || readingLanguage, event)}><Volume2 size={16} aria-hidden="true" />{readerText('simplified.listen_along', 'Listen along')}</button>{version.key === 'source' && props.onReadOriginal && original.text && <button type="button" className="min-h-11 rounded border border-indigo-300 px-3 text-indigo-900" onClick={() => openOriginalReading(selected ? original.artifact : capturedSource ? generatedContent : original.artifact, original.text, true)}>{viewText('simplified.compare_open_original_reader', 'Open original reader')}</button>}</div><div data-compare-version={version.key} data-reading-language={version.language} data-word-help-language={version.key === 'adapted' && showReadingGlosses && !showDiff && !(adaptedParts && effectiveLanguage === 'english') ? targetLanguage : undefined} lang={simplifiedLanguageTag(version.language)} dir={getContentDirection(version.language)} style={{ whiteSpace: 'pre-wrap', overflowWrap: 'anywhere', maxHeight: '70vh', overflowY: 'auto' }} tabIndex={0} role="region" aria-label={version.title}>{renderVersion(version.key, version.text)}</div>{version.key === 'source' && !showDiff && renderPictureCredits(comparisonGlosses)}{version.key === 'source' && isTeacherMode && comparisonSupportOwner && props.onUpdateReadingSupports && <ReadingGlossEditor draftSession={supportDraftSession} key={readingSupportDraftKey(comparisonSupportOwner, false)} item={comparisonSupportOwner} supports={comparisonSupports} request={glossEditorRequest} onUpdate={props.onUpdateReadingSupports} disabled={isProcessing} />}</section>)}</div>
        {showReadingGlosses && !showDiff && <AdaptedWordHelp supportView={adaptedSupportView} onOpen={(event, entry) => showPreparedWordHelp(event, entry, readingLanguage, null)} draftSession={supportDraftSession} key={readingSupportDraftKey(generatedContent, true)} item={generatedContent} teacher={false} passageSelector='[data-compare-version="adapted"]' language={targetLanguage} markWords={!(adaptedParts && effectiveLanguage === 'english')} languageTag={simplifiedLanguageTag(readingLanguage)} direction={typeof getContentDirection === 'function' ? getContentDirection(readingLanguage) : undefined} onListen={props.isStudentPreview ? undefined : text => speakExactPassage(text, 'adapted-word-help', readingLanguage)} listening={isExactPassagePlaying('adapted-word-help')} renderCredits={renderPictureCredits} />}
      </div>;
    }

    function playPreparedCardAudio(kind, text) {
      var owner = wordHelpOwnerRef.current;
      if (!owner || owner !== currentWordHelpCard) return;
      // The host assigns the audio ID before speech is ready. The same control
      // must stop that pending request instead of starting it a second time.
      var id = owner.audioIds[kind], wasPlaying = playingContentId === id;
      if (typeof stopPlayback === 'function') stopPlayback();
      if (!wasPlaying && typeof handleSpeak === 'function') handleSpeak(text, id, 0, true, owner.language || readingLanguage);
    }
    function isExactPassagePlaying(pane) { return !!isPlaying && playingContentId === 'reading-' + generatedContent.id + '-' + pane; }
    function speakExactPassage(text, pane, language) {
      if (props.isStudentPreview) return;
      var wasPlaying = isExactPassagePlaying(pane);
      if (typeof stopPlayback === 'function') stopPlayback();
      if (wasPlaying) return;
      if (typeof handleSpeak === 'function') handleSpeak(text, 'reading-' + generatedContent.id + '-' + pane, 0, true, language || readingLanguage);
    }
    // Credits for pictures shown beside word supports (their licences require it).
    function renderPictureCredits(annotations) {
      var pictured = (annotations || []).filter(entry => entry.image && entry.image.attribution);
      if (!pictured.length) return null;
      var line = attribution => window.AlloModules?.AltText?.openImageCreditLine ? window.AlloModules.AltText.openImageCreditLine(attribution)
        : [attribution.set, attribution.author, attribution.license].filter(Boolean).join(' · ');
      return <div data-reading-picture-credits className="mt-4 border-t border-slate-200 pt-2 text-xs text-slate-700"><p className="font-semibold">{viewText('simplified.original_picture_credits', 'Picture credits')}</p><ul className="mt-1 space-y-1">{pictured.map(entry => <li key={entry.id} className="break-words">{entry.quote}: {line(entry.image.attribution)}{/^https:\/\//i.test(entry.image.attribution.url || '') && <> · <a href={entry.image.attribution.url} target="_blank" rel="noopener noreferrer" className="underline">{viewText('simplified.original_source', 'Source')}</a></>}{/^https:\/\//i.test(entry.image.attribution.licenseUrl || '') && <> · <a href={entry.image.attribution.licenseUrl} target="_blank" rel="noopener noreferrer" className="underline">{viewText('simplified.original_license', 'License')}</a></>}</li>)}</ul></div>;
    }
    function renderExactPassage(raw, pane, language, annotations, annotationOwner, relatedRange, formatted) {
      var blocks = simplifiedExactBlocks(raw, formatted);
      var headingLevels = blocks.filter(block => block.type === 'heading').map(block => block.level);
      var renderBlock = function (block) {
        var line = block.raw, lineIndex = block.lineIndex, lineStart = block.start;
        if (block.type === 'hidden') return null;
        // Headings, quotes and dividers end their own line, so the line break after
        // one is not drawn: it doubled the gap before the next blank line.
        if (block.type === 'rule') return <hr key={lineIndex} aria-hidden="true" style={{ border: 0, borderTop: '1px solid currentColor', opacity: 0.25, marginBlock: '0.5em' }} />;
        if (!line) return <React.Fragment key={lineIndex}>{block.separator}</React.Fragment>;
        var hasLineGloss = (annotations || []).some(entry => entry.end > lineStart && entry.end <= lineStart + line.length);
        // Plain reading does not need a React node or word segmentation for every token.
        var wordIndex = 0;
        var renderLeaf = function (text, offset, interactive) {
          var parts = ['define', 'phonics'].includes(interactionMode) && interactive !== false || hasLineGloss ? simplifiedWordSegments(text, language) : [{ text, word: false }], wordOffset = 0;
          return parts.map(function (part, index) {
            var start = offset + wordOffset; wordOffset += part.text.length;
            var glosses = (annotations || []).filter(entry => entry.end > start && entry.end <= offset + wordOffset);
            var node = part.text;
            if (part.word && interactive !== false && ['define', 'phonics'].includes(interactionMode)) {
              var activate = event => { if (event.type === 'click' && (selectionMenu?.text || window.getSelection?.().toString().trim())) return; event.stopPropagation(); if (interactionMode === 'phonics') { handlePhonicsClick(part.text, event, { audioPlayback: 'reader', language }); return; } var helpPane = pane === 'adapted' ? event.currentTarget.closest('[data-word-help-language]') : null; if (!openWordHelpCard(event, helpPane, helpPane && helpPane.getAttribute('data-word-help-language'))) handleWordClick?.(part.text, event, { text: raw, language }); };
              node = <span role="button" tabIndex={wordIndex++ === 0 ? 0 : -1} data-exact-word="true" aria-label={interactionMode === 'phonics' ? viewText('simplified.original_word_sounds_for', 'Word sounds: {word}', { word: part.text }) : viewText('simplified.original_define_word', 'Define: {word}', { word: part.text })} onClick={activate} onKeyDown={event => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); activate(event); } else if (['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) { const nodes = Array.from(event.currentTarget.closest('[data-reading-paragraph]').querySelectorAll('[data-exact-word]')); const delta = (event.key === 'ArrowRight' ? 1 : -1) * (getContentDirection(language) === 'rtl' ? -1 : 1); const next = event.key === 'Home' ? 0 : event.key === 'End' ? nodes.length - 1 : Math.max(0, Math.min(nodes.length - 1, nodes.indexOf(event.currentTarget) + delta)); event.preventDefault(); nodes[next]?.focus(); } }} onFocus={event => { event.currentTarget.closest('[data-reading-paragraph]').querySelectorAll('[data-exact-word]').forEach(n => n.tabIndex = n === event.currentTarget ? 0 : -1); }} className="cursor-help rounded hover:bg-yellow-100 focus-visible:ring-2 focus-visible:ring-indigo-600">{part.text}</span>;
            }
            return <React.Fragment key={index}>{node}{glosses.map(entry => <span role="group" key={entry.id} data-reading-gloss className="mx-1 rounded bg-indigo-50 px-1 text-base text-indigo-900" aria-label={viewText('simplified.original_gloss_for', 'Gloss for {word}', { word: entry.quote })}>{entry.image && <img src={entry.image.src} alt={entry.image.alt || ''} data-reading-gloss-picture className="mx-1 inline-block h-12 w-12 rounded bg-white object-contain align-middle" />} ({entry.definition || entry.explanation || entry.text}){isTeacherMode && annotationOwner && props.onUpdateReadingSupports && <button type="button" aria-label={viewText('simplified.original_edit_explanation_for', 'Edit explanation for {word}', { word: entry.quote })} disabled={isProcessing} onClick={event => { event.stopPropagation(); setGlossEditorRequest(previous => ({ ownerId: annotationOwner.id, id: entry.id, serial: (previous?.serial || 0) + 1 })); }} className="ml-1 inline-flex min-h-11 min-w-11 items-center justify-center rounded border border-indigo-200 px-2 text-xs font-semibold text-indigo-900 focus-visible:ring-2 focus-visible:ring-indigo-600">{viewText('common.edit', 'Edit')}</button>}</span>)}</React.Fragment>;
          });
        };
        var content = formatted ? simplifiedInline(block.text, renderLeaf, block.textStart) : renderLeaf(line, lineStart);
        var Tag = block.type === 'heading' ? simplifiedHeadingTag(block.level, headingLevels) : block.type === 'quote' ? 'blockquote' : 'span';
        var markdownStyle = block.type === 'heading' ? { fontWeight: 750, fontSize: block.level === 1 ? '1.5em' : block.level === 2 ? '1.3em' : '1.15em', marginBlock: '0.6em 0.3em' } : block.type === 'quote' ? { borderInlineStart: '3px solid #a5b4fc', paddingInlineStart: '1em' } : undefined;
        var isRelated = !!relatedRange && relatedRange.end > lineStart && relatedRange.start < lineStart + line.length;
        const explanationText = formatted ? simplifiedPlainInline(block.text) : line;
        const explain = event => {
          if (interactionMode !== 'explain') return;
          const control = event.target.closest('a, button, input, select, textarea, [role="button"]');
          if (control && control !== event.currentTarget) return;
          event.stopPropagation();
          const selected = window.getSelection?.().toString().trim();
          const rect = event.currentTarget.getBoundingClientRect();
          setSelectionMenu({ text: selected || explanationText, language, x: rect.left, y: rect.bottom });
        };
        const explainButton = interactionMode === 'explain' ? <button type="button" data-exact-explain aria-label={viewText('simplified.explain_mode', 'Explain') + ': ' + explanationText} onClick={explain} className="mx-1 inline-flex min-h-11 items-center rounded-lg border border-indigo-300 bg-white px-3 text-sm font-semibold text-indigo-900 focus-visible:ring-2 focus-visible:ring-indigo-600">{viewText('simplified.explain_mode', 'Explain')}</button> : null;
        return <React.Fragment key={lineIndex}><Tag style={markdownStyle} data-reading-offset-start={lineStart} data-reading-offset-end={lineStart + line.length} data-related-original={isRelated ? "true" : undefined} data-reading-language={language} onMouseUp={interactionMode === 'define' ? handleTextMouseUp : undefined} data-reading-paragraph={pane + '-' + lineIndex} lang={simplifiedLanguageTag(language)} dir={getContentDirection(language)} tabIndex={isLineFocusMode ? 0 : undefined} onClick={explain} onFocus={() => { if (isLineFocusMode && typeof setFocusedParagraphIndex === 'function') setFocusedParagraphIndex(pane + '-' + lineIndex); }} className={isRelated ? 'bg-indigo-100 outline outline-2 outline-indigo-500 text-slate-950' : isLineFocusMode ? (focusedParagraphIndex === pane + '-' + lineIndex || focusedParagraphIndex == null && lineIndex === 0 ? 'bg-yellow-100 text-slate-950' : 'opacity-50') : ''}>{content}</Tag>{explainButton}{block.type === 'heading' || block.type === 'quote' ? null : block.separator}</React.Fragment>;
      };
      return formatted ? simplifiedNestLists(blocks, renderBlock) : blocks.map(renderBlock);
    }
    var returnComparisonItem = protectedOriginal && comparisonReturn && generatedContent.data === comparisonReturn.expectedText && readingContract?.sameReadingSourceFamily?.(generatedContent, comparisonReturn.sourceItem) && (history || []).find(item => item.id === comparisonReturn.id && readingFingerprint(item.data) === comparisonReturn.fingerprint && readingScopeIdentity(item) === comparisonReturn.scope && getSimplifiedInstructionalText(item).form === 'adapted');
    function switchReadingVersion(item, compare) {
      if (!item || (item.id === generatedContent?.id && !!compare === !!isCompareMode)) return;
      if (supportDraftSession?.blocked()) return requestSupportTransition(() => switchReadingVersion(item, compare));
      // A deferred save can replace this artifact while the requested transition waits.
      const live = liveReaderProps.current;
      item = [live.generatedContent, ...(live.history || [])].find(candidate => candidate && readingSupportDraftKey(candidate, false) === readingSupportDraftKey(item, false)) || item;
      prepareReadingNavigation(compare ? 'both' : 'adapted', false);
      if (typeof stopPlayback === 'function') stopPlayback();
      if (props.onOpenReadingArtifact) props.onOpenReadingArtifact(item, compare);
      else { chooseReadingMode('read'); setGeneratedContent?.(previous => previous && readingSupportDraftKey(previous, false) === readingSupportDraftKey(item, false) ? previous : item); setIsCompareMode?.(!!compare); }
    }
    var versionControls = <div data-reading-versions className="my-3 flex flex-wrap items-center gap-2" role="group" aria-label={viewText('simplified.reader_reading_versions', 'Reading versions')}>{props.onReadOriginal && <button type="button" disabled={!capturedSource && !protectedOriginal} aria-pressed={protectedOriginal && !isCompareMode} className={`min-h-11 rounded-lg border px-3 disabled:opacity-50 ${protectedOriginal && !isCompareMode ? 'bg-indigo-700 text-white border-indigo-700' : 'border-indigo-300'}`} data-reading-version="original" onClick={() => openOriginalReading(generatedContent, capturedSource?.text, false)}>{viewText('simplified.reader_original', 'Original')}</button>}{(companion || !protectedOriginal) && <><button type="button" aria-pressed={!protectedOriginal && !isCompareMode} className={`min-h-11 rounded-lg border px-3 ${!protectedOriginal && !isCompareMode ? 'bg-indigo-700 text-white border-indigo-700' : 'border-indigo-300'}`} data-reading-version="adapted" onClick={() => switchReadingVersion(companion || generatedContent, false)}>{viewText('simplified.diff_adapted', 'Adapted')}</button><button type="button" aria-pressed={isCompareMode} disabled={!capturedSource} className={`min-h-11 rounded-lg border px-3 disabled:opacity-50 ${isCompareMode ? 'bg-indigo-700 text-white border-indigo-700' : 'border-indigo-300'}`} data-reading-version="both" onClick={() => switchReadingVersion(companion || generatedContent, true)}>{viewText('simplified.reader_both', 'Both')}</button></>}{returnComparisonItem && <button type="button" className="min-h-11 rounded-lg border border-indigo-300 px-3" onClick={() => switchReadingVersion(returnComparisonItem, true)}>{viewText('simplified.reader_back_to_comparison', 'Back to comparison')}</button>}{protectedOriginal && isTeacherMode && props.onCreateAdaptedCompanion && <button type="button" disabled={isProcessing} onClick={() => props.onCreateAdaptedCompanion(generatedContent)} className="min-h-11 rounded-lg bg-indigo-700 px-3 text-white disabled:opacity-50">{viewText('simplified.reader_create_adapted_companion', 'Create adapted companion')}</button>}</div>;
    function renderOriginalReading() {
      return <div data-simplified-reading-body="true" style={{ maxWidth: readingColumn + 'ch', marginInline: 'auto' }}><div className="mb-3 flex flex-wrap items-center gap-3"><button type="button" data-reader-listen onClick={() => speakExactPassage(simplifiedReadAloudText, 'original', readingLanguage)} className="min-h-11 rounded-lg bg-indigo-700 px-3 text-white">{isExactPassagePlaying('original') ? viewText('simplified.original_stop_original', 'Stop original') : viewText('simplified.original_listen_to_original', 'Listen to original')}</button>{checkedSupports?.annotations?.length > 0 && <><label className="inline-flex min-h-11 items-center gap-2"><input type="checkbox" checked={showReadingGlosses} onChange={e => setShowReadingGlosses(e.target.checked)} />{viewText('simplified.compare_show_glosses', 'Show glosses')}</label><label>{viewText('simplified.compare_gloss_density', 'Gloss density')}{' '}<select value={glossDensity} onChange={e => setGlossDensity(e.target.value)} className="min-h-11 rounded border p-2"><option value="all">{viewText('simplified.compare_all_supports', 'All supports')}</option><option value="light">{viewText('simplified.compare_lighter', 'Lighter')}</option></select></label><button type="button" className="min-h-11 rounded border px-3" onClick={() => { let audio = '', from = 0; audioGlosses.forEach(entry => { audio += simplifiedReadAloudText.slice(from, entry.end) + '. ' + (entry.definition || entry.explanation || entry.text) + '. '; from = entry.end; }); audio += simplifiedReadAloudText.slice(from); speakExactPassage(audio, 'glosses-' + audioGlosses.length, readingLanguage); }}>{isExactPassagePlaying('glosses-' + audioGlosses.length) ? viewText('simplified.original_stop_gloss_reading', 'Stop gloss reading') : viewText('simplified.original_listen_with_glosses', 'Listen with glosses')}</button></>}{isTeacherMode && props.onGenerateReadingSupports && <button type="button" disabled={glossBusy || !verifiedOriginal} className="min-h-11 rounded border border-indigo-300 px-3 disabled:opacity-50" onClick={async () => { const request = currentGlossSourceRef.current; setGlossBusy(true); setGlossNotice(''); try { const result = await props.onGenerateReadingSupports(generatedContent); if (request === currentGlossSourceRef.current) setGlossNotice(result?.status === 'unavailable' ? viewText('simplified.original_word_supports_could_not_be_generated', 'Word supports could not be generated. The original is unchanged.') : result?.status === 'partial' ? viewText('simplified.original_some_words_could_not_be_supported', 'Some words could not be supported. The original is unchanged.') : viewText('simplified.original_word_supports_are_ready', 'Word supports are ready.')); } catch(error) { if (request === currentGlossSourceRef.current) setGlossNotice(error?.message || viewText('simplified.original_word_supports_could_not_be_generated', 'Word supports could not be generated. The original is unchanged.')); } finally { setGlossBusy(false); } }}>{glossBusy ? viewText('simplified.original_adding_word_supports', 'Adding word supports…') : checkedSupports?.annotations?.length ? viewText('simplified.original_refresh_suggested_supports', 'Refresh suggested supports') : viewText('simplified.original_add_word_supports', 'Add word supports')}</button>}</div><p role="status" data-gloss-status className={glossNotice ? 'my-3 rounded bg-indigo-50 p-3 text-indigo-900' : 'sr-only'}>{glossNotice}</p>{isTeacherMode && verifiedOriginal && props.onUpdateReadingSupports && <ReadingGlossEditor draftSession={supportDraftSession} key={readingSupportDraftKey(generatedContent, false)} item={generatedContent} supports={checkedSupports} request={glossEditorRequest} onUpdate={props.onUpdateReadingSupports} disabled={isProcessing} />}<div data-reading-passage="true" data-original-source="true" role="region" aria-label={viewText('simplified.original_original_reading', 'Original reading')} tabIndex={-1} ref={readingStartRef} style={{ whiteSpace: 'pre-wrap', overflowWrap: 'anywhere' }} className="text-lg leading-relaxed">{renderExactPassage(simplifiedReadAloudText, 'original', readingLanguage, activeGlosses, generatedContent, null, true)}</div>{renderPictureCredits(activeGlosses)}</div>;
    }

    function renderSimplifiedReading() {
      var parts = getSideBySideContent(simplifiedReadAloudText);
      var languages = parts ? [{ key: 'src', label: readingLanguage, paragraphs: parts.source }, { key: 'tgt', label: readingTranslationLanguage, paragraphs: parts.target }] : [{ key: 'mono', label: readingLanguage, paragraphs: simplifiedReadAloudText.split(/\n{2,}/) }];
      var isWordMode = ['define', 'phonics', 'add-glossary'].includes(interactionMode);
      var isSelectionMode = ['explain', 'revise'].includes(interactionMode);
      var sentenceCursor = 0;
      var renderedSentenceIds = new Set();
      var rendered = languages.map(function (section) {
        var headingLevels = simplifiedHeadingLevels(section.paragraphs.join('\n'));
        return section.paragraphs.map(function (paragraph, paragraphIndex) {
          var paragraphId = section.key === 'mono' ? paragraphIndex : section.key + '-' + paragraphIndex;
          if (/^\[\[CHART:/.test(paragraph.trim())) return <div key={paragraphId} data-reading-chart="true" className="my-4 max-w-full overflow-x-auto">{renderFormattedText(paragraph, false)}</div>;
          if (paragraph.trim().startsWith('|') || paragraph.includes('\n|')) return <div key={paragraphId} data-reading-table="true" lang={simplifiedLanguageTag(section.label)} dir={getContentDirection(section.label)} className="my-4 max-w-full overflow-x-auto" tabIndex={0} role="region" aria-label={readerText('simplified.table_label', 'Reading table')}>{renderFormattedText(paragraph, false)}</div>;
          var startIdx = sentenceCursor;
          var blocks = simplifiedParagraphBlocks(paragraph).map(function (block) {
            block.start = sentenceCursor;
            block.sentences = splitTextToSentences(block.raw);
            sentenceCursor += block.sentences.length;
            return block;
          });
          // Playback numbers the sentences of the whole paragraph (phase_k handleSpeak).
          // Where the block split differs (a list item's last line running into the
          // next line), each part takes the number of the spoken sentence it starts
          // in, so every later click and highlight stays on the same words.
          var spoken = splitTextToSentences(paragraph);
          if (spoken.length !== sentenceCursor - startIdx) {
            var letters = value => String(value || '').replace(/[^\p{L}\p{N}]+/gu, '').length;
            var spokenStarts = [], letterCount = 0;
            spoken.forEach(sentence => { spokenStarts.push(letterCount); letterCount += letters(sentence); });
            letterCount = 0;
            blocks.forEach(block => {
              block.indices = block.sentences.map(sentence => {
                var j = 0;
                while (j + 1 < spokenStarts.length && spokenStarts[j + 1] <= letterCount) j++;
                letterCount += letters(sentence);
                return startIdx + j;
              });
            });
            sentenceCursor = startIdx + spoken.length;
          }
          var endIdx = sentenceCursor;
          var shouldFocus = isPlaying && playingContentId === 'simplified-main' ? playbackState.currentIdx >= startIdx && playbackState.currentIdx < endIdx : focusedParagraphIndex === paragraphId || (focusedParagraphIndex == null && paragraphIndex === 0);
          var wordIndex = 0;
          var sentenceOrder = 0;
          // One Tab stop per paragraph; arrow keys, Home and End move within it.
          var claimRovingStop = function (event, selector) {
            var group = event.currentTarget.closest('[data-reading-paragraph]');
            if (group) group.querySelectorAll(selector).forEach(function (node) { node.tabIndex = node === event.currentTarget ? 0 : -1; });
          };
          var moveRovingStop = function (event, selector) {
            if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
            var group = event.currentTarget.closest('[data-reading-paragraph]');
            if (!group) return;
            var items = Array.from(group.querySelectorAll(selector));
            var delta = (event.key === 'ArrowRight' ? 1 : -1) * (group.dir === 'rtl' ? -1 : 1);
            var next = event.key === 'Home' ? 0 : event.key === 'End' ? items.length - 1 : Math.max(0, Math.min(items.length - 1, items.indexOf(event.currentTarget) + delta));
            event.preventDefault(); items[next]?.focus();
          };
          var renderWords = function (text) {
            return simplifiedWordSegments(text, section.label).map(function (part, index) {
              if (!part.word) return <React.Fragment key={index}>{part.text}</React.Fragment>;
              var order = wordIndex++;
              var label = interactionMode === 'phonics' ? simplifiedHearPhonicsLabel : interactionMode === 'add-glossary' ? readerText('common.click_add_glossary', 'Add to glossary') : simplifiedDefineLabel;
              var activate = function (event) {
                if (event.type === 'click' && (selectionMenu?.text || window.getSelection?.().toString().trim())) return;
                event.stopPropagation();
                if (interactionMode === 'phonics') handlePhonicsClick(part.text, event, { audioPlayback: 'reader' });
                else if (interactionMode === 'add-glossary') handleQuickAddGlossary(part.text, true);
                else if (!openWordHelpCard(event, event.currentTarget.closest('[data-reading-passage]'), readingLanguage)) handleWordClick?.(part.text, event);
              };
              return <span key={index} data-reading-word={order} role="button" tabIndex={order === 0 ? 0 : -1} aria-label={label + ': ' + part.text} title={label} onClick={activate} onFocus={function (event) { claimRovingStop(event, '[data-reading-word]'); }} onKeyDown={function (event) {
                if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); activate(event); return; }
                moveRovingStop(event, '[data-reading-word]');
              }} className="cursor-help rounded px-0.5 hover:bg-yellow-100 focus:bg-yellow-200 focus:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 focus-visible:ring-offset-1">{part.text}</span>;
            });
          };
          var renderReadingInline = value => /\$|!\[/.test(value) || !window.AlloModules?.TextPipelineHelpers?.readingText ? formatInteractiveText(value, false, !!isLineFocusMode) : simplifiedInline(value, text => typeof highlightGlossaryTerms === 'function' ? highlightGlossaryTerms(text, latestGlossary, false, !!isLineFocusMode) : text);
          var renderBlock = function (block, key) {
            if (block.type === 'rule') return <hr key={key} aria-hidden="true" style={{ border: 0, borderTop: '1px solid currentColor', opacity: 0.25, marginBlock: '1em' }} />;
            var Tag = block.type === 'heading' ? simplifiedHeadingTag(block.level, headingLevels) : block.type === 'quote' ? 'blockquote' : block.type === 'li' ? 'span' : 'p';
            var text = block.text === undefined ? block.raw : block.text;
            var content;
            if (isWordMode) content = simplifiedInline(text, renderWords);
            else content = block.sentences.map(function (sentence, index) {
              var currentGlobalIdx = block.indices ? block.indices[index] : block.start + index;
              var firstPart = !renderedSentenceIds.has(currentGlobalIdx);
              renderedSentenceIds.add(currentGlobalIdx);
              var cleanText = sentence.replace(/^\s*#{1,6}\s+/, '').replace(/^\s*<\/?h[1-6][^>]*>/gi, '').replace(/<\/h[1-6]>\s*$/i, '').replace(/^\s*(?:[-+*]|\d+[.)])\s+/, '').replace(/^\s*>\s?/, '');
              var active = playingContentId === 'simplified-main' && playbackState.currentIdx === currentGlobalIdx;
              if (interactionMode === 'cloze') return <span key={index}>{formatInteractiveText(cleanText, true, !!isLineFocusMode, 's' + currentGlobalIdx + (firstPart ? '' : '.' + key + '.' + index))} </span>;
              // A button's content is hidden from screen readers, so a link inside the
              // sentence button could not be heard or opened. Links at the end go after
              // the button; a sentence with a link inside it stays plain text and gets
              // its own read button, shown when it has focus.
              var trailingLinks = (cleanText.match(/(?:\s*\[[^\]]*\]\([^)]*\))+\s*$/) || [''])[0];
              var sentenceText = trailingLinks ? cleanText.slice(0, cleanText.length - trailingLinks.length) : cleanText;
              var innerLink = /\[[^\]]*\]\([^)]*\)|<a\b/i.test(sentenceText);
              var speakSentence = function (event) {
                var control = event.target.closest('a,button,input,select,textarea');
                if (control && control !== event.currentTarget) return;
                // A drag-selection is handled on mouseup; a leftover selection must not block Enter.
                if (event.type === 'click' && window.getSelection && window.getSelection().toString().trim()) return;
                event.stopPropagation();
                if (interactionMode === 'explain') {
                  event.currentTarget.focus();
                  var rect = event.currentTarget.getBoundingClientRect();
                  setSelectionMenu({ text: simplifiedPlainInline(cleanText), language: section.label, x: rect.left + rect.width / 2, y: rect.top });
                } else if (interactionMode === 'revise') {
                  // Mouse users drag or double-click to choose words. Keyboard and screen
                  // reader activation (detail 0) selects the sentence and opens the same menu.
                  if (event.type === 'click' && event.detail > 0) return;
                  var node = event.currentTarget.closest('[data-reading-sentence]'), range = document.createRange(), selection = window.getSelection();
                  var readButton = node.querySelector('[data-sentence-read]');
                  event.currentTarget.focus(); range.selectNodeContents(node); if (readButton) range.setEndBefore(readButton);
                  selection.removeAllRanges(); selection.addRange(range);
                  handleTextMouseUp({ currentTarget: node.closest('[data-reading-paragraph]') });
                } else handleSpeak(simplifiedReadAloudText, 'simplified-main', currentGlobalIdx, true, readingLanguage);
              };
              if (trailingLinks && !sentenceText.trim()) return <React.Fragment key={index}>{renderReadingInline(cleanText.trim())} </React.Fragment>;
              var order = sentenceOrder++;
              var sentenceAction = interactionMode === 'explain' ? readerText('simplified.explain_mode', 'Explain') : interactionMode === 'revise' ? readerText('simplified.revise_mode', 'Revise') : simplifiedReadSentenceLabel;
              var sentenceClass = `rounded px-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 focus-visible:ring-offset-1 ${interactionMode === 'revise' ? '' : 'cursor-pointer '}${active ? 'bg-yellow-300 text-slate-950' : interactionMode === 'revise' ? '' : 'hover:bg-indigo-100/30'}`;
              var sentenceTitle = interactionMode === 'explain' || interactionMode === 'revise' ? sentenceAction : t('common.click_read_from_here');
              var sentenceLabel = sentenceAction + ': ' + simplifiedPlainInline(cleanText);
              var stopProps = { 'data-sentence-stop': true, tabIndex: order === 0 ? 0 : -1, onFocus: function (event) { claimRovingStop(event, '[data-sentence-stop]'); } };
              if (props.isStudentPreview) return <span key={index} id={firstPart ? readerId('sentence-' + currentGlobalIdx) : undefined} data-reading-sentence={currentGlobalIdx}>{renderReadingInline(cleanText)} </span>;
              if (innerLink) return <span key={index} id={firstPart ? readerId('sentence-' + currentGlobalIdx) : undefined} data-reading-sentence={currentGlobalIdx} aria-current={active ? 'true' : undefined} onClick={speakSentence} className={sentenceClass} title={sentenceTitle}>{renderReadingInline(cleanText)}<button type="button" data-sentence-read {...stopProps} aria-label={sentenceLabel} onClick={speakSentence} onKeyDown={event => moveRovingStop(event, '[data-sentence-stop]')} className="sr-only focus:not-sr-only focus:ms-1 focus:rounded focus:bg-indigo-700 focus:px-2 focus:py-0.5 focus:text-sm focus:font-bold focus:text-white">{sentenceAction}</button> </span>;
              var sentenceButton = <span key={index} id={firstPart ? readerId('sentence-' + currentGlobalIdx) : undefined} data-reading-sentence={currentGlobalIdx} role="button" {...stopProps} aria-current={active ? 'true' : undefined} aria-label={trailingLinks ? sentenceAction + ': ' + simplifiedPlainInline(sentenceText) : sentenceLabel} onClick={speakSentence} onKeyDown={function (event) {
                if (event.target !== event.currentTarget) return;
                if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); speakSentence(event); return; }
                moveRovingStop(event, '[data-sentence-stop]');
              }} className={sentenceClass} title={sentenceTitle}>{renderReadingInline(trailingLinks ? sentenceText : cleanText)}{trailingLinks ? null : ' '}</span>;
              return trailingLinks ? <React.Fragment key={index}>{sentenceButton}{renderReadingInline(trailingLinks.trim())} </React.Fragment> : sentenceButton;
            });
            var style = { whiteSpace: 'pre-wrap', overflowWrap: 'anywhere', lineHeight: 'inherit' };
            if (block.type === 'heading') { style.fontWeight = 750; style.fontSize = block.level === 1 ? '1.5em' : block.level === 2 ? '1.3em' : '1.15em'; style.marginBlock = '0.9em 0.45em'; }
            return <Tag key={key} style={style} className={block.type === 'quote' ? 'border-l-4 border-indigo-200 pl-4 my-3 italic' : block.type === 'p' ? 'my-3' : undefined}>{content}</Tag>;
          };
          return <div key={paragraphId} data-reading-paragraph={paragraphId} data-reading-focused={!!shouldFocus} data-reading-language={section.label} lang={simplifiedLanguageTag(section.label)} dir={getContentDirection(section.label)} {...lineFocusParagraphProps(paragraphId)} onMouseUp={isSelectionMode || interactionMode === 'define' ? handleTextMouseUp : undefined} className={`mb-4 rounded-xl transition-opacity motion-reduce:transition-none ${isLineFocusMode ? shouldFocus ? 'opacity-100 bg-slate-800 p-4 text-white' : 'opacity-20 blur-[1px]' : section.key === 'tgt' ? 'text-slate-700' : 'text-slate-800'}`}>{simplifiedNestLists(blocks, renderBlock)}</div>;
        });
      });
      var sourceDirection = getContentDirection(readingLanguage);
      return <div ref={clozeBodyRef} data-simplified-reading-body="true" className="w-full min-w-0 text-lg font-medium leading-relaxed font-sans" style={{ maxWidth: parts && isSideBySide ? '100%' : 'min(' + readingColumn + 'ch, 100%)', marginInline: 'auto' }}>
        <div className="mb-4 flex flex-wrap items-center gap-3 text-sm">
          {(props.isStudentPreview || typeof handleSpeak === 'function') && <button type="button" data-reader-listen aria-describedby={props.isStudentPreview ? props.previewLimitId : undefined} disabled={!!props.isStudentPreview || !simplifiedReadAloudText} onClick={() => { if (isPlaying && playingContentId === 'simplified-main' && typeof stopPlayback === 'function') stopPlayback(); else handleSpeak(interactionMode === 'cloze' ? maskClozeTerms(simplifiedReadAloudText) : simplifiedReadAloudText, 'simplified-main', 0, false, readingLanguage); }} className="min-h-11 inline-flex items-center gap-2 rounded-lg bg-indigo-700 px-3 py-2 font-bold text-white focus-visible:ring-2 focus-visible:ring-indigo-600 focus-visible:ring-offset-2 disabled:opacity-50">{isPlaying && playingContentId === 'simplified-main' ? <StopCircle size={16} aria-hidden="true" /> : <Volume2 size={16} aria-hidden="true" />}{isPlaying && playingContentId === 'simplified-main' ? readerText('common.stop_reading', 'Stop reading aloud') : readerText('simplified.listen_start', 'Listen from the beginning')}</button>}
          
          
          {props.onReadReflect && <button type="button" onClick={openReadingReflection} className="rounded-lg border border-indigo-200 bg-white px-3 py-2 text-indigo-800">{readerText('simplified.read_reflect', 'Read & reflect')}</button>}
          {renderReadingPlaceControls()}
        </div>
        {renderReadingPlacePanels()}

        <div ref={readingStartRef} data-reading-passage="true" data-reading-language={readingLanguage} data-paragraph-focus={!!isLineFocusMode} tabIndex={-1} role="region" aria-label={readerText('simplified.passage', 'Reading passage')} className={(isLineFocusMode ? 'bg-slate-950 rounded-xl p-4 ' : '') + 'rounded-xl focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600'}>
          {parts && isSideBySide ? <>
            {parts.source.length !== parts.target.length && <p role="status" className="mb-4 rounded-lg bg-amber-50 p-3 text-sm text-amber-900">{readerText('simplified.unmatched_paragraphs', 'The versions have different paragraph counts. They are shown in order; a row may not be an exact translation match.')}</p>}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">{Array.from({ length: Math.max(rendered[0].length, rendered[1].length) }, (_, i) => <React.Fragment key={i}>{languages.map((section, j) => <section key={section.key} data-reading-language={section.label} lang={simplifiedLanguageTag(section.label)} dir={j === 1 ? getContentDirection(readingTranslationLanguage) : sourceDirection} className="min-w-0 rounded-xl border border-slate-200 bg-white/60 p-4" style={{ backgroundColor: isLineFocusMode ? 'transparent' : undefined }}><div data-reading-ui="true" className="mb-3 text-sm font-bold" style={{ color: isLineFocusMode ? '#e2e8f0' : '#334155' }}>{section.label}</div><div style={{ maxWidth: readingColumn + 'ch', marginInline: 'auto' }}>{rendered[j][i] || <p data-reading-ui="true" className="text-sm italic text-slate-600">{readerText('simplified.no_paired_paragraph', 'No corresponding paragraph in this version.')}</p>}</div></section>)}</React.Fragment>)}</div>
          </> : languages.map((section, i) => <section key={section.key} data-reading-language={section.label} lang={simplifiedLanguageTag(section.label)} dir={i === 1 ? getContentDirection(readingTranslationLanguage) : sourceDirection}>{i === 1 && <h2 data-reading-ui="true" className="my-6 border-t border-indigo-200 pt-4 text-lg font-bold">{simplifiedEnglishTranslationLabel}</h2>}{rendered[i]}</section>)}
        </div>
        {renderSectionPromptsArea()}
        {/* Novak's ramp: an adaptation prepares students for the original, so its end leads there. */}
        {props.onReadOriginal && capturedSource && !protectedOriginal && instructionalRole !== 'primary' && interactionMode !== 'cloze' && <div data-read-original-next className="mt-6 flex justify-center"><button type="button" onClick={() => openOriginalReading(generatedContent, capturedSource.text, true)} className="min-h-11 rounded-lg border-2 border-indigo-700 bg-white px-4 py-2 font-bold text-indigo-800 hover:bg-indigo-50 focus-visible:ring-2 focus-visible:ring-indigo-600 focus-visible:ring-offset-2">{viewText('simplified.read_original_next', 'Now read the original')} <span aria-hidden="true">&rarr;</span></button></div>}
        <SourceReferencesPanel referencesText={simplifiedReferences} />
        <p role="status" data-generating-status className={isProcessing ? 'mt-4 text-sm text-indigo-700' : 'sr-only'}>{isProcessing ? simplifiedGeneratingMoreLabel : ''}</p>
      </div>;
    }

    return <>{renderStudentPreview()}<div ref={readerSurfaceRef} data-adapted-reader={isTeacherMode ? "teacher" : "student"} className="space-y-6">{comparisonKaraoke && listenAlongIsCurrent && !isEditingLeveledText && !props.isStudentPreview && KaraokeReaderOverlay && <KaraokeReaderOverlay isOpen={true} isTeacher={isTeacherMode} playbackOnly={true} onClose={closeListenAlong} text={comparisonKaraoke.text} sentenceList={comparisonKaraoke.sentences} sentenceLanguages={comparisonKaraoke.languages} language={simplifiedLanguageTag(comparisonKaraoke.language)} getAudioUrl={getComparisonKaraokeAudioUrl} />}<span className="sr-only" role="status" aria-live="polite" aria-atomic="true" data-read-aloud-status>{activeReadAloudStatus}</span>{isImmersiveReaderActive && generatedContent?.immersiveData && <div ref={immersiveDialogRef} role="dialog" aria-modal="true" aria-label={t('immersive.title') || 'Immersive Reader'} tabIndex={-1} onKeyDown={e => containSimplifiedModalFocus(e, immersiveDialogRef.current, handleCloseImmersiveReader)} className="fixed inset-0 z-[200] overflow-y-auto animate-in motion-reduce:animate-none fade-in zoom-in-95 duration-300 motion-reduce:animate-none motion-reduce:transition-none flex flex-col font-sans" style={{
        backgroundColor: immersiveSettings.bgColor || '#fdfbf7'
      }} onPointerMove={e => { if (immersiveSettings.lineFocus && e.clientY > immersiveToolbarBottom) setImmersiveRulerY(e.clientY); }} onFocusCapture={e => { if (immersiveSettings.lineFocus && !e.target.closest("[data-immersive-toolbar]") && e.target.closest("[role=dialog]") === immersiveDialogRef.current) { const rect = e.target.getBoundingClientRect(); setImmersiveRulerY(Math.max(immersiveToolbarBottom + immersiveSettings.textSize * 2.5, rect.top + Math.min(rect.height / 2, immersiveSettings.textSize * 2.5))); } }}><ImmersiveToolbar settings={immersiveSettings} setSettings={setImmersiveSettings} onClose={handleCloseImmersiveReader} onGeneratePOS={handleGeneratePOSData} isGeneratingPOS={isAnalyzingPos} posReady={!!generatedContent?.posEnriched} onGenerateSyllables={handleGeneratePOSData} isGeneratingSyllables={isAnalyzingPos} syllablesReady={!!generatedContent?.posEnriched} playbackRate={playbackRate} setPlaybackRate={setPlaybackRate} lineHeight={lineHeight} setLineHeight={setLineHeight} letterSpacing={letterSpacing} setLetterSpacing={setLetterSpacing} isFocusReaderActive={isFocusReaderActive} onToggleFocusReader={() => setIsFocusReaderActive(!isFocusReaderActive)} isChunkReaderActive={isChunkReaderActive} onToggleChunkReader={() => {
          setIsChunkReaderActive(!isChunkReaderActive);
          setChunkReaderIdx(0);
          setChunkReaderAutoPlay(false);
        }} chunkReaderIdx={chunkReaderIdx} setChunkReaderIdx={setChunkReaderIdx} chunkReaderAutoPlay={chunkReaderAutoPlay} setChunkReaderAutoPlay={setChunkReaderAutoPlay} chunkReaderSpeed={chunkReaderSpeed} setChunkReaderSpeed={setChunkReaderSpeed} chunkReaderMood={chunkReaderMood} setChunkReaderMood={setChunkReaderMood} interactionMode={interactionMode} setInteractionMode={setInteractionMode} isCrawlReaderActive={isCrawlReaderActive} onToggleCrawlReader={() => setIsCrawlReaderActive(!isCrawlReaderActive)} isKaraokeOverlayActive={isKaraokeOverlayActive} onToggleKaraokeOverlay={() => setIsKaraokeOverlayActive(!isKaraokeOverlayActive)} chunkReaderReadAlong={chunkReaderReadAlong} onToggleChunkReaderReadAlong={() => {
          const next = !chunkReaderReadAlong;
          setChunkReaderReadAlong(next);
          setChunkReaderSweepPct(0);
          if (!next) {
            try {
              if (chunkReaderSweepAudioRef.current) {
                chunkReaderSweepAudioRef.current.pause();
                chunkReaderSweepAudioRef.current = null;
              }
            } catch (e) {}
            if (chunkReaderSweepRafRef.current) {
              cancelAnimationFrame(chunkReaderSweepRafRef.current);
              chunkReaderSweepRafRef.current = null;
            }
            try {
              window.speechSynthesis && window.speechSynthesis.cancel();
            } catch (e) {}
          }
        }} totalSentences={immersiveSentences.length || 1} /><ErrorBoundary fallbackMessage="Focus reader encountered an error. Please close and reopen."><FocusReaderOverlay language={leveledTextLanguage} isOpen={isFocusReaderActive} onClose={handleCloseSpeedReader} text={simplifiedDisplayBody.replace(/<\/?[a-zA-Z][^<>]*>/g, '')} /><PerspectiveCrawlOverlay isOpen={isCrawlReaderActive} onClose={() => setIsCrawlReaderActive(false)} text={(immersiveFresh ? generatedContent.immersiveData.filter(w => w.pos !== 'newline').map(w => w.text).join(' ') : simplifiedDisplayBody).replace(/<\/?[a-zA-Z][^<>]*>/g, '')} /><KaraokeReaderOverlay isOpen={isKaraokeOverlayActive} isTeacher={isTeacherMode} onClose={() => setIsKaraokeOverlayActive(false)} getAudioUrl={getKaraokeAudioUrl} sentenceList={karaokeReaderSentences} captureOn={saveTtsAsPlayed} onCaptureChange={setSaveTtsAsPlayedEnabled} text={(immersiveFresh ? generatedContent.immersiveData.filter(w => w.pos !== 'newline').map(w => w.text).join(' ') : simplifiedDisplayBody).replace(/<\/?[a-zA-Z][^<>]*>/g, '')} /></ErrorBoundary>{immersiveSettings.lineFocus && <><div className="fixed top-0 left-0 right-0 bg-black/80 pointer-events-none z-[210] transition-[height] duration-75 ease-out motion-reduce:transition-none" style={{
            top: immersiveToolbarBottom + 'px',
            height: Math.max(0, immersiveRulerY - immersiveSettings.textSize * 2.5 - immersiveToolbarBottom) + 'px'
          }} /><div className="fixed bottom-0 left-0 right-0 bg-black/80 pointer-events-none z-[210] transition-[top] duration-75 ease-out motion-reduce:transition-none" style={{
            top: immersiveRulerY + immersiveSettings.textSize * 2.5 + 'px'
          }} /><div className="fixed left-0 right-0 border-b border-indigo-400/30 z-[210] pointer-events-none transition-[top] duration-75 ease-out motion-reduce:transition-none" style={{
            top: immersiveRulerY + 'px'
          }} /></>}<div data-immersive-passage tabIndex={0} role="region" aria-label={viewText('simplified.reader_reading_passage_when_line_focus_is', 'Reading passage. When Line Focus is on, use Up and Down arrows to move the reading window.')} onKeyDown={e => { if (e.target === e.currentTarget && immersiveSettings.lineFocus && (e.key === "ArrowUp" || e.key === "ArrowDown")) { e.preventDefault(); const step = immersiveSettings.textSize * lineHeight; setImmersiveRulerY(y => Math.max(immersiveToolbarBottom + immersiveSettings.textSize * 2.5, Math.min(window.innerHeight - immersiveSettings.textSize, y + (e.key === "ArrowDown" ? step : -step)))); } }} className="flex-grow overflow-y-auto p-5 md:p-16 custom-scrollbar relative z-10 focus-visible:outline focus-visible:outline-2"><div className={`max-w-4xl mx-auto transition-all duration-300`} style={{
            color: immersiveSettings.fontColor || '#1e293b',
            lineHeight: lineHeight,
            letterSpacing: `${immersiveSettings.wideText ? letterSpacing + 0.15 : letterSpacing}em`,
            wordSpacing: immersiveSettings.wideText ? '0.25em' : 'normal',
            fontFamily: immersiveSettings.fontFamily || undefined
          }}>{(() => {

              const reduceMotion = typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
              return immersiveWordGroups.map((group, index) => {
                const active = isChunkReaderActive && group.sentence === chunkReaderIdx;
                return <SimplifiedImmersiveSentence key={index} group={group}
                  chunkActive={active} playingActive={!!isPlaying && playbackState.currentIdx === group.sentence}
                  isChunkReaderActive={isChunkReaderActive} chunkReaderMood={chunkReaderMood}
                  chunkReaderReadAlong={chunkReaderReadAlong} chunkReaderSweepPct={active ? chunkReaderSweepPct : 0}
                  chunkTypewriterCharIdx={active ? chunkTypewriterCharIdx : 0}
                  immersiveSettings={immersiveWordSettings} reduceMotion={reduceMotion}
                  ImmersiveWord={ImmersiveWord} onWordClick={handleImmersiveWordClick} />;
              });
            })()}</div></div></div>}{interactionMode === 'cloze' && clozeAllSolved && <div className="fixed inset-0 pointer-events-none z-[100] flex items-center justify-center" data-a11y-overlay="nonmodal-status" role="status" aria-live="polite" aria-atomic="true"><ConfettiExplosion /><div className="mt-40 bg-green-100 text-green-800 px-6 py-3 rounded-full font-bold border-4 border-white shadow-xl animate-in motion-reduce:animate-none zoom-in duration-500 motion-reduce:animate-none motion-reduce:transition-none flex items-center gap-2"><Trophy size={24} className="text-yellow-500 fill-current" aria-hidden="true" /> {simplifiedActivityCompleteLabel}</div></div>}{isTeacherMode && !isZenMode && <div className="bg-green-50 p-4 rounded-lg border border-green-100 mb-6"><p className="text-sm text-green-800">{(() => {
              // Split once at the first colon, ASCII or full-width: the Chinese and
              // Japanese packs use "：", which left the goal bold with an empty body.
              const goal = String(t('simplified.udl_goal') || ''), at = goal.search(/[:：]/);
              return at < 0 ? goal : <><strong>{goal.slice(0, at + 1)}</strong> {goal.slice(at + 1).trim()}</>;
            })()}</p></div>}<div data-reading-card className={`bg-orange-50 border-l-4 border-orange-400 shadow-sm rounded-r-lg relative ${isZenMode ? 'p-3 sm:p-4' : 'p-3 sm:p-6 lg:p-8'}`}><button type="button" data-reader-skip className="sr-only focus:not-sr-only focus:mb-2 focus:inline-block focus:rounded focus:bg-indigo-700 focus:px-3 focus:py-2 focus:font-bold focus:text-white" onClick={() => { var target = readingStartRef.current || readerSurfaceRef.current?.querySelector('[data-reading-comparison]'); if (!target) return; if (!target.hasAttribute('tabindex')) target.setAttribute('tabindex', '-1'); target.focus(); }}>{readerText('simplified.skip_passage', 'Skip reading controls')}</button>{!isZenMode && <div className="flex justify-center items-center mb-2 flex-wrap gap-2">{(() => {
            const displayGrade = generatedContent?.config?.grade || gradeLevel;
            const displayLang = generatedContent?.config?.language || leveledTextLanguage;
            const displayInterests = generatedContent?.config?.interests || studentInterests || [];
            const displayStandards = generatedContent?.config?.standards || standardsInput;
            return <div className="flex min-w-0 flex-wrap items-center justify-center gap-2"><h4 className="break-words font-comic font-bold text-xl text-orange-800">{isTeacherMode ? `${t('simplified.target_level_label')}: ${displayGrade}` : generatedContent?.title || generatedContent?.topic || sourceTopic || readerText('simplified.your_reading', 'Your reading')}</h4>{displayLang !== 'English' && <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full font-bold border border-blue-200">{displayLang}</span>}{isTeacherMode && displayInterests.length > 0 && <span className="bg-red-100 text-red-800 text-xs px-2 py-1 rounded-full font-bold border border-red-200 flex items-center gap-1"><Heart size={10} /> {t('simplified.engagement_optimized')}</span>}{isTeacherMode && typeof displayStandards === 'string' && displayStandards && <span className="bg-green-100 text-green-700 text-xs px-2 py-1 rounded-full font-bold border border-green-200 flex items-center gap-1 cursor-help" title={`${t('simplified.label_standard')}: ${displayStandards}`}><CheckCircle size={10} />{displayStandards.length > 20 ? displayStandards.substring(0, 20) + '...' : displayStandards}</span>}</div>;
          })()}</div>}<div className={`flex items-center gap-2 ${isZenMode ? 'justify-center mb-4' : 'justify-center'}`}><div className="flex flex-col gap-1 items-center min-w-0 w-full"><div role="group" aria-label={readerText('simplified.reading_actions', 'Reading tools')} className="flex flex-wrap justify-center w-full min-w-0 bg-white rounded-2xl p-2 border border-indigo-200 shadow-sm gap-2">
              {[
                ['read', 'simplified.read_mode', 'Read', Volume2],
                ['define', 'simplified.word_meaning', 'Word meaning', Search],
                ['phonics', 'simplified.word_sounds', 'Word sounds', Ear],
                ...(studentAiFeaturesHidden ? [] : [['explain', 'simplified.explain_mode', 'Explain', HelpCircle]]),
              ].map(renderReadingModeButton)}
              <button type="button" aria-expanded={practiceOpen} aria-controls={readerId('simplified-practice-tools')} onClick={() => setPracticeOpen(!practiceOpen)} className="min-h-11 rounded-xl px-3 py-2 text-sm font-bold text-slate-700 hover:bg-slate-100 focus-visible:ring-2 focus-visible:ring-indigo-600">{readerText('simplified.practice_tools', 'Practice')}{practiceOpen ? <ChevronUp size={14} className="inline ml-1" /> : <ChevronDown size={14} className="inline ml-1" />}</button>
              {typeof props.onFocusViewChange === 'function' && <button ref={focusViewButtonRef} type="button" data-reader-focus-view aria-pressed={!!isZenMode} aria-describedby={readerId('simplified-focus-view-hint')} onClick={() => props.onFocusViewChange(!isZenMode)} className="min-h-11 rounded-xl px-3 py-2 text-sm font-bold text-slate-700 hover:bg-slate-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600">{isZenMode ? readerText('simplified.exit_focus_view', 'Exit focus view') : readerText('simplified.focus_view', 'Focus view')}</button>}
              <button ref={displayToggleRef} type="button" data-reader-display aria-expanded={displayOpen} aria-controls={readerId('simplified-display-panel')} onClick={() => setDisplayOpen(!displayOpen)} className="min-h-11 inline-flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-bold text-slate-700 hover:bg-slate-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600"><span aria-hidden="true" className="font-serif text-base leading-none">Aa</span>{viewText('simplified.display_menu', 'Display')}{displayOpen ? <ChevronUp size={14} aria-hidden="true" /> : <ChevronDown size={14} aria-hidden="true" />}</button>
            </div>
            <div id={readerId('simplified-practice-tools')} hidden={!practiceOpen} style={{ display: practiceOpen ? undefined : 'none' }} className="flex flex-wrap justify-center gap-2 py-2">
              <button type="button" aria-describedby={props.isStudentPreview ? props.previewLimitId : undefined} disabled={!!props.isStudentPreview} data-help-key="simplified_read_along" aria-pressed={!!isFluencyMode} onClick={() => chooseReadingMode('fluency')} className="min-h-11 rounded-lg border border-rose-200 bg-white px-3 py-2 text-sm font-semibold text-rose-900">{readerText('simplified.record_my_reading', 'Record my reading')}</button>
              {!protectedOriginal && !isCompareMode && hasClozeTerms && <button type="button" aria-describedby={props.isStudentPreview ? props.previewLimitId : undefined} disabled={!!props.isStudentPreview} data-help-key="simplified_cloze_mode" aria-pressed={interactionMode === 'cloze'} onClick={() => chooseReadingMode('cloze')} className="min-h-11 rounded-lg border border-indigo-200 bg-white px-3 py-2 text-sm font-semibold text-indigo-900">{readerText('simplified.practice_blanks', 'Fill in the blanks')}</button>}
              <button type="button" aria-describedby={props.isStudentPreview ? props.previewLimitId : undefined} disabled={!!props.isStudentPreview} data-help-key="simplified_scramble_game" onClick={handleSetIsSyntaxGameToTrue} className="min-h-11 rounded-lg border border-orange-200 bg-white px-3 py-2 text-sm font-semibold text-orange-900">{readerText('simplified.practice_sentences', 'Sentence scramble')}</button>
            </div>
            <div id={readerId('simplified-display-panel')} data-reader-display-panel role="group" aria-label={viewText('simplified.display_menu', 'Display')} hidden={!displayOpen} style={{ display: displayOpen ? undefined : 'none' }} onKeyDown={event => { if (event.key !== 'Escape') return; event.stopPropagation(); setDisplayOpen(false); displayToggleRef.current?.focus(); }} className="mt-2 flex w-full flex-wrap items-center justify-center gap-3 rounded-xl border border-indigo-100 bg-white/70 p-3 text-sm">{!isCompareMode && <button type="button" data-reader-listen-along aria-describedby={props.isStudentPreview ? props.previewLimitId : undefined} disabled={!!props.isStudentPreview || isEditingLeveledText || !KaraokeReaderOverlay || !karaokeReaderSentences.length} onClick={event => openListenAlong(simplifiedReadAloudText, readingLanguage, event)} className="min-h-11 inline-flex items-center gap-2 rounded-lg bg-indigo-700 px-4 py-2 font-bold text-white disabled:opacity-50 focus-visible:ring-2 focus-visible:ring-indigo-600 focus-visible:ring-offset-2"><Volume2 size={16} aria-hidden="true" />{readerText('simplified.listen_along', 'Listen along')}</button>}<button type="button" aria-label={readerText('simplified.immersive_reader', 'Immersive Reader')} data-help-key="simplified_immersive_reader" onClick={() => {
                if (generatedContent.immersiveData) {
                  setIsImmersiveReaderActive(true);
                } else {
                  handleAnalyzePOS();
                }
              }} aria-describedby={props.isStudentPreview ? props.previewLimitId : undefined} disabled={!!props.isStudentPreview || isAnalyzingPos || isEditingLeveledText} className="flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold bg-white text-fuchsia-600 border border-fuchsia-200 hover:bg-fuchsia-50 transition-all shadow-sm disabled:opacity-50 disabled:cursor-not-allowed" title={t('simplified.tip_immersive_btn')}>{isAnalyzingPos ? <RefreshCw size={14} className="animate-spin motion-reduce:animate-none" /> : <BookOpen size={14} />}{isAnalyzingPos ? t('simplified.loading_reader') : t('simplified.immersive_reader')}</button><label className="inline-flex min-w-0 max-w-full flex-wrap items-center gap-2 text-sm"><span>{readerText('header.reading_theme_aria', 'Reading theme')}</span><select data-adapted-theme-picker value={readingTheme || 'default'} title={readerText('simplified.theme_scope', 'Changes the reading area. Your app theme stays the same.')} onChange={e => setReadingTheme(e.target.value)} aria-label={simplifiedReadingThemeLabel} className={`min-h-11 min-w-0 max-w-full px-3 py-2 rounded-lg text-sm font-semibold border transition-colors cursor-pointer ${readingTheme === 'default' ? 'border-slate-200 bg-white text-slate-600' : 'border-indigo-300 bg-indigo-50 text-indigo-700'}`}><option value="default">{readerText('simplified.theme_follow_app', 'Use app theme')}</option><option value="warm">{t('header.reading_theme_warm')}</option><option value="sepia">{t('header.reading_theme_sepia')}</option><option value="dark">{t('header.reading_theme_dark')}</option><option value="dim">{readerText('header.reading_theme_dim', 'Dim')}</option><option value="highContrast">{t('header.reading_theme_contrast')}</option><option value="blue">{t('header.reading_theme_blue')}</option><option value="green">{t('header.reading_theme_green')}</option><option value="rose">{t('header.reading_theme_rose')}</option><option value="dyslexia">{t('header.reading_theme_easy_read')}</option></select></label><label className="flex items-center gap-2">{readerText('simplified.reading_width', 'Reading width')}<select aria-label={readerText('simplified.reading_width', 'Reading width')} value={readingColumn} onChange={e => updateReadingColumn(e.target.value)} className="rounded-lg border border-slate-300 bg-white px-2 py-2 text-slate-800"><option value={40}>{readerText('simplified.width_narrow', 'Narrow')}</option><option value={56}>{readerText('simplified.width_medium', 'Medium')}</option><option value={72}>{readerText('simplified.width_wide', 'Wide')}</option></select></label></div>
            {(() => {
              var status = readingModeStatus();
              return <p role="status" data-reading-mode-status={status.mode} className={'my-2 text-center text-sm ' + (status.label ? 'mx-auto w-fit max-w-full rounded-xl border-2 border-indigo-700 bg-indigo-50 px-3 py-2 text-indigo-950' : 'text-slate-700')}>{status.label && <strong className="font-bold">{status.label}{' · '}</strong>}{status.hint}</p>;
            })()}{isTeacherMode && (teacherReadingModes.length > 0 || !isZenMode) && <div role="group" aria-labelledby={readerId('simplified-teacher-editing-label')} data-teacher-editing-tools className="mt-1 flex w-full min-w-0 flex-wrap items-center justify-center gap-2 rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-2"><span id={readerId('simplified-teacher-editing-label')} className="px-1 text-xs font-bold uppercase tracking-wide text-slate-600">{viewText('simplified.teacher_editing', 'Teacher editing')}</span>{teacherReadingModes.map(renderReadingModeButton)}{isTeacherMode && !isZenMode && <button type="button" data-help-key="simplified_teacher_tools" aria-expanded={!!isTeacherToolbarExpanded} aria-controls={readerId('simplified-teacher-tools-panel')} onClick={handleToggleIsTeacherToolbarExpanded} className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold transition-all shadow-sm border ${isTeacherToolbarExpanded ? 'bg-indigo-100 text-indigo-700 border-indigo-200' : 'bg-white text-slate-600 border-slate-200 hover:text-indigo-600 hover:border-indigo-200'}`} title={t('simplified.teacher_tools_tooltip')}><Settings size={14} /><span>{readerText('simplified.teacher_actions', 'Teacher tools')}</span>{isTeacherToolbarExpanded ? <ChevronLeft size={14} /> : <ChevronRight size={14} />}</button>}{isTeacherMode && !protectedOriginal && !isZenMode && <button type="button" onClick={handleToggleIsEditingLeveledText} className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold transition-all shadow-sm ${isEditingLeveledText ? 'bg-orange-700 text-white hover:bg-orange-700' : 'bg-white text-orange-700 border border-orange-200 hover:bg-orange-50'}`} data-help-key="simplified_edit">{isEditingLeveledText ? <CheckCircle2 size={14} /> : <Pencil size={14} />}{isEditingLeveledText ? t('common.done_editing') : t('common.edit')}</button>}</div>}{renderTeacherReviewSummary()}{renderEditAudioSentenceTools()}{isTeacherMode && !isZenMode && <div id={readerId('simplified-teacher-tools-panel')} hidden={!isTeacherToolbarExpanded} style={{ display: isTeacherToolbarExpanded ? undefined : 'none' }} className="mt-2 w-full min-w-0 rounded-xl border border-indigo-200 bg-white px-1 py-2 sm:p-3"><div className="flex flex-wrap items-center justify-center gap-2"><button type="button" onClick={handleDuplicateResource} className="flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold bg-white text-indigo-600 hover:bg-indigo-50 border border-slate-400 transition-all shadow-md whitespace-nowrap" title={t('simplified.tip_duplicate_btn')} data-help-key="simplified_duplicate"><Copy size={14} /> {t('common.duplicate')}</button><button type="button" onClick={handleCheckLevel} disabled={isCheckingLevel} className="flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold bg-white text-indigo-600 hover:bg-indigo-50 border border-slate-400 transition-all shadow-md disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap" title={t('simplified.tip_check_level_btn')} data-help-key="simplified_check_level">{isCheckingLevel ? <RefreshCw size={14} className="animate-spin motion-reduce:animate-none" /> : <Search size={14} />}{isCheckingLevel ? t('simplified.checking') : t('simplified.check_level')}</button><button type="button" onClick={handleCheckAlignment} disabled={isCheckingAlignment || !standardsInput} className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold border transition-all shadow-md disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap ${!standardsInput ? 'opacity-50 cursor-not-allowed bg-slate-100 text-slate-600 border-slate-300' : 'bg-white text-indigo-600 hover:bg-indigo-50 border-slate-300'}`} title={!standardsInput ? t('simplified.tip_rigor_disabled') : t('simplified.tip_rigor_btn')} data-help-key="simplified_rigor_report">{isCheckingAlignment ? <RefreshCw size={14} className="animate-spin motion-reduce:animate-none" /> : <ShieldCheck size={14} />}{isCheckingAlignment ? t('simplified.checking') : t('simplified.rigor_report')}</button><button type="button" onClick={() => copyToClipboard(generatedContent?.data)} className="flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold bg-white text-indigo-600 hover:bg-indigo-50 border border-slate-400 transition-all shadow-md whitespace-nowrap" title={t('simplified.tip_copy_btn')} aria-label={t('simplified.tip_copy_btn')} data-help-key="simplified_copy_text"><Copy size={14} /> {t('common.copy_text')}</button><button type="button" onClick={() => { if (isSimplifiedAudioDownloading) { try { window.__alloCancelAudioDownload?.(); } catch (_) {} return; } handleDownloadAudio(generatedContent?.data, `leveled-text-${gradeLevel}`, 'dl-simplified-main'); }} title={isSimplifiedAudioDownloading ? simplifiedStopAudioDownloadLabel : (t('simplified.tip_download_audio') || t('common.download_audio'))} aria-label={isSimplifiedAudioDownloading ? simplifiedStopAudioDownloadLabel : t('common.download_audio')} className="flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold bg-white text-indigo-600 hover:bg-indigo-50 border border-slate-400 transition-all shadow-md whitespace-nowrap" data-help-key="simplified_download_audio">{isSimplifiedAudioDownloading ? <StopCircle size={14} /> : <Download size={14} />}{isSimplifiedAudioDownloading ? (t('common.stop') || simplifiedAudioStopLabel) : t('common.download_audio')}</button><button type="button" onClick={function () { if (ttsPrepState.busy) { var request = ttsPrepRequestRef.current; if (request && request.controller) request.controller.abort(); window.__alloPrepareReadAloudCancel = true; return; } handlePrepareReadAloudAudio(); }} className="flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold bg-white text-indigo-600 hover:bg-indigo-50 border border-slate-400 transition-all shadow-md whitespace-nowrap" title={ttsPrepState.busy ? readerText('simplified.save_audio_stop', 'Stop saving audio') : readerText('simplified.save_audio_tip', 'Save read-aloud audio for every sentence, so it plays without waiting')} data-help-key="simplified_save_tts">{ttsPrepState.busy ? <RefreshCw size={14} className="animate-spin motion-reduce:animate-none" /> : <Volume2 size={14} />}{ttsPrepState.busy ? `${simplifiedAudioStopLabel || viewText('common.stop', 'Stop')} · ${ttsPrepState.done}/${ttsPrepState.total || '...'}` : readerText('simplified.save_audio', 'Save audio')}</button></div><details data-teacher-reading-review className="my-4 min-w-0 rounded-xl border border-indigo-200 bg-white p-1 sm:p-3"><summary className="min-h-11 cursor-pointer py-2 text-sm font-bold text-indigo-900 focus-visible:ring-2 focus-visible:ring-indigo-600">{readerText('simplified.review_adjust', 'Review & adjust text')}</summary>{isTeacherMode && !protectedOriginal && !isCompareMode && !isZenMode && generatedContent && ['simplified', 'quiz', 'sentence-frames', 'glossary'].includes(generatedContent.type) && <div className="min-w-0 bg-white p-1 sm:p-4 rounded-lg border border-indigo-100 shadow-sm mb-6 sm:mx-1" data-help-key="simplified_complexity_slider"><label className="block text-xs font-bold text-indigo-600 uppercase tracking-wider mb-2 text-center">{generatedContent.type === 'quiz' ? t('simplified.complexity_controls.adjust_difficulty') : generatedContent.type === 'sentence-frames' ? t('simplified.complexity_controls.adjust_scaffolding') : generatedContent.type === 'glossary' ? t('simplified.complexity_controls.adjust_definition') : t('simplified.complexity_controls.adjust_relative')}</label><div className="flex items-center gap-3"><span className="text-xs font-bold text-slate-600 uppercase w-20 text-right">{generatedContent.type === 'quiz' ? t('simplified.complexity_controls.easier') : generatedContent.type === 'sentence-frames' ? t('simplified.complexity_controls.more_support') : t('simplified.complexity_controls.simpler')}</span><div className="relative flex-grow h-6 flex items-center"><div className="absolute left-1/2 top-0 bottom-0 w-0.5 bg-slate-200 transform -translate-x-1/2" /><input aria-label={readerText('simplified.adjust_complexity', 'Adjust text complexity')} type="range" min="1" max="9" step="1" value={complexityLevel} onChange={e => setComplexityLevel(parseInt(e.target.value))} aria-valuetext={complexityLevel < 5 ? readerText('simplified.simpler_setting', 'Simpler') + ' ' + complexityLevel : complexityLevel > 5 ? readerText('simplified.complex_setting', 'More complex') + ' ' + complexityLevel : readerText('simplified.unchanged_setting', 'Current version')} disabled={isProcessing} aria-busy={isProcessing} className="w-full h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-indigo-600 z-10 relative" /></div><span className="text-xs font-bold text-slate-600 uppercase w-20">{generatedContent.type === 'quiz' ? t('simplified.complexity_controls.harder') : generatedContent.type === 'sentence-frames' ? t('simplified.complexity_controls.less_support') : t('simplified.complexity_controls.complex')}</span></div><div className="px-2 sm:px-16"><ComplexityGauge level={complexityLevel} /></div><div className="mt-3 text-center"><p className="text-xs text-slate-600 mb-2">{readerText('simplified.adjust_hint', 'Choose a change, then apply it. Review the new version before sharing.')}</p>{generatedContent.type === 'simplified' ? renderAdaptationControls() : <button type="button" data-apply-complexity onClick={handleComplexityAdjustment} disabled={isProcessing || Number(complexityLevel) === 5} className="min-h-11 rounded-lg bg-indigo-700 px-4 py-2 text-sm font-bold text-white disabled:opacity-50">{isProcessing ? readerText('simplified.applying_change', 'Updating text…') : readerText('simplified.apply_complexity', 'Apply text change')}</button>}</div><div className="flex items-center justify-center mt-4 pt-3 border-t border-slate-100"><label className={`flex items-center gap-2 text-xs font-bold px-4 py-2 rounded-full cursor-pointer select-none transition-all border ${saveOriginalOnAdjust ? 'bg-indigo-100 text-indigo-700 border-indigo-200 ring-2 ring-indigo-500 ring-offset-1 shadow-sm' : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100 hover:text-slate-700'}`} title={t('common.choose_overwrite_version')} data-help-key="simplified_overwrite_toggle"><input type="checkbox" checked={saveOriginalOnAdjust} onChange={e => setSaveOriginalOnAdjust(e.target.checked)} className="h-4 w-4 accent-indigo-600" />{saveOriginalOnAdjust ? <CheckCircle2 size={16} /> : <Copy size={16} />}<span>{t('common.keep_original')}</span></label></div></div>}{/* Measured level (C1, 2026-08-16). The generator now computes Flesch-Kincaid
             locally on the finished English passage and stores it on the item. It used
             to be computed only for the Analysis resource, so the one place a target
             grade actually matters reported nothing unless the teacher spent two model
             calls on Check Level. Shown as a plain measurement next to the target, with
             no regeneration and no claim beyond what the formula says. Suppressed when
             levelCheck is open so the two panels do not stack. */}
            {/* Automatic re-level receipt. The dispatcher only rewrites when the
                local measurement AND the model review agreed the draft missed
                the target; the draft it replaced rides on the item so Undo is a
                plain restore, not a regeneration. */}
            {isTeacherMode && generatedContent.relevel && (() => {
              const info = generatedContent.relevel || {};
              const fmt = (v) => (Number.isFinite(Number(v)) ? Number(v).toFixed(1) : '?');
              const undoRelevel = () => {
                if (supportDraftSession?.blocked()) return requestSupportTransition(undoRelevel);
                const restored = { ...generatedContent, data: info.fromText };
                delete restored.relevel;
                delete restored.levelCheck;
                if (info.fromLocalStats) restored.localStats = info.fromLocalStats; else delete restored.localStats;
                if (info.fromInstructionalText) restored.instructionalText = info.fromInstructionalText;
                if (info.fromLevelCheck) restored.levelCheck = info.fromLevelCheck;
                setGeneratedContent(restored);
                if (typeof setHistory === 'function') setHistory(prev => prev.map(item => item.id === restored.id ? restored : item));
              };
              return <div role="status" data-relevel="auto" className="mb-3 flex flex-wrap items-center gap-x-3 gap-y-1 rounded-lg border border-indigo-200 bg-indigo-50 px-3 py-2 text-xs text-indigo-900">
                <span className="font-bold uppercase tracking-wider">{t('simplified.relevel_label') || 'Re-leveled automatically'}</span>
                <span>{info.direction === 'simpler'
                  ? viewText('simplified.relevel_detail_too_complex', 'Measured grade {before} → {after} (target {target}). The measurement and the review agreed the first draft was too complex.', { before: fmt(info.measuredBefore), after: fmt(info.measuredAfter), target: info.targetGrade || '' })
                  : viewText('simplified.relevel_detail_too_simple', 'Measured grade {before} → {after} (target {target}). The measurement and the review agreed the first draft was too simple.', { before: fmt(info.measuredBefore), after: fmt(info.measuredAfter), target: info.targetGrade || '' })}</span>
                <button type="button" onClick={undoRelevel} className="ml-auto rounded-full border border-indigo-300 bg-white px-2 py-0.5 text-[11px] font-bold text-indigo-700 hover:bg-indigo-100">{t('simplified.relevel_undo') || 'Undo re-level'}</button>
              </div>;
            })()}
            {/* Disagreement between the two signals is information, not an action:
                say which lens says what and the fix that fits, and leave the text alone. */}
            {isTeacherMode && generatedContent.levelCheck && generatedContent.levelCheck.triangulation && generatedContent.levelCheck.triangulation.note && !generatedContent.levelCheck.triangulation.agree && (
              <div role="status" data-relevel="disagreement" className="mb-3 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-900">
                <span className="font-bold uppercase tracking-wider mr-2">{t('simplified.level_signals_disagree') || 'Two reads, one text'}</span>
                <span>{generatedContent.levelCheck.triangulation.note}</span>
              </div>
            )}
            {isTeacherMode && !generatedContent.levelCheck && simplifiedComplexityDisplay.measuredGrade !== null && (() => {
              const measured = simplifiedComplexityDisplay.measuredGrade;
              const targetGrade = simplifiedComplexityDisplay.targetGrade;
              const status = simplifiedComplexityDisplay.status;
              const tone = status === 'above-target' ? 'bg-amber-50 border-amber-200 text-amber-900'
                : status === 'below-target' ? 'bg-blue-50 border-blue-200 text-blue-900'
                : status === 'within-target' ? 'bg-green-50 border-green-200 text-green-900'
                : 'bg-slate-50 border-slate-200 text-slate-700';
              const verdict = status === 'above-target' ? viewText('simplified.level_above_target', 'Above the target range for {grade}', { grade: targetGrade })
                : status === 'below-target' ? viewText('simplified.level_below_target', 'Below the target range for {grade}', { grade: targetGrade })
                : status === 'within-target' ? viewText('simplified.level_within_target', 'Within the target range for {grade}', { grade: targetGrade })
                : '';
              const rangeNote = simplifiedComplexityDisplay.target && simplifiedComplexityDisplay.target.fkLabel
                ? ' ' + viewText('simplified.level_shared_range', 'Shared target range: {range}.', { range: simplifiedComplexityDisplay.target.fkLabel })
                : '';
              const stats = generatedContent.localStats || {};
              return <div className={`mb-4 flex flex-wrap items-center gap-x-3 gap-y-1 rounded-lg border px-3 py-2 text-xs ${tone}`} data-complexity-status={status}>
                <span className="font-bold uppercase tracking-wider">{t('simplified.measured_level_label') || 'Measured reading level'}</span>
                <span className="font-mono font-bold text-sm" title={`${t('analysis.readability.formula') || 'Flesch-Kincaid'}: (0.39 × ASL) + (11.8 × ASW) - 15.59\n${t('analysis.readability.words') || 'Words'}: ${stats.words || '—'}\n${t('analysis.readability.sentences') || 'Sentences'}: ${stats.sentences || '—'}\n${t('analysis.readability.syllables') || 'Syllables'}: ${stats.syllables || '—'}`}>{measured}</span>
                {verdict && <span className="font-semibold">{verdict}</span>}
                <span className="text-[11px] opacity-80">{viewText('simplified.reader_flesch_kincaid_measured_on_this_passage', 'Flesch-Kincaid, measured on this passage.')}{rangeNote}{' '}{viewText('simplified.reader_use_check_level_for_a_fuller', 'Use Check Level for a fuller review.')}</span>
                <label className="ml-auto flex items-center gap-1 text-[11px] font-semibold cursor-pointer" title={viewText('simplified.reader_after_each_adapted_text_run_one', 'After each adapted text, run one model review alongside this measurement and re-level automatically only when both agree the target was missed.')}>
                  <input type="checkbox" checked={!!autoLevelCheckOn} onChange={(e) => setAutoLevelCheckOn(e.target.checked)} className="h-3 w-3" />
                  {t('simplified.auto_level_check') || 'Auto-check on generate'}
                </label>
              </div>;
            })()}{isTeacherMode && !generatedContent.levelCheck && simplifiedComplexityDisplay.status === 'stale' && <div role="status" className="mb-4 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-900"><strong>{viewText('simplified.reader_reading_level_measurement_needs_refresh', 'Reading-level measurement needs refresh.')}</strong>{' '}{viewText('simplified.reader_the_text_changed_after_it_was', 'The text changed after it was measured; use Check Level before relying on a complexity verdict.')}</div>}{isTeacherMode && generatedContent.levelCheck && <div className="mb-6 bg-indigo-50 border border-indigo-100 p-4 rounded-lg animate-in motion-reduce:animate-none slide-in-from-top-2"><div className="flex items-start gap-3"><div className="bg-indigo-100 p-2 rounded-full text-indigo-600 mt-1"><Search size={16} /></div><div className="flex-grow"><h4 className="font-bold text-indigo-900 text-sm flex items-center justify-between">{t('simplified.level_analysis_title')}<span className="text-xs bg-indigo-200 text-indigo-800 px-2 py-0.5 rounded-full">{generatedContent.levelCheck.confirmedLevel || generatedContent.levelCheck.estimatedLevel}</span></h4>{generatedContent.levelCheck.rubric ? <div className="mt-3 space-y-3 bg-white p-3 rounded-lg border border-indigo-100 shadow-sm"><p className="text-xs font-bold text-slate-600 uppercase tracking-wider mb-2">{t('simplified.complexity_rubric_title')}</p>{Object.entries(generatedContent.levelCheck.rubric).map(([key, data]) => {
                  const percent = (data.score + 5) / 10 * 100;
                  const isAligned = Math.abs(data.score) <= 1;
                  const colorClass = isAligned ? 'bg-green-500' : data.score < 0 ? 'bg-blue-400' : 'bg-red-400';
                  return <div key={key} className="space-y-1"><div className="flex justify-between text-xs"><span className="font-bold text-slate-700 capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}</span><span className={`font-mono font-bold ${isAligned ? 'text-green-600' : 'text-slate-600'}`}>{data.score > 0 ? '+' : ''}{data.score}</span></div><div className="relative h-2 bg-slate-100 rounded-full overflow-hidden"><div className="absolute left-1/2 top-0 bottom-0 w-0.5 bg-slate-300 z-10" /><div className={`absolute top-0 bottom-0 rounded-full transition-all duration-500 ${colorClass}`} style={{
                        left: data.score < 0 ? `${percent}%` : '50%',
                        width: `${Math.abs(data.score) * 10}%`
                      }} /></div><p className="text-[11px] text-slate-600 italic">{simplifiedAiText(data.reason)}</p></div>;
                })}<div className="flex justify-between text-[11px] text-slate-600 font-bold uppercase tracking-widest mt-1"><span>{t('simplified.gauge_simple')}</span><span>{t('simplified.gauge_aligned')}</span><span>{t('simplified.gauge_complex')}</span></div></div> : <div className="flex items-center flex-wrap gap-2 mt-1 mb-2"><span className="text-xs font-bold uppercase tracking-wider text-slate-600">{t('simplified.level_estimate_label')}:</span><span className="font-bold text-indigo-700 bg-white px-2 py-0.5 rounded text-sm border border-indigo-100 shadow-sm">{generatedContent.levelCheck.estimatedLevel}</span><span className={`text-xs font-bold px-2 py-0.5 rounded border ${generatedContent.levelCheck.alignment === 'Aligned' ? 'bg-green-100 text-green-700 border-green-200' : 'bg-yellow-100 text-yellow-700 border-yellow-200'}`}>{generatedContent.levelCheck.alignment}</span></div>}<p className="text-sm text-slate-700 leading-relaxed mt-2 p-2 bg-indigo-50/50 rounded italic border border-indigo-100/50">"{generatedContent.levelCheck.nuanceSummary || generatedContent.levelCheck.feedback}"</p></div><button type="button" aria-label={t('common.close_fluency_session')} onClick={() => {
              const updated = {
                ...generatedContent
              };
              delete updated.levelCheck;
              setGeneratedContent(updated);
            }} className="text-slate-600 hover:text-slate-600 p-1"><X size={14} /></button></div></div>}{isTeacherMode && generatedContent.alignmentCheck && <div className="mb-6 bg-emerald-50 border border-emerald-100 p-4 rounded-lg animate-in motion-reduce:animate-none slide-in-from-top-2"><div className="flex items-start gap-3"><div className="bg-emerald-100 p-2 rounded-full text-emerald-800 mt-1"><ShieldCheck size={16} /></div><div className="flex-grow"><h4 className="font-bold text-emerald-900 text-sm">{t('simplified.rigor_check_title')}</h4><div className="flex items-center flex-wrap gap-2 mt-1 mb-2"><span className="text-xs font-bold uppercase tracking-wider text-slate-600">{t('simplified.rigor_status_label')}:</span><span className={`text-xs font-bold px-2 py-0.5 rounded border ${generatedContent.alignmentCheck.status === 'Aligned' ? 'bg-green-100 text-green-700 border-green-200' : 'bg-orange-100 text-orange-700 border-orange-200'}`}>{generatedContent.alignmentCheck.status}</span></div><div className="space-y-2 mb-3"><p className="text-sm text-slate-700 leading-relaxed"><span className="font-bold text-emerald-800">{t('simplified.rigor_evidence_label')}:</span> "{generatedContent.alignmentCheck.evidence}"</p><p className="text-sm text-slate-700 leading-relaxed"><span className="font-bold text-emerald-800">{t('simplified.rigor_analysis_label')}:</span> {generatedContent.alignmentCheck.rigorReport}</p>{generatedContent.alignmentCheck.missingElements && generatedContent.alignmentCheck.missingElements !== "None" && <p className="text-sm text-red-700 leading-relaxed bg-red-50 p-2 rounded border border-red-100"><span className="font-bold flex items-center gap-1"><AlertCircle size={12} /> {t('simplified.missing_label')}:</span> {generatedContent.alignmentCheck.missingElements}</p>}</div>{generatedContent.alignmentCheck.improvement && <div className="bg-white p-3 rounded border border-emerald-200 mt-2 shadow-sm"><p className="text-xs font-bold text-emerald-700 uppercase tracking-wider mb-1 flex items-center gap-1"><Sparkles size={12} /> {t('simplified.suggestion_label')}</p><p className="text-sm text-slate-600 italic mb-2">"{generatedContent.alignmentCheck.improvement}"</p><button type="button" onClick={handleRegenerateWithRigor} disabled={isProcessing} aria-busy={isProcessing} className="text-xs font-bold bg-emerald-700 text-white px-3 py-1.5 rounded-full hover:bg-emerald-700 transition-colors flex items-center gap-1 shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"><RefreshCw size={12} className={isProcessing ? "animate-spin motion-reduce:animate-none" : ""} /> {t('simplified.apply_regenerate')}</button></div>}</div><button type="button" aria-label={t('common.close_fluency_results')} onClick={() => {
              const updated = {
                ...generatedContent
              };
              delete updated.alignmentCheck;
              setGeneratedContent(updated);
            }} className="text-slate-600 hover:text-slate-600 p-1"><X size={14} /></button></div></div>}</details></div>}{typeof props.onFocusViewChange === 'function' && <p id={readerId('simplified-focus-view-hint')} className={isZenMode ? 'mt-2 text-center text-xs text-slate-600' : 'sr-only'}>{isZenMode ? readerText('simplified.focus_view_active', 'Focus view is on. Exit any time to bring back the header and sidebar.') : readerText('simplified.focus_view_hint', 'Focus view hides the header and sidebar so you can concentrate on reading.')}</p>}</div></div><p role="status" aria-live="polite" aria-atomic="true" data-tts-prep-status className={ttsPrepNotice ? 'rounded-lg border border-indigo-200 bg-indigo-50 p-3 text-sm text-indigo-900' : 'sr-only'}>{ttsPrepNotice}</p>{renderAudioPreparationIssues()}{currentWordHelpCard && (() => {
          var entry = wordHelpCard.entry, cardLanguage = wordHelpCard.language || readingLanguage, explanation = entry.definition || entry.explanation || entry.text || '';
          var cardDirection = typeof getContentDirection === 'function' ? getContentDirection(cardLanguage) : undefined;
          var cardButton = 'min-h-11 rounded-lg border border-indigo-300 bg-white px-3 text-sm font-semibold text-indigo-900 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600';
          var cardLink = 'min-h-11 rounded px-1 text-sm text-indigo-800 underline underline-offset-2 hover:text-indigo-950 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600';
          var moreHelp = () => {
            var card = currentWordHelpCard, opener = wordHelpCardOpener.current, passage = adaptedSupportView.snapshot;
            if (!card || !passage || interactionMode !== 'define' || typeof handleWordClick !== 'function') return;
            if (passage.text.slice(card.entry.start, card.entry.end) !== card.entry.quote) return;
            // The opener may be a list button or any word within a phrase. Its
            // DOM position cannot stand in for the prepared support's anchor.
            var context = { passageText: passage.text, selectionStart: card.entry.start, selectionEnd: card.entry.end,
              lookupText: card.entry.quote, language: card.language,
              preparedText: card.entry.definition || card.entry.explanation || card.entry.text || '' };
            closeWordHelpCard(false);
            handleWordClick(card.entry.quote, { stopPropagation: () => {}, currentTarget: opener, clientX: card.x, clientY: card.y }, context);
          };
          var showAll = () => { var list = (readerSurfaceRef.current || document).querySelector('[data-adapted-word-help]'); closeWordHelpCard(!list); if (!list) return; if (!list.hasAttribute('tabindex')) list.setAttribute('tabindex', '-1'); scrollReadingTarget(list, { block: 'start' }); list.focus(); };
          return <div ref={wordHelpCardRef} id={wordHelpDialogId} role="dialog" aria-labelledby={wordHelpDialogId + '-title'} tabIndex={-1} data-word-help-card onKeyDown={e => { if (e.key !== 'Escape') return; e.preventDefault(); e.stopPropagation(); closeWordHelpCard(); }} className={`fixed ${_popupZ} rounded-xl border-2 border-indigo-200 bg-white p-4 text-slate-900 shadow-2xl focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600`} style={simplifiedPopupStyle(wordHelpCard, 20)}>
            <div className="mb-2 flex items-start justify-between gap-2"><div className="min-w-0"><h5 id={wordHelpDialogId + '-title'} lang={simplifiedLanguageTag(cardLanguage)} dir={cardDirection} className="break-words text-lg font-bold text-indigo-900">{entry.quote}</h5><p className="text-xs font-semibold text-indigo-700">{viewText('simplified.word_help_card_prepared', 'Word help from your teacher')}</p></div><button type="button" onClick={() => closeWordHelpCard()} aria-label={viewText('common.close', 'Close')} className="min-h-11 min-w-11 shrink-0 rounded-full bg-slate-100 p-2 text-slate-600 hover:bg-slate-200 hover:text-slate-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600"><X size={14} /></button></div>
            {entry.image && <img src={entry.image.src} alt={entry.image.alt || ''} data-word-help-card-picture className="mb-2 h-24 w-full rounded-lg bg-white object-contain" />}
            <p data-word-help-card-text lang={simplifiedLanguageTag(cardLanguage)} dir={cardDirection} className="break-words text-base leading-relaxed">{explanation}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              <button type="button" data-word-help-card-hear aria-describedby={props.isStudentPreview ? props.previewLimitId : undefined} disabled={!!props.isStudentPreview} onClick={() => playPreparedCardAudio('word', entry.quote)} className={cardButton}>{playingContentId === wordHelpCard.audioIds.word ? viewText('common.stop', 'Stop') : viewText('simplified.word_help_card_hear_word', 'Hear the word')}</button>
              <button type="button" data-word-help-card-listen aria-describedby={props.isStudentPreview ? props.previewLimitId : undefined} disabled={!!props.isStudentPreview} onClick={() => playPreparedCardAudio('help', entry.quote + '. ' + explanation)} className={cardButton}>{playingContentId === wordHelpCard.audioIds.help ? viewText('common.stop', 'Stop') : viewText('simplified.word_help_card_listen', 'Listen to the help')}</button>
            </div>
            <div className="mt-2 flex flex-wrap gap-x-3">
              {interactionMode === 'define' && typeof handleWordClick === 'function' && <button type="button" data-word-help-card-more onClick={moreHelp} className={cardLink}>{viewText('simplified.word_help_card_more', 'More about this word')}</button>}
              <button type="button" data-word-help-card-all onClick={showAll} className={cardLink}>{viewText('simplified.word_help_card_all', 'All word help')}</button>
            </div>
            {renderPictureCredits([entry])}
          </div>;
        })()}{definitionData && <div ref={definitionDialogRef} role="dialog" aria-modal="true" aria-labelledby={readerId("simplified-definition-title")} tabIndex={-1} onKeyDown={e => containSimplifiedModalFocus(e, definitionDialogRef.current, closeDefinition)} className={`fixed ${_popupZ} bg-white p-4 rounded-xl shadow-2xl border border-indigo-200 w-64 max-h-[50vh] overflow-y-auto custom-scrollbar animate-in motion-reduce:animate-none fade-in zoom-in-75 duration-300 ease-out motion-reduce:animate-none motion-reduce:transition-none`} style={simplifiedPopupStyle(definitionData, 16)}>{!definitionData.aiStatus && <SimplifiedPopupStatus message={definitionData.text || definitionData.preparedText ? viewText('common.ready', 'Ready') : definitionData.status === 'error' || definitionData.status === 'disabled' ? viewText('glossary.popups.failed', 'Definition unavailable.') : viewText('glossary.popups.finding', 'Finding a definition…')} />}<div className="flex flex-wrap justify-between items-start gap-2 mb-2"><h5 id={readerId("simplified-definition-title")} className="min-w-0 break-words font-bold text-indigo-900 text-lg capitalize">{definitionData.word}</h5><div className="flex flex-wrap items-center justify-end gap-1">{renderDefinitionSpeech(definitionData)}<button ref={definitionCloseRef} type="button" onClick={closeDefinition} className="min-h-11 min-w-11 text-slate-600 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-full p-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 focus-visible:ring-offset-2" aria-label={t('common.close')}><X size={14} /></button></div></div>{renderHelpAudioNotice('definition-')}{renderLookupStatus(definitionData, 'definition')}{definitionData.text && renderReadingLevelExplanation(definitionData, t, renderFormattedText)}{definitionData.dictionary && renderDictionaryPanel(definitionData.dictionary, t, renderHelpAudioButton, definitionData)}{definitionData.text && <div className="mt-3 pt-3 border-t border-slate-100">{renderLookupPicture(definitionData)}</div>}<div className="absolute -top-2 left-6 w-4 h-4 bg-white border-t border-l border-indigo-200 transform rotate-45" /></div>}{definitionData && <div aria-hidden="true" className={`fixed inset-0 ${_popupBackdropZ}`} onClick={closeDefinition} />}{phonicsData && <div ref={phonicsDialogRef} role="dialog" aria-modal="true" aria-labelledby={readerId("phonics-popup-title")} tabIndex={-1} onKeyDown={e => containSimplifiedModalFocus(e, phonicsDialogRef.current, closePhonics)} className={`fixed ${_popupZ} bg-white allo-popover-solid p-5 rounded-xl shadow-2xl border-2 border-emerald-200 w-72 animate-in motion-reduce:animate-none zoom-in-95 duration-200 motion-reduce:animate-none motion-reduce:transition-none`} style={simplifiedPopupStyle(phonicsData, 18)}>{!phonicsData.aiStatus && <SimplifiedPopupStatus message={phonicsData.isLoading ? viewText('glossary.popups.analyzing', 'Analyzing…') : phonicsData.data ? viewText('common.ready', 'Ready') : viewText('glossary.popups.failed', 'Unable to load word sounds.')} />}<div className="flex justify-between items-start mb-3"><h5 id={readerId("phonics-popup-title")} className="min-w-0 break-words font-black text-emerald-900 text-2xl capitalize tracking-tight">{phonicsData.word}</h5><button ref={phonicsCloseRef} type="button" onClick={closePhonics} className="min-h-11 min-w-11 shrink-0 text-slate-600 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-full p-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600" aria-label={t('common.close')}><X size={14} /></button></div>{renderHelpAudioNotice('phonics-')}{renderLookupStatus(phonicsData, 'phonics')}<div className="mb-3 flex flex-wrap gap-2">{renderHelpAudioButton('phonics-word', null, phonicsData.word, phonicsData.language)}{phonicsData.lookupRequest?.passageText && renderHelpAudioButton('phonics-context', null, phonicsData.lookupRequest.passageText, phonicsData.language, helpText('simplified.lookup_hear_passage', 'Hear in passage'))}</div>{renderPhonicsDictRow(phonicsData, t, renderHelpAudioButton)}{phonicsData.data ? <div className="space-y-4">{phonicsData.data.phoneticSpelling && <div className="flex flex-wrap items-center justify-between gap-2 bg-emerald-50 p-3 rounded-lg border border-emerald-100"><div><div className="text-xs font-bold text-emerald-700 uppercase tracking-wider mb-1">{t('glossary.phonetic_spelling')}</div><div className="text-lg font-serif italic text-slate-700">/{phonicsData.data.phoneticSpelling}/</div></div></div>}<div className="space-y-3"><div className="bg-slate-50 p-3 rounded border border-slate-100"><div className="text-xs font-bold text-slate-600 mb-2">{t('glossary.popups.syllables')}</div><div className="flex flex-wrap items-center gap-1">{Array.isArray(phonicsData.data.syllables) && phonicsData.data.syllables.some(syl => typeof syl === 'string' && syl.trim()) ? phonicsData.data.syllables.filter(syl => typeof syl === 'string' && syl.trim()).map((syl, i) => <React.Fragment key={i}>{i > 0 && <span className="text-emerald-700 font-bold px-0.5" aria-hidden="true">•</span>}<span className="bg-white px-1.5 rounded border border-slate-400 text-sm font-bold text-slate-700 shadow-sm">{syl}</span></React.Fragment>) : <span className="text-sm text-slate-700">{helpText('simplified.word_parts_unavailable', 'Word parts are unavailable. You can still listen to the word.')}</span>}</div></div>{phonicsData.data.ipa && <details className="bg-slate-50 p-3 rounded border border-slate-100"><summary className="min-h-11 cursor-pointer py-2 text-sm font-semibold text-slate-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600">{helpText('simplified.word_ipa_details', 'Pronunciation symbols (IPA)')}</summary><p className="mt-2 font-mono text-sm text-slate-700">{phonicsData.data.ipa}</p></details>}</div></div> : null}<div className="allo-popover-solid absolute -top-2 left-6 w-4 h-4 bg-white border-t-2 border-l-2 border-emerald-200 transform rotate-45" /></div>}{phonicsData && <div aria-hidden="true" className={`fixed inset-0 ${_popupBackdropZ}`} onClick={closePhonics} />}{selectionMenu && <div ref={selectionDialogRef} role="dialog" aria-modal="true" aria-label={readerText('simplified.selected_passage', 'Selected passage')} tabIndex={-1} onKeyDown={e => containSimplifiedModalFocus(e, selectionDialogRef.current, () => { setSelectionMenu(null); setIsCustomReviseOpen(false); })} className={`fixed ${_popupZ} flex flex-col gap-1 items-center animate-in motion-reduce:animate-none fade-in slide-in-from-bottom-2 duration-200`} style={simplifiedPopupStyle(selectionMenu, 20)}><button type="button" data-selection-close onClick={() => { setSelectionMenu(null); setIsCustomReviseOpen(false); }} className="min-h-11 self-end rounded-lg border border-slate-300 bg-white px-3 text-sm font-semibold text-slate-900 focus-visible:ring-2 focus-visible:ring-indigo-600">{viewText('common.close', 'Close')}</button><div className="bg-slate-900/90 text-white text-[11px] px-2 py-0.5 rounded-full mb-1 whitespace-nowrap shadow-sm max-w-[150px] truncate border border-slate-700">"{selectionMenu.text.length > 20 ? selectionMenu.text.substring(0, 20) + '...' : selectionMenu.text}"</div><div className="max-w-full bg-slate-800 text-white rounded-2xl shadow-xl p-1 flex flex-wrap items-center justify-center gap-1">{isCustomReviseOpen ? <div className="flex w-full min-w-0 flex-wrap items-center gap-1 px-1 animate-in motion-reduce:animate-none slide-in-from-right-2 duration-200"><input aria-label={t('common.enter_custom_revise_instruction')} autoFocus={true} type="text" value={customReviseInstruction} onChange={e => setCustomReviseInstruction(e.target.value)} onKeyDown={e => {
                if (e.key === 'Enter') handleReviseSelection('custom', customReviseInstruction);
                if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); setIsCustomReviseOpen(false); selectionDialogRef.current?.querySelector('[data-selection-close]')?.focus(); }
              }} placeholder={t('text_tools.menu_placeholder')} className="text-xs bg-slate-700 border-none rounded-full px-3 py-1.5 focus:ring-1 focus:ring-indigo-400 outline-none text-white w-full min-w-0 placeholder:text-slate-300" /><button type="button" aria-label={t('common.continue')} onClick={() => handleReviseSelection('custom', customReviseInstruction)} className="p-1.5 bg-indigo-600 hover:bg-indigo-600 rounded-full text-white transition-colors" disabled={!customReviseInstruction.trim()}><ArrowRight size={12} /></button><button type="button" aria-label={t('common.close_revision_panel')} onClick={() => { handleSetIsCustomReviseOpenToFalse(); selectionDialogRef.current?.querySelector('[data-selection-close]')?.focus(); }} className="p-1.5 text-slate-600 hover:text-white rounded-full transition-colors"><X size={12} /></button></div> : <>{interactionMode === 'explain' && <button ref={selectionActionRef} type="button" aria-label={readerText('simplified.explain_mode', 'Explain')} onClick={() => handleReviseSelection('explain')} className="px-3 py-1.5 hover:bg-white/20 rounded-full text-xs font-bold transition-colors flex items-center gap-1"><HelpCircle size={12} className="text-teal-700" /> {t('text_tools.explain')}</button>}{interactionMode === 'revise' && <><button type="button" onClick={() => handleReviseSelection('simplify')} className="px-3 py-1.5 hover:bg-white/20 rounded-full text-xs font-bold transition-colors flex items-center gap-1"><Sparkles size={12} className="text-yellow-700" /> {t('text_tools.simplify')}</button><div className="w-px h-3 bg-slate-600" /><button type="button" onClick={() => handleReviseSelection('custom-input')} className="px-3 py-1.5 hover:bg-white/20 rounded-full text-xs font-bold transition-colors flex items-center gap-1"><PenTool size={12} className="text-indigo-600" /> {t('text_tools.custom')}</button></>}{interactionMode === 'define' && <button type="button" onClick={handleDefineSelection} className="px-3 py-1.5 hover:bg-white/20 rounded-full text-xs font-bold transition-colors flex items-center gap-1"><Search size={12} className="text-yellow-700" /> {t('text_tools.define')}</button>}{interactionMode === 'add-glossary' && <button type="button" onClick={() => {
                handleQuickAddGlossary(selectionMenu.text, true);
                setSelectionMenu(null);
              }} className="px-3 py-1.5 hover:bg-white/20 rounded-full text-xs font-bold transition-colors flex items-center gap-1"><Plus size={12} className="text-green-700" /> {t('text_tools.add_term')}</button>}</>}</div><div className="w-2 h-2 bg-slate-800 rotate-45" /></div>}{selectionMenu && <div className={`fixed inset-0 ${_popupBackdropZ} bg-transparent`} onMouseDown={e => {
          setSelectionMenu(null);
          setIsCustomReviseOpen(false);
        }} />}{revisionData && <div ref={revisionDialogRef} role="dialog" aria-modal="true" aria-labelledby={readerId("simplified-revision-title")} tabIndex={-1} onKeyDown={e => containSimplifiedModalFocus(e, revisionDialogRef.current, closeRevision)} className={`fixed ${_popupZ} bg-white p-4 rounded-xl shadow-2xl border border-indigo-200 w-72 max-h-[50vh] overflow-y-auto custom-scrollbar animate-in motion-reduce:animate-none zoom-in-95 duration-200 motion-reduce:animate-none motion-reduce:transition-none`} style={simplifiedPopupStyle(revisionData, 18)}><SimplifiedPopupStatus message={revisionData.result ? viewText('common.ready', 'Ready') : viewText('simplified.revision.working', 'Working…')} /><div className="flex flex-wrap justify-between items-center gap-2 mb-3 pb-2 border-b border-slate-100"><h5 id={readerId("simplified-revision-title")} className="min-w-0 break-words font-bold text-slate-700 text-xs uppercase tracking-wider flex items-center gap-2">{revisionData.type === 'simplify' ? <Sparkles size={14} className="text-yellow-500" /> : revisionData.type === 'custom' ? <PenTool size={14} className="text-indigo-500" /> : <HelpCircle size={14} className="text-teal-500" />}{revisionData.type === 'simplify' ? t('simplified.revision.header_simplify') : revisionData.type === 'custom' ? t('simplified.revision.header_custom') : t('simplified.revision.header_explain')}</h5><div className="flex items-center gap-1">{revisionData.result ? renderSimplifiedPopupSpeaker(SIMPLIFIED_REVISION_AUDIO_ID, revisionData.result) : null}<button ref={revisionCloseRef} type="button" onClick={closeRevision} className="min-h-11 min-w-11 text-slate-600 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-full p-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 focus-visible:ring-offset-2" aria-label={t('common.close')}><X size={14} /></button></div></div>{revisionData.result ? <><div className="text-sm text-slate-800 leading-relaxed font-medium bg-slate-50 p-3 rounded border border-slate-100 mb-3">{renderFormattedText(revisionData.result, false)}</div>{isTeacherMode && !protectedOriginal && (revisionData.type === 'simplify' || revisionData.type === 'custom') && <button type="button" onClick={applyTextRevision} className="min-h-11 w-full bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold px-3 py-2 rounded-lg transition-colors flex items-center justify-center gap-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 focus-visible:ring-offset-2"><RefreshCw size={12} /> {t('simplified.revision.replace_btn')}</button>}</> : <div className="flex flex-col items-center justify-center py-4 gap-2 text-slate-600"><RefreshCw size={20} className="animate-spin motion-reduce:animate-none text-indigo-500" /><span className="text-xs">{t('simplified.revision.working')}</span></div>}</div>}{revisionData && <div aria-hidden="true" className={`fixed inset-0 ${_popupBackdropZ} bg-black/5`} onClick={closeRevision} />}{instructionalRoleControl}{versionControls}{isCompareMode ? renderSimplifiedComparison() : isEditingLeveledText ? <div className="w-full bg-white border border-orange-200 rounded-lg overflow-hidden shadow-sm"><div className="flex items-center gap-1 p-2 bg-orange-50 border-b border-orange-100"><button type="button" onClick={() => handleFormatText('bold')} className="p-1.5 rounded hover:bg-orange-200 text-orange-800 transition-colors" title={t('formatting.bold')}><Bold size={16} strokeWidth={3} /></button><button type="button" onClick={() => handleFormatText('italic')} className="p-1.5 rounded hover:bg-orange-200 text-orange-800 transition-colors" title={t('formatting.italic')}><Italic size={16} /></button><button type="button" onClick={() => handleFormatText('highlight')} className="p-1.5 rounded hover:bg-orange-200 text-orange-800 transition-colors" title={t('formatting.highlight')}><Highlighter size={16} /></button><div className="w-px h-4 bg-orange-200 mx-1" /><button type="button" onClick={() => handleFormatText('h1')} className="p-1.5 rounded hover:bg-orange-200 text-orange-800 transition-colors font-bold text-xs" title={t('formatting.h1')}>H1</button><button type="button" onClick={() => handleFormatText('h2')} className="p-1.5 rounded hover:bg-orange-200 text-orange-800 transition-colors font-bold text-xs" title={t('formatting.h2')}>H2</button><button type="button" onClick={() => handleFormatText('h3')} className="p-1.5 rounded hover:bg-orange-200 text-orange-800 transition-colors font-bold text-xs" title={t('formatting.h3') || 'Heading 3'}>H3</button><div className="w-px h-4 bg-orange-200 mx-1" /><button type="button" onClick={() => handleFormatText('list')} className="p-1.5 rounded hover:bg-orange-200 text-orange-800 transition-colors" title={t('formatting.list')}><List size={16} /></button><button type="button" onClick={() => handleFormatText('numlist')} className="p-1.5 rounded hover:bg-orange-200 text-orange-800 transition-colors" title={t('formatting.numlist') || 'Numbered List'}><ListOrdered size={16} /></button></div><textarea aria-label={t('simplified.revision.placeholder_edit_text') || 'Edit simplified text'} data-allo-textundo="simplified" ref={textEditorRef} value={generatedContent?.data} onChange={e => handleSimplifiedTextChange(e.target.value)} className="w-full min-h-[500px] bg-white p-4 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-1 text-lg text-slate-800 font-medium leading-relaxed resize-none font-sans" spellCheck="false" placeholder={t('simplified.revision.placeholder_edit_text')} /></div> : protectedOriginal ? renderOriginalReading() : <>{isImmersiveReaderActive && generatedContent?.immersiveData && hiddenPassageRef.current ? hiddenPassageRef.current : (hiddenPassageRef.current = renderSimplifiedReading())}<div style={{ maxWidth: readingColumn + 'ch', marginInline: 'auto' }}><AdaptedWordHelp supportView={adaptedSupportView} onOpen={(event, entry) => showPreparedWordHelp(event, entry, readingLanguage, null)} draftSession={supportDraftSession} key={readingSupportDraftKey(generatedContent, true)} item={generatedContent} teacher={isTeacherMode} originalSupports={checkedSupports} passageSelector="[data-reading-passage]" language={readingLanguage} quiet={interactionMode === 'cloze'} disabled={isProcessing} onUpdate={props.onUpdateReadingSupports} onGenerate={props.onGenerateReadingSupports} languageTag={simplifiedLanguageTag(readingLanguage)} direction={typeof getContentDirection === 'function' ? getContentDirection(readingLanguage) : undefined} onListen={props.isStudentPreview ? undefined : text => speakExactPassage(text, 'adapted-word-help', readingLanguage)} listening={isExactPassagePlaying('adapted-word-help')} renderCredits={renderPictureCredits} /></div></>}</div></div></>;
  }
  SimplifiedView.getReadingNavigationSections = getReadingNavigationSections;
  SimplifiedView.findRelatedOriginalPassage = findRelatedOriginalPassage;
  SimplifiedView.ReadingGlossEditor = ReadingGlossEditor;
  SimplifiedView.AdaptedWordHelp = AdaptedWordHelp;
  SimplifiedView.locateWordHelp = locateWordHelp;
  SimplifiedView.readingTextSegments = readingTextSegments;
  SimplifiedView.findGlossOccurrences = findReadingGlossOccurrences;
  SimplifiedView.languageTag = simplifiedLanguageTag;
  SimplifiedView.wordSegments = simplifiedWordSegments;
  SimplifiedView.paragraphBlocks = simplifiedParagraphBlocks;
  SimplifiedView.alignImmersiveWords = alignImmersiveWords;
  SimplifiedView.resolveReferences = resolveSimplifiedReferences;
  SimplifiedView.hasCitationMarkers = simplifiedBodyHasCitationMarkers;
  SimplifiedView.getInstructionalText = getSimplifiedInstructionalText;
  SimplifiedView.updateInstructionalRole = updateSimplifiedInstructionalRole;
  SimplifiedView.upsertFullHistoryArtifact = upsertFullHistoryArtifact;
  SimplifiedView.resolveCompareSource = resolveSimplifiedCompareSource;
  SimplifiedView.getComplexityDisplay = getSimplifiedComplexityDisplay;
  SimplifiedView.checkAlignment = checkSimplifiedAlignment;
  SimplifiedView.regenerateWithRigor = regenerateSimplifiedWithRigor;

  SimplifiedView.ReadingRoleControl = SimplifiedReadingRoleControl;
