// WCAG 2.4.3: Focus management — save/restore focus on modal open/close.
// Added in commit ba27e92 to module.js only; back-ported here to close source/module drift.
// Actually USED in teacher by the Escape-to-close handler (vs dead code in games/visual_panel/story_forge).
var _alloFocusTrigger = null;
function alloSaveFocus() { _alloFocusTrigger = document.activeElement; }
function alloRestoreFocus() { if (_alloFocusTrigger && typeof _alloFocusTrigger.focus === 'function') { try { _alloFocusTrigger.focus(); } catch(e) {} _alloFocusTrigger = null; } }

function alloTeacherStableId(prefix) {
  var value = '';
  try {
    if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') value = crypto.randomUUID();
  } catch (e) {}
  if (!value) value = Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 14);
  return prefix + '-' + value;
}

var ALLO_TEACHER_READING_THEME_OPTIONS = [
  { id: 'default', label: 'Default' },
  { id: 'warm', label: 'Warm' },
  { id: 'sepia', label: 'Sepia' },
  { id: 'dark', label: 'Dark' },
  { id: 'highContrast', label: 'Contrast' },
  { id: 'blue', label: 'Blue' },
  { id: 'green', label: 'Green' },
  { id: 'rose', label: 'Rose' },
  { id: 'dyslexia', label: 'Easy Read' },
  { id: 'dim', label: 'Dim' }
];
var ALLO_TEACHER_READING_THEME_IDS = ALLO_TEACHER_READING_THEME_OPTIONS.map(function(option) { return option.id; });

function alloNormalizeTeacherReadingTheme(value, fallback) {
  return ALLO_TEACHER_READING_THEME_IDS.indexOf(value) >= 0 ? value : fallback;
}

function alloNormalizeTeacherReadingFavorites(value) {
  var seen = {};
  return (Array.isArray(value) ? value : []).filter(function(themeId) {
    if (ALLO_TEACHER_READING_THEME_IDS.indexOf(themeId) < 0 || seen[themeId]) return false;
    seen[themeId] = true;
    return true;
  }).slice(0, ALLO_TEACHER_READING_THEME_IDS.length);
}

function alloNormalizeTeacherLearnerPreference(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
  var readingTheme = alloNormalizeTeacherReadingTheme(value.readingTheme, '');
  var favoriteReadingThemes = alloNormalizeTeacherReadingFavorites(value.favoriteReadingThemes);
  if (!readingTheme && favoriteReadingThemes.length === 0) return null;
  var normalized = {};
  if (readingTheme) normalized.readingTheme = readingTheme;
  if (favoriteReadingThemes.length) normalized.favoriteReadingThemes = favoriteReadingThemes;
  if (typeof value.updatedAt === 'string' && value.updatedAt.trim()) normalized.updatedAt = value.updatedAt.trim().slice(0, 48);
  return normalized;
}

function alloTeacherBoundedRosterNumber(value, max) {
  var parsed = Number(value);
  return Number.isFinite(parsed) ? Math.max(0, Math.min(max == null ? 100000 : max, Math.floor(parsed))) : 0;
}

function alloTeacherBoundedRosterText(value, max) {
  return typeof value === 'string' ? value.trim().slice(0, max || 160) : '';
}

function alloTeacherSafeLearnerId(value) {
  var id = alloTeacherBoundedRosterText(value, 160);
  return /^[A-Za-z0-9_-]{1,160}$/.test(id) && id !== '__proto__' && id !== 'prototype' && id !== 'constructor' ? id : '';
}

function alloTeacherRosterValueSet(value) {
  var out = Object.create(null);
  Object.keys(value && typeof value === 'object' && !Array.isArray(value) ? value : {}).forEach(function(key) { out[key] = 1; });
  return out;
}

function alloTeacherFilterRosterCodenames(value, studentSet) {
  var seen = Object.create(null);
  return (Array.isArray(value) ? value : []).filter(function(codename) {
    if (typeof codename !== 'string' || !studentSet[codename] || seen[codename]) return false;
    seen[codename] = 1;
    return true;
  }).slice(0, 250);
}

function alloTeacherSanitizeOrganizerEvidence(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
  var type = alloTeacherBoundedRosterText(value.type, 40).replace(/[^a-z0-9_-]/gi, '');
  var statuses = { waiting: 1, loading: 1, ready: 1, failed: 1, working: 1, attempted: 1, complete: 1 };
  var status = statuses[value.status] ? value.status : '';
  if (!type && !status) return null;
  return {
    type: type || 'organizer',
    status: status || 'waiting',
    score: alloTeacherBoundedRosterNumber(value.score, 100000),
    correct: alloTeacherBoundedRosterNumber(value.correct, 100000),
    total: alloTeacherBoundedRosterNumber(value.total, 100000),
    attempts: alloTeacherBoundedRosterNumber(value.attempts, 10000)
  };
}

function alloTeacherSanitizeRosterProgressHistory(value, students, groups) {
  var source = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  var groupSet = alloTeacherRosterValueSet(groups);
  var out = Object.create(null);
  Object.keys(students || {}).forEach(function(codename) {
    var entries = Array.isArray(source[codename]) ? source[codename] : [];
    var safeEntries = entries.map(function(entry) {
      if (!entry || typeof entry !== 'object' || Array.isArray(entry)) return null;
      var sessionId = alloTeacherBoundedRosterText(entry.sessionId, 160);
      if (!sessionId) return null;
      var groupId = alloTeacherBoundedRosterText(entry.groupId, 80);
      var safe = {
        sessionId: sessionId,
        timestamp: typeof entry.timestamp === 'string' ? entry.timestamp.slice(0, 48) : null,
        groupId: groupId && groupSet[groupId] ? groupId : null,
        responseCount: alloTeacherBoundedRosterNumber(entry.responseCount, 10000),
        resourcesOpened: alloTeacherBoundedRosterNumber(entry.resourcesOpened, 1000),
        liveActivityCount: alloTeacherBoundedRosterNumber(entry.liveActivityCount, 1000),
        liveSubmissionCount: alloTeacherBoundedRosterNumber(entry.liveSubmissionCount, 1000),
        liveRevisionCount: alloTeacherBoundedRosterNumber(entry.liveRevisionCount, 1000)
      };
      var organizer = alloTeacherSanitizeOrganizerEvidence(entry.organizer);
      if (organizer) safe.organizer = organizer;
      return safe;
    }).filter(Boolean).slice(-30);
    if (safeEntries.length) out[codename] = safeEntries;
  });
  return out;
}

function alloTeacherSanitizeRosterInsightBrief(value, studentSet, groupSet) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
  var safe = {
    schemaVersion: 2,
    activityCount: alloTeacherBoundedRosterNumber(value.activityCount, 60),
    submissions: alloTeacherBoundedRosterNumber(value.submissions, 100000),
    revisions: alloTeacherBoundedRosterNumber(value.revisions, 100000),
    feedbackSent: alloTeacherBoundedRosterNumber(value.feedbackSent, 100000),
    votesCast: alloTeacherBoundedRosterNumber(value.votesCast, 100000),
    participantsWithRecordedResponse: alloTeacherBoundedRosterNumber(value.participantsWithRecordedResponse, 250),
    followUpCodenames: alloTeacherFilterRosterCodenames(value.followUpCodenames, studentSet),
    evidenceScope: 'teacher-device-derived-participation'
  };
  safe.evidenceCohorts = (Array.isArray(value.evidenceCohorts) ? value.evidenceCohorts : []).map(function(cohort) {
    if (!cohort || typeof cohort !== 'object' || Array.isArray(cohort)) return null;
    var codenames = alloTeacherFilterRosterCodenames(cohort.codenames, studentSet);
    if (!codenames.length) return null;
    var code = alloTeacherBoundedRosterText(cohort.code, 80).replace(/[^a-z0-9_-]/gi, '');
    if (!code) return null;
    return {
      code: code,
      intent: cohort.intent === 'celebrate' ? 'celebrate' : 'support',
      label: alloTeacherBoundedRosterText(cohort.label, 140) || 'Evidence cohort',
      count: codenames.length,
      codenames: codenames,
      recommendedAction: alloTeacherBoundedRosterText(cohort.recommendedAction, 240)
    };
  }).filter(Boolean).slice(0, 8);
  safe.byKind = (Array.isArray(value.byKind) ? value.byKind : []).map(function(item) {
    if (!item || typeof item !== 'object' || Array.isArray(item)) return null;
    var kind = alloTeacherBoundedRosterText(item.kind, 40).replace(/[^a-z0-9_-]/gi, '');
    if (!kind) return null;
    return {
      kind: kind,
      activityCount: alloTeacherBoundedRosterNumber(item.activityCount, 60),
      invited: alloTeacherBoundedRosterNumber(item.invited, 100000),
      submitted: alloTeacherBoundedRosterNumber(item.submitted, 100000),
      revised: alloTeacherBoundedRosterNumber(item.revised, 100000),
      completionPercent: alloTeacherBoundedRosterNumber(item.completionPercent, 100)
    };
  }).filter(Boolean).slice(0, 60);
  safe.groups = (Array.isArray(value.groups) ? value.groups : []).map(function(item) {
    if (!item || typeof item !== 'object' || Array.isArray(item)) return null;
    var groupId = alloTeacherBoundedRosterText(item.groupId, 80);
    if (!groupId || !groupSet[groupId]) return null;
    return {
      groupId: groupId,
      participantCount: alloTeacherBoundedRosterNumber(item.participantCount, 250),
      activityOpportunities: alloTeacherBoundedRosterNumber(item.activityOpportunities, 100000),
      submissions: alloTeacherBoundedRosterNumber(item.submissions, 100000),
      revisions: alloTeacherBoundedRosterNumber(item.revisions, 100000),
      followUpCount: alloTeacherBoundedRosterNumber(item.followUpCount, 250)
    };
  }).filter(Boolean).slice(0, 100);
  safe.nextMoves = (Array.isArray(value.nextMoves) ? value.nextMoves : []).map(function(move) {
    if (!move || typeof move !== 'object' || Array.isArray(move)) return null;
    var code = alloTeacherBoundedRosterText(move.code, 80).replace(/[^a-z0-9_-]/gi, '');
    var label = alloTeacherBoundedRosterText(move.label, 240);
    return code && label ? { code: code, count: alloTeacherBoundedRosterNumber(move.count, 100000), label: label } : null;
  }).filter(Boolean).slice(0, 4);
  return safe;
}

function alloTeacherSanitizeRosterSessionHistory(value, students, groups) {
  var studentSet = alloTeacherRosterValueSet(students);
  var groupSet = alloTeacherRosterValueSet(groups);
  return (Array.isArray(value) ? value : []).map(function(session) {
    if (!session || typeof session !== 'object' || Array.isArray(session)) return null;
    var id = alloTeacherBoundedRosterText(session.id, 160);
    if (!id) return null;
    var participants = Object.create(null);
    var rawParticipants = session.participants && typeof session.participants === 'object' && !Array.isArray(session.participants) ? session.participants : {};
    Object.keys(rawParticipants).forEach(function(codename) {
      if (Object.keys(participants).length >= 500) return;
      if (!studentSet[codename]) return;
      var record = rawParticipants[codename];
      if (!record || typeof record !== 'object' || Array.isArray(record)) return;
      var groupId = alloTeacherBoundedRosterText(record.groupId, 80);
      var safeRecord = {
        groupId: groupId && groupSet[groupId] ? groupId : null,
        joinedAt: typeof record.joinedAt === 'string' ? record.joinedAt.slice(0, 48) : null,
        responseCount: alloTeacherBoundedRosterNumber(record.responseCount, 10000),
        resourcesOpened: alloTeacherBoundedRosterNumber(record.resourcesOpened, 1000),
        liveActivityCount: alloTeacherBoundedRosterNumber(record.liveActivityCount, 1000),
        liveSubmissionCount: alloTeacherBoundedRosterNumber(record.liveSubmissionCount, 1000),
        liveRevisionCount: alloTeacherBoundedRosterNumber(record.liveRevisionCount, 1000)
      };
      var organizer = alloTeacherSanitizeOrganizerEvidence(record.organizer);
      if (organizer) safeRecord.organizer = organizer;
      participants[codename] = safeRecord;
    });
    var safe = {
      schemaVersion: 2,
      id: id,
      startedAt: typeof session.startedAt === 'string' ? session.startedAt.slice(0, 48) : null,
      endedAt: typeof session.endedAt === 'string' ? session.endedAt.slice(0, 48) : null,
      durationMinutes: session.durationMinutes === null ? null : alloTeacherBoundedRosterNumber(session.durationMinutes, 100000),
      mode: session.mode === 'mailbox' ? 'mailbox' : 'firebase',
      resourceTitles: (Array.isArray(session.resourceTitles) ? session.resourceTitles : []).map(function(title) { return alloTeacherBoundedRosterText(title, 160); }).filter(Boolean).slice(0, 20),
      participants: participants,
      absentCodenames: alloTeacherFilterRosterCodenames(session.absentCodenames, studentSet)
    };
    var unmatchedCount = Math.max(
      Array.isArray(session.unmatchedCodenames) ? session.unmatchedCodenames.map(String).filter(Boolean).slice(0, 250).length : 0,
      alloTeacherBoundedRosterNumber(session.unmatchedCount, 250)
    );
    if (unmatchedCount) safe.unmatchedCount = unmatchedCount;
    safe.classGoals = (Array.isArray(session.classGoals) ? session.classGoals : []).map(function(goal) {
      if (!goal || typeof goal !== 'object' || Array.isArray(goal)) return null;
      var label = alloTeacherBoundedRosterText(goal.label, 80);
      return label ? {
        label: label,
        mode: goal.mode === 'independent' ? 'independent' : 'interdependent',
        tokens: Number(goal.tokens) === 2 ? 2 : 1,
        delivered: alloTeacherBoundedRosterNumber(goal.delivered, 250),
        at: alloTeacherBoundedRosterNumber(goal.at, Number.MAX_SAFE_INTEGER)
      } : null;
    }).filter(Boolean).slice(0, 40);
    safe.liveActivities = (Array.isArray(session.liveActivities) ? session.liveActivities : []).map(function(activity) {
      if (!activity || typeof activity !== 'object' || Array.isArray(activity)) return null;
      var kind = alloTeacherBoundedRosterText(activity.kind, 40).replace(/[^a-z0-9_-]/gi, '');
      if (!kind) return null;
      var out = { kind: kind, phase: alloTeacherBoundedRosterText(activity.phase, 20) || 'closed' };
      ['invited', 'submitted', 'revised', 'approved', 'hidden', 'revealed', 'feedbackSent', 'guesses', 'showcased', 'votesCast'].forEach(function(field) {
        out[field] = alloTeacherBoundedRosterNumber(activity[field], 100000);
      });
      out.startedAt = alloTeacherBoundedRosterNumber(activity.startedAt, Number.MAX_SAFE_INTEGER);
      out.endedAt = alloTeacherBoundedRosterNumber(activity.endedAt, Number.MAX_SAFE_INTEGER);
      return out;
    }).filter(Boolean).slice(0, 60);
    if (session.organizerActivity && typeof session.organizerActivity === 'object' && !Array.isArray(session.organizerActivity)) {
      var organizerType = alloTeacherBoundedRosterText(session.organizerActivity.type, 40).replace(/[^a-z0-9_-]/gi, '');
      if (organizerType) {
        var statusCounts = {};
        ['waiting', 'loading', 'ready', 'failed', 'working', 'attempted', 'complete'].forEach(function(status) {
          statusCounts[status] = alloTeacherBoundedRosterNumber(session.organizerActivity.statusCounts && session.organizerActivity.statusCounts[status], 250);
        });
        safe.organizerActivity = {
          type: organizerType,
          wasLiveAtEnd: session.organizerActivity.wasLiveAtEnd === true,
          participantCount: alloTeacherBoundedRosterNumber(session.organizerActivity.participantCount, 250),
          statusCounts: statusCounts,
          followUpCodenames: alloTeacherFilterRosterCodenames(session.organizerActivity.followUpCodenames, studentSet)
        };
      }
    }
    var insightBrief = alloTeacherSanitizeRosterInsightBrief(session.insightBrief, studentSet, groupSet);
    if (insightBrief) safe.insightBrief = insightBrief;
    var teacherNote = typeof session.teacherNote === 'string' ? session.teacherNote.replace(/\u000d\u000a?/g, '\n').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '').trim().slice(0, 1000) : '';
    if (teacherNote) safe.teacherNote = teacherNote;
    if (session.followUpPlan && typeof session.followUpPlan === 'object' && !Array.isArray(session.followUpPlan)) {
      var resourceId = alloTeacherBoundedRosterText(session.followUpPlan.resourceId, 160);
      if (resourceId && resourceId !== '__proto__' && resourceId !== 'prototype' && resourceId !== 'constructor') {
        var cohortCode = alloTeacherBoundedRosterText(session.followUpPlan.cohortCode, 80);
        var audience = session.followUpPlan.audience === 'cohort' && cohortCode ? 'cohort' : 'class';
        safe.followUpPlan = {
          schemaVersion: 1,
          resourceId: resourceId,
          resourceTitle: alloTeacherBoundedRosterText(session.followUpPlan.resourceTitle, 140) || 'Follow-up resource',
          resourceType: alloTeacherBoundedRosterText(session.followUpPlan.resourceType, 80),
          audience: audience,
          cohortCode: audience === 'cohort' ? cohortCode : '',
          cohortLabel: audience === 'cohort' ? (alloTeacherBoundedRosterText(session.followUpPlan.cohortLabel, 120) || 'Evidence cohort') : 'Whole class',
          cohortCount: audience === 'cohort' ? alloTeacherBoundedRosterNumber(session.followUpPlan.cohortCount, 250) : 0,
          status: session.followUpPlan.status === 'completed' ? 'completed' : 'planned',
          plannedAt: typeof session.followUpPlan.plannedAt === 'string' ? session.followUpPlan.plannedAt.slice(0, 48) : ''
        };
      }
    }
    return safe;
  }).filter(Boolean).slice(-30);
}

function alloTeacherSanitizePortableSeating(value, students) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
  var studentSet = alloTeacherRosterValueSet(students);
  var reserved = { '__proto__': true, prototype: true, constructor: true };
  var clamp = function(raw, min, max, fallback) {
    return typeof raw === 'number' && Number.isFinite(raw) ? Math.max(min, Math.min(max, raw)) : fallback;
  };
  var safeId = function(raw) {
    var id = typeof raw === 'string' ? raw.trim().slice(0, 80) : '';
    return /^[A-Za-z0-9_-]{1,80}$/.test(id) && !reserved[id.toLowerCase()] ? id : '';
  };
  var layoutsSource = value.layouts && typeof value.layouts === 'object' && !Array.isArray(value.layouts)
    ? value.layouts : {};
  var layouts = {};
  var layoutIdsTaken = Object.create(null);
  Object.keys(layoutsSource).forEach(function(layoutKey) {
    if (Object.keys(layouts).length >= 30) return;
    var rawLayout = layoutsSource[layoutKey];
    if (!rawLayout || typeof rawLayout !== 'object' || Array.isArray(rawLayout)) return;
    var keyId = safeId(layoutKey);
    var layoutId = safeId(rawLayout.id);
    if (!keyId || layoutId !== keyId || layoutIdsTaken[layoutId]) return;
    layoutIdsTaken[layoutId] = 1;
    var objectIdsTaken = Object.create(null);
    var seats = [];
    (Array.isArray(rawLayout.seats) ? rawLayout.seats : []).forEach(function(rawSeat) {
      if (seats.length >= 60) return;
      if (!rawSeat || typeof rawSeat !== 'object' || Array.isArray(rawSeat)) return;
      var id = safeId(rawSeat.id);
      if (!id || objectIdsTaken[id]) return;
      var width = clamp(rawSeat.w, 4, 30, 10);
      var height = clamp(rawSeat.h, 3, 30, 7);
      objectIdsTaken[id] = 1;
      seats.push({
        id: id,
        x: clamp(rawSeat.x, 0, 100 - width, 0),
        y: clamp(rawSeat.y, 0, 62 - height, 0),
        w: width,
        h: height
      });
    });
    var furnitureSpecs = {
      teacher_desk: { w: 16, h: 8 },
      table: { w: 16, h: 10 },
      rug: { w: 20, h: 14 },
      shelf: { w: 14, h: 4 },
      door: { w: 8, h: 3 },
      window: { w: 14, h: 3 }
    };
    var furniture = [];
    (Array.isArray(rawLayout.furniture) ? rawLayout.furniture : []).forEach(function(rawItem) {
      if (furniture.length >= 30) return;
      if (!rawItem || typeof rawItem !== 'object' || Array.isArray(rawItem)) return;
      var id = safeId(rawItem.id);
      if (!id || objectIdsTaken[id]) return;
      var kind = Object.prototype.hasOwnProperty.call(furnitureSpecs, rawItem.kind) ? rawItem.kind : 'table';
      var spec = furnitureSpecs[kind];
      var width = clamp(rawItem.w, 2, 60, spec.w);
      var height = clamp(rawItem.h, 2, 40, spec.h);
      objectIdsTaken[id] = 1;
      furniture.push({
        id: id,
        kind: kind,
        x: clamp(rawItem.x, 0, 100 - width, 0),
        y: clamp(rawItem.y, 0, 62 - height, 0),
        w: width,
        h: height,
        label: typeof rawItem.label === 'string' ? rawItem.label.slice(0, 40) : ''
      });
    });
    var seatSet = Object.create(null);
    seats.forEach(function(seat) { seatSet[seat.id] = 1; });
    var assignments = {};
    var assignedStudents = Object.create(null);
    var rawAssignments = rawLayout.assignments && typeof rawLayout.assignments === 'object' && !Array.isArray(rawLayout.assignments)
      ? rawLayout.assignments : {};
    Object.keys(rawAssignments).forEach(function(seatId) {
      var codename = rawAssignments[seatId];
      if (seatSet[seatId] && typeof codename === 'string' && studentSet[codename] && !assignedStudents[codename]) {
        assignments[seatId] = codename;
        assignedStudents[codename] = 1;
      }
    });
    layouts[layoutId] = {
      id: layoutId,
      name: typeof rawLayout.name === 'string' && rawLayout.name.trim() ? rawLayout.name.trim().slice(0, 60) : 'Layout',
      seats: seats,
      furniture: furniture,
      assignments: assignments
    };
  });
  var activeLayoutId = safeId(value.activeLayoutId);
  if (!activeLayoutId || !Object.prototype.hasOwnProperty.call(layouts, activeLayoutId)) {
    activeLayoutId = Object.keys(layouts)[0] || null;
  }
  var activeSeatSet = Object.create(null);
  if (activeLayoutId) layouts[activeLayoutId].seats.forEach(function(seat) { activeSeatSet[seat.id] = 1; });
  var constraintSizes = {
    keep_apart: 2,
    keep_together: 2,
    front_row: 1,
    near_teacher: 1,
    near_door: 1,
    avoid_window: 1,
    fixed_seat: 1
  };
  var constraintIdsTaken = Object.create(null);
  var constraints = [];
  (Array.isArray(value.constraints) ? value.constraints : []).forEach(function(rawConstraint) {
    if (constraints.length >= 80) return;
    if (!rawConstraint || typeof rawConstraint !== 'object' || Array.isArray(rawConstraint)) return;
    var id = safeId(rawConstraint.id);
    var expectedSize = constraintSizes[rawConstraint.type];
    if (!id || !expectedSize || constraintIdsTaken[id]) return;
    var seenStudents = Object.create(null);
    var codenames = (Array.isArray(rawConstraint.students) ? rawConstraint.students : []).filter(function(codename) {
      if (typeof codename !== 'string' || !studentSet[codename] || seenStudents[codename]) return false;
      seenStudents[codename] = 1;
      return true;
    }).slice(0, expectedSize);
    if (codenames.length !== expectedSize) return;
    var safeConstraint = { id: id, type: rawConstraint.type, students: codenames };
    if (rawConstraint.type === 'fixed_seat') {
      var seatId = safeId(rawConstraint.seatId);
      if (!seatId || !activeSeatSet[seatId]) return;
      safeConstraint.seatId = seatId;
    }
    constraintIdsTaken[id] = 1;
    constraints.push(safeConstraint);
  });
  var history = (Array.isArray(value.history) ? value.history : []).filter(function(entry) {
    return entry && typeof entry === 'object' && !Array.isArray(entry)
      && typeof entry.at === 'string' && !Number.isNaN(Date.parse(entry.at.slice(0, 48)));
  }).map(function(entry) {
    return {
      at: entry.at.slice(0, 48),
      layoutId: safeId(entry.layoutId),
      layoutName: typeof entry.layoutName === 'string' ? entry.layoutName.slice(0, 60) : '',
      kind: entry.kind === 'created' ? 'created' : 'solve'
    };
  }).slice(-50);
  return {
    version: 1,
    activeLayoutId: activeLayoutId,
    layouts: layouts,
    constraints: constraints,
    solveSeed: clamp(value.solveSeed, 1, 1000000000, 1),
    history: history
  };
}
function alloTeacherSanitizeSubmissionKey(value, classId) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
  var jwk = value.publicJwk;
  if (!jwk || typeof jwk !== 'object' || Array.isArray(jwk) || jwk.kty !== 'RSA') return null;
  var modulus = typeof jwk.n === 'string' && /^[A-Za-z0-9_-]{16,2048}$/.test(jwk.n) ? jwk.n : '';
  var exponent = typeof jwk.e === 'string' && /^[A-Za-z0-9_-]{1,16}$/.test(jwk.e) ? jwk.e : '';
  if (!modulus || !exponent) return null;
  var keyClassId = alloTeacherBoundedRosterText(value.classId, 160);
  if (classId && keyClassId && classId !== keyClassId) return null;
  var publicJwk = { kty: 'RSA', n: modulus, e: exponent };
  if (typeof jwk.alg === 'string' && /^[A-Za-z0-9_-]{1,40}$/.test(jwk.alg)) publicJwk.alg = jwk.alg;
  if (typeof jwk.ext === 'boolean') publicJwk.ext = jwk.ext;
  if (jwk.use === 'enc') publicJwk.use = 'enc';
  var keyOps = (Array.isArray(jwk.key_ops) ? jwk.key_ops : []).filter(function(op) { return op === 'encrypt'; }).slice(0, 1);
  if (keyOps.length) publicJwk.key_ops = keyOps;
  var safe = { publicJwk: publicJwk, classId: classId || keyClassId };
  var keyId = alloTeacherSafeLearnerId(value.keyId);
  if (keyId) safe.keyId = keyId;
  if (typeof value.createdAt === 'string') safe.createdAt = value.createdAt.slice(0, 48);
  return safe;
}

function alloEnsureTeacherRosterIdentity(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return value;
  var students = value.students && typeof value.students === 'object' && !Array.isArray(value.students)
    ? value.students : {};
  var groups = value.groups && typeof value.groups === 'object' && !Array.isArray(value.groups)
    ? value.groups : {};
  var legacyClassId = alloTeacherSafeLearnerId(
    value.submissionKey && typeof value.submissionKey.classId === 'string' ? value.submissionKey.classId : ''
  );
  var classId = alloTeacherSafeLearnerId(value.classId) || legacyClassId || alloTeacherStableId('CLS');
  var currentIds = value.learnerIds && typeof value.learnerIds === 'object' && !Array.isArray(value.learnerIds)
    ? value.learnerIds : {};
  var currentPreferences = value.learnerPreferences && typeof value.learnerPreferences === 'object' && !Array.isArray(value.learnerPreferences)
    ? value.learnerPreferences : {};
  var learnerIds = Object.create(null);
  var learnerPreferences = Object.create(null);
  var usedLearnerIds = Object.create(null);
  var readingThemeDefault = alloNormalizeTeacherReadingTheme(value.readingThemeDefault, 'default');
  var currentProgressHistory = value.progressHistory && typeof value.progressHistory === 'object' && !Array.isArray(value.progressHistory)
    ? value.progressHistory : {};
  var currentSessionHistory = Array.isArray(value.sessionHistory) ? value.sessionHistory : [];
  var progressHistory = alloTeacherSanitizeRosterProgressHistory(currentProgressHistory, students, groups);
  var sessionHistory = alloTeacherSanitizeRosterSessionHistory(currentSessionHistory, students, groups);
  var hasSeating = Object.prototype.hasOwnProperty.call(value, 'seating');
  var seating = hasSeating ? alloTeacherSanitizePortableSeating(value.seating, students) : null;
  var hasSubmissionKey = Object.prototype.hasOwnProperty.call(value, 'submissionKey');
  var submissionKey = hasSubmissionKey ? alloTeacherSanitizeSubmissionKey(value.submissionKey, classId) : null;
  var progressChanged = false;
  var sessionsChanged = false;
  var seatingChanged = false;
  var submissionKeyChanged = false;
  try {
    progressChanged = JSON.stringify(currentProgressHistory) !== JSON.stringify(progressHistory);
    sessionsChanged = JSON.stringify(currentSessionHistory) !== JSON.stringify(sessionHistory);
    seatingChanged = hasSeating && JSON.stringify(value.seating) !== JSON.stringify(seating);
    submissionKeyChanged = hasSubmissionKey && JSON.stringify(value.submissionKey) !== JSON.stringify(submissionKey);
  } catch (e) {
    progressChanged = true;
    sessionsChanged = true;
    seatingChanged = hasSeating;
    submissionKeyChanged = hasSubmissionKey;
  }
  // Earlier builds could store real-name lookup maps beside codenames. Keep
  // roster state codename-only even when an older backup or local record loads.
  var hasLegacyIdentityMap = Object.prototype.hasOwnProperty.call(value, 'displayNames')
    || Object.prototype.hasOwnProperty.call(value, 'importAliases');
  var changed = classId !== value.classId || readingThemeDefault !== value.readingThemeDefault
    || hasLegacyIdentityMap || progressChanged || sessionsChanged || seatingChanged || submissionKeyChanged;
  Object.keys(students).forEach(function(codename) {
    var rawExisting = typeof currentIds[codename] === 'string' ? currentIds[codename].trim() : '';
    var existing = alloTeacherSafeLearnerId(rawExisting);
    if (existing && usedLearnerIds[existing]) existing = '';
    var learnerId = existing;
    while (!learnerId || usedLearnerIds[learnerId]) learnerId = alloTeacherStableId('LRN');
    usedLearnerIds[learnerId] = 1;
    learnerIds[codename] = learnerId;
    if (!existing || existing !== rawExisting) changed = true;
    var preferenceSource = existing && Object.prototype.hasOwnProperty.call(currentPreferences, existing)
      ? currentPreferences[existing] : currentPreferences[codename];
    var preference = alloNormalizeTeacherLearnerPreference(preferenceSource);
    if (preference) learnerPreferences[learnerId] = preference;
    if (preferenceSource && JSON.stringify(preferenceSource) !== JSON.stringify(preference)) changed = true;
    if (preferenceSource && !Object.prototype.hasOwnProperty.call(currentPreferences, learnerId)) changed = true;
  });
  if (Object.keys(currentIds).length !== Object.keys(learnerIds).length) changed = true;
  if (Object.keys(currentPreferences).length !== Object.keys(learnerPreferences).length) changed = true;
  if (!changed) return value;
  var safeValue = Object.assign({}, value);
  delete safeValue.displayNames;
  delete safeValue.importAliases;
  if (hasSeating) {
    if (seating) safeValue.seating = seating;
    else delete safeValue.seating;
  }
  if (hasSubmissionKey) {
    if (submissionKey) safeValue.submissionKey = submissionKey;
    else delete safeValue.submissionKey;
  }
  return Object.assign({}, safeValue, {
    classId: classId,
    learnerIds: learnerIds,
    learnerPreferences: learnerPreferences,
    readingThemeDefault: readingThemeDefault,
    progressHistory: progressHistory,
    sessionHistory: sessionHistory
  });
}

function alloRemoveTeacherStudentReferences(seatingValue, codename) {
  if (!seatingValue || typeof seatingValue !== 'object' || Array.isArray(seatingValue) || !codename) return seatingValue;
  var changed = false;
  var layoutsSource = seatingValue.layouts && typeof seatingValue.layouts === 'object' && !Array.isArray(seatingValue.layouts)
    ? seatingValue.layouts : {};
  var layouts = {};
  Object.keys(layoutsSource).forEach(function(layoutId) {
    var layout = layoutsSource[layoutId];
    if (!layout || typeof layout !== 'object' || Array.isArray(layout)) {
      layouts[layoutId] = layout;
      return;
    }
    var assignmentsSource = layout.assignments && typeof layout.assignments === 'object' && !Array.isArray(layout.assignments)
      ? layout.assignments : {};
    var assignments = {};
    Object.keys(assignmentsSource).forEach(function(seatId) {
      if (assignmentsSource[seatId] === codename) changed = true;
      else assignments[seatId] = assignmentsSource[seatId];
    });
    layouts[layoutId] = Object.keys(assignments).length === Object.keys(assignmentsSource).length
      ? layout : Object.assign({}, layout, { assignments: assignments });
  });
  var constraints = Array.isArray(seatingValue.constraints)
    ? seatingValue.constraints.filter(function(constraint) {
        var referencesStudent = !!(constraint && Array.isArray(constraint.students) && constraint.students.indexOf(codename) >= 0);
        if (referencesStudent) changed = true;
        return !referencesStudent;
      })
    : seatingValue.constraints;
  return changed ? Object.assign({}, seatingValue, { layouts: layouts, constraints: constraints }) : seatingValue;
}
function alloRemoveTeacherGroupReferences(rosterValue, groupId) {
  if (!rosterValue || typeof rosterValue !== 'object' || Array.isArray(rosterValue) || !groupId) return rosterValue;
  var groups = Object.assign({}, rosterValue.groups || {});
  if (!Object.prototype.hasOwnProperty.call(groups, groupId)) return rosterValue;
  delete groups[groupId];
  var students = Object.assign({}, rosterValue.students || {});
  Object.keys(students).forEach(function(codename) {
    if (students[codename] === groupId) students[codename] = '';
  });
  var teamKey = 'group:' + groupId;
  var classGoals = Array.isArray(rosterValue.classGoals)
    ? rosterValue.classGoals.filter(function(goal) { return !(goal && goal.team === teamKey); })
    : rosterValue.classGoals;
  var next = Object.assign({}, rosterValue, { groups: groups, students: students });
  if (Array.isArray(rosterValue.classGoals)) next.classGoals = classGoals;
  return next;
}

const ALLO_ROSTER_RESERVED_KEYS = new Set(['__proto__', 'prototype', 'constructor']);
const ALLO_ROSTER_MAX_GROUPS = 100;
const ALLO_ROSTER_MAX_STUDENTS = 500;
const ALLO_ROSTER_FALLBACK_ADJECTIVES = ['Brave', 'Bright', 'Calm', 'Clever', 'Curious', 'Gentle', 'Kind', 'Mighty', 'Quiet', 'Swift'];
const ALLO_ROSTER_FALLBACK_ANIMALS = ['Bear', 'Dolphin', 'Falcon', 'Fox', 'Otter', 'Owl', 'Panda', 'Tiger', 'Turtle', 'Wolf'];
const alloNormalizeRosterCodenameKey = value => {
  const raw = String(value || '');
  const canonical = (typeof raw.normalize === 'function' ? raw.normalize('NFKC') : raw).toLowerCase();
  const compact = canonical.replace(/[^\p{L}\p{M}\p{N}]/gu, '');
  return /[\p{L}\p{N}]/u.test(compact) ? compact : '';
};
const alloRosterCodenameWordOptions = (value, fallback) => {
  const sanitize = source => {
    const seen = new Set();
    return (Array.isArray(source) ? source : []).reduce((words, candidate) => {
      if (typeof candidate !== 'string') return words;
      const word = Array.from(candidate.replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim()).slice(0, 36).join('');
      const key = alloNormalizeRosterCodenameKey(word);
      if (!key || seen.has(key) || words.length >= 120) return words;
      seen.add(key);
      words.push(word);
      return words;
    }, []);
  };
  const translated = sanitize(value);
  return translated.length ? translated : sanitize(fallback);
};
const alloRosterPlainRecord = value => !!value && typeof value === 'object' && !Array.isArray(value);
const alloNormalizeTeacherRosterImport = data => {
  if (!alloRosterPlainRecord(data) || !alloRosterPlainRecord(data.groups) || !alloRosterPlainRecord(data.students)) throw new Error('A roster file must contain group and student records.');
  const groupEntries = Object.entries(data.groups);
  const studentEntries = Object.entries(data.students);
  if (groupEntries.length > ALLO_ROSTER_MAX_GROUPS || studentEntries.length > ALLO_ROSTER_MAX_STUDENTS) throw new Error(`This roster is too large (maximum ${ALLO_ROSTER_MAX_GROUPS} groups and ${ALLO_ROSTER_MAX_STUDENTS} codenames).`);
  const groups = {};
  const groupNames = new Set();
  const groupIds = new Set();
  groupEntries.forEach(([rawId, rawGroup]) => {
    const id = String(rawId || '').trim().slice(0, 80);
    const name = typeof rawGroup?.name === 'string' ? rawGroup.name.trim().slice(0, 80) : '';
    const normalizedName = name.toLocaleLowerCase();
    if (!id || ALLO_ROSTER_RESERVED_KEYS.has(id.toLowerCase()) || !alloRosterPlainRecord(rawGroup) || !name || groupIds.has(id) || groupNames.has(normalizedName)) throw new Error('Group names and identifiers must be present, safe, and unique.');
    groupIds.add(id);
    groupNames.add(normalizedName);
    const rawProfile = alloRosterPlainRecord(rawGroup.profile) ? rawGroup.profile : {};
    const profile = {};
    ['gradeLevel', 'leveledTextLanguage', 'readingLevel', 'studentInterests', 'dokLevel', 'simplifyLevel', 'leveledTextCustomInstructions', 'readingThemeDefault'].forEach(field => {
      if (typeof rawProfile[field] === 'string') profile[field] = rawProfile[field].slice(0, field === 'leveledTextCustomInstructions' ? 500 : 120);
    });
    ['dyslexiaFriendly', 'useOpenDyslexic', 'karaokeMode'].forEach(field => { if (typeof rawProfile[field] === 'boolean') profile[field] = rawProfile[field]; });
    if (Number.isFinite(rawProfile.ttsSpeed)) profile.ttsSpeed = Math.max(0.5, Math.min(1.5, rawProfile.ttsSpeed));
    groups[id] = { name, color: /^#[0-9a-f]{6}$/i.test(rawGroup.color || '') ? rawGroup.color : '#4F46E5', profile };
  });
  const students = {};
  const codenames = new Set();
  studentEntries.forEach(([rawCodename, rawGroupId]) => {
    const codename = String(rawCodename || '').trim().slice(0, 80);
    const normalized = alloNormalizeRosterCodenameKey(codename);
    const groupId = typeof rawGroupId === 'string' ? rawGroupId.trim() : '';
    if (!normalized || ALLO_ROSTER_RESERVED_KEYS.has(codename.toLowerCase()) || codenames.has(normalized)) throw new Error('Student codenames must be present, safe, and unique.');
    if (groupId && !Object.prototype.hasOwnProperty.call(groups, groupId)) throw new Error('A student references a group that is not in this file.');
    codenames.add(normalized);
    students[codename] = groupId;
  });
  const asRecord = value => alloRosterPlainRecord(value) ? value : {};
  const importedClassId = alloTeacherSafeLearnerId(data.classId)
    || alloTeacherSafeLearnerId(data.submissionKey?.classId);
  const classGoals = (Array.isArray(data.classGoals) ? data.classGoals : []).map(goal => {
    if (!alloRosterPlainRecord(goal) || typeof goal.id !== 'string' || !/^[A-Za-z0-9_-]{1,40}$/.test(goal.id)) return null;
    const label = typeof goal.label === 'string' ? goal.label.trim().slice(0, 80) : '';
    if (!label) return null;
    let team = 'class';
    if (typeof goal.team === 'string' && goal.team.startsWith('group:') && Object.prototype.hasOwnProperty.call(groups, goal.team.slice(6))) team = goal.team;
    else if (typeof goal.team === 'string' && /^pod:\d{1,2}$/.test(goal.team)) team = goal.team;
    const tracked = alloRosterPlainRecord(goal.tracked) && (goal.tracked.metric === 'xp_total' || goal.tracked.metric === 'responded_each')
      ? { metric: goal.tracked.metric, threshold: Math.max(1, Math.min(1000000, Math.floor(Number(goal.tracked.threshold) || 1))) }
      : null;
    return {
      id: goal.id,
      label,
      templateId: typeof goal.templateId === 'string' ? goal.templateId.slice(0, 40) : 'custom',
      tokens: Number(goal.tokens) === 2 ? 2 : 1,
      allowance: Math.max(0, Math.min(5, Math.floor(Number(goal.allowance) || 0))),
      mode: goal.mode === 'independent' ? 'independent' : 'interdependent',
      team,
      tracked,
      active: goal.active !== false,
      metCount: alloTeacherBoundedRosterNumber(goal.metCount, 100000),
      lastMetAt: Number(goal.lastMetAt) > 0 ? Math.min(Number.MAX_SAFE_INTEGER, Number(goal.lastMetAt)) : null,
    };
  }).filter(Boolean).slice(0, 20);
  const classGoalLog = (Array.isArray(data.classGoalLog) ? data.classGoalLog : []).map(entry => {
    if (!alloRosterPlainRecord(entry)) return null;
    const goalId = typeof entry.goalId === 'string' && /^[A-Za-z0-9_-]{1,40}$/.test(entry.goalId) ? entry.goalId : '';
    const label = typeof entry.label === 'string' ? entry.label.trim().slice(0, 80) : '';
    if (!goalId || !label) return null;
    return {
      goalId,
      label,
      mode: entry.mode === 'independent' ? 'independent' : 'interdependent',
      tokens: Number(entry.tokens) === 2 ? 2 : 1,
      delivered: alloTeacherBoundedRosterNumber(entry.delivered, 250),
      sessionCode: typeof entry.sessionCode === 'string' ? entry.sessionCode.slice(0, 160) : null,
      at: alloTeacherBoundedRosterNumber(entry.at, Number.MAX_SAFE_INTEGER),
    };
  }).filter(Boolean).slice(-60);
  const normalizedRoster = alloEnsureTeacherRosterIdentity({
    className: typeof data.className === 'string' ? data.className.slice(0, 120) : '', classId: importedClassId, groups, students,
    learnerIds: asRecord(data.learnerIds), learnerPreferences: asRecord(data.learnerPreferences), readingThemeDefault: alloNormalizeTeacherReadingTheme(data.readingThemeDefault, 'default'),
    progressHistory: asRecord(data.progressHistory), sessionHistory: Array.isArray(data.sessionHistory) ? data.sessionHistory.slice(-30) : [],
    ...(alloRosterPlainRecord(data.seating) ? { seating: data.seating } : {}),
    ...(classGoals.length ? { classGoals } : {}), ...(classGoalLog.length ? { classGoalLog } : {})
  });
  const submissionKey = alloTeacherSanitizeSubmissionKey(data.submissionKey, normalizedRoster.classId);
  return submissionKey ? { ...normalizedRoster, submissionKey } : normalizedRoster;
};

// Safe membership updates bypass the replacement normalizer: current public
// roster fields must survive byte-for-byte JSON values, including future fields.
// Private plan state is transient and never becomes part of a roster or export.
const alloTeacherRosterUpdatePlans = new WeakMap();
let alloTeacherRosterUpdateSequence = 0;
const alloTeacherRosterUpdateSnapshot = value => {
  const ancestors = new Set();
  let count = 0;
  const canonical = (item, depth) => {
    if (++count > 150000 || depth > 80) throw new Error('This roster is too complex to update safely.');
    if (item === null || typeof item === 'string' || typeof item === 'boolean') return item;
    if (typeof item === 'number' && Number.isFinite(item)) return item;
    if (!item || typeof item !== 'object' || ancestors.has(item)) throw new Error('Safe updates require a complete JSON roster.');
    ancestors.add(item);
    let result;
    if (Array.isArray(item)) result = Array.from(item, entry => canonical(entry, depth + 1));
    else {
      if (Object.prototype.toString.call(item) !== '[object Object]') throw new Error('Safe updates require plain roster records.');
      result = {};
      Object.keys(item).sort().forEach(key => {
        if (ALLO_ROSTER_RESERVED_KEYS.has(key.toLowerCase())) throw new Error('A roster contains an unsafe record key.');
        result[key] = canonical(item[key], depth + 1);
      });
    }
    ancestors.delete(item);
    return result;
  };
  return JSON.stringify(canonical(value, 0));
};
const alloTeacherRosterUpdateIndex = roster => {
  if (!alloRosterPlainRecord(roster) || !alloRosterPlainRecord(roster.students)
    || !alloRosterPlainRecord(roster.groups) || !alloRosterPlainRecord(roster.learnerIds)
    || !roster.classId || alloTeacherSafeLearnerId(roster.classId) !== roster.classId) {
    throw new Error('Safe updates need a class ID and an explicit learner ID for every codename.');
  }
  const entries = Object.entries(roster.students);
  if (entries.length > ALLO_ROSTER_MAX_STUDENTS || Object.keys(roster.groups).length > ALLO_ROSTER_MAX_GROUPS) throw new Error('This roster exceeds the class size limits.');
  if (Object.keys(roster.learnerIds).length !== entries.length) throw new Error('Every learner ID must belong to exactly one roster codename.');
  const byId = new Map();
  const byCodename = new Map();
  entries.forEach(([codename, groupId]) => {
    const key = alloNormalizeRosterCodenameKey(codename);
    const learnerId = roster.learnerIds[codename];
    if (!key || codename.trim() !== codename || codename.length > 80 || ALLO_ROSTER_RESERVED_KEYS.has(codename.toLowerCase()) || byCodename.has(key)) throw new Error('Codenames must be safe and unique, including equivalent spelling and punctuation.');
    if (typeof groupId !== 'string' || (groupId && !Object.prototype.hasOwnProperty.call(roster.groups, groupId))) throw new Error('A roster codename has an invalid group assignment.');
    if (!Object.prototype.hasOwnProperty.call(roster.learnerIds, codename) || !learnerId || alloTeacherSafeLearnerId(learnerId) !== learnerId || byId.has(learnerId)) throw new Error('Learner IDs must be present, safe, and unique. Export a corrected roster before updating.');
    const entry = { codename, learnerId };
    byId.set(learnerId, entry);
    byCodename.set(key, entry);
  });
  return { byId, byCodename };
};
const alloBuildStoreRosterManifest = roster => {
  const index = alloTeacherRosterUpdateIndex(roster);
  if (!index.byId.size) throw new Error('Add at least one codename before preparing a Store review file.');
  if (/^(?:__proto__|prototype|constructor)$/i.test(roster.classId)) throw new Error('The class identity is reserved and cannot be used for Store review.');
  index.byId.forEach(entry => {
    if (/^(?:__proto__|prototype|constructor)$/i.test(entry.learnerId)) throw new Error('A learner identity is reserved and cannot be used for Store review.');
    if (/[\u0000-\u001f\u007f-\u009f]/.test(entry.codename)) throw new Error('Store review codenames cannot contain control characters.');
  });
  return {
    format: 'alloflow-store-roster', version: 1, classId: roster.classId,
    learners: Array.from(index.byId.values(), entry => ({ learnerId: entry.learnerId, codename: entry.codename }))
  };
};
const alloPlanTeacherRosterUpdate = (currentRoster, incomingRoster) => {
  if (!alloRosterPlainRecord(incomingRoster) || incomingRoster.exportVersion !== 4) throw new Error('Choose a codename-only AlloFlow version 4 roster backup for this class.');
  const allowedFields = new Set(['className', 'classId', 'groups', 'students', 'learnerIds', 'learnerPreferences', 'readingThemeDefault', 'progressHistory', 'sessionHistory', 'seating', 'classGoals', 'classGoalLog', 'submissionKey', 'exportVersion', 'exportDate']);
  if (Object.keys(incomingRoster).some(key => !allowedFields.has(key))) throw new Error('The update contains unsupported fields. Use a codename-only AlloFlow roster export.');
  const prohibitedFields = new Set(['displaynames', 'importaliases', 'identitymap', 'mappings', 'googleid', 'sourceid', 'userid', 'courseid', 'email', 'emailaddress', 'fullname', 'givenname', 'familyname', 'accesstoken', 'refreshtoken', 'privatejwk']);
  const rejectIdentityFields = value => {
    if (!value || typeof value !== 'object') return;
    Object.keys(value).forEach(key => {
      if (prohibitedFields.has(key.toLowerCase().replace(/[^a-z]/g, ''))) throw new Error('Identity records and credentials cannot be used in a roster update.');
      rejectIdentityFields(value[key]);
    });
  };
  // Canonicalization bounds and rejects cycles before traversing untrusted input.
  const incomingSnapshot = alloTeacherRosterUpdateSnapshot(incomingRoster);
  if (new TextEncoder().encode(incomingSnapshot).byteLength > 2 * 1024 * 1024) throw new Error('That roster file is larger than the 2 MB safety limit.');
  rejectIdentityFields(incomingRoster);
  const baseSnapshot = alloTeacherRosterUpdateSnapshot(currentRoster);
  rejectIdentityFields(currentRoster);
  const current = alloTeacherRosterUpdateIndex(currentRoster);
  const incoming = alloTeacherRosterUpdateIndex(incomingRoster);
  const additions = [];
  const retainedAbsences = [];
  const matches = [];
  const conflicts = [];
  let matchedCount = 0;
  if (incomingRoster.classId !== currentRoster.classId) conflicts.push({ code: 'CLASS_MISMATCH', message: 'This file belongs to a different class. Use the same class ID; a new Classroom download is not a refresh of an existing class.' });
  incoming.byId.forEach(entry => {
    const sameId = current.byId.get(entry.learnerId);
    const sameCodename = current.byCodename.get(alloNormalizeRosterCodenameKey(entry.codename));
    if (sameId && sameId.codename !== entry.codename) {
      conflicts.push({ code: 'CODENAME_CHANGED', codename: sameId.codename, message: 'An existing learner ID has a different codename in the file. Keep the existing identity binding.' });
    } else if (sameCodename && sameCodename.learnerId !== entry.learnerId) {
      conflicts.push({ code: 'LEARNER_ID_CHANGED', codename: sameCodename.codename, message: 'An existing codename has a different learner ID in the file. Names are never used to infer a match.' });
    } else if (sameId) { matchedCount++; matches.push(sameId); }
    else if (!/^LRN-[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(entry.learnerId)) {
      conflicts.push({ code: 'NEW_ID_NOT_OPAQUE', codename: entry.codename, message: 'A new learner needs an explicitly assigned opaque LRN UUID from the approved class mapping.' });
    } else additions.push(entry);
  });
  current.byId.forEach(entry => { if (!incoming.byId.has(entry.learnerId)) retainedAbsences.push(entry); });
  if (current.byId.size + additions.length > ALLO_ROSTER_MAX_STUDENTS) conflicts.push({ code: 'CLASS_SIZE_LIMIT', message: 'Keeping all existing learners and adding these learners would exceed 500 codenames.' });
  const candidate = JSON.parse(baseSnapshot);
  additions.forEach(entry => {
    candidate.students[entry.codename] = '';
    candidate.learnerIds[entry.codename] = entry.learnerId;
  });
  const freezeEntries = entries => Object.freeze(entries.map(entry => Object.freeze({ ...entry })));
  const preview = Object.freeze({
    revision: ++alloTeacherRosterUpdateSequence,
    classId: currentRoster.classId,
    additions: freezeEntries(additions), retainedAbsences: freezeEntries(retainedAbsences),
    conflicts: freezeEntries(conflicts), matches: freezeEntries(matches), matchedCount, canApply: conflicts.length === 0,
  });
  alloTeacherRosterUpdatePlans.set(preview, { baseSnapshot, candidateSnapshot: alloTeacherRosterUpdateSnapshot(candidate) });
  return preview;
};
const alloApplyTeacherRosterUpdate = (preview, currentRoster) => {
  const plan = preview && alloTeacherRosterUpdatePlans.get(preview);
  if (!plan) throw new Error('This update preview is no longer available. Choose the file again.');
  if (!preview.canApply) throw new Error('Resolve the identity conflicts before updating this roster.');
  // Compare the entire canonical snapshot, rather than a lossy hash or only IDs.
  if (alloTeacherRosterUpdateSnapshot(currentRoster) !== plan.baseSnapshot) throw new Error('The roster changed after this preview. Choose the file again to review the latest roster.');
  return JSON.parse(plan.candidateSnapshot);
};
const alloCancelTeacherRosterUpdate = preview => { if (preview) alloTeacherRosterUpdatePlans.delete(preview); };
const ALLO_TEACHER_CLASSROOM_IMPORT_URL = (() => {
  try {
    const scriptUrl = typeof document !== 'undefined' ? document.currentScript?.src : '';
    if (scriptUrl && /^https?:/i.test(scriptUrl)) return new URL('classroom-import.html', scriptUrl).href;
  } catch (_) {}
  return 'https://alloflow-cdn.pages.dev/classroom-import.html';
})();

const alloEscapeRosterWorksheetHtml = value => String(value ?? '').replace(/[&<>"']/g, character => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[character]));
const alloNormalizeRosterWorksheetOptions = value => {
  const source = alloRosterPlainRecord(value) ? value : {};
  return {
    locationPosition: source.locationPosition === 'before-name' || source.locationPosition === 'hidden' ? source.locationPosition : 'after-name',
    rowSize: source.rowSize === 'compact' || source.rowSize === 'large' ? source.rowSize : 'standard',
    sortBy: source.sortBy === 'group' ? 'group' : 'codename',
  };
};
const buildRosterCodenameWorksheetHtml = (roster, options) => {
  const settings = alloNormalizeRosterWorksheetOptions(options);
  const students = roster?.students && typeof roster.students === 'object' && !Array.isArray(roster.students) ? roster.students : {};
  const groups = roster?.groups && typeof roster.groups === 'object' && !Array.isArray(roster.groups) ? roster.groups : {};
  const entries = Object.entries(students).map(([codename, groupId]) => ({
    codename,
    groupName: typeof groups[groupId]?.name === 'string' ? groups[groupId].name.trim().slice(0, 80) : '',
  })).sort((a, b) => {
    if (settings.sortBy === 'group') {
      const groupOrder = (a.groupName || 'Unassigned').localeCompare(b.groupName || 'Unassigned', undefined, { numeric: true, sensitivity: 'base' });
      if (groupOrder) return groupOrder;
    }
    return a.codename.localeCompare(b.codename, undefined, { numeric: true, sensitivity: 'base' });
  });
  const locationHeader = '<th scope="col">Location / seat (write in)</th>';
  const groupHeader = settings.sortBy === 'group' ? '<th scope="col">Group</th>' : '';
  const headers = '<th scope="col">#</th><th scope="col">Codename</th>' + groupHeader
    + (settings.locationPosition === 'before-name' ? locationHeader : '')
    + '<th scope="col">Student name (write in)</th>'
    + (settings.locationPosition === 'after-name' ? locationHeader : '');
  const rows = entries.map((entry, index) => {
    const groupCell = settings.sortBy === 'group' ? `<td>${alloEscapeRosterWorksheetHtml(entry.groupName || 'Unassigned')}</td>` : '';
    const locationCell = '<td></td>';
    return `<tr><td>${index + 1}</td><th scope="row">${alloEscapeRosterWorksheetHtml(entry.codename)}</th>${groupCell}${settings.locationPosition === 'before-name' ? locationCell : ''}<td></td>${settings.locationPosition === 'after-name' ? locationCell : ''}</tr>`;
  }).join('');
  const rowHeight = settings.rowSize === 'compact' ? 8 : settings.rowSize === 'large' ? 16 : 12;
  const pageSize = settings.sortBy === 'group' ? 'landscape' : 'portrait';
  const privacySummary = settings.sortBy === 'group' ? 'AlloFlow printed codenames and roster group labels only.' : 'AlloFlow printed codenames only.';
  return `<!doctype html><html><head><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'"><title>AlloFlow Codename Roster Worksheet</title><style>@page{size:${pageSize};margin:12mm}body{font-family:Arial,sans-serif;color:#111}h1{font-size:20pt}.line{display:inline-block;width:50mm;border-bottom:1px solid #111}.notice{border:1px solid #555;padding:3mm}table{width:100%;border-collapse:collapse}thead{display:table-header-group}tr{break-inside:avoid}th,td{border:1px solid #222;padding:2.5mm;text-align:left;height:${rowHeight}mm}thead th{background:#eee}</style></head><body><h1>Class roster worksheet</h1><p>Class / period: <span class="line"></span> &nbsp; Date: <span class="line"></span></p><p class="notice"><strong>Privacy note:</strong> ${privacySummary} Write names and locations by hand; handwriting is not saved in AlloFlow. Keep the completed private teacher record secure.</p><table><caption>Codename-to-student reference</caption><thead><tr>${headers}</tr></thead><tbody>${rows}</tbody></table></body></html>`;
};

const rosterSessionCsvCell = (value) => {
  const raw = value === null || value === undefined ? '' : String(value);
  const text = /^[=+@-]/.test(raw) ? "'" + raw : raw;
  return /[",\r\n]/.test(text) ? '"' + text.replace(/"/g, '""') + '"' : text;
};

const buildRosterSessionEvidenceCsv = (session) => {
  const source = session && typeof session === 'object' ? session : {};
  const headers = [
    'record_type', 'session_id', 'ended_at', 'duration_minutes', 'transport',
    'codename', 'group_id', 'quiz_responses', 'activity_opportunities',
    'activity_submissions', 'revisions', 'follow_up', 'organizer_type',
    'organizer_status', 'organizer_score', 'organizer_correct', 'organizer_total',
    'organizer_attempts', 'activity_kind',
    'invited', 'submitted', 'approved', 'hidden', 'feedback_sent', 'votes_cast',
  ];
  const rows = [headers];
  const followUp = new Set((source.insightBrief?.followUpCodenames || []).map(String));
  Object.entries(source.participants && typeof source.participants === 'object' ? source.participants : {})
    .sort(([a], [b]) => a.localeCompare(b))
    .forEach(([codename, rawRecord]) => {
      const record = rawRecord && typeof rawRecord === 'object' ? rawRecord : {};
      rows.push([
        'participant', source.id || '', source.endedAt || '', source.durationMinutes ?? '', source.mode || '',
        codename, record.groupId || '', record.responseCount || 0, record.liveActivityCount || 0,
        record.liveSubmissionCount || 0, record.liveRevisionCount || 0, followUp.has(codename) ? 'yes' : 'no',
        record.organizer?.type || '', record.organizer?.status || '', record.organizer?.score || 0,
        record.organizer?.correct || 0, record.organizer?.total || 0, record.organizer?.attempts || 0,
        '', '', '', '', '', '', '',
      ]);
    });
  (Array.isArray(source.liveActivities) ? source.liveActivities : []).slice(0, 60).forEach(activity => {
    const record = activity && typeof activity === 'object' ? activity : {};
    rows.push([
      'activity', source.id || '', source.endedAt || '', source.durationMinutes ?? '', source.mode || '',
      '', '', '', '', '', record.revised || 0, '', '', '', '', '', '', '', record.kind || 'activity',
      record.invited || 0, record.submitted || 0, record.approved || 0, record.hidden || 0,
      record.feedbackSent || 0, record.votesCast || 0,
    ]);
  });
  return rows.map(row => row.map(rosterSessionCsvCell).join(',')).join('\r\n');
};

const downloadRosterSessionEvidenceCsv = (session) => {
  const csv = buildRosterSessionEvidenceCsv(session);
  const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  const stamp = String(session?.endedAt || new Date().toISOString()).slice(0, 10);
  anchor.href = url;
  anchor.download = 'alloflow_session_evidence_' + stamp + '.csv';
  document.body.appendChild(anchor);
  anchor.click();
  window.setTimeout(() => {
    URL.revokeObjectURL(url);
    anchor.remove();
  }, 1000);
};

const ROSTER_SESSION_FOLLOW_UP_FILTERS = new Set(['all', 'follow_up', 'revision', 'celebrate', 'planned']);

const normalizeRosterSessionTeacherNote = value => String(value || '')
  .replace(/\u000d\u000a?/g, '\n')
  .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '')
  .trim()
  .slice(0, 1000);

const normalizeRosterSessionFollowUpPlan = value => {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
  const resourceId = String(value.resourceId || '').trim().slice(0, 160);
  if (!resourceId || resourceId === '__proto__' || resourceId === 'prototype' || resourceId === 'constructor') return null;
  const status = value.status === 'completed' ? 'completed' : 'planned';
  const cohortCode = String(value.cohortCode || '').trim().slice(0, 80);
  const audience = value.audience === 'cohort' && cohortCode ? 'cohort' : 'class';
  const plannedAtMs = Date.parse(value.plannedAt || '');
  return {
    schemaVersion: 1,
    resourceId,
    resourceTitle: String(value.resourceTitle || 'Follow-up resource').replace(/\s+/g, ' ').trim().slice(0, 140) || 'Follow-up resource',
    resourceType: String(value.resourceType || '').trim().slice(0, 80),
    audience,
    cohortCode: audience === 'cohort' ? cohortCode : '',
    cohortLabel: audience === 'cohort' ? String(value.cohortLabel || 'Evidence cohort').replace(/\s+/g, ' ').trim().slice(0, 120) : 'Whole class',
    cohortCount: audience === 'cohort' ? Math.max(0, Math.min(250, Math.floor(Number(value.cohortCount) || 0))) : 0,
    status,
    plannedAt: Number.isFinite(plannedAtMs) ? new Date(plannedAtMs).toISOString() : '',
  };
};

const normalizeRosterSessionPlanningFields = session => {
  if (!session || typeof session !== 'object' || Array.isArray(session)) return session;
  const next = { ...session };
  const teacherNote = normalizeRosterSessionTeacherNote(session.teacherNote);
  const followUpPlan = normalizeRosterSessionFollowUpPlan(session.followUpPlan);
  if (teacherNote) next.teacherNote = teacherNote;
  else delete next.teacherNote;
  if (followUpPlan) next.followUpPlan = followUpPlan;
  else delete next.followUpPlan;
  return next;
};

const updateRosterSessionFollowUp = (rosterKey, sessionId, patch) => {
  const sourceRoster = rosterKey && typeof rosterKey === 'object' && !Array.isArray(rosterKey)
    ? rosterKey : { groups: {}, students: {} };
  const safeId = String(sessionId || '').trim().slice(0, 160);
  if (!safeId) return sourceRoster;
  const input = patch && typeof patch === 'object' && !Array.isArray(patch) ? patch : {};
  let found = false;
  const sessionHistory = (Array.isArray(sourceRoster.sessionHistory) ? sourceRoster.sessionHistory : []).map(rawSession => {
    if (!rawSession || String(rawSession.id || '') !== safeId) return rawSession;
    found = true;
    const next = { ...rawSession };
    if (Object.prototype.hasOwnProperty.call(input, 'teacherNote')) {
      const teacherNote = normalizeRosterSessionTeacherNote(input.teacherNote);
      if (teacherNote) next.teacherNote = teacherNote;
      else delete next.teacherNote;
    }
    if (Object.prototype.hasOwnProperty.call(input, 'followUpPlan')) {
      const followUpPlan = normalizeRosterSessionFollowUpPlan(input.followUpPlan);
      if (followUpPlan) next.followUpPlan = followUpPlan;
      else delete next.followUpPlan;
    }
    return next;
  });
  return found ? { ...sourceRoster, sessionHistory } : sourceRoster;
};

const filterRosterSessionHistory = (sessions, focusValue = 'all', activityKindValue = 'all') => {
  const focus = ROSTER_SESSION_FOLLOW_UP_FILTERS.has(focusValue) ? focusValue : 'all';
  const activityKind = String(activityKindValue || 'all').trim().slice(0, 80) || 'all';
  return (Array.isArray(sessions) ? sessions : []).filter(session => {
    if (!session || typeof session !== 'object') return false;
    const brief = session.insightBrief && typeof session.insightBrief === 'object' ? session.insightBrief : {};
    const cohorts = Array.isArray(brief.evidenceCohorts) ? brief.evidenceCohorts : [];
    const nextMoves = Array.isArray(brief.nextMoves) ? brief.nextMoves : [];
    const activities = Array.isArray(session.liveActivities) ? session.liveActivities : [];
    const organizerKind = String(session.organizerActivity?.type || '').trim();
    const kindMatches = activityKind === 'all' || organizerKind === activityKind || activities.some(activity => activity && activity.kind === activityKind);
    if (!kindMatches) return false;
    if (focus === 'follow_up') return cohorts.some(cohort => cohort && cohort.intent === 'support') || nextMoves.some(move => move && move.code !== 'review-evidence');
    if (focus === 'revision') return nextMoves.some(move => move && move.code === 'revision-opportunity') || Number(brief.feedbackSent || 0) > Number(brief.revisions || 0);
    if (focus === 'celebrate') return cohorts.some(cohort => cohort && cohort.intent === 'celebrate');
    if (focus === 'planned') return !!normalizeRosterSessionFollowUpPlan(session.followUpPlan);
    return true;
  });
};

const RosterKeyPanel = React.memo(({ isOpen, onClose, rosterKey, setRosterKey, onApplyGroup, onSyncToSession, onBatchGenerate, activeSessionCode, t, isParentMode, isIndependentMode, onOpenSubmissionInbox, onOpenSeatingChart, followUpResources = [], onOpenFollowUpResource, onPrepareFollowUpAssignment, onSendFollowUpToLiveSession, batchOpenRequest = 0, rosterStorageError = '' }) => {
  const [newGroupName, setNewGroupName] = useState('');
  const [newGroupColor, setNewGroupColor] = useState('#4F46E5');
  const [groupNameError, setGroupNameError] = useState('');
  const [rosterNotice, setRosterNotice] = useState('');
  const [rosterNoticeTone, setRosterNoticeTone] = useState('info');
  const [rosterImportUndo, setRosterImportUndo] = useState(null);
  const [showPrintOptions, setShowPrintOptions] = useState(false);
  const [printLocationPosition, setPrintLocationPosition] = useState('after-name');
  const [printRowSize, setPrintRowSize] = useState('standard');
  const [printSortBy, setPrintSortBy] = useState('codename');
  const [rosterStudentQuery, setRosterStudentQuery] = useState('');
  const [rosterAdj, setRosterAdj] = useState('');
  const [rosterAnimal, setRosterAnimal] = useState('');
  const rosterAdjectives = alloRosterCodenameWordOptions(t('codenames.adjectives', { returnObjects: true }), ALLO_ROSTER_FALLBACK_ADJECTIVES);
  const rosterAnimals = alloRosterCodenameWordOptions(t('codenames.animals', { returnObjects: true }), ALLO_ROSTER_FALLBACK_ANIMALS);
  const rosterAdjIsValid = rosterAdjectives.includes(rosterAdj);
  const rosterAnimalIsValid = rosterAnimals.includes(rosterAnimal);
  const announceRoster = (message, tone = 'info') => {
    setRosterNoticeTone(tone === 'error' || tone === 'warning' || tone === 'success' ? tone : 'info');
    setRosterNotice(String(message || '').slice(0, 320));
  };
  const randomizeRosterName = () => {
    if (rosterAdjectives.length > 0 && rosterAnimals.length > 0) {
      setRosterAdj(rosterAdjectives[Math.floor(Math.random() * rosterAdjectives.length)]);
      setRosterAnimal(rosterAnimals[Math.floor(Math.random() * rosterAnimals.length)]);
    }
  };
  const [newStudentGroup, setNewStudentGroup] = useState('');
  const [expandedGroup, setExpandedGroup] = useState(null);
  const [readingPreferencesStudent, setReadingPreferencesStudent] = useState(null);
  const [editingField, setEditingField] = useState(null);
  const [showBatchConfig, setShowBatchConfig] = useState(false);
  const [batchTypes, setBatchTypes] = useState({ simplified: true, glossary: false, quiz: false, 'sentence-frames': false, brainstorm: false, faq: false, outline: false, adventure: false, 'concept-sort': false, image: false, timeline: false });
  const [batchStatus, setBatchStatus] = useState('');
  const fileInputRef = useRef(null);
  const rosterUpdateFileRef = useRef(null);
  const rosterUpdatePreviewRef = useRef(null);
  const rosterUpdateReadRef = useRef(0);
  const currentRosterRef = useRef(rosterKey);
  currentRosterRef.current = rosterKey;
  const [rosterUpdatePreview, setRosterUpdatePreview] = useState(null);
  const [rosterUpdateAcknowledged, setRosterUpdateAcknowledged] = useState(false);
  const [rosterUpdateCompletion, setRosterUpdateCompletion] = useState(null);
  const panelRef = useRef(null);
  const printCleanupRef = useRef(null);
  const storeExportCleanupRef = useRef(null);
  const submissionDialogRef = useRef(null);
  const submissionDialogTriggerRef = useRef(null);
  const [submissionDialog, setSubmissionDialog] = useState(null);
  const [sessionHistoryFocus, setSessionHistoryFocus] = useState('all');
  const [sessionHistoryActivityKind, setSessionHistoryActivityKind] = useState('all');
  const [sessionNoteDrafts, setSessionNoteDrafts] = useState({});
  const [sessionPlanDrafts, setSessionPlanDrafts] = useState({});
  const [sessionPlannerStatus, setSessionPlannerStatus] = useState({});
  const [sessionLiveSendingId, setSessionLiveSendingId] = useState('');
  const safeFollowUpResources = useMemo(() => (Array.isArray(followUpResources) ? followUpResources : [])
    .filter(item => item && item.id && item.type)
    .slice(0, 250), [followUpResources]);
  const sessionActivityKinds = useMemo(() => Array.from(new Set(
    (Array.isArray(rosterKey?.sessionHistory) ? rosterKey.sessionHistory : [])
      .flatMap(session => (Array.isArray(session?.liveActivities) ? session.liveActivities : [])
        .map(activity => String(activity?.kind || '').trim())
        .concat(String(session?.organizerActivity?.type || '').trim()))
      .filter(Boolean)
  )).sort(), [rosterKey?.sessionHistory]);
  const filteredSessionHistory = useMemo(() => filterRosterSessionHistory(
    [...(Array.isArray(rosterKey?.sessionHistory) ? rosterKey.sessionHistory : [])].reverse(),
    sessionHistoryFocus,
    sessionHistoryActivityKind
  ), [rosterKey?.sessionHistory, sessionHistoryFocus, sessionHistoryActivityKind]);
  useFocusTrap(panelRef, isOpen, onClose);
  useEffect(() => {
    if (rosterUpdatePreview) rosterUpdatePreviewRef.current?.focus();
  }, [rosterUpdatePreview]);
  useEffect(() => {
    if (isOpen) return;
    rosterUpdateReadRef.current++;
    alloCancelTeacherRosterUpdate(rosterUpdatePreview);
    setRosterUpdatePreview(null);
    setRosterUpdateAcknowledged(false);
  }, [isOpen]);
  useEffect(() => {
    if (!rosterUpdateCompletion) return;
    const result = rosterUpdateCompletion;
    if (rosterKey === result.candidate) {
      setRosterImportUndo({ roster: result.previous, groupCount: Object.keys(result.previous.groups).length, studentCount: Object.keys(result.previous.students).length });
      announceRoster(`Roster updated: ${result.preview.additions.length} codenames added. ${result.preview.retainedAbsences.length} absent codenames were kept for review. Existing records and settings were preserved.`, 'success');
      alloCancelTeacherRosterUpdate(result.preview);
      setRosterUpdatePreview(null);
      setRosterUpdateAcknowledged(false);
    } else announceRoster('The roster changed before the update could be applied. Choose the file again to review the latest roster.', 'error');
    setRosterUpdateCompletion(null);
  }, [rosterKey, rosterUpdateCompletion]);
  useEffect(() => {
    if (!submissionDialog) return;
    const dialog = submissionDialogRef.current;
    const focusTarget = submissionDialog.kind === 'confirm'
      ? dialog?.querySelector('[data-safe-default="true"]')
      : dialog?.querySelector('button');
    focusTarget?.focus();
  }, [submissionDialog]);
  useEffect(() => {
    if (!isOpen || typeof setRosterKey !== 'function') return;
    setRosterKey(previous => alloEnsureTeacherRosterIdentity(previous));
  }, [isOpen, setRosterKey]);
  useEffect(() => {
    if (isOpen && batchOpenRequest) setShowBatchConfig(true);
  }, [isOpen, batchOpenRequest]);
  useEffect(() => () => printCleanupRef.current?.(), []);
  useEffect(() => () => storeExportCleanupRef.current?.(), []);
  useEffect(() => {
    if (readingPreferencesStudent && !rosterKey?.students?.[readingPreferencesStudent] && rosterKey?.students?.[readingPreferencesStudent] !== '') {
      setReadingPreferencesStudent(null);
    }
  }, [readingPreferencesStudent, rosterKey?.students]);
  if (!isOpen) return null;
  const groups = rosterKey?.groups || {};
  const students = rosterKey?.students || {};
  const groupIds = Object.keys(groups);
  const studentCodenames = Object.keys(students);
  const normalizedStudentQuery = rosterStudentQuery.trim().toLocaleLowerCase();
  const matchesStudentQuery = name => !normalizedStudentQuery || name.toLocaleLowerCase().includes(normalizedStudentQuery);
  const sortCodenames = names => names.sort((a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' }));
  const getStudentsInGroup = (gId) => sortCodenames(Object.entries(students).filter(([_, g]) => g === gId).map(([name]) => name));
  const getUnassigned = () => sortCodenames(Object.entries(students).filter(([_, g]) => !g || !groups[g]).map(([name]) => name));
  const visibleGroupIds = normalizedStudentQuery
    ? groupIds.filter(gId => getStudentsInGroup(gId).some(matchesStudentQuery))
    : groupIds;
  const visibleUnassigned = getUnassigned().filter(matchesStudentQuery);
  const studentMatchCount = studentCodenames.filter(matchesStudentQuery).length;
  const updateSessionPlannerStatus = (sessionId, message) => {
    setSessionPlannerStatus(previous => ({ ...previous, [sessionId]: String(message || '').slice(0, 180) }));
  };
  const noteDraftFor = session => Object.prototype.hasOwnProperty.call(sessionNoteDrafts, session.id)
    ? sessionNoteDrafts[session.id]
    : normalizeRosterSessionTeacherNote(session.teacherNote);
  const planDraftFor = session => {
    if (sessionPlanDrafts[session.id]) return sessionPlanDrafts[session.id];
    const existing = normalizeRosterSessionFollowUpPlan(session.followUpPlan);
    const existingResourceAvailable = existing && safeFollowUpResources.some(item => item.id === existing.resourceId);
    const supportCohorts = (session.insightBrief?.evidenceCohorts || []).filter(cohort => cohort && cohort.intent === 'support');
    const existingCohortAvailable = existing?.audience === 'cohort' && supportCohorts.some(cohort => cohort.code === existing.cohortCode);
    return {
      resourceId: existingResourceAvailable ? existing.resourceId : (safeFollowUpResources[0]?.id || ''),
      audienceKey: existingCohortAvailable ? 'cohort:' + existing.cohortCode : 'class',
    };
  };
  const saveSessionNote = session => {
    const note = normalizeRosterSessionTeacherNote(noteDraftFor(session));
    setRosterKey(previous => updateRosterSessionFollowUp(previous, session.id, { teacherNote: note }));
    setSessionNoteDrafts(previous => ({ ...previous, [session.id]: note }));
    updateSessionPlannerStatus(session.id, note ? 'Codename-only follow-up note saved.' : 'Follow-up note cleared.');
  };
  const saveSessionPlan = session => {
    const draft = planDraftFor(session);
    const resource = safeFollowUpResources.find(item => item.id === draft.resourceId);
    if (!resource) {
      updateSessionPlannerStatus(session.id, 'Choose an available student-safe resource first.');
      return;
    }
    const cohortCode = String(draft.audienceKey || '').startsWith('cohort:') ? String(draft.audienceKey).slice(7) : '';
    const cohort = (session.insightBrief?.evidenceCohorts || []).find(item => item && item.code === cohortCode);
    const plan = normalizeRosterSessionFollowUpPlan({
      resourceId: resource.id,
      resourceTitle: resource.title || resource.type || 'Follow-up resource',
      resourceType: resource.type,
      audience: cohort ? 'cohort' : 'class',
      cohortCode: cohort?.code || '',
      cohortLabel: cohort?.label || 'Whole class',
      cohortCount: cohort?.count || 0,
      status: 'planned',
      plannedAt: new Date().toISOString(),
    });
    setRosterKey(previous => updateRosterSessionFollowUp(previous, session.id, { followUpPlan: plan }));
    updateSessionPlannerStatus(session.id, 'Follow-up plan saved in this session record.');
  };
  const setSessionPlanStatus = (session, status) => {
    const current = normalizeRosterSessionFollowUpPlan(session.followUpPlan);
    if (!current) return;
    setRosterKey(previous => updateRosterSessionFollowUp(previous, session.id, { followUpPlan: { ...current, status } }));
    updateSessionPlannerStatus(session.id, status === 'completed' ? 'Follow-up marked complete.' : 'Follow-up reopened.');
  };
  const clearSessionPlan = session => {
    setRosterKey(previous => updateRosterSessionFollowUp(previous, session.id, { followUpPlan: null }));
    setSessionPlanDrafts(previous => {
      const next = { ...previous };
      delete next[session.id];
      return next;
    });
    updateSessionPlannerStatus(session.id, 'Follow-up plan cleared.');
  };
  const sendSessionPlanToLive = async session => {
    if (!session?.id || typeof onSendFollowUpToLiveSession !== 'function' || sessionLiveSendingId) return;
    const sessionId = session.id;
    setSessionLiveSendingId(sessionId);
    updateSessionPlannerStatus(sessionId, 'Checking the current live session…');
    try {
      const result = await onSendFollowUpToLiveSession(sessionId);
      updateSessionPlannerStatus(sessionId, result?.message || 'The live follow-up action finished.');
    } catch (_) {
      updateSessionPlannerStatus(sessionId, 'The live follow-up action failed. Review the current session and try again.');
    } finally {
      setSessionLiveSendingId(previous => previous === sessionId ? '' : previous);
    }
  };
  const cancelRosterUpdate = () => {
    rosterUpdateReadRef.current++;
    alloCancelTeacherRosterUpdate(rosterUpdatePreview);
    setRosterUpdatePreview(null);
    setRosterUpdateAcknowledged(false);
    announceRoster('Roster update cancelled. The current roster was not changed.');
  };
  const handleRosterUpdateFile = event => {
    const file = event.target?.files?.[0];
    if (!file) return;
    event.target.value = '';
    const requestId = ++rosterUpdateReadRef.current;
    alloCancelTeacherRosterUpdate(rosterUpdatePreview);
    setRosterUpdatePreview(null);
    setRosterUpdateAcknowledged(false);
    announceRoster('');
    if (file.size > 2 * 1024 * 1024) {
      announceRoster('That roster file is larger than the 2 MB safety limit.', 'error');
      return;
    }
    const reader = new FileReader();
    reader.onload = event => {
      if (requestId !== rosterUpdateReadRef.current) return;
      try {
        const preview = alloPlanTeacherRosterUpdate(currentRosterRef.current, JSON.parse(event.target.result));
        setRosterUpdatePreview(preview);
        announceRoster(preview.canApply ? 'Review the roster update below. Nothing has changed yet.' : 'This update has identity conflicts. Review the details below.', preview.canApply ? 'info' : 'error');
      } catch (error) { announceRoster(error instanceof SyntaxError ? 'This file is not valid roster JSON.' : (error?.message || 'This roster cannot be updated safely.'), 'error'); }
    };
    reader.onerror = () => { if (requestId === rosterUpdateReadRef.current) announceRoster('The roster file could not be read.', 'error'); };
    reader.readAsText(file);
  };
  const confirmRosterUpdate = () => {
    if (!rosterUpdatePreview || !rosterUpdateAcknowledged || rosterUpdateCompletion) return;
    try {
      const previous = currentRosterRef.current;
      const preview = rosterUpdatePreview;
      const candidate = alloApplyTeacherRosterUpdate(preview, previous);
      // Recheck against the state supplied by React, including queued edits.
      // The updater has no side effects and is safe for React's double invocation.
      setRosterKey(current => {
        try { alloApplyTeacherRosterUpdate(preview, current); return candidate; }
        catch (_) { return current; }
      });
      setRosterUpdateCompletion({ candidate, previous, preview });
    } catch (error) {
      setRosterUpdateAcknowledged(false);
      announceRoster(error?.message || 'Choose the file again to review the latest roster.', 'error');
    }
  };
  const handleImport = (e) => {
    const file = e.target?.files?.[0];
    if (!file) return;
    e.target.value = '';
    announceRoster('');
    if (file.size > 2 * 1024 * 1024) {
      announceRoster('That roster file is larger than the 2 MB safety limit.', 'error');
      return;
    }
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const data = JSON.parse(ev.target.result);
        const pendingRoster = alloNormalizeTeacherRosterImport(data);
        const groupsCount = Object.keys(pendingRoster.groups || {}).length;
        const studentsCount = Object.keys(pendingRoster.students || {}).length;
        if (!window.confirm(`Replace the current roster with ${groupsCount} groups and ${studentsCount} codenames? This also replaces roster history, seating, class goals, and offline-submission setup. Digital real-name fields are discarded.`)) return;
        const previousRoster = rosterKey || { groups: {}, students: {} };
        setRosterImportUndo({
          roster: previousRoster,
          groupCount: Object.keys(previousRoster.groups || {}).length,
          studentCount: Object.keys(previousRoster.students || {}).length,
        });
        setRosterKey(pendingRoster);
        setNewStudentGroup('');
        setExpandedGroup(null);
        setSessionNoteDrafts({});
        setSessionPlanDrafts({});
        setSessionPlannerStatus({});
        setRosterStudentQuery('');
        setShowPrintOptions(false);
        announceRoster(`Roster imported: ${groupsCount} groups and ${studentsCount} codenames. Legacy real-name fields were removed.`, 'success');
      } catch(err) {
        console.error('Invalid roster JSON:', err);
        announceRoster(err?.message || 'This file is not a valid roster.', 'error');
      }
    };
    reader.onerror = () => announceRoster('The roster file could not be read.', 'error');
    reader.readAsText(file);
  };
  const handleRestoreRosterImport = () => {
    if (!rosterImportUndo?.roster) return;
    if (!window.confirm('Restore the roster that was open before the last import? Any changes made since that import will be replaced.')) return;
    const previous = rosterImportUndo;
    setRosterKey(previous.roster);
    setNewStudentGroup('');
    setExpandedGroup(null);
    setSessionNoteDrafts({});
    setSessionPlanDrafts({});
    setSessionPlannerStatus({});
    setRosterStudentQuery('');
    setShowPrintOptions(false);
    setRosterImportUndo(null);
    announceRoster(`Previous roster restored: ${previous.groupCount} groups and ${previous.studentCount} codenames.`, 'success');
  };
  const handleExport = () => {
    const safeRoster = alloEnsureTeacherRosterIdentity(rosterKey || { groups: {}, students: {} });
    const exportData = {
      className: safeRoster.className || '', classId: safeRoster.classId || '', groups: safeRoster.groups || {}, students: safeRoster.students || {},
      learnerIds: safeRoster.learnerIds || {}, learnerPreferences: safeRoster.learnerPreferences || {}, readingThemeDefault: safeRoster.readingThemeDefault || 'default',
      progressHistory: safeRoster.progressHistory || {}, sessionHistory: safeRoster.sessionHistory || [],
      ...(safeRoster.submissionKey?.publicJwk ? { submissionKey: safeRoster.submissionKey } : {}), ...(safeRoster.seating ? { seating: safeRoster.seating } : {}),
      ...(Array.isArray(safeRoster.classGoals) ? { classGoals: safeRoster.classGoals } : {}), ...(Array.isArray(safeRoster.classGoalLog) ? { classGoalLog: safeRoster.classGoalLog } : {}),
      exportVersion: 4, exportDate: new Date().toISOString()
    };
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'roster_key_' + (rosterKey?.className || 'roster').replace(/[^a-zA-Z0-9]/g, '_') + '_' + new Date().toISOString().slice(0,10) + '.json';
    document.body.appendChild(a);
    a.click();
    announceRoster('Roster JSON backup downloaded.', 'success');
    window.setTimeout(() => {
      URL.revokeObjectURL(url);
      a.remove();
    }, 1000);
  };
  const handleStoreRosterExport = () => {
    if (isParentMode || isIndependentMode) return;
    let cleanup;
    try {
      const manifest = alloBuildStoreRosterManifest(rosterKey);
      if (!window.confirm('Download class and learner IDs with codenames for authorized School Store review? These are pseudonymous identifiers, not anonymous data. Check that codenames contain no real names. This file does not link students, authorize access, or award points.')) {
        announceRoster('Store review download cancelled. No roster records changed.');
        return;
      }
      storeExportCleanupRef.current?.();
      const url = URL.createObjectURL(new Blob([JSON.stringify(manifest, null, 2)], { type: 'application/json' }));
      const link = document.createElement('a');
      let timer, cleaned = false;
      cleanup = () => {
        if (cleaned) return;
        cleaned = true;
        window.clearTimeout(timer);
        URL.revokeObjectURL(url);
        link.remove();
        if (storeExportCleanupRef.current === cleanup) storeExportCleanupRef.current = null;
      };
      storeExportCleanupRef.current = cleanup;
      link.href = url;
      link.download = 'class.alloflow-store-roster.json';
      document.body.appendChild(link);
      link.click();
      timer = window.setTimeout(cleanup, 1000);
      announceRoster('Store review file downloaded. Give it only to your authorized Store administrator for manual matching. No records or points changed.', 'success');
    } catch (error) {
      cleanup?.();
      announceRoster(error?.message || 'The Store review file could not be prepared.', 'error');
    }
  };
  const handlePrintRosterWorksheet = event => {
    const trigger = event.currentTarget;
    const iframe = document.createElement('iframe');
    iframe.title = 'Print codename roster worksheet';
    iframe.tabIndex = -1;
    iframe.setAttribute('aria-hidden', 'true');
    iframe.style.cssText = 'position:fixed;width:1px;height:1px;right:0;bottom:0;border:0;opacity:0;pointer-events:none';
    let timer = null;
    let cleaned = false;
    const cleanup = () => {
      if (cleaned) return;
      cleaned = true;
      if (timer) window.clearTimeout(timer);
      iframe.remove();
      if (printCleanupRef.current === cleanup) printCleanupRef.current = null;
      window.setTimeout(() => trigger?.focus(), 0);
    };
    printCleanupRef.current?.();
    printCleanupRef.current = cleanup;
    iframe.addEventListener('load', () => {
      try {
        iframe.contentWindow?.addEventListener('afterprint', cleanup, { once: true });
        timer = window.setTimeout(cleanup, 60000);
        iframe.contentWindow?.focus();
        iframe.contentWindow?.print();
      } catch (_) {
        cleanup();
        announceRoster('The print dialog could not be opened. Please try again.', 'error');
      }
    }, { once: true });
    iframe.srcdoc = buildRosterCodenameWorksheetHtml(rosterKey, {
      locationPosition: printLocationPosition,
      rowSize: printRowSize,
      sortBy: printSortBy,
    });
    document.body.appendChild(iframe);
  };
  // ── Offline submissions setup ──
  // Generates an RSA-OAEP class keypair, downloads the private key as
  // `class-key.alloflow` for the teacher's class Drive folder, and stores
  // the public JWK in rosterKey.submissionKey so HTML exports embed it.
  // Phase 1, May 11 2026. Teacher MUST keep the downloaded file safe;
  // without it, encrypted student submissions are unrecoverable.
  const closeSubmissionDialog = () => {
    setSubmissionDialog(null);
    window.setTimeout(() => submissionDialogTriggerRef.current?.focus(), 0);
  };
  const requestOfflineSubmissionSetup = (event) => {
    submissionDialogTriggerRef.current = event.currentTarget;
    if (rosterKey?.submissionKey?.publicJwk) {
      setSubmissionDialog({ kind: 'confirm' });
      return;
    }
    handleSetupOfflineSubmissions();
  };
  const handleSetupOfflineSubmissions = async () => {
    const SC = window.AlloModules && window.AlloModules.SubmissionCrypto;
    if (!SC || typeof SC.generateClassKeypair !== 'function') {
      setSubmissionDialog({ kind: 'error', message: 'Submission security is not available yet. Please refresh and try again.' });
      return;
    }
    setSubmissionDialog(null);
    try {
      const { publicJwk, privateJwk } = await SC.generateClassKeypair();
      const normalizedRoster = alloEnsureTeacherRosterIdentity(rosterKey || { groups: {}, students: {} });
      const classId = normalizedRoster.classId;
      const keyId = alloTeacherStableId('KEY');
      const createdAt = new Date().toISOString();
      // Download the private key file
      const keyFile = {
        schemaVersion: 2,
        kind: 'alloflow-class-key',
        className: rosterKey?.className || '',
        classId: classId,
        keyId: keyId,
        createdAt: createdAt,
        privateJwk: privateJwk
      };
      const blob = new Blob([JSON.stringify(keyFile, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      const safeClass = (rosterKey?.className || 'class').replace(/[^a-zA-Z0-9]/g, '_').slice(0, 40);
      a.href = url;
      a.download = 'class-key_' + safeClass + '_' + createdAt.slice(0, 10) + '.alloflow';
      document.body.appendChild(a);
      a.click();
      setTimeout(() => { URL.revokeObjectURL(url); if (a.parentNode) a.parentNode.removeChild(a); }, 200);
      // Store the public key in roster for future exports
      setRosterKey(prev => ({
        ...alloEnsureTeacherRosterIdentity(prev || { groups: {}, students: {} }),
        className: prev?.className || '',
        groups: prev?.groups || {},
        students: prev?.students || {},
        classId: classId,
        submissionKey: { publicJwk: publicJwk, classId: classId, keyId: keyId, createdAt: createdAt }
      }));
      // Keep the recovery warning visible until the teacher acknowledges it.
      setSubmissionDialog({ kind: 'complete' });
    } catch (err) {
      console.error('handleSetupOfflineSubmissions failed:', err);
      setSubmissionDialog({ kind: 'error', message: 'Could not set up submissions: ' + (err && err.message ? err.message : 'unknown error') });
    }
  };
  const handleAddGroup = () => {
    if (Object.keys(groups).length >= ALLO_ROSTER_MAX_GROUPS) {
      setGroupNameError(`A roster can contain up to ${ALLO_ROSTER_MAX_GROUPS} groups.`);
      announceRoster('Delete an unused group before adding another one.', 'warning');
      return;
    }
    const name = newGroupName.trim();
    if (!name) return;
    if (Object.values(groups).some(group => String(group?.name || '').trim().toLocaleLowerCase() === name.toLocaleLowerCase())) {
      setGroupNameError('Choose a unique group name.');
      return;
    }
    const id = alloTeacherStableId('GRP');
    setRosterKey(prev => ({
      ...alloEnsureTeacherRosterIdentity(prev || { groups: {}, students: {} }),
      className: prev?.className || '',
      groups: { ...(prev?.groups || {}), [id]: { name, color: newGroupColor, profile: { gradeLevel: '3rd Grade', leveledTextLanguage: 'English' } } },
      students: prev?.students || {}
    }));
    setNewGroupName('');
    setGroupNameError('');
    setExpandedGroup(id);
    announceRoster('Group "' + name + '" added.', 'success');
  };
  const handleRemoveGroup = (gId) => {
    const group = groups[gId];
    const affected = getStudentsInGroup(gId).length;
    const affectedGoals = (Array.isArray(rosterKey?.classGoals) ? rosterKey.classGoals : []).filter(goal => goal && goal.team === 'group:' + gId).length;
    const goalNotice = affectedGoals ? ` ${affectedGoals} active group goal${affectedGoals === 1 ? '' : 's'} will also be removed.` : '';
    if (!window.confirm(`Delete “${group?.name || 'this group'}”? ${affected} student${affected === 1 ? '' : 's'} will remain in the roster as Unassigned.${goalNotice}`)) return;
    setRosterKey(prev => alloEnsureTeacherRosterIdentity(alloRemoveTeacherGroupReferences(prev, gId)));
    setNewStudentGroup(current => current === gId ? '' : current);
    setExpandedGroup(current => current === gId ? null : current);
    announceRoster('Group "' + (group?.name || 'Untitled group') + '" deleted. ' + affected + ' codename' + (affected === 1 ? '' : 's') + ' moved to Unassigned.', 'success');
  };
  const handleUpdateGroupProfile = (gId, field, value) => {
    const safeValue = typeof value === 'string'
      ? value.slice(0, field === 'leveledTextCustomInstructions' ? 500 : 120)
      : value;
    setRosterKey(prev => ({
      ...prev,
      groups: { ...prev.groups, [gId]: { ...prev.groups[gId], profile: { ...prev.groups[gId].profile, [field]: safeValue } } }
    }));
  };
  const handleUpdateGroupMeta = (gId, field, value) => {
    const safeValue = field === 'name' ? String(value || '').slice(0, 80) : value;
    if (field === 'name') {
      const name = safeValue.trim();
      if (!name || Object.entries(groups).some(([otherId, group]) => otherId !== gId && String(group?.name || '').trim().toLocaleLowerCase() === name.toLocaleLowerCase())) {
        setGroupNameError(!name ? 'Group names cannot be blank.' : 'Choose a unique group name.');
        return;
      }
      setGroupNameError('');
    }
    setRosterKey(prev => ({
      ...prev,
      groups: { ...prev.groups, [gId]: { ...prev.groups[gId], [field]: safeValue } }
    }));
  };
  const handleAddStudent = () => {
    if (Object.keys(students).length >= ALLO_ROSTER_MAX_STUDENTS) {
      announceRoster(`This roster has reached the ${ALLO_ROSTER_MAX_STUDENTS}-codename limit. Delete an unused codename before adding another.`, 'warning');
      return;
    }
    const codename = rosterAdjIsValid && rosterAnimalIsValid ? `${rosterAdj} ${rosterAnimal}` : '';
    if (!codename) return;
    const normalizedCodename = alloNormalizeRosterCodenameKey(codename);
    const duplicate = Object.keys(students).some(name => alloNormalizeRosterCodenameKey(name) === normalizedCodename);
    if (duplicate) {
      announceRoster('That codename is already in this roster. Generate another one.', 'warning');
      if (window.AlloFlowUX) window.AlloFlowUX.toast('That codename is already in this roster. Generate another one.', 'warn');
      randomizeRosterName();
      return;
    }
    const targetGroup = newStudentGroup && groups[newStudentGroup] ? newStudentGroup : '';
    setRosterKey(prev => ({
      ...alloEnsureTeacherRosterIdentity(prev || { groups: {} }),
      className: prev?.className || '',
      groups: prev?.groups || {},
      students: { ...(prev?.students || {}), [codename]: targetGroup },
      learnerIds: { ...(prev?.learnerIds || {}), [codename]: alloTeacherStableId('LRN') }
    }));
    randomizeRosterName();
    announceRoster('Codename "' + codename + '" added' + (targetGroup ? ' to ' + groups[targetGroup].name : ' as Unassigned') + '.', 'success');
  };
  const handleRemoveStudent = (name) => {
    if (!window.confirm(`Delete ${name} from the roster? This removes the codename and its linked preferences, individual progress, participant lists, and seating references. De-identified class activity totals and teacher notes remain. Assessment Center records are kept and can be removed separately in its Records manager.`)) return;
    setRosterKey(prev => {
      const learnerId = prev.learnerIds?.[name];
      const ns = { ...prev.students }; delete ns[name];
      const ni = { ...(prev.learnerIds || {}) }; delete ni[name];
      const nr = { ...(prev.learnerPreferences || {}) };
      if (learnerId) delete nr[learnerId];
      delete nr[name];
      const np = { ...(prev.progressHistory || {}) }; delete np[name];
      const nh = (Array.isArray(prev.sessionHistory) ? prev.sessionHistory : []).map(session => {
        const removedOrganizer = session.participants?.[name]?.organizer || null;
        const participants = { ...(session.participants || {}) }; delete participants[name];
        const insightBrief = session.insightBrief && typeof session.insightBrief === 'object' ? {
          ...session.insightBrief,
          followUpCodenames: (session.insightBrief.followUpCodenames || []).filter(codename => codename !== name),
          evidenceCohorts: (session.insightBrief.evidenceCohorts || []).map(cohort => {
            const codenames = (cohort.codenames || []).filter(codename => codename !== name);
            return { ...cohort, codenames, count: codenames.length };
          }).filter(cohort => cohort.count > 0),
        } : session.insightBrief;
        const organizerActivity = session.organizerActivity && typeof session.organizerActivity === 'object' ? {
          ...session.organizerActivity,
          participantCount: Math.max(0, Number(session.organizerActivity.participantCount || 0) - (removedOrganizer ? 1 : 0)),
          statusCounts: removedOrganizer ? {
            ...(session.organizerActivity.statusCounts || {}),
            [removedOrganizer.status]: Math.max(0, Number(session.organizerActivity.statusCounts?.[removedOrganizer.status] || 0) - 1),
          } : session.organizerActivity.statusCounts,
          followUpCodenames: (session.organizerActivity.followUpCodenames || []).filter(codename => codename !== name),
        } : null;
        const nextSession = { ...session, participants, insightBrief, absentCodenames: (session.absentCodenames || []).filter(codename => codename !== name) };
        if (organizerActivity?.participantCount > 0) nextSession.organizerActivity = organizerActivity;
        else delete nextSession.organizerActivity;
        return nextSession;
      });
      const seating = alloRemoveTeacherStudentReferences(prev.seating, name);
      const next = { ...prev, students: ns, learnerIds: ni, learnerPreferences: nr, progressHistory: np, sessionHistory: nh };
      if (seating !== prev.seating) next.seating = seating;
      return next;
    });
    announceRoster('Codename "' + name + '" deleted from the roster.', 'success');
  };
  const handleMoveStudent = (name, toGroup) => {
    const targetGroup = toGroup && groups[toGroup] ? toGroup : '';
    setRosterKey(prev => ({ ...prev, students: { ...prev.students, [name]: targetGroup } }));
    announceRoster('Codename "' + name + '" moved to ' + (targetGroup ? groups[targetGroup].name : 'Unassigned') + '.', 'info');
  };
  const handleRunBatchGenerate = async () => {
    const selected = Object.keys(batchTypes).filter(type => batchTypes[type]);
    if (!selected.length) { setBatchStatus('Select at least one output type.'); return; }
    setBatchStatus('');
    try {
      await onBatchGenerate?.(selected);
      setShowBatchConfig(false);
    } catch (_) {
      setBatchStatus('The differentiated resources could not be generated. Try again.');
    }
  };
  const getLearnerReadingPreference = (name) => {
    const learnerId = rosterKey?.learnerIds?.[name];
    return alloNormalizeTeacherLearnerPreference(learnerId ? rosterKey?.learnerPreferences?.[learnerId] : null) || {};
  };
  const updateLearnerReadingPreference = (name, updater) => {
    setRosterKey(previous => {
      const normalizedRoster = alloEnsureTeacherRosterIdentity(previous || { groups: {}, students: {} });
      const learnerId = normalizedRoster?.learnerIds?.[name];
      if (!learnerId) return normalizedRoster;
      const current = alloNormalizeTeacherLearnerPreference(normalizedRoster.learnerPreferences?.[learnerId]) || {};
      const candidate = typeof updater === 'function' ? updater(current) : updater;
      const next = alloNormalizeTeacherLearnerPreference({ ...candidate, updatedAt: new Date().toISOString() });
      const learnerPreferences = { ...(normalizedRoster.learnerPreferences || {}) };
      if (next) learnerPreferences[learnerId] = next;
      else delete learnerPreferences[learnerId];
      return { ...normalizedRoster, learnerPreferences };
    });
  };
  const handleSetLearnerReadingTheme = (name, readingTheme) => {
    updateLearnerReadingPreference(name, current => {
      const next = { ...current };
      if (readingTheme) next.readingTheme = alloNormalizeTeacherReadingTheme(readingTheme, '');
      else delete next.readingTheme;
      return next;
    });
  };
  const handleToggleLearnerReadingFavorite = (name, readingTheme) => {
    updateLearnerReadingPreference(name, current => {
      const favorites = alloNormalizeTeacherReadingFavorites(current.favoriteReadingThemes);
      return {
        ...current,
        favoriteReadingThemes: favorites.includes(readingTheme)
          ? favorites.filter(themeId => themeId !== readingTheme)
          : favorites.concat(readingTheme)
      };
    });
  };
  const handleResetLearnerReadingPreference = (name) => updateLearnerReadingPreference(name, null);
  const COLORS = ['#4F46E5', '#059669', '#D97706', '#DC2626', '#7C3AED', '#0891B2', '#BE185D', '#65A30D'];
  const GRADE_OPTIONS = ['Pre-K', 'Kindergarten', '1st Grade', '2nd Grade', '3rd Grade', '4th Grade', '5th Grade', '6th Grade', '7th Grade', '8th Grade', '9th Grade', '10th Grade', '11th Grade', '12th Grade'];
  const LANG_OPTIONS = ['English', 'Spanish', 'French', 'Arabic', 'Somali', 'Vietnamese', 'Portuguese', 'Mandarin', 'Korean', 'Tagalog', 'Russian', 'Japanese'];
  const ProfileField = ({ label, value, field, gId, type = 'text', options }) => (
    <div className="flex items-center gap-2 text-xs">
      <span className="font-bold text-slate-600 w-24 shrink-0">{label}:</span>
      {type === 'select' ? (
        <select value={value || ''} onChange={e => handleUpdateGroupProfile(gId, field, e.target.value)}
          aria-label={label}
          className="flex-1 px-2 py-1 rounded-lg border border-slate-400 text-slate-700 text-xs focus:ring-2 focus:ring-indigo-400 focus:outline-none">
          <option value="">—</option>
          {options.map(o => {
            const optionValue = typeof o === 'object' ? o.id : o;
            const optionLabel = typeof o === 'object' ? o.label : o;
            return <option key={optionValue} value={optionValue}>{optionLabel}</option>;
          })}
        </select>
      ) : type === 'range' ? (
        <div className="flex-1 flex items-center gap-2">
          <input type="range" min="0.5" max="1.5" step="0.05" value={value || 1}
            onChange={e => handleUpdateGroupProfile(gId, field, parseFloat(e.target.value))}
            aria-label={label}
            className="flex-1 accent-indigo-500" />
          <span className="text-slate-600 font-mono w-10 text-right">{(value || 1).toFixed(2)}x</span>
        </div>
      ) : type === 'toggle' ? (
        <button type="button" onClick={() => handleUpdateGroupProfile(gId, field, !value)}
          aria-pressed={!!value}
          className={`px-3 py-1 rounded-full text-xs font-bold transition-all motion-reduce:transition-none ${value ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-600'}`}>
          {value ? 'On' : 'Off'}
        </button>
      ) : (
        <input type="text" value={value || ''} maxLength={field === 'leveledTextCustomInstructions' ? 500 : 120} onChange={e => handleUpdateGroupProfile(gId, field, e.target.value)}
          aria-label={label}
          placeholder="—" className="flex-1 px-2 py-1 rounded-lg border border-slate-400 text-slate-700 text-xs focus:ring-2 focus:ring-indigo-400 focus:outline-none" />
      )}
    </div>
  );
  return (
    <div ref={panelRef} role="dialog" aria-modal="true" aria-labelledby="teacher-roster-panel-title" className="fixed inset-0 z-[260] bg-slate-900/80 backdrop-blur-sm flex items-center justify-center p-0 sm:p-4 animate-in motion-reduce:animate-none fade-in duration-200">
      <div className="bg-white rounded-none sm:rounded-2xl shadow-2xl max-w-2xl w-full h-[100dvh] sm:h-auto sm:max-h-[85vh] flex flex-col border-0 sm:border-2 border-indigo-100 animate-in motion-reduce:animate-none zoom-in-95 duration-200 min-w-0">
        <div className="flex items-start justify-between gap-3 p-4 sm:p-5 border-b border-slate-100">
          <div data-help-key="roster_panel_header">
            <h2 id="teacher-roster-panel-title" className="text-lg font-black text-slate-800 flex items-center gap-2">
              <ClipboardList size={20} className="text-indigo-500" /> {isParentMode ? 'Family Learning Profiles' : (isIndependentMode ? 'My Learning Profile' : (t('roster.title') || 'Class Roster & Progress Tracking'))}
            </h2>
            <p className="text-xs text-slate-600 mt-0.5">{isParentMode ? 'Manage family member profiles and track learning progress' : (isIndependentMode ? 'Manage your learning profile and track your progress' : (t('roster.subtitle') || 'Organize student groups with differentiated profiles for instruction'))}</p>
          </div>
          <button type="button" onClick={onClose} className="p-2 rounded-full hover:bg-slate-100 transition-colors motion-reduce:transition-none" aria-label={t('common.close')}>
            <X size={20} className="text-slate-600" />
          </button>
        </div>
        <div className="flex flex-wrap gap-2 px-4 sm:px-5 py-3 border-b border-slate-50 bg-slate-50/50">
          <button type="button" onClick={() => rosterUpdateFileRef.current?.click()} disabled={!rosterKey?.classId} className="px-3 py-1.5 bg-indigo-700 text-white rounded-lg text-xs font-bold hover:bg-indigo-800 transition-colors motion-reduce:transition-none flex items-center gap-1.5 disabled:opacity-40">
            <Upload size={14} /> Update roster safely
          </button>
          <button type="button" onClick={() => fileInputRef.current?.click()} className="px-3 py-1.5 bg-indigo-50 text-indigo-700 rounded-lg text-xs font-bold hover:bg-indigo-100 transition-colors motion-reduce:transition-none flex items-center gap-1.5">
            <Upload size={14} /> Import / replace roster
          </button>
          {!isParentMode && !isIndependentMode && <a href={ALLO_TEACHER_CLASSROOM_IMPORT_URL} target="_blank" rel="noopener noreferrer" className="px-3 py-1.5 bg-blue-50 text-blue-800 rounded-lg text-xs font-bold hover:bg-blue-100 transition-colors motion-reduce:transition-none">Google Classroom setup</a>}
          <button type="button" onClick={handleExport} disabled={!rosterKey} className="px-3 py-1.5 bg-green-50 text-green-700 rounded-lg text-xs font-bold hover:bg-green-100 transition-colors motion-reduce:transition-none flex items-center gap-1.5 disabled:opacity-40">
            <Download size={14} /> {t('roster.export') || 'Export JSON'}
          </button>
          {!isParentMode && !isIndependentMode && <button type="button" onClick={handleStoreRosterExport} disabled={!rosterKey?.classId || !Object.keys(rosterKey?.students || {}).length} aria-describedby="roster-store-export-note" className="px-3 py-1.5 min-h-[44px] bg-purple-50 text-purple-800 rounded-lg text-xs font-bold hover:bg-purple-100 transition-colors motion-reduce:transition-none flex items-center gap-1.5 disabled:opacity-40">
            <Download size={14} /> Store review file
          </button>}
          <button type="button" onClick={handlePrintRosterWorksheet} disabled={!Object.keys(rosterKey?.students || {}).length} className="px-3 py-1.5 bg-cyan-50 text-cyan-800 rounded-lg text-xs font-bold hover:bg-cyan-100 transition-colors motion-reduce:transition-none flex items-center gap-1.5 disabled:opacity-40">
            <Printer size={14} /> Print worksheet
          </button>
          {!isParentMode && !isIndependentMode && <p id="roster-store-export-note" className="w-full text-xs text-slate-600">Store review shares only class/learner IDs and codenames. An authorized Store administrator must review each match; no learning records or points are transferred.</p>}
          <button type="button" onClick={() => setShowPrintOptions(value => !value)} aria-expanded={showPrintOptions} aria-controls="roster-print-options" className="px-3 py-1.5 rounded-lg border border-cyan-200 bg-white text-xs font-bold text-cyan-900 hover:bg-cyan-50 transition-colors motion-reduce:transition-none">
            Worksheet options
          </button>
          <button type="button"
            onClick={requestOfflineSubmissionSetup}
            disabled={!rosterKey}
            title={rosterKey?.submissionKey?.publicJwk
              ? 'Offline submissions are active for this class. Click to regenerate (invalidates the existing key).'
              : 'Generate a class keypair so students can save HTML worksheets back to you.'}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors motion-reduce:transition-none flex items-center gap-1.5 disabled:opacity-40 ${
              rosterKey?.submissionKey?.publicJwk
                ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200 border border-emerald-300'
                : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
            }`}
          >
            <Lock size={14} />
            {rosterKey?.submissionKey?.publicJwk
              ? (t('roster.submissions_active') || 'Submissions On')
              : (t('roster.setup_submissions') || 'Set up offline submissions')}
          </button>
          {typeof onOpenSubmissionInbox === 'function' && (
            <button type="button"
              onClick={onOpenSubmissionInbox}
              disabled={!rosterKey?.submissionKey?.publicJwk}
              title={rosterKey?.submissionKey?.publicJwk
                ? 'Open the submission inbox to decrypt and review student-submitted HTML files.'
                : 'Set up offline submissions first to use the inbox.'}
              className="px-3 py-1.5 bg-emerald-50 text-emerald-700 rounded-lg text-xs font-bold hover:bg-emerald-100 transition-colors motion-reduce:transition-none flex items-center gap-1.5 disabled:opacity-40"
            >
              📥 {t('roster.import_submissions') || 'Import submissions'}
            </button>
          )}
          {typeof onOpenSeatingChart === 'function' && (
            <button type="button"
              onClick={onOpenSeatingChart}
              disabled={!rosterKey || Object.keys(rosterKey?.students || {}).length === 0}
              title="Design your classroom map, encode seating needs as constraints, and auto-arrange. Everything stays on this device inside the roster."
              className="px-3 py-1.5 bg-sky-50 text-sky-700 rounded-lg text-xs font-bold hover:bg-sky-100 transition-colors motion-reduce:transition-none flex items-center gap-1.5 disabled:opacity-40"
            >
              🪑 {t('roster.seating_chart') || 'Seating Chart'}
            </button>
          )}
          <button type="button" onClick={() => setShowBatchConfig(true)} disabled={!rosterKey || Object.keys(rosterKey?.groups || {}).length === 0} className="px-3 py-1.5 bg-amber-50 text-amber-700 rounded-lg text-xs font-bold hover:bg-amber-100 transition-colors motion-reduce:transition-none flex items-center gap-1.5 disabled:opacity-40 border border-amber-200">
            <Layers size={14} /> {t('roster.batch_generate') || 'Differentiate by Group'}
          </button>
          {activeSessionCode && (
            <button type="button" onClick={onSyncToSession} disabled={!rosterKey || groupIds.length === 0} title="Update this live session's group choices and differentiation settings from the roster." className="px-3 py-1.5 bg-purple-50 text-purple-700 rounded-lg text-xs font-bold hover:bg-purple-100 transition-colors motion-reduce:transition-none flex items-center gap-1.5 disabled:opacity-40 ml-auto">
              <RefreshCw size={14} /> {t('roster.sync_session') || 'Sync to Live Session'}
            </button>
          )}
          <input ref={fileInputRef} type="file" accept=".json" onChange={handleImport} className="hidden" aria-label={t('roster.import') || 'Import roster JSON'} />
          <input ref={rosterUpdateFileRef} type="file" accept=".json,application/json" onChange={handleRosterUpdateFile} className="hidden" aria-label="Choose same-class roster update JSON" />
        </div>
        <div className="flex-1 overflow-y-auto overflow-x-hidden p-4 sm:p-5 space-y-3 custom-scrollbar min-w-0">
          <div className="grid grid-cols-1 gap-2 mb-2 sm:grid-cols-[1fr_auto]">
            <label className="flex items-center gap-2 text-xs font-bold text-slate-600 uppercase tracking-wider">
              <span className="shrink-0">{t('roster.class_name') || 'Class Name'}:</span>
              <input type="text" value={rosterKey?.className || ''} maxLength={120} onChange={e => setRosterKey(prev => ({ ...(prev || { groups: {}, students: {} }), className: e.target.value.slice(0, 120) }))}
                placeholder={t('common.placeholder_ms_smith_period_3')}
                aria-label={t('roster.class_name') || 'Class name'}
                className="min-w-0 flex-1 px-3 py-1.5 rounded-lg border border-slate-400 text-sm font-normal normal-case tracking-normal focus:ring-2 focus:ring-indigo-400 focus:outline-none" />
            </label>
            <label className="flex items-center gap-2 text-xs font-bold text-slate-600">
              <span className="shrink-0">Reading default:</span>
              <select
                value={alloNormalizeTeacherReadingTheme(rosterKey?.readingThemeDefault, 'default')}
                onChange={event => setRosterKey(previous => ({ ...alloEnsureTeacherRosterIdentity(previous || { groups: {}, students: {} }), readingThemeDefault: alloNormalizeTeacherReadingTheme(event.target.value, 'default') }))}
                aria-label="Class reading theme default"
                className="min-h-9 rounded-lg border border-slate-400 bg-white px-2 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-400"
              >
                {ALLO_TEACHER_READING_THEME_OPTIONS.map(option => <option key={option.id} value={option.id}>{option.label}</option>)}
              </select>
            </label>
          </div>
          <details className="rounded-xl border border-indigo-100 bg-indigo-50/60 px-3 py-2 text-xs text-slate-700">
            <summary className="cursor-pointer font-bold text-indigo-800">How does this roster connect to AlloFlow?</summary>
            <ul className="mt-2 ml-4 list-disc space-y-1">
              <li>Use codenames only. Never enter student names or other identifying information in the digital roster.</li>
              <li>Groups provide reusable differentiation settings and can be synced to an active live session.</li>
              <li>Matching codenames are assigned to their roster group automatically when students join.</li>
              <li>Reading favorites and the last selected reading theme follow a matched learner; personal choices override group and class suggestions.</li>
              <li>The same codenames help identify imported student submissions.</li>
              <li>This roster is stored on this device. Export a JSON backup before changing devices or clearing browser data.</li>
            </ul>
          </details>
          {rosterNotice && (
            <p
              role={rosterNoticeTone === 'error' ? 'alert' : 'status'}
              aria-live={rosterNoticeTone === 'error' ? 'assertive' : 'polite'}
              aria-atomic="true"
              className={'rounded-lg border px-3 py-2 text-xs font-bold ' + (rosterNoticeTone === 'error' ? 'border-red-300 bg-red-50 text-red-900' : rosterNoticeTone === 'warning' ? 'border-amber-300 bg-amber-50 text-amber-900' : rosterNoticeTone === 'success' ? 'border-emerald-300 bg-emerald-50 text-emerald-900' : 'border-indigo-200 bg-indigo-50 text-indigo-900')}
            >{rosterNotice}</p>
          )}
          {rosterUpdatePreview && (
            <section ref={rosterUpdatePreviewRef} tabIndex={-1} className="rounded-xl border-2 border-indigo-300 bg-indigo-50 p-4 focus:outline-none focus:ring-2 focus:ring-indigo-500" aria-labelledby="roster-update-preview-title">
              <h3 id="roster-update-preview-title" className="text-sm font-black text-indigo-950">Review roster update</h3>
              <p className="mt-1 text-xs text-indigo-950">{rosterUpdatePreview.matchedCount} existing identities match. Current groups, learner IDs, codenames, preferences, history, seating, goals and submission keys stay in place. New codenames start unassigned.</p>
              <p className="mt-2 text-xs font-bold text-slate-800">Add {rosterUpdatePreview.additions.length} codenames</p>
              {rosterUpdatePreview.additions.length > 0 && <ul className="mt-1 max-h-32 overflow-y-auto list-disc pl-5 text-xs text-slate-800">{rosterUpdatePreview.additions.map(entry => <li key={entry.learnerId}><span className="font-bold">{entry.codename}</span><span className="block break-all font-mono">{entry.learnerId}</span></li>)}</ul>}
              {rosterUpdatePreview.matches.length > 0 && <details className="mt-2 text-xs text-slate-800"><summary className="cursor-pointer font-bold">Review {rosterUpdatePreview.matchedCount} unchanged identity bindings</summary><ul className="mt-1 max-h-32 overflow-y-auto list-disc pl-5">{rosterUpdatePreview.matches.map(entry => <li key={entry.learnerId}><span className="font-bold">{entry.codename}</span><span className="block break-all font-mono">{entry.learnerId}</span></li>)}</ul></details>}
              <p className="mt-2 text-xs font-bold text-amber-950">Absent from this file: {rosterUpdatePreview.retainedAbsences.length}. Keep these codenames and all their work for teacher review.</p>
              {rosterUpdatePreview.retainedAbsences.length > 0 && <ul className="mt-1 max-h-32 overflow-y-auto list-disc pl-5 text-xs text-amber-950">{rosterUpdatePreview.retainedAbsences.map(entry => <li key={entry.learnerId}>{entry.codename}</li>)}</ul>}
              {rosterUpdatePreview.conflicts.length > 0 && <div role="alert" className="mt-3 rounded-lg border border-red-300 bg-red-50 p-3 text-xs text-red-950"><p className="font-bold">Update blocked: resolve these identity conflicts in the source file.</p><ul className="mt-1 max-h-40 overflow-y-auto list-disc pl-5">{rosterUpdatePreview.conflicts.map((conflict, index) => <li key={conflict.code + index}>{conflict.codename ? conflict.codename + ': ' : ''}{conflict.message}</li>)}</ul></div>}
              <p className="mt-3 text-xs text-slate-700">Use a version 4 AlloFlow export for this same class with reviewed stable learner IDs. A newly generated Google Classroom roster has new IDs and cannot refresh an existing class. Imported settings and history are ignored by this update.</p>
              {rosterUpdatePreview.canApply && <label className="mt-3 flex items-start gap-2 text-xs font-bold text-indigo-950"><input type="checkbox" checked={rosterUpdateAcknowledged} onChange={event => setRosterUpdateAcknowledged(event.target.checked)} className="mt-0.5" /><span>I reviewed these exact codename and learner ID bindings and approve the additions. Absent learners will stay in the roster.</span></label>}
              <div className="mt-3 flex flex-wrap gap-2">
                <button type="button" onClick={cancelRosterUpdate} className="min-h-10 rounded-lg border border-indigo-300 bg-white px-3 text-xs font-bold text-indigo-900 hover:bg-indigo-100">Cancel update</button>
                <button type="button" onClick={confirmRosterUpdate} disabled={!rosterUpdatePreview.canApply || !rosterUpdateAcknowledged || !!rosterUpdateCompletion} className="min-h-10 rounded-lg bg-indigo-700 px-3 text-xs font-bold text-white hover:bg-indigo-800 disabled:opacity-40">Confirm safe update</button>
              </div>
            </section>
          )}
          {rosterImportUndo && (
            <section className="rounded-lg border border-amber-300 bg-amber-50 px-3 py-2" aria-label="Roster import recovery">
              <p className="text-xs font-bold text-amber-950">The pre-import roster ({rosterImportUndo.groupCount} groups, {rosterImportUndo.studentCount} codenames) is available until another import, dismissal, or page reload. It is kept in memory only.</p>
              <div className="mt-2 flex flex-wrap gap-2">
                <button type="button" onClick={handleRestoreRosterImport} className="min-h-10 rounded-lg bg-amber-800 px-3 text-xs font-bold text-white hover:bg-amber-900">Restore previous roster</button>
                <button type="button" onClick={() => { setRosterImportUndo(null); announceRoster('Previous roster recovery dismissed.'); }} className="min-h-10 rounded-lg border border-amber-400 bg-white px-3 text-xs font-bold text-amber-900 hover:bg-amber-100">Dismiss</button>
              </div>
            </section>
          )}
          {showPrintOptions && (
            <section id="roster-print-options" className="rounded-xl border-2 border-cyan-200 bg-cyan-50/70 p-4" aria-labelledby="roster-print-options-title">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h3 id="roster-print-options-title" className="text-sm font-black text-cyan-950">Print worksheet options</h3>
                  <p className="mt-1 text-xs text-cyan-900">Choose the blank-column layout before opening the print dialog.</p>
                </div>
                <button type="button" onClick={() => setShowPrintOptions(false)} className="min-h-9 min-w-9 rounded-full hover:bg-cyan-100" aria-label="Close worksheet options"><X size={16} className="mx-auto" /></button>
              </div>
              <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-3">
                <label className="text-xs font-bold text-cyan-950">Location column
                  <select value={printLocationPosition} onChange={event => setPrintLocationPosition(event.target.value)} className="mt-1 min-h-10 w-full rounded-lg border border-cyan-300 bg-white px-2 text-xs text-slate-900">
                    <option value="after-name">After student name</option>
                    <option value="before-name">Before student name</option>
                    <option value="hidden">Do not print location</option>
                  </select>
                </label>
                <label className="text-xs font-bold text-cyan-950">Writing space
                  <select value={printRowSize} onChange={event => setPrintRowSize(event.target.value)} className="mt-1 min-h-10 w-full rounded-lg border border-cyan-300 bg-white px-2 text-xs text-slate-900">
                    <option value="compact">Compact · 8 mm</option>
                    <option value="standard">Standard · 12 mm</option>
                    <option value="large">Large · 16 mm</option>
                  </select>
                </label>
                <label className="text-xs font-bold text-cyan-950">Order
                  <select value={printSortBy} onChange={event => setPrintSortBy(event.target.value)} className="mt-1 min-h-10 w-full rounded-lg border border-cyan-300 bg-white px-2 text-xs text-slate-900">
                    <option value="codename">Codename</option>
                    <option value="group">Group, then codename (prints group labels)</option>
                  </select>
                </label>
              </div>
              <div className="mt-3 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                <p className="text-[11px] text-cyan-900">These options are temporary. Names and locations remain handwritten and are never stored in AlloFlow.</p>
                <button type="button" onClick={handlePrintRosterWorksheet} disabled={!studentCodenames.length} className="min-h-10 shrink-0 rounded-lg bg-cyan-800 px-3 text-xs font-bold text-white hover:bg-cyan-900 disabled:opacity-40"><Printer size={14} className="mr-1 inline" /> Print with these options</button>
              </div>
            </section>
          )}
          {showBatchConfig && (
            <section className="rounded-xl border-2 border-amber-300 bg-amber-50 p-4" aria-labelledby="roster-batch-title">
              <div className="flex items-start justify-between gap-3"><div><h3 id="roster-batch-title" className="text-sm font-black text-amber-950">Differentiate by group</h3><p className="mt-1 text-xs text-amber-900">Create the selected resource types for every roster group.</p></div><button type="button" onClick={() => setShowBatchConfig(false)} className="min-h-9 min-w-9 rounded-full hover:bg-amber-100" aria-label="Close batch configuration"><X size={16} className="mx-auto" /></button></div>
              <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-2">{Object.keys(batchTypes).map(type => <label key={type} className="flex min-h-10 items-center gap-2 rounded-lg border border-amber-300 bg-white px-3 text-xs font-bold text-amber-950"><input type="checkbox" checked={!!batchTypes[type]} onChange={event => setBatchTypes(previous => ({ ...previous, [type]: event.target.checked }))} /> {type.replace(/-/g, ' ')}</label>)}</div>
              {batchStatus && <p role="alert" className="mt-2 text-xs font-bold text-red-700">{batchStatus}</p>}
              <div className="mt-3 flex flex-col-reverse sm:flex-row sm:justify-end gap-2"><button type="button" onClick={() => setShowBatchConfig(false)} className="min-h-11 rounded-lg border border-slate-400 px-4 text-sm font-bold">Cancel</button><button type="button" onClick={handleRunBatchGenerate} className="min-h-11 rounded-lg bg-amber-700 px-4 text-sm font-bold text-white">Generate for {groupIds.length} group{groupIds.length === 1 ? '' : 's'}</button></div>
            </section>
          )}
          {(studentCodenames.length > 10 || normalizedStudentQuery) && (
            <section className="rounded-xl border border-slate-300 bg-white p-3" aria-label="Find a roster codename">
              <div className="flex flex-col gap-2 sm:flex-row sm:items-end">
                <label htmlFor="roster-student-search" className="flex-1 text-xs font-bold text-slate-700">Find codename
                  <input id="roster-student-search" type="search" value={rosterStudentQuery} maxLength={80} aria-describedby="roster-student-search-status" onChange={event => setRosterStudentQuery(event.target.value)} placeholder="Search codenames…" className="mt-1 min-h-10 w-full rounded-lg border border-slate-400 px-3 text-sm font-normal text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-400" />
                </label>
                {normalizedStudentQuery && <button type="button" onClick={() => setRosterStudentQuery('')} className="min-h-10 rounded-lg border border-slate-300 bg-slate-50 px-3 text-xs font-bold text-slate-700 hover:bg-slate-100">Clear search</button>}
              </div>
              <p id="roster-student-search-status" role="status" aria-live="polite" className="mt-2 text-[11px] text-slate-600">{normalizedStudentQuery ? `${studentMatchCount} of ${studentCodenames.length} codenames match.` : `${studentCodenames.length} codenames available.`}</p>
            </section>
          )}
          {normalizedStudentQuery && studentMatchCount === 0 && <p role="status" className="rounded-xl border border-amber-200 bg-amber-50 p-3 text-xs font-bold text-amber-900">No codenames match “{rosterStudentQuery.trim()}”.</p>}
          {visibleGroupIds.map(gId => {
            const group = groups[gId];
            const gStudents = getStudentsInGroup(gId);
            const shownStudents = gStudents.filter(matchesStudentQuery);
            const isExpanded = expandedGroup === gId;
            return (
              <div key={gId} className="border border-slate-400 rounded-xl overflow-hidden transition-all motion-reduce:transition-none hover:border-indigo-200">
                <button type="button" onClick={() => setExpandedGroup(isExpanded ? null : gId)}
                  aria-expanded={isExpanded} aria-controls={'roster-group-' + gId}
                  className="w-full flex items-center gap-3 p-3 bg-slate-50 hover:bg-slate-100 transition-colors motion-reduce:transition-none text-left">
                  <div className="w-3 h-3 rounded-full shrink-0" style={{ backgroundColor: group.color || '#4F46E5' }} />
                  <div className="flex-1 min-w-0">
                    <div className="font-bold text-sm text-slate-800 truncate">{group.name}</div>
                    <div className="text-[11px] text-slate-600">{normalizedStudentQuery ? `${shownStudents.length} of ${gStudents.length} matching` : `${gStudents.length} student${gStudents.length !== 1 ? 's' : ''}`} · {group.profile?.gradeLevel || '—'} · {group.profile?.leveledTextLanguage || '—'}</div>
                  </div>
                  <ChevronDown size={16} className={`text-slate-600 transition-transform motion-reduce:transition-none ${isExpanded ? 'rotate-180' : ''}`} />
                </button>
                {isExpanded && (
                  <div id={'roster-group-' + gId} className="p-4 space-y-3 border-t border-slate-100 bg-white">
                    <div className="flex flex-col sm:flex-row gap-2 sm:items-center mb-2 min-w-0">
                      <input type="text" value={group.name} maxLength={80} onChange={e => handleUpdateGroupMeta(gId, 'name', e.target.value)}
                        aria-label={t('roster.group_name') || 'Group name'}
                        className="flex-1 px-2 py-1 rounded-lg border border-slate-400 text-sm font-bold focus:ring-2 focus:ring-indigo-400 focus:outline-none" />
                      <div className="flex flex-wrap gap-1">
                        {COLORS.map(c => (
                          <button type="button" key={c} onClick={() => handleUpdateGroupMeta(gId, 'color', c)}
                            className={`w-9 h-9 rounded-full border-2 transition-all motion-reduce:transition-none ${group.color === c ? 'border-slate-800 scale-110' : 'border-transparent hover:scale-105'}`}
                            style={{ backgroundColor: c }}
                            aria-label={(t('roster.set_group_color') || 'Set group color') + ' ' + c}
                            aria-pressed={group.color === c} />
                        ))}
                      </div>
                    </div>
                    <div className="grid grid-cols-1 gap-2 bg-slate-50 p-3 rounded-xl">
                      <ProfileField label={t('roster.grade') || 'Grade'} value={group.profile?.gradeLevel} field="gradeLevel" gId={gId} type="select" options={GRADE_OPTIONS} />
                      <ProfileField label={t('roster.language') || 'Language'} value={group.profile?.leveledTextLanguage} field="leveledTextLanguage" gId={gId} type="select" options={LANG_OPTIONS} />
                      <ProfileField label={t('roster.reading') || 'Reading Lvl'} value={group.profile?.readingLevel} field="readingLevel" gId={gId} />
                      <ProfileField label={t('roster.interests') || 'Interests'} value={group.profile?.studentInterests} field="studentInterests" gId={gId} />
                      <ProfileField label={t('roster.dok') || 'DOK Level'} value={group.profile?.dokLevel} field="dokLevel" gId={gId} type="select" options={['1', '2', '3', '4']} />
                      <ProfileField label={t('roster.tts_speed') || 'TTS Speed'} value={group.profile?.ttsSpeed} field="ttsSpeed" gId={gId} type="range" />
                      <ProfileField label={t('roster.karaoke') || 'Karaoke'} value={group.profile?.karaokeMode} field="karaokeMode" gId={gId} type="toggle" />
                      <ProfileField label="Reading theme" value={group.profile?.readingThemeDefault} field="readingThemeDefault" gId={gId} type="select" options={ALLO_TEACHER_READING_THEME_OPTIONS} />
                      <ProfileField label={t('roster.simplify') || 'Simplify'} value={group.profile?.simplifyLevel} field="simplifyLevel" gId={gId} type="select" options={['basic', 'intermediate', 'advanced']} />
                      <ProfileField label={t('roster.custom') || 'Custom Instr.'} value={group.profile?.leveledTextCustomInstructions} field="leveledTextCustomInstructions" gId={gId} />
                    </div>
                    <div>
                      <div className="text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1.5">{t('roster.students_in_group') || 'Students'}</div>
                      <div className="flex flex-wrap gap-1.5">
                        {shownStudents.map(name => (
                          <span key={name} className="inline-flex max-w-full flex-wrap items-center gap-1 px-2.5 py-1 bg-indigo-50 text-indigo-700 rounded-xl text-xs font-medium">
                            {name}
                            {rosterKey?.progressHistory?.[name]?.length > 0 && (
                              <span className="text-[11px] bg-indigo-100 text-indigo-600 px-1 py-0.5 rounded-full font-mono" title={`${rosterKey.progressHistory[name].length} sessions`}>
                                {rosterKey.progressHistory[name].length}s
                              </span>
                            )}
                            <select value={students[name] || ''} onChange={event => handleMoveStudent(name, event.target.value)} aria-label={'Move ' + name + ' to group'} className="min-h-9 max-w-[10rem] rounded-lg border border-indigo-300 bg-white px-2 text-xs text-indigo-900"><option value="">Unassigned</option>{groupIds.map(id => <option key={id} value={id}>{groups[id].name}</option>)}</select>
                            <button type="button" onClick={() => setReadingPreferencesStudent(name)} className="w-9 h-9 inline-flex items-center justify-center rounded-full hover:bg-indigo-100 hover:text-indigo-900 transition-colors motion-reduce:transition-none" aria-label={'Edit reading preferences for ' + name} title="Reading preferences">
                              <span aria-hidden="true">★</span>
                            </button>
                            <button type="button" onClick={() => handleRemoveStudent(name)} className="min-h-9 rounded-lg border border-red-200 bg-white px-2 text-red-700 hover:bg-red-50 transition-colors motion-reduce:transition-none" aria-label={'Delete ' + name + ' from roster'}>
                              Delete
                            </button>
                          </span>
                        ))}
                        {shownStudents.length === 0 && <span className="text-xs text-slate-600 italic">{normalizedStudentQuery ? 'No matching codenames' : (t('roster.no_students') || 'No students assigned')}</span>}
                      </div>
                    </div>
                    <div className="flex flex-col sm:flex-row gap-2 pt-2 border-t border-slate-100">
                      <button type="button" onClick={() => onApplyGroup(gId)} className="px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-xs font-bold hover:bg-indigo-700 transition-colors motion-reduce:transition-none flex items-center gap-1.5">
                        <Sparkles size={12} /> {t('roster.apply_to_generator') || 'Apply to Generator'}
                      </button>
                      <button type="button" onClick={() => handleRemoveGroup(gId)} className="px-3 py-1.5 bg-red-50 text-red-800 rounded-lg text-xs font-bold hover:bg-red-100 transition-colors motion-reduce:transition-none sm:ml-auto flex items-center gap-1.5">
                        <Trash2 size={12} /> {t('roster.delete_group') || 'Delete Group'}
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
          <div className="flex flex-col sm:flex-row gap-2 sm:items-center p-3 border-2 border-dashed border-slate-200 rounded-xl hover:border-indigo-300 transition-colors motion-reduce:transition-none min-w-0">
            <input type="text" value={newGroupName} maxLength={80} onChange={e => { setNewGroupName(e.target.value); setGroupNameError(''); }}
              placeholder={t('roster.new_group_placeholder') || 'New group name...'}
              aria-label={t('roster.new_group_placeholder') || 'New group name'}
              onKeyDown={e => e.key === 'Enter' && handleAddGroup()}
              className="min-w-0 w-full flex-1 px-3 py-2 rounded-lg border border-slate-400 text-sm focus:ring-2 focus:ring-indigo-400 focus:outline-none" />
            <div className="flex flex-wrap gap-1">
              {COLORS.slice(0, 4).map(c => (
                <button type="button" key={c} onClick={() => setNewGroupColor(c)}
                  className={`w-9 h-9 rounded-full border-2 ${newGroupColor === c ? 'border-slate-800' : 'border-transparent'}`}
                  style={{ backgroundColor: c }}
                  aria-label={(t('roster.new_group_color') || 'New group color') + ' ' + c}
                  aria-pressed={newGroupColor === c} />
              ))}
            </div>
            <button type="button" onClick={handleAddGroup} disabled={!newGroupName.trim() || groupIds.length >= ALLO_ROSTER_MAX_GROUPS} title={groupIds.length >= ALLO_ROSTER_MAX_GROUPS ? 'Maximum ' + ALLO_ROSTER_MAX_GROUPS + ' groups reached' : undefined}
              className="px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-xs font-bold hover:bg-indigo-700 transition-colors motion-reduce:transition-none disabled:opacity-40 flex items-center gap-1">
              <Plus size={14} /> {t('roster.add_group') || 'Add'}
            </button>
          </div>
          {groupNameError && <p role="alert" className="text-xs font-bold text-red-700">{groupNameError}</p>}
          {groupIds.length >= ALLO_ROSTER_MAX_GROUPS && <p role="status" className="text-xs font-bold text-amber-800">Group limit reached ({ALLO_ROSTER_MAX_GROUPS}). Delete an unused group to add another.</p>}
           <div className="mt-4 pt-4 border-t border-slate-100">
             <div className="text-xs font-bold text-slate-600 uppercase tracking-wider mb-2 flex items-center gap-1.5">
               <Users size={14} /> {t('roster.manage_students') || 'Manage Students'}
               <span className="ml-auto text-[11px] font-medium normal-case tracking-normal text-slate-500">{studentCodenames.length}/{ALLO_ROSTER_MAX_STUDENTS}</span>
             </div>
             <div className="flex flex-col gap-2">
               <p className="text-xs text-slate-700">Add a codename only. Use the printable worksheet for a private handwritten name and location mapping.</p>
               <div className="flex flex-col sm:flex-row gap-2 sm:items-center min-w-0">
                 <div className="flex-1 flex flex-col gap-1.5">
                     <div className="flex flex-col sm:flex-row gap-1.5 sm:items-center min-w-0">
                       <select value={rosterAdjIsValid ? rosterAdj : ''} onChange={e => setRosterAdj(e.target.value)}
                         aria-label={t('codenames.pick_adjective') || 'Pick adjective'}
                         className="min-w-0 w-full flex-1 px-2 py-2 rounded-lg border border-slate-400 text-xs focus:ring-2 focus:ring-teal-400 focus:outline-none">
                         <option value="">{t('codenames.pick_adjective') || '— Adjective —'}</option>
                         {rosterAdjectives.map(a => <option key={a} value={a}>{a}</option>)}
                       </select>
                       <select value={rosterAnimalIsValid ? rosterAnimal : ''} onChange={e => setRosterAnimal(e.target.value)}
                         aria-label={t('codenames.pick_animal') || 'Pick animal'}
                         className="min-w-0 w-full flex-1 px-2 py-2 rounded-lg border border-slate-400 text-xs focus:ring-2 focus:ring-teal-400 focus:outline-none">
                         <option value="">{t('codenames.pick_animal') || '— Animal —'}</option>
                         {rosterAnimals.map(a => <option key={a} value={a}>{a}</option>)}
                       </select>
                       <button type="button" onClick={randomizeRosterName} title={t('common.randomize') || 'Randomize'} aria-label={t('common.randomize') || 'Randomize codename'} className="min-h-10 min-w-10 p-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 transition-colors motion-reduce:transition-none">
                         <RefreshCw size={12} />
                       </button>
                     </div>
                   </div>
                 <select value={newStudentGroup} onChange={e => setNewStudentGroup(e.target.value)}
                   aria-label={t('roster.assign_group') || 'Assign to group'}
                   className="w-full sm:w-auto min-h-10 px-2 py-1.5 rounded-lg border border-slate-400 text-xs focus:ring-2 focus:ring-indigo-400 focus:outline-none">
                   <option value="">{t('roster.unassigned') || 'Unassigned'}</option>
                   {groupIds.map(gId => <option key={gId} value={gId}>{groups[gId].name}</option>)}
                 </select>
                 <button type="button" onClick={handleAddStudent} disabled={!rosterAdjIsValid || !rosterAnimalIsValid || studentCodenames.length >= ALLO_ROSTER_MAX_STUDENTS} title={studentCodenames.length >= ALLO_ROSTER_MAX_STUDENTS ? 'Maximum ' + ALLO_ROSTER_MAX_STUDENTS + ' codenames reached' : undefined}
                   className="w-full sm:w-auto min-h-10 px-3 py-1.5 bg-teal-700 text-white rounded-lg text-xs font-bold hover:bg-teal-800 transition-colors motion-reduce:transition-none disabled:opacity-40 flex items-center justify-center gap-1">
                   <Plus size={14} /> {t('roster.add_student') || 'Add'}
                 </button>
               </div>
               {rosterAdjIsValid && rosterAnimalIsValid && (
                 <div className="text-xs text-teal-600 font-medium pl-1">
                   <span>Codename: <strong>{rosterAdj} {rosterAnimal}</strong></span>
                 </div>
               )}
               {studentCodenames.length >= ALLO_ROSTER_MAX_STUDENTS && <p role="status" className="text-xs font-bold text-amber-800">Codename limit reached ({ALLO_ROSTER_MAX_STUDENTS}). Delete an unused codename to add another.</p>}
             </div>
           </div>
          {visibleUnassigned.length > 0 && (
            <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl mt-2">
              <div className="text-[11px] font-bold text-amber-700 uppercase tracking-wider mb-1.5">{t('roster.unassigned_students') || 'Unassigned Students'}</div>
              <div className="flex flex-wrap gap-1.5">
                {visibleUnassigned.map(name => (
                  <span key={name} className="inline-flex max-w-full flex-wrap items-center gap-1 px-2.5 py-1 bg-white text-amber-800 rounded-xl text-xs font-medium border border-amber-200">
                    {name}
                    {rosterKey?.progressHistory?.[name]?.length > 0 && (
                      <span className="text-[11px] bg-amber-100 text-amber-800 px-1 py-0.5 rounded-full font-mono ml-0.5" title={`${rosterKey.progressHistory[name].length} sessions`}>
                        {rosterKey.progressHistory[name].length}s
                      </span>
                    )}
                    <select onChange={e => handleMoveStudent(name, e.target.value)} value={students[name] || ''}
                      aria-label={'Move ' + name + ' to group'}
                      className="min-h-9 max-w-[10rem] rounded-lg border border-amber-300 bg-white px-2 text-[11px] focus:outline-none focus:ring-2 focus:ring-amber-300 cursor-pointer text-amber-800 ml-1">
                      <option value="">Unassigned</option>
                      {groupIds.map(gId => <option key={gId} value={gId}>{groups[gId].name}</option>)}
                    </select>
                    <button type="button" onClick={() => setReadingPreferencesStudent(name)} className="w-9 h-9 inline-flex items-center justify-center rounded-full hover:bg-amber-100 hover:text-amber-950 transition-colors motion-reduce:transition-none" aria-label={'Edit reading preferences for ' + name} title="Reading preferences">
                      <span aria-hidden="true">★</span>
                    </button>
                    <button type="button" onClick={() => handleRemoveStudent(name)} className="min-h-9 rounded-lg border border-red-200 px-2 text-red-700 hover:bg-red-50 transition-colors motion-reduce:transition-none" aria-label={'Delete ' + name + ' from roster'}>
                      Delete
                    </button>
                  </span>
                ))}
              </div>
            </div>
          )}
          {readingPreferencesStudent && (() => {
            const preference = getLearnerReadingPreference(readingPreferencesStudent);
            const favorites = alloNormalizeTeacherReadingFavorites(preference.favoriteReadingThemes);
            const groupId = students[readingPreferencesStudent];
            const groupDefault = alloNormalizeTeacherReadingTheme(groups[groupId]?.profile?.readingThemeDefault, '');
            const fallbackTheme = groupDefault || alloNormalizeTeacherReadingTheme(rosterKey?.readingThemeDefault, 'default');
            const fallbackLabel = ALLO_TEACHER_READING_THEME_OPTIONS.find(option => option.id === fallbackTheme)?.label || 'Default';
            return (
              <section className="rounded-xl border-2 border-violet-200 bg-violet-50/70 p-4" aria-labelledby="roster-reading-preferences-title">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h3 id="roster-reading-preferences-title" className="text-sm font-black text-violet-950">Reading preferences · {readingPreferencesStudent}</h3>
                    <p className="mt-1 text-xs text-violet-800">Use neutral preferences only. The learner can privately change these choices at any time.</p>
                  </div>
                  <button type="button" onClick={() => setReadingPreferencesStudent(null)} className="min-h-9 min-w-9 inline-flex items-center justify-center rounded-full bg-white text-violet-800 hover:bg-violet-100 focus:outline-none focus:ring-2 focus:ring-violet-500" aria-label="Close reading preferences">
                    <X size={14} />
                  </button>
                </div>
                <label className="mt-3 block text-xs font-bold text-violet-950">Preferred reading theme
                  <select value={preference.readingTheme || ''} onChange={event => handleSetLearnerReadingTheme(readingPreferencesStudent, event.target.value)} className="mt-1 min-h-10 w-full rounded-lg border border-violet-300 bg-white px-3 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-violet-500">
                    <option value="">Use group/class default ({fallbackLabel})</option>
                    {ALLO_TEACHER_READING_THEME_OPTIONS.map(option => <option key={option.id} value={option.id}>{option.label}</option>)}
                  </select>
                </label>
                <fieldset className="mt-3">
                  <legend className="text-xs font-bold text-violet-950">Favorite themes</legend>
                  <p className="mt-0.5 text-[11px] text-violet-800">Favorites appear first in this learner's reading-theme picker.</p>
                  <div className="mt-2 flex flex-wrap gap-2">
                    {ALLO_TEACHER_READING_THEME_OPTIONS.map(option => {
                      const selected = favorites.includes(option.id);
                      return <button type="button" key={option.id} onClick={() => handleToggleLearnerReadingFavorite(readingPreferencesStudent, option.id)} aria-pressed={selected} className={`min-h-9 rounded-full border px-3 text-xs font-bold transition-colors motion-reduce:transition-none ${selected ? 'border-violet-700 bg-violet-700 text-white' : 'border-violet-300 bg-white text-violet-900 hover:bg-violet-100'}`}>{selected ? '★ ' : '☆ '}{option.label}</button>;
                    })}
                  </div>
                </fieldset>
                <div className="mt-3 flex items-center justify-between gap-3 border-t border-violet-200 pt-3">
                  <span className="text-[11px] text-violet-800">Choice priority: learner → saved preference → group → class → device.</span>
                  <button type="button" onClick={() => handleResetLearnerReadingPreference(readingPreferencesStudent)} className="min-h-9 shrink-0 rounded-lg border border-violet-300 bg-white px-3 text-xs font-bold text-violet-900 hover:bg-violet-100">Reset to defaults</button>
                </div>
              </section>
            );
          })()}
          {Array.isArray(rosterKey?.sessionHistory) && rosterKey.sessionHistory.length > 0 && (
            <details className="rounded-xl border border-cyan-200 bg-cyan-50/60 p-3">
              <summary className="cursor-pointer font-bold text-sm text-cyan-900">Saved session history ({rosterKey.sessionHistory.length})</summary>
              <div role="group" className="mt-3 rounded-lg border border-cyan-100 bg-white p-2" aria-label="Saved session history filters">
                <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                  <label className="text-[11px] font-bold text-cyan-900">Focus
                    <select value={sessionHistoryFocus} onChange={event => setSessionHistoryFocus(event.target.value)} className="mt-1 min-h-9 w-full rounded-lg border border-cyan-300 bg-white px-2 text-xs text-slate-800" aria-label="Filter saved sessions by follow-up focus">
                      <option value="all">All saved sessions</option>
                      <option value="follow_up">Needs follow-up</option>
                      <option value="revision">Revision opportunities</option>
                      <option value="celebrate">Celebrate progress</option>
                      <option value="planned">Has follow-up plan</option>
                    </select>
                  </label>
                  <label className="text-[11px] font-bold text-cyan-900">Activity
                    <select value={sessionHistoryActivityKind} onChange={event => setSessionHistoryActivityKind(event.target.value)} className="mt-1 min-h-9 w-full rounded-lg border border-cyan-300 bg-white px-2 text-xs text-slate-800" aria-label="Filter saved sessions by activity type">
                      <option value="all">All activity types</option>
                      {sessionActivityKinds.map(kind => <option key={kind} value={kind}>{kind.replace(/_/g, ' ')}</option>)}
                    </select>
                  </label>
                </div>
              </div>
              <div className="mt-3 space-y-2">
                {filteredSessionHistory.length === 0 && <p className="rounded-lg border border-cyan-100 bg-white p-3 text-xs text-slate-600">No saved sessions match these filters.</p>}
                {filteredSessionHistory.slice(0, 10).map(session => (
                  <details key={session.id} className="rounded-lg border border-cyan-100 bg-white p-2">
                    <summary className="cursor-pointer text-xs font-bold text-slate-700 flex flex-wrap gap-x-2">
                      <span>{session.endedAt ? new Date(session.endedAt).toLocaleString() : 'Saved session'}</span>
                      <span className="text-cyan-700">{Object.keys(session.participants || {}).length} present</span>
                      <span className="text-slate-500">{session.mode === 'mailbox' ? 'Mailbox' : 'Firebase'}</span>
                    </summary>
                    <div className="mt-2 text-xs text-slate-600 space-y-1">
                      <div className="flex justify-end">
                        <button type="button" onClick={() => downloadRosterSessionEvidenceCsv(session)} className="min-h-9 rounded-lg border border-cyan-300 bg-cyan-50 px-2 py-1 text-[11px] font-bold text-cyan-900 hover:bg-cyan-100" aria-label="Download this privacy-safe session evidence report as CSV">Download evidence CSV</button>
                      </div>
                      {typeof session.durationMinutes === 'number' && <p>Duration: {session.durationMinutes} min</p>}
                      <div className="rounded-lg border border-violet-100 bg-violet-50/60 p-2" data-session-follow-up-planner={session.id}>
                        <p className="font-bold text-violet-900">Post-session follow-up</p>
                        <p className="mt-0.5 text-[11px] text-violet-700">Local planning only. Nothing is sent or assigned until you choose an action.</p>
                        <label className="mt-2 block text-[11px] font-bold text-slate-700">Codename-only private note
                          <textarea
                            value={noteDraftFor(session)}
                            onChange={event => setSessionNoteDrafts(previous => ({ ...previous, [session.id]: event.target.value.slice(0, 1000) }))}
                            rows={2}
                            maxLength={1000}
                            aria-label={'Codename-only follow-up note for session ' + session.id}
                            className="mt-1 w-full rounded-lg border border-violet-200 bg-white p-2 text-xs text-slate-800"
                          />
                          <span className="mt-1 block font-normal text-violet-700">Use codenames only. This note is stored on this device and included in roster backups.</span>
                        </label>
                        <button type="button" onClick={() => saveSessionNote(session)} className="min-h-9 rounded-lg border border-violet-300 bg-white px-2 text-[11px] font-bold text-violet-900">Save codename note</button>
                        {(() => {
                          const draft = planDraftFor(session);
                          const savedPlan = normalizeRosterSessionFollowUpPlan(session.followUpPlan);
                          const savedResource = savedPlan && safeFollowUpResources.find(item => item.id === savedPlan.resourceId);
                          const supportCohorts = (session.insightBrief?.evidenceCohorts || []).filter(cohort => cohort && cohort.intent === 'support');
                          const savedAudienceKey = savedPlan?.audience === 'cohort' && savedPlan.cohortCode ? 'cohort:' + savedPlan.cohortCode : 'class';
                          const planDirty = !!savedPlan && (draft.resourceId !== savedPlan.resourceId || draft.audienceKey !== savedAudienceKey);
                          const liveSending = sessionLiveSendingId === session.id;
                          const liveActionInFlight = Boolean(sessionLiveSendingId);
                          const canSendToLive = Boolean(activeSessionCode && savedPlan && savedPlan.status !== 'completed' && savedResource && !planDirty && typeof onSendFollowUpToLiveSession === 'function');
                          const liveActionLabel = savedPlan?.audience === 'cohort' ? 'Assign to current live cohort' : 'Present to current live class';
                          return (
                            <div className="mt-2 border-t border-violet-100 pt-2">
                              {safeFollowUpResources.length === 0 && <p className="mb-2 rounded-lg border border-amber-200 bg-amber-50 p-2 text-[11px] text-amber-900">Create or restore a student-safe resource in History to prepare this follow-up. Any saved plan remains available to review or clear.</p>}
                              <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                                <label className="text-[11px] font-bold text-slate-700">Existing resource
                                  <select value={draft.resourceId} disabled={safeFollowUpResources.length === 0 || liveSending} onChange={event => setSessionPlanDrafts(previous => ({ ...previous, [session.id]: { ...draft, resourceId: event.target.value } }))} aria-label={'Choose follow-up resource for session ' + session.id} className="mt-1 min-h-9 w-full rounded-lg border border-violet-200 bg-white px-2 text-xs text-slate-800 disabled:bg-slate-100">
                                    {safeFollowUpResources.length === 0 && <option value="">No student-safe resources in History</option>}
                                    {safeFollowUpResources.map(item => <option key={item.id} value={item.id}>{item.title || item.type || 'Untitled resource'}</option>)}
                                  </select>
                                </label>
                                <label className="text-[11px] font-bold text-slate-700">Planned audience
                                  <select value={draft.audienceKey} disabled={liveSending} onChange={event => setSessionPlanDrafts(previous => ({ ...previous, [session.id]: { ...draft, audienceKey: event.target.value } }))} aria-label={'Choose follow-up audience for session ' + session.id} className="mt-1 min-h-9 w-full rounded-lg border border-violet-200 bg-white px-2 text-xs text-slate-800">
                                    <option value="class">Whole class</option>
                                    {supportCohorts.map(cohort => <option key={cohort.code} value={'cohort:' + cohort.code}>{cohort.label} ({cohort.count})</option>)}
                                  </select>
                                </label>
                              </div>
                              <p className="mt-2 text-[11px] text-slate-600">Planned audience is a private distribution reminder. Prepared links are shareable, not recipient-restricted. When a live session is active, the explicit live action below re-resolves current recipients before using the existing class or individual delivery controls.</p>
                              {planDirty && <p role="status" className="mt-2 text-[11px] font-bold text-amber-800">Save your plan changes before opening, assigning, or presenting this resource.</p>}
                              <div className="mt-2 flex flex-wrap gap-2">
                                <button type="button" onClick={() => saveSessionPlan(session)} disabled={safeFollowUpResources.length === 0 || liveSending} className="min-h-9 rounded-lg border border-violet-300 bg-violet-100 px-2 text-[11px] font-bold text-violet-900 disabled:cursor-not-allowed disabled:opacity-50">Save follow-up plan</button>
                                {savedResource && typeof onOpenFollowUpResource === 'function' && <button type="button" onClick={() => onOpenFollowUpResource(savedResource)} disabled={planDirty || liveSending} className="min-h-9 rounded-lg border border-sky-300 bg-sky-50 px-2 text-[11px] font-bold text-sky-900 disabled:cursor-not-allowed disabled:opacity-50">Open planned resource</button>}
                                {savedResource && typeof onPrepareFollowUpAssignment === 'function' && <button type="button" onClick={() => onPrepareFollowUpAssignment(savedResource)} disabled={planDirty || liveSending} className="min-h-9 rounded-lg border border-emerald-300 bg-emerald-50 px-2 text-[11px] font-bold text-emerald-900 disabled:cursor-not-allowed disabled:opacity-50">Prepare assignment link</button>}
                                {canSendToLive && <button type="button" onClick={() => sendSessionPlanToLive(session)} disabled={liveActionInFlight} aria-label={liveActionLabel + ' from saved follow-up plan'} className="min-h-9 rounded-lg border border-fuchsia-300 bg-fuchsia-50 px-2 text-[11px] font-bold text-fuchsia-900 disabled:cursor-not-allowed disabled:opacity-50">{liveSending ? (savedPlan.audience === 'cohort' ? 'Assigning…' : 'Presenting…') : liveActionLabel}</button>}
                                {savedPlan && <button type="button" onClick={() => setSessionPlanStatus(session, savedPlan.status === 'completed' ? 'planned' : 'completed')} disabled={planDirty || liveSending} className="min-h-9 rounded-lg border border-slate-300 bg-white px-2 text-[11px] font-bold text-slate-700 disabled:cursor-not-allowed disabled:opacity-50">{savedPlan.status === 'completed' ? 'Reopen plan' : 'Mark complete'}</button>}
                                {savedPlan && <button type="button" onClick={() => clearSessionPlan(session)} disabled={liveSending} className="min-h-9 rounded-lg border border-rose-200 bg-white px-2 text-[11px] font-bold text-rose-700 disabled:cursor-not-allowed disabled:opacity-50">Clear plan</button>}
                              </div>
                              {savedPlan && <p className="mt-2 text-[11px] text-violet-800"><span className="font-bold">{savedPlan.status === 'completed' ? 'Completed' : 'Planned'}:</span> {savedPlan.resourceTitle} · {savedPlan.cohortLabel}{!savedResource ? ' · resource no longer available in History' : ''}</p>}
                            </div>
                          );
                        })()}
                        {sessionPlannerStatus[session.id] && <p role="status" aria-live="polite" className="mt-2 text-[11px] font-bold text-violet-800">{sessionPlannerStatus[session.id]}</p>}
                      </div>
                      {Array.isArray(session.liveActivities) && session.liveActivities.length > 0 && (
                        <p><span className="font-bold">Live activity evidence:</span> {session.liveActivities.length} activit{session.liveActivities.length === 1 ? 'y' : 'ies'} · {session.liveActivities.reduce((sum, activity) => sum + (activity.submitted || 0), 0)} submissions · {session.liveActivities.reduce((sum, activity) => sum + (activity.revised || 0), 0)} revisions</p>
                      )}
                      {session.organizerActivity && (
                        <p><span className="font-bold">Visual organizer:</span> {String(session.organizerActivity.type || 'organizer').replace(/3d$/i, ' 3D')} · {session.organizerActivity.statusCounts?.complete || 0} complete · {session.organizerActivity.statusCounts?.attempted || 0} attempted · {(session.organizerActivity.followUpCodenames || []).length} launch follow-up</p>
                      )}
                      {session.insightBrief && (
                        <div className="rounded-lg border border-indigo-100 bg-indigo-50/70 p-2">
                          <p><span className="font-bold text-indigo-900">Insight brief:</span> {session.insightBrief.activityCount || 0} activities · {session.insightBrief.submissions || 0} submissions · {session.insightBrief.revisions || 0} revisions · {(session.insightBrief.followUpCodenames || []).length} follow-up</p>
                          {Array.isArray(session.insightBrief.evidenceCohorts) && session.insightBrief.evidenceCohorts.length > 0 && (
                            <div role="group" className="mt-2 space-y-1" aria-label="Saved evidence cohorts">
                              {session.insightBrief.evidenceCohorts.map(cohort => (
                                <details key={cohort.code} className={'rounded border p-1.5 ' + (cohort.intent === 'celebrate' ? 'border-emerald-200 bg-emerald-50' : 'border-amber-200 bg-amber-50')}>
                                  <summary className="cursor-pointer font-bold text-slate-700">{cohort.label} - {cohort.count}</summary>
                                  <p className="mt-1 text-[11px] text-slate-600">{cohort.recommendedAction}</p>
                                  <p className="mt-1 text-[11px] text-slate-600">{(cohort.codenames || []).join(', ')}</p>
                                </details>
                              ))}
                            </div>
                          )}
                          {Array.isArray(session.insightBrief.groups) && session.insightBrief.groups.some(group => group.followUpCount > 0) && (
                            <p><span className="font-bold">Group patterns:</span> {session.insightBrief.groups.filter(group => group.followUpCount > 0).map(group => `${groups[group.groupId]?.name || group.groupId}: ${group.followUpCount} follow-up`).join(' · ')}</p>
                          )}
                          {Array.isArray(session.insightBrief.nextMoves) && session.insightBrief.nextMoves.length > 0 && (
                            <ul className="mt-1 list-disc pl-4">
                              {session.insightBrief.nextMoves.map(move => <li key={move.code}>{move.label}</li>)}
                            </ul>
                          )}
                        </div>
                      )}
                      {Array.isArray(session.classGoals) && session.classGoals.length > 0 && (
                        <p><span className="font-bold">Class Goals met:</span> {session.classGoals.map(goal => `${goal.label} (${goal.mode === 'independent' ? goal.delivered + ' students' : '+' + goal.tokens + ' each, ' + goal.delivered + ' students'})`).join(' · ')}</p>
                      )}
                      {Object.entries(session.participants || {}).map(([codename, record]) => (
                        <p key={codename}><span className="font-bold">{codename}</span>: {record.responseCount || 0} quiz response{record.responseCount === 1 ? '' : 's'}{record.liveActivityCount ? ` · ${record.liveSubmissionCount || 0}/${record.liveActivityCount} activity submissions` : ''}{record.liveRevisionCount ? ` · ${record.liveRevisionCount} revision${record.liveRevisionCount === 1 ? '' : 's'}` : ''}{record.organizer ? ` · organizer ${record.organizer.status}${record.organizer.total ? ` ${record.organizer.correct}/${record.organizer.total}` : ''}` : ''}{record.groupId ? ` · group ${record.groupId}` : ''}</p>
                      ))}
                      {Number(session.unmatchedCount || 0) > 0 && <p className="text-rose-700"><span className="font-bold">Unmatched entries:</span> {session.unmatchedCount} (typed values were not retained)</p>}
                    </div>
                  </details>
                ))}
                {filteredSessionHistory.length > 10 && <p className="text-[11px] text-cyan-800">Showing the 10 most recent matching sessions of {filteredSessionHistory.length}. Export JSON for the complete retained history.</p>}
              </div>
            </details>
          )}          {rosterKey && (
            <div className="flex flex-wrap gap-3 pt-3 border-t border-slate-100 text-[11px] text-slate-600 font-medium">
              <span>{groupIds.length} group{groupIds.length !== 1 ? 's' : ''}</span>
              <span>{Object.keys(students).length} student{Object.keys(students).length !== 1 ? 's' : ''}</span>
              <span>{getUnassigned().length} unassigned</span>
              {rosterStorageError ? <span role="alert" className="sm:ml-auto flex items-center gap-1 font-bold text-red-700"><AlertTriangle size={12} /> {rosterStorageError}</span> : <span className="sm:ml-auto flex items-center gap-1"><ShieldCheck size={10} className="text-green-500" /> Saved on this device · codenames only</span>}
            </div>
          )}
        </div>
        {submissionDialog && (
          <div className="absolute inset-0 z-20 bg-slate-900/70 flex items-center justify-center p-4">
            <div ref={submissionDialogRef} role="alertdialog" aria-modal="true" aria-labelledby="offline-submission-dialog-title" aria-describedby="offline-submission-dialog-description"
              onKeyDown={event => {
                if (event.key === 'Escape') { event.preventDefault(); closeSubmissionDialog(); return; }
                if (event.key !== 'Tab') return;
                const focusable = Array.from(event.currentTarget.querySelectorAll('button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'));
                if (!focusable.length) { event.preventDefault(); return; }
                const first = focusable[0];
                const last = focusable[focusable.length - 1];
                if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
                else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
              }}
              className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl">
              <h3 id="offline-submission-dialog-title" className="text-lg font-black text-slate-900">
                {submissionDialog.kind === 'confirm' ? 'Replace the class submission key?' : submissionDialog.kind === 'error' ? 'Offline submission setup failed' : 'Offline submissions are ready'}
              </h3>
              <div id="offline-submission-dialog-description" className="mt-3 space-y-3 text-sm text-slate-700">
                {submissionDialog.kind === 'confirm' ? (<><p>This class already has offline submissions set up.</p><p>Generating a new key invalidates the old key. Student files saved with the old key will no longer be decryptable.</p></>) : submissionDialog.kind === 'error' ? (<><p>{submissionDialog.message}</p><p>No class key was changed. Close this message and try again when you are ready.</p></>) : (<><p>Save the downloaded class-key file in a safe place, such as your class Google Drive folder. You cannot open student submissions without it.</p><p>AlloFlow does not keep a copy. Lost keys and their encrypted submissions cannot be recovered.</p></>)}
              </div>
              <div className="mt-6 flex flex-wrap justify-end gap-3">
                {submissionDialog.kind === 'confirm' ? (<><button type="button" data-safe-default="true" onClick={closeSubmissionDialog} className="min-h-11 rounded-lg border border-slate-400 px-4 py-2 font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500">Keep existing key</button><button type="button" onClick={handleSetupOfflineSubmissions} className="min-h-11 rounded-lg bg-red-700 px-4 py-2 font-bold text-white focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2">Replace key</button></>) : (<button type="button" onClick={closeSubmissionDialog} className="min-h-11 rounded-lg bg-indigo-700 px-4 py-2 font-bold text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2">{submissionDialog.kind === 'error' ? 'Close' : 'Done'}</button>)}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
});
// @section CHARTS — Bar charts and longitudinal progress
const SimpleBarChart = React.memo(({ data, color = "indigo" }) => {
  const { t } = useContext(LanguageContext);
  const height = 150;
  const width = 300;
  const margin = 20;
  const chartHeight = height - margin * 2;
  const chartWidth = width - margin * 2;
  if (!data || data.length === 0) return <div className="text-xs text-slate-600 italic text-center py-8">{t('dashboard.empty.no_data')}</div>;
  const maxValue = Math.max(...data.map(d => d.value), 1);
  const barWidth = Math.min(40, (chartWidth / data.length) * 0.6);
  const gap = (chartWidth - (barWidth * data.length)) / (data.length + 1);
  return (
    <div className="w-full h-full flex items-center justify-center select-none">
      <svg role="img" aria-label={data.map(d => `${d.label}: ${d.value}`).join(', ')} viewBox={`0 0 ${width} ${height}`} className="w-full h-auto max-h-[160px]" preserveAspectRatio="xMidYMid meet">
        {data.map((d, i) => {
          const barHeight = (d.value / maxValue) * chartHeight;
          const x = gap + i * (barWidth + gap);
          const y = height - margin - barHeight;
          return (
            <g key={i} className="group">
              <rect
                x={x}
                y={y}
                width={barWidth}
                height={barHeight}
                rx="4"
                className={`fill-${color}-500 group-hover:fill-${color}-600 transition-all motion-reduce:transition-none duration-300`}
              />
              <text
                x={x + barWidth / 2}
                y={y - 5}
                textAnchor="middle"
                className="fill-slate-500 text-[11px] font-bold opacity-0 group-hover:opacity-100 transition-opacity motion-reduce:transition-none"
              >
                {d.value}
              </text>
              <text
                x={x + barWidth / 2}
                y={height - 5}
                textAnchor="middle"
                className="fill-slate-400 text-[11px] uppercase tracking-wider font-medium"
              >
                {d.label.length > 5 ? d.label.substring(0, 4) + '.' : d.label}
              </text>
            </g>
          );
        })}
        <line x1="0" y1={height - margin} x2={width} y2={height - margin} stroke="#e2e8f0" strokeWidth="2" strokeLinecap="round" />
      </svg>
    </div>
  );
});
const SimpleDonutChart = ({ percentage, label, color = "indigo" }) => {
  const size = 100;
  const strokeWidth = 10;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const safePercent = Math.min(100, Math.max(0, percentage || 0));
  const offset = circumference - (safePercent / 100) * circumference;
  return (
    <div role="progressbar" aria-label={label} aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(safePercent)} className="flex flex-col items-center justify-center select-none">
      <div className="relative w-24 h-24">
        <svg aria-hidden="true" focusable="false" viewBox={`0 0 ${size} ${size}`} className="transform -rotate-90 w-full h-full">
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            className="stroke-slate-100 fill-none"
            strokeWidth={strokeWidth}
          />
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            className={`stroke-${color}-500 fill-none transition-all motion-reduce:transition-none duration-1000 ease-out`}
            strokeWidth={strokeWidth}
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            strokeLinecap="round"
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className={`text-xl font-black text-${color}-600`}>{Math.round(safePercent)}%</span>
        </div>
      </div>
      <span className="text-xs font-bold text-slate-600 uppercase tracking-wider mt-2 text-center leading-tight">{label}</span>
    </div>
  );
};
const ConfettiEffect = ({ isActive }) => {
  if (!isActive) return null;
  const colors = ['#f43f5e', '#8b5cf6', '#3b82f6', '#22c55e', '#f59e0b', '#ec4899'];
  const particles = Array.from({ length: 50 }, (_, i) => ({
    id: i,
    color: colors[i % colors.length],
    left: Math.random() * 100,
    delay: Math.random() * 2,
    size: Math.random() * 8 + 4,
    duration: Math.random() * 2 + 2
  }));
  return (
    <div className="absolute inset-0 motion-reduce:hidden pointer-events-none z-[10001] overflow-hidden" aria-hidden="true">
      <style>{`
        @keyframes confetti-fall {
          0% { transform: translateY(-100px) rotate(0deg); opacity: 1; }
          100% { transform: translateY(100vh) rotate(720deg); opacity: 0; }
        }
        .confetti-particle {
          position: absolute;
          top: -20px;
          animation: confetti-fall linear forwards;
        }
        @media (prefers-reduced-motion: reduce) {
          .confetti-particle { animation: none !important; display: none !important; }
        }
      `}</style>
      {particles.map(p => (
        <div
          key={p.id}
          className="confetti-particle"
          style={{
            left: `${p.left}%`,
            width: p.size,
            height: p.size,
            backgroundColor: p.color,
            animationDelay: `${p.delay}s`,
            animationDuration: `${p.duration}s`,
            borderRadius: Math.random() > 0.5 ? '50%' : '0%',
          }}
        />
      ))}
    </div>
  );
};
// @section ESCAPE_ROOM — Escape Room student overlay
const StudentConceptQuestOverlay = React.memo(({ sessionData, user, activeSessionCode, targetAppId, t, playSound }) => {
  const tr = (key, fallback, params = {}) => {
    const fullKey = `concept_quest.${key}`;
    const translated = typeof t === 'function' ? t(fullKey, params) : '';
    if (typeof translated === 'string' && translated && translated !== fullKey) return translated;
    return Object.keys(params).reduce((text, name) => text.replace(`{${name}}`, params[name]), fallback);
  };
  const gameLabel = (entry, type, field = 'name') => {
    if (!entry) return '';
    const suffix = field === 'description' ? 'description' : 'name';
    const key = entry[`${field}Key`] || (entry.id ? `${type}_${entry.id}_${suffix}` : '');
    return key ? tr(key, entry[field] || '') : (entry[field] || '');
  };
  const escapeState = sessionData?.escapeRoomState;
  const quest = escapeState?.conceptQuest;
  const engine = window.AlloModules?.ConceptQuestEngine;
  const [abilityId, setAbilityId] = useState('analyze');
  const [answerIndex, setAnswerIndex] = useState(null);
  const [supportId, setSupportId] = useState('clarify');
  const [supportTargetUid, setSupportTargetUid] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [questSyncError, setQuestSyncError] = useState('');
  const questWriteRef = useRef('');
  const [localAction, setLocalAction] = useState(null);
  const encounterFocusRef = useRef(null);
  const pauseFocusRef = useRef(null);
  const currentScopeRef = useRef('');
  const turnKey = engine?.getTurnKey?.(quest) || quest?.turnKey || String(quest?.turn || 0);
  const actionScope = activeSessionCode + ':' + turnKey;
  currentScopeRef.current = actionScope;
  const userTeam = escapeState?.teams?.[user?.uid];
  const progress = escapeState?.teamProgress?.All || {};
  const currentRoom = engine?.getRoom?.(quest, quest?.currentRoomId);
  const rooms = quest?.rooms || [];
  const validVotes = engine?.currentVotes?.(quest, progress.questVotes, progress.questVoteTurns) || {};
  const myVote = validVotes[user?.uid];
  const validActions = engine?.currentActions?.(quest, progress.questActions) || {};
  const myAction = validActions[user?.uid] || (localAction?.scope === actionScope ? localAction.value : null);
  const myRole = progress.questRoles?.[user?.uid];
  const peerRoster = Object.entries(sessionData?.roster || {}).filter(([uid, entry]) => entry && uid !== user?.uid).map(([uid, entry]) => ({ ...entry, uid }));

  useEffect(() => {
    if (!escapeState?.isActive || !user?.uid || !activeSessionCode || userTeam === 'All') return;
    const assign = async () => {
      try {
        const sessionRef = doc(db, 'artifacts', targetAppId, 'public', 'data', 'sessions', activeSessionCode);
        await updateDoc(sessionRef, { [`escapeRoomState.teams.${user.uid}`]: 'All' });
      } catch (error) { warnLog('Concept Quest party assignment failed:', error); }
    };
    assign();
  }, [escapeState?.isActive, user?.uid, activeSessionCode, targetAppId, userTeam]);

  useEffect(() => {
    setAnswerIndex(null); setLocalAction(null); setQuestSyncError(''); setIsSubmitting(false); questWriteRef.current = '';
  }, [actionScope]);
  useEffect(() => {
    if (!myAction) return;
    setAnswerIndex(myAction.answerIndex); setAbilityId(myAction.abilityId);
    setSupportId(myAction.supportId || 'clarify'); setSupportTargetUid(myAction.supportTargetUid || '');
  }, [myAction?.turnKey, myAction?.submittedAt, myAction?.answerIndex]);
  useEffect(() => {
    if (escapeState?.isPaused) pauseFocusRef.current?.focus();
    else encounterFocusRef.current?.focus();
  }, [actionScope, quest?.phase, escapeState?.isPaused]);
  useEffect(() => {
    if (supportTargetUid && !peerRoster.some(entry => entry.uid === supportTargetUid)) setSupportTargetUid('');
  }, [supportTargetUid, sessionData?.roster]);

  if (!quest || !engine || escapeState?.isActive === false) return null;
  const writeChoice = async (field, value) => {
    if (!user?.uid || !activeSessionCode || !escapeState.isActive || escapeState.isPaused || questWriteRef.current || !['explore', 'battle'].includes(quest.phase)) return;
    if (field === 'questActions' && (myAction || quest.phase !== 'battle')) return;
    if (field === 'questVotes' && quest.phase !== 'explore') return;
    if (field === 'questRoles' && myAction) return;
    const requestScope = actionScope;
    questWriteRef.current = requestScope; setQuestSyncError('');
    setIsSubmitting(true);
    try {
      const sessionRef = doc(db, 'artifacts', targetAppId, 'public', 'data', 'sessions', activeSessionCode);
      const updates = { [`escapeRoomState.teamProgress.All.${field}.${user.uid}`]: value };
      if (field === 'questVotes' && quest.actionSchema === 1) updates[`escapeRoomState.teamProgress.All.questVoteTurns.${user.uid}`] = turnKey;
      await updateDoc(sessionRef, updates);
      if (currentScopeRef.current === requestScope && field === 'questActions') setLocalAction({ scope: requestScope, value });
      playSound?.('click');
    } catch (error) { warnLog('Concept Quest action failed:', error); if (currentScopeRef.current === requestScope) setQuestSyncError(tr('choice_sync_failed', 'Your choice could not be saved. Try again when the connection returns.')); }
    finally { if (questWriteRef.current === requestScope) { questWriteRef.current = ''; setIsSubmitting(false); } }
  };
  const currentEnemy = currentRoom?.enemy;
  const adjacent = (currentRoom?.neighbors || []).map(id => rooms.find(room => room.id === id)).filter(Boolean);
  const partyHpPercent = Math.round((quest.party.hp / quest.party.maxHp) * 100);
  const enemyHpPercent = currentEnemy ? Math.round((currentEnemy.hp / currentEnemy.maxHp) * 100) : 0;
  const debrief = engine.createDebrief?.(quest);
  const neededSigils = engine.requiredSigils(quest);

  return (
    <div className="fixed inset-0 z-[9999] overflow-auto bg-gradient-to-br from-slate-950 via-indigo-950 to-purple-950 text-white" role="region" aria-labelledby="concept-quest-title">
      {questSyncError && <p role="alert" className="m-3 rounded-lg bg-red-950 p-3 text-red-100">{questSyncError}</p>}
      {escapeState.isPaused && <div ref={pauseFocusRef} tabIndex={-1} role="status" className="sticky top-0 z-30 border-b border-amber-300 bg-amber-100 p-3 text-center font-bold text-amber-900">{tr('paused_notice', 'Quest paused. Your choices are saved while the teacher prepares the next step.')}</div>}
      <header className="sticky top-0 z-20 border-b border-indigo-400/30 bg-slate-950/95 p-3 backdrop-blur">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3">
          <div><h2 id="concept-quest-title" className="text-xl font-black">🗺️ {quest.title}</h2><p className="text-xs text-indigo-200">{tr('turn_room', 'Turn {turn} · {room}', { turn: quest.turn, room: currentRoom?.name || '' })}</p></div>
          <div role="group" className="flex flex-wrap gap-3 text-sm font-bold" aria-label={tr('party_health_aria', 'Party health {current} of {maximum}', { current: quest.party.hp, maximum: quest.party.maxHp })}><span>❤️ {quest.party.hp}/{quest.party.maxHp}</span><span>🛡️ {quest.party.shield || 0}</span><span>✨ {quest.party.xp || 0} XP</span><span>🔷 {(quest.sigils || []).length}/{neededSigils}</span></div>
        </div>
        <div role="progressbar" aria-label={tr('party_hp', 'Party HP')} aria-valuemin={0} aria-valuemax={quest.party.maxHp} aria-valuenow={quest.party.hp} className="mx-auto mt-2 h-2 max-w-6xl overflow-hidden rounded-full bg-slate-700"><div className="h-full bg-emerald-500 transition-all motion-reduce:transition-none" style={{ width: `${partyHpPercent}%` }} /></div>
      </header>
      <main className="mx-auto grid max-w-6xl gap-5 p-4 lg:grid-cols-[1.25fr_.75fr]">
        <section className="rounded-2xl border border-indigo-400/30 bg-slate-900/80 p-4" aria-labelledby="quest-map-heading">
          <h3 id="quest-map-heading" className="mb-3 text-lg font-black">{tr('cooperative_map', 'Cooperative map')}</h3>
          <div role="group" className="relative grid grid-cols-2 gap-2 rounded-xl border border-slate-700 bg-slate-950/70 p-2 sm:block sm:h-[360px] sm:p-0" aria-label={tr('map_aria', 'Eight-room game map')}>
            <svg aria-hidden="true" className="pointer-events-none absolute inset-0 hidden h-full w-full sm:block" viewBox="0 0 100 100" preserveAspectRatio="none">{rooms.flatMap(room => (room.neighbors || []).filter(id => id > room.id).map(id => { const other = rooms.find(entry => entry.id === id); return other ? <line key={room.id + id} x1={room.x} y1={room.y} x2={other.x} y2={other.y} stroke="#64748b" strokeWidth="0.5"/> : null; }))}</svg>
            {rooms.map(room => {
              const isCurrent = room.id === quest.currentRoomId;
              const isVisited = (quest.visited || []).includes(room.id);
              const isAdjacent = (currentRoom?.neighbors || []).includes(room.id);
              const isLocked = room.kind === 'boss' && (quest.sigils || []).length < (neededSigils);
              const lockedSuffix = isLocked ? tr('room_locked_suffix', ', locked until more concept sigils are earned') : '';
              const currentSuffix = isCurrent ? tr('room_current_suffix', ', current room') : '';
              return <button key={room.id} type="button" disabled={!isAdjacent || isLocked || quest.phase !== 'explore' || escapeState.isPaused || isSubmitting} onClick={() => writeChoice('questVotes', room.id)} style={{ left: `clamp(3.5rem, ${room.x}%, calc(100% - 3.5rem))`, top: `${room.y}%` }} className={`min-h-20 min-w-0 break-words sm:absolute sm:min-h-14 sm:w-24 sm:-translate-x-1/2 sm:-translate-y-1/2 rounded-xl border-2 p-1 text-center text-[11px] font-bold focus:outline-none focus:ring-4 focus:ring-yellow-300 ${isCurrent ? 'border-yellow-300 bg-yellow-500 text-slate-900' : isAdjacent && !isLocked ? 'border-cyan-300 bg-indigo-800 hover:bg-indigo-700' : isVisited ? 'border-emerald-500 bg-slate-800' : 'border-slate-600 bg-slate-900 text-slate-300'} disabled:cursor-default`} aria-pressed={myVote === room.id} aria-current={isCurrent ? 'location' : undefined} aria-label={tr('room_aria', '{name}, {kind}{locked}{current}', { name: room.name, kind: tr(`room_kind_${room.kind}`, room.kind), locked: lockedSuffix, current: currentSuffix })}><span className="block text-xl" aria-hidden="true">{isLocked ? '🔒' : room.emoji}</span>{room.name}</button>;
            })}
          </div>
          <div className="mt-3 rounded-xl bg-indigo-950/60 p-3"><p className="font-bold">{currentRoom?.emoji} {currentRoom?.name}</p><p className="text-sm text-indigo-100">{tr('concept_label', 'Concept: {concept}', { concept: currentRoom?.concept || '' })}</p>
            <div className="mt-3"><p className="mb-2 text-sm font-bold">{tr('choose_role', 'Choose a party role')}</p><div className="grid grid-cols-2 gap-2">{(quest.roles || engine.ROLES || []).map(role => <button key={role.id} type="button" disabled={!!myAction || isSubmitting || escapeState.isPaused || !['explore', 'battle'].includes(quest.phase)} onClick={() => { setAbilityId(role.abilityId); writeChoice('questRoles', role.id); }} aria-pressed={myRole === role.id} className={`min-h-14 rounded-lg border p-2 text-left text-xs focus:ring-4 focus:ring-yellow-300 ${myRole === role.id ? 'border-emerald-300 bg-emerald-900' : 'border-slate-600 bg-slate-800'}`}><strong>{role.emoji} {gameLabel(role, 'role')}</strong><span className="mt-1 block text-slate-300">{gameLabel(role, 'role', 'description')}</span></button>)}</div></div>
            {quest.phase === 'explore' && <div className="mt-3"><p className="mb-2 text-sm">{tr('vote_instruction', 'Vote for a connected room. Earn {count} concept sigils to unlock the Mastery Gate.', { count: neededSigils })}</p><div className="flex flex-wrap gap-2">{adjacent.map(room => { const locked = room.kind === 'boss' && (quest.sigils || []).length < (neededSigils); return <button key={room.id} type="button" disabled={isSubmitting || escapeState.isPaused || locked} onClick={() => writeChoice('questVotes', room.id)} className={`min-h-11 rounded-lg px-3 py-2 text-sm font-bold focus:ring-4 focus:ring-yellow-300 disabled:opacity-50 ${myVote === room.id ? 'bg-yellow-400 text-slate-950' : 'bg-indigo-700 hover:bg-indigo-600'}`}>{locked ? '🔒' : room.emoji} {room.name}</button>; })}</div>{myVote && <p role="status" className="mt-2 text-sm text-yellow-200">{tr('vote_recorded', 'Your vote is recorded.')}</p>}</div>}
          </div>
        </section>
        <section className={`space-y-4 lg:col-start-2 lg:row-start-1 ${quest.phase === 'battle' ? 'order-first lg:order-none' : ''}`} aria-label={tr('current_encounter_aria', 'Current encounter')}>
          <h3 ref={encounterFocusRef} tabIndex={-1} className="text-lg font-black focus:outline-none focus:ring-2 focus:ring-yellow-300">{tr('phase_' + quest.phase, quest.phase === 'battle' ? 'Choose your action' : quest.phase === 'explore' ? 'Choose a path together' : quest.phase === 'defeat' ? 'Regroup with your teacher' : 'Quest complete')}</h3>
          {isSubmitting && <p role="status" className="text-sm text-cyan-200">{tr('saving_choice', 'Saving your choice…')}</p>}
          {quest.activeEvent && <div className="rounded-2xl border-2 border-amber-300 bg-amber-950/70 p-4" role="status" aria-live="polite"><p className="text-xs font-black uppercase text-amber-300">{tr('teacher_event', 'Teacher GM event')}</p><h3 className="text-lg font-black">{quest.activeEvent.title}</h3><p className="mt-1 text-sm">{quest.activeEvent.description}</p></div>}
          {quest.lastRound && <div className="rounded-2xl border border-cyan-400/40 bg-cyan-950/60 p-4" role="status" aria-live="polite"><p className="font-black">{tr('round_recap', 'Round recap: {correct}/{total} checks succeeded', { correct: quest.lastRound.correct, total: quest.lastRound.total })}</p><p className="mt-1 text-sm">{tr('damage_recap', 'The party dealt {damage} damage and took {incoming}.', { damage: quest.lastRound.damage, incoming: quest.lastRound.incoming })}</p>{quest.lastRound.combo && <p className="mt-1 font-bold text-yellow-200">⚡ {tr('combo_full', 'Concept Combo! Three different abilities worked together.')}</p>}{quest.lastRound.synergyCount > 0 && <p className="text-sm text-emerald-200">{tr('role_synergies_activated', '{count} role synergies activated.', { count: quest.lastRound.synergyCount })}</p>}{quest.lastRound.assistedCount > 0 && <p className="text-sm text-sky-200">🤝 {tr('peer_assists_activated', '{count} peer assists activated.', { count: quest.lastRound.assistedCount })}</p>}{quest.lastRound.encounterRule && <p className="mt-1 rounded-lg bg-slate-900/60 p-2 text-sm text-cyan-100">{quest.lastRound.encounterRule}</p>}<details className="mt-2 text-sm"><summary className="cursor-pointer font-bold">{tr('review_concept', 'Review the concept')}</summary><p className="mt-1 font-bold text-cyan-100">{quest.lastRound.prompt}</p><p className="mt-1 text-cyan-100">{quest.lastRound.explanation}</p></details></div>}
          {quest.phase === 'battle' && currentEnemy && <div className="rounded-2xl border border-fuchsia-400/40 bg-slate-900 p-4">
            <div className="text-center"><div className="text-6xl" aria-hidden="true">{currentEnemy.emoji}</div><h3 className="text-xl font-black">{currentEnemy.name}</h3><p className="text-sm text-fuchsia-200">{tr('misconception_about', 'A misconception about {concept}', { concept: currentRoom.concept })}</p>{currentRoom.kind === 'puzzle' && <p className="mt-1 text-xs font-bold text-cyan-200">{tr('reasoning_lock_student', 'Reasoning Lock: reach two-thirds class consensus for bonus damage.')}</p>}{currentRoom.kind === 'boss' && <p className="mt-1 text-xs font-bold text-yellow-200">{tr('mastery_barrier_student', 'Mastery Barrier: reach 60% class accuracy to break through.')}</p>}</div>
            <div role="progressbar" aria-valuemin={0} aria-valuemax={currentEnemy.maxHp} aria-valuenow={currentEnemy.hp} className="my-3 h-3 overflow-hidden rounded-full bg-slate-700" aria-label={tr('enemy_health_aria', 'Enemy health {current} of {maximum}', { current: currentEnemy.hp, maximum: currentEnemy.maxHp })}><div className="h-full bg-fuchsia-500" style={{ width: `${enemyHpPercent}%` }} /></div>
            <fieldset disabled={!!myAction || isSubmitting || escapeState.isPaused} className="space-y-3"><legend className="font-bold">{currentRoom.challenge.prompt}</legend>
              <div className="grid grid-cols-2 gap-2">{(quest.abilities || []).map(ability => <button type="button" key={ability.id} onClick={() => setAbilityId(ability.id)} aria-pressed={abilityId === ability.id} className={`min-h-16 rounded-lg border p-2 text-left text-xs focus:ring-4 focus:ring-yellow-300 ${abilityId === ability.id ? 'border-cyan-300 bg-cyan-900' : 'border-slate-600 bg-slate-800'}`}><span className="font-black">{ability.emoji} {gameLabel(ability, 'ability')}</span><span className="mt-1 block text-slate-300">{gameLabel(ability, 'ability', 'description')}</span></button>)}</div>
              <div className="space-y-2">{currentRoom.challenge.options.map((option, index) => <label key={index} className={`flex min-h-11 cursor-pointer items-center gap-2 rounded-lg border p-2 text-sm ${answerIndex === index ? 'border-yellow-300 bg-yellow-950' : 'border-slate-600 bg-slate-800'}`}><input type="radio" name="concept-quest-answer" checked={answerIndex === index} onChange={() => setAnswerIndex(index)} />{option}</label>)}</div>
              {peerRoster.length > 0 && <div className="rounded-xl border border-sky-500/40 bg-sky-950/50 p-3"><p className="font-bold text-sky-100">{tr('support_teammate', 'Support a teammate')}</p><p className="text-xs text-sky-200">{tr('support_optional', 'Optional: a correct response can help one classmate this turn.')}</p><div className="mt-2 grid grid-cols-3 gap-1">{(quest.supports || engine.SUPPORTS || []).map(support => <button key={support.id} type="button" onClick={() => setSupportId(support.id)} aria-pressed={supportId === support.id} className={`min-h-11 rounded-lg border p-1 text-xs font-bold ${supportId === support.id ? 'border-sky-300 bg-sky-800' : 'border-slate-600 bg-slate-800'}`}>{support.emoji} {gameLabel(support, 'support')}</button>)}</div><label className="mt-2 block text-xs font-bold text-sky-100">{tr('teammate', 'Teammate')}<select value={supportTargetUid} onChange={event => setSupportTargetUid(event.target.value)} className="mt-1 min-h-11 w-full rounded-lg border border-sky-400 bg-slate-900 p-2 text-white"><option value="">{tr('no_assist', 'No assist this turn')}</option>{peerRoster.map(peer => <option key={peer.uid} value={peer.uid}>{peer.name || tr('classmate', 'Classmate')}</option>)}</select></label></div>}
              <button type="button" onClick={() => answerIndex != null && writeChoice('questActions', { abilityId, roleId: myRole || '', answerIndex, submittedAt: Date.now(), ...(quest.actionSchema === 1 ? { turnKey } : {}), ...(supportTargetUid ? { supportId, supportTargetUid } : {}) })} disabled={answerIndex == null} className="min-h-12 w-full rounded-xl bg-emerald-600 px-4 py-2 font-black hover:bg-emerald-500 disabled:opacity-50">{tr('commit_turn', 'Commit turn')}</button>
            </fieldset>{myAction && <p role="status" className="mt-3 rounded-lg bg-emerald-950 p-2 text-center text-sm text-emerald-200">{tr('committed_notice', 'Turn committed. Discuss your reasoning while the co-GM resolves the round.')}</p>}
          </div>}
          {quest.phase === 'complete' && <div className="rounded-2xl border-2 border-yellow-300 bg-emerald-950 p-6 text-center" role="status"><div className="text-6xl">🏆</div><h3 className="text-2xl font-black">{tr('gate_cleared', 'Mastery Gate cleared!')}</h3><p>{tr('class_won', 'The class won by combining its ideas.')}</p>{debrief && <><div className="mt-4 grid grid-cols-2 gap-2 text-sm sm:grid-cols-3"><span className="rounded-lg bg-emerald-900 p-2"><strong className="block text-xl">{debrief.accuracy}%</strong>{tr('accuracy', 'Accuracy')}</span><span className="rounded-lg bg-emerald-900 p-2"><strong className="block text-xl">{debrief.combos}</strong>{tr('combos', 'Combos')}</span><span className="rounded-lg bg-emerald-900 p-2"><strong className="block text-xl">{debrief.roleSynergies}</strong>{tr('role_synergies', 'Role synergies')}</span><span className="rounded-lg bg-emerald-900 p-2"><strong className="block text-xl">{debrief.peerAssists}</strong>{tr('peer_assists', 'Peer assists')}</span><span className="rounded-lg bg-emerald-900 p-2"><strong className="block text-xl">{debrief.puzzlesSolved}</strong>{tr('puzzles', 'Puzzles')}</span><span className="rounded-lg bg-emerald-900 p-2"><strong className="block text-xl">{debrief.rounds}</strong>{tr('rounds', 'Rounds')}</span></div>{debrief.strongestConcept && <p className="mt-3 text-sm text-emerald-100">{tr('strongest_concept', 'Strongest concept: {concept} ({accuracy}%)', { concept: debrief.strongestConcept.concept, accuracy: debrief.strongestConcept.accuracy })}</p>}</>}</div>}
          {quest.phase === 'defeat' && <div className="rounded-2xl border-2 border-rose-400 bg-rose-950 p-6 text-center" role="alert"><h3 className="text-2xl font-black">{tr('regroup_title', 'The party needs a regroup')}</h3><p>{tr('regroup_body', 'The teacher can introduce help, an item, or a new challenge—this is not an individual loss.')}</p></div>}
          <div className="rounded-2xl border border-slate-700 bg-slate-900 p-4"><h3 className="font-black">{tr('shared_inventory', 'Shared inventory')}</h3>{quest.inventory.length ? <ul className="mt-2 space-y-2 text-sm">{quest.inventory.map((item, index) => <li key={`${item.id}-${index}`} className="rounded-lg bg-slate-800 p-2">{item.emoji} <strong>{item.name}</strong> — {item.description}</li>)}</ul> : <p className="mt-2 text-sm text-slate-300">{tr('inventory_empty', 'Items awarded or generated by the teacher appear here.')}</p>}</div>
        </section>
      </main>
    </div>
  );
});

// Leaf writes keep simultaneous teammates from replacing one another's progress.
function alloLiveEscapeProgress(raw = {}, puzzles = []) {
  const solvedPuzzles = [...new Set([...(raw.solvedPuzzles || []), ...Object.values(raw.solved || {}).filter(id => puzzles.some(p => p.id === id))])];
  if (raw.progressVersion !== 2) return { ...raw, solvedPuzzles };
  const maxLives = Number.isFinite(raw.maxLives) ? raw.maxLives : 3;
  const wrongAttempts = Object.keys(raw.misses || {}).length;
  const lives = maxLives >= 99 ? maxLives : Math.max(0, maxLives - wrongAttempts);
  return { ...raw, solvedPuzzles, maxLives, lives, wrongAttempts,
    streak: Object.values(raw.solvedAt || {}).filter(at => at > Math.max(0, ...Object.values(raw.misses || {}).filter(Number.isFinite), ...Object.values(raw.hintedAt || {}).filter(Number.isFinite))).length,
    hintsRemaining: Math.max(0, (raw.maxHints ?? 3) - Object.values(raw.revealedHints || {}).filter(Boolean).length),
    isGameOver: maxLives < 99 && lives <= 0,
    isEscaped: puzzles.length > 0 && puzzles.every(p => solvedPuzzles.includes(p.id)) };
}
function alloLiveEscapeSeconds(state, now = Date.now()) {
  if (state?.isGameOver) return 0;
  if (!state?.isPaused && Number.isFinite(state?.endsAt)) return Math.max(0, Math.ceil((state.endsAt - now) / 1000));
  return Math.max(0, Number(state?.timeRemaining) || 0);
}
function useLiveEscapeSeconds(state) {
  const [now, setNow] = useState(Date.now);
  useEffect(() => {
    setNow(Date.now());
    if (!state?.isActive || state.isPaused || state.isGameOver || !Number.isFinite(state.endsAt)) return;
    const timer = setInterval(() => setNow(Date.now()), 250);
    return () => clearInterval(timer);
  }, [state?.isActive, state?.isPaused, state?.isGameOver, state?.endsAt]);
  return alloLiveEscapeSeconds(state, now);
}
function alloLiveEscapeAnswer(puzzle, answer, type) {
  const normalize = value => String(value ?? '').normalize('NFC').trim().replace(/\s+/g, ' ').toLocaleLowerCase();
  if (type === 'mcq') return Number.isInteger(answer) && answer === puzzle.correctIndex;
  if (type === 'sequence') return Array.isArray(answer) && JSON.stringify(answer) === JSON.stringify(puzzle.correctOrder);
  if (type === 'matching') return Array.isArray(answer) && answer.length === puzzle.pairs?.length
    && new Set(answer.map(pair => pair.left)).size === answer.length
    && new Set(answer.map(pair => pair.right)).size === answer.length
    && answer.every(pair => puzzle.pairs.some(expected => expected.left === pair.left && expected.right === pair.right));
  return !!normalize(answer) && [puzzle.answer, ...(puzzle.acceptedAnswers || [])].some(value => value != null && normalize(value) === normalize(answer));
}
function alloLiveSequenceIndices(puzzle) {
  const items = puzzle?.items || [];
  const shuffled = puzzle?.shuffledItems || [];
  if (shuffled.length === items.length && shuffled.every(Number.isInteger) && new Set(shuffled).size === items.length && shuffled.every(i => i >= 0 && i < items.length)) return shuffled.slice();
  const unused = items.map((_, i) => i);
  const indices = shuffled.map(item => { const at = unused.findIndex(i => items[i] === item); return at < 0 ? -1 : unused.splice(at, 1)[0]; });
  return indices.length === items.length && !indices.includes(-1) ? indices : items.map((_, i) => i);
}
function alloLiveFieldKey(value) { return encodeURIComponent(String(value)).replace(/\./g, '%2E'); }

const ClassicStudentEscapeRoomOverlay = React.memo(({ sessionData, user, activeSessionCode, targetAppId, t, playSound, setIsEscapeTimerRunning }) => {
  const escapeState = sessionData?.escapeRoomState || {};
  const timeRemaining = useLiveEscapeSeconds(escapeState);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [syncError, setSyncError] = useState('');
  const submissionRef = useRef(false);
  const draftsRef = useRef({});
  const [selectedPuzzle, setSelectedPuzzle] = useState(null);
  const [userInput, setUserInput] = useState('');
  const [sequenceOrder, setSequenceOrder] = useState([]);
  const [matchingPairs, setMatchingPairs] = useState([]);
  const [matchingSelected, setMatchingSelected] = useState(null);
  const [showConfetti, setShowConfetti] = useState(false);
  const [teamEscapeToast, setTeamEscapeToast] = useState(null);
  const [lastEscapedTeams, setLastEscapedTeams] = useState([]);
  const puzzleDialogRef = useRef(null);
  const puzzleTriggerRef = useRef(null);
  const escapeStateScreenRef = useRef(null);
  const escapeMainRef = useRef(null);
  const pauseDialogRef = useRef(null);
  const wasPausedRef = useRef(false);
  useEffect(() => {
    if (!selectedPuzzle) return;
    puzzleDialogRef.current?.querySelector('[data-initial-focus="true"]')?.focus();
  }, [selectedPuzzle]);
  const closePuzzleDialog = () => {
    const puzzle = (escapeState.puzzles || []).find(p => p.linkedObjectId === selectedPuzzle || p.id === selectedPuzzle);
    if (puzzle) draftsRef.current[puzzle.id] = { input: userInput, sequence: sequenceOrder, pairs: matchingPairs, selected: matchingSelected };
    setSelectedPuzzle(null);
    window.setTimeout(() => { if (!puzzleTriggerRef.current?.disabled) puzzleTriggerRef.current?.focus(); else escapeMainRef.current?.focus(); }, 0);
  };
  const openPuzzleDialog = (event, objectId) => {
    puzzleTriggerRef.current = event.currentTarget;
    const puzzle = (escapeState.puzzles || []).find(p => p.linkedObjectId === objectId || p.id === objectId);
    if (!puzzle || escapeState.isPaused || submissionRef.current) return;
    const draft = draftsRef.current[puzzle.id] || {};
    setUserInput(draft.input || '');
    setSequenceOrder(draft.sequence || alloLiveSequenceIndices(puzzle));
    setMatchingPairs(draft.pairs || []);
    setMatchingSelected(draft.selected || null);
    setSyncError('');
    setSelectedPuzzle(objectId);
  };
  const formatTime = (seconds) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };
  const isCoopMode = escapeState.isCoopMode || false;
  const isPaused = escapeState.isPaused || false;
  const userTeam = escapeState.teams?.[user?.uid];
  const teamProgress = alloLiveEscapeProgress(escapeState.teamProgress?.[userTeam], escapeState.puzzles || []);
  const solvedPuzzlesSet = new Set(teamProgress.solvedPuzzles || []);
  const teamMaxLives = Number.isFinite(teamProgress.maxLives) ? teamProgress.maxLives : 3;
  const teamLives = Number.isFinite(teamProgress.lives) ? teamProgress.lives : teamMaxLives;
  const teamWrongAttempts = teamProgress.wrongAttempts || 0;
  const teamStreak = teamProgress.streak || 0;
  const teamGameOver = teamProgress.isGameOver || false;
  const teamHintsRemaining = Number.isFinite(teamProgress.hintsRemaining) ? teamProgress.hintsRemaining : 3;
  const teamRevealedHints = teamProgress.revealedHints || {};
  const allTeams = Object.keys(escapeState.teamProgress || {});
  const puzzles = escapeState.puzzles || [];
  const objects = escapeState.objects || [];
  const teamEscaped = teamProgress.isEscaped;
  const roomTimedOut = !isPaused && timeRemaining <= 0 && Number.isFinite(escapeState.endsAt);
  const teamColors = {
    Red: { bg: 'bg-red-500', text: 'text-red-500', border: 'border-red-500', light: 'bg-red-100' },
    Blue: { bg: 'bg-blue-500', text: 'text-blue-500', border: 'border-blue-500', light: 'bg-blue-100' },
    Green: { bg: 'bg-green-500', text: 'text-green-500', border: 'border-green-500', light: 'bg-green-100' },
    Yellow: { bg: 'bg-yellow-500', text: 'text-yellow-500', border: 'border-yellow-500', light: 'bg-yellow-100' },
    All: { bg: 'bg-purple-500', text: 'text-purple-500', border: 'border-purple-500', light: 'bg-purple-100' }
  };
  const myTeamColors = teamColors[userTeam] || teamColors.Blue;
  useEffect(() => {
    const completedState = escapeState.isGameOver || roomTimedOut || teamGameOver || teamEscaped;
    if (!userTeam || completedState) escapeStateScreenRef.current?.focus();
    else if (isPaused) pauseDialogRef.current?.focus();
    else if (wasPausedRef.current) {
      if (puzzleDialogRef.current) puzzleDialogRef.current.querySelector('[data-initial-focus="true"]')?.focus();
      else escapeMainRef.current?.focus();
    }
    wasPausedRef.current = isPaused;
  }, [userTeam, escapeState.isGameOver, roomTimedOut, teamGameOver, teamEscaped, isPaused]);
  useEffect(() => {
    const escapedTeams = allTeams.filter(team =>
      alloLiveEscapeProgress(escapeState.teamProgress?.[team], puzzles).isEscaped && team !== userTeam
    );
    const newEscapes = escapedTeams.filter(t => !lastEscapedTeams.includes(t));
    if (newEscapes.length > 0 && !teamEscaped) {
      playSound?.('notification');
      setTeamEscapeToast(newEscapes[0]);
      const _toastTimer = setTimeout(() => setTeamEscapeToast(null), 4000);
      return () => clearTimeout(_toastTimer);
    }
    setLastEscapedTeams(escapedTeams);
  }, [escapeState.teamProgress]);
  useEffect(() => {
    if (teamEscaped) {
      playSound?.('levelUp');
      setShowConfetti(true);
      const _confettiTimer = setTimeout(() => setShowConfetti(false), 5000);
      return () => clearTimeout(_confettiTimer);
    }
  }, [teamEscaped]);
  useEffect(() => {
    if (escapeState?.isActive && user && activeSessionCode && !userTeam) {
      const teamOptions = isCoopMode ? ['All'] : ['Red', 'Blue', 'Green', 'Yellow'];
      const assignedColor = teamOptions[Math.floor(Math.random() * teamOptions.length)];
      const joinTeam = async () => {
        try {
          const effectiveAppId = targetAppId || appId;
          const sessionRef = doc(db, 'artifacts', effectiveAppId, 'public', 'data', 'sessions', activeSessionCode);
          await updateDoc(sessionRef, {
            [`escapeRoomState.teams.${user.uid}`]: assignedColor
          });
        } catch (e) {
          warnLog("Escape room team assignment failed:", e);
        }
      };
      joinTeam();
    }
  }, [escapeState?.isActive, user, activeSessionCode, userTeam, targetAppId, isCoopMode]);
  useEffect(() => {
    draftsRef.current = {};
    setSelectedPuzzle(null); setUserInput(''); setSequenceOrder([]); setMatchingPairs([]); setMatchingSelected(null); setSyncError('');
  }, [activeSessionCode, escapeState.startedAt, userTeam]);
  const handleSubmitAnswer = async (puzzleId, answer, answerType) => {
    if (!userTeam || !activeSessionCode || submissionRef.current || isPaused || !escapeState.isActive || escapeState.isGameOver || teamGameOver || teamEscaped || timeRemaining <= 0) return;
    const puzzle = puzzles.find(p => p.id === puzzleId);
    if (!puzzle || solvedPuzzlesSet.has(puzzleId) || (typeof answer === 'string' && !answer.trim())) return;
    const isCorrect = alloLiveEscapeAnswer(puzzle, answer, answerType);
    submissionRef.current = true; setIsSubmitting(true); setSyncError('');
    try {
    if (isCorrect) {
      playSound?.('correct');
      try {
        const effectiveAppId = targetAppId || appId;
        const sessionRef = doc(db, 'artifacts', effectiveAppId, 'public', 'data', 'sessions', activeSessionCode);
        const newSolvedPuzzles = [...(teamProgress.solvedPuzzles || []), puzzleId];
        const allSolved = newSolvedPuzzles.length >= puzzles.length;
        const newStreak = teamStreak + 1;
        await updateDoc(sessionRef, teamProgress.progressVersion === 2 ? {
          [`escapeRoomState.teamProgress.${userTeam}.solved.${alloLiveFieldKey(puzzleId)}`]: puzzleId,
          [`escapeRoomState.teamProgress.${userTeam}.solvedAt.${alloLiveFieldKey(puzzleId)}`]: Date.now()
        } : {
          [`escapeRoomState.teamProgress.${userTeam}.solvedPuzzles`]: newSolvedPuzzles,
          [`escapeRoomState.teamProgress.${userTeam}.isEscaped`]: allSolved,
          [`escapeRoomState.teamProgress.${userTeam}.streak`]: newStreak
        });
        if (allSolved) {
          setIsEscapeTimerRunning?.(false);
        }
        closePuzzleDialog();
        setUserInput('');
        setSequenceOrder([]);
        setMatchingPairs([]);
      } catch (e) {
        throw e;
      }
    } else {
      playSound?.('incorrect');
      try {
        const effectiveAppId = targetAppId || appId;
        const sessionRef = doc(db, 'artifacts', effectiveAppId, 'public', 'data', 'sessions', activeSessionCode);
        // Legacy live sessions may not have team life fields. Treat a missing
        // value as a full three-life pool so the first miss can never become
        // an accidental immediate game over.
        const newLives = teamMaxLives < 99 ? Math.max(0, teamLives - 1) : teamLives;
        const isGameOver = newLives <= 0 && teamMaxLives < 99;
        const missId = alloLiveFieldKey(user?.uid || 'student') + '_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 8);
        await updateDoc(sessionRef, teamProgress.progressVersion === 2 ? {
          [`escapeRoomState.teamProgress.${userTeam}.misses.${missId}`]: Date.now()
        } : {
          [`escapeRoomState.teamProgress.${userTeam}.lives`]: newLives,
          [`escapeRoomState.teamProgress.${userTeam}.maxLives`]: teamMaxLives,
          [`escapeRoomState.teamProgress.${userTeam}.streak`]: 0,
          [`escapeRoomState.teamProgress.${userTeam}.wrongAttempts`]: teamWrongAttempts + 1,
          [`escapeRoomState.teamProgress.${userTeam}.isGameOver`]: isGameOver
        });
      } catch (e) {
        throw e;
      }
    }
    } catch (error) {
      warnLog('Live escape room submission failed:', error);
      setSyncError('Your answer could not be saved. Your work is still here; try submitting again.');
    } finally { submissionRef.current = false; setIsSubmitting(false); }
  };
  if ((!escapeState.isActive && !escapeState.isGameOver) || !escapeState.room) return null;
  if (!userTeam) {
    return (
      <div ref={escapeStateScreenRef} tabIndex={-1} role="status" aria-live="polite" aria-busy="true" className="fixed top-0 right-0 bottom-0 left-0 z-[9999] bg-gradient-to-br from-purple-900 via-slate-900 to-indigo-900 flex items-center justify-center focus:outline-none focus:ring-4 focus:ring-inset focus:ring-white">
        <div className="text-center text-white">
          <RefreshCw className="w-12 h-12 animate-spin motion-reduce:animate-none mx-auto mb-4 text-purple-700" aria-hidden="true" />
          <p className="text-xl font-bold">{t('escape_room.waiting_host')}</p>
        </div>
      </div>
    );
  }
  if ((escapeState.isGameOver || roomTimedOut || teamGameOver) && !teamEscaped) {
    return (
      <div ref={escapeStateScreenRef} tabIndex={-1} role="alert" aria-labelledby="escape-room-game-over-title" aria-describedby="escape-room-game-over-description" className="fixed top-0 right-0 bottom-0 left-0 z-[9999] bg-gradient-to-br from-red-900 via-slate-900 to-gray-900 flex items-center justify-center focus:outline-none focus:ring-4 focus:ring-inset focus:ring-white">
        <div className="text-center text-white animate-in motion-reduce:animate-none zoom-in duration-500">
          <div className="text-9xl mb-6 animate-pulse motion-reduce:animate-none">💀</div>
          <h2 id="escape-room-game-over-title" className="text-5xl font-black mb-4 text-red-600">{t('escape_room.game_over')}</h2>
          <p id="escape-room-game-over-description" className="text-2xl text-slate-300 mb-6">{t((escapeState.isGameOver || roomTimedOut) && !teamGameOver ? 'escape_room.time_up' : 'escape_room.life_lost')}</p><p className="text-slate-200 mb-6">{t('escape_room.waiting_host')}</p>
          <div className="flex gap-4 justify-center text-lg">
            <span className="px-4 py-2 bg-slate-800 rounded-lg">
              {t('escape_room.puzzles_remaining')}: {puzzles.length - solvedPuzzlesSet.size}
            </span>
            <span className="px-4 py-2 bg-slate-800 rounded-lg">
              {t('escape_room.wrong_attempts')}: {teamWrongAttempts}
            </span>
          </div>
        </div>
      </div>
    );
  }
  if (teamEscaped) {
    const isFirstToEscape = allTeams.filter(team =>
      alloLiveEscapeProgress(escapeState.teamProgress?.[team], puzzles).isEscaped
    ).length === 1;
    return (
      <div ref={escapeStateScreenRef} tabIndex={-1} role="status" aria-labelledby="escape-room-escaped-title" aria-describedby="escape-room-escaped-description" className="fixed top-0 right-0 bottom-0 left-0 z-[9999] bg-gradient-to-br from-green-900 via-emerald-900 to-teal-900 flex items-center justify-center focus:outline-none focus:ring-4 focus:ring-inset focus:ring-white">
        <ConfettiEffect isActive={showConfetti} />
        <div className="text-center text-white animate-in motion-reduce:animate-none zoom-in duration-500">
          <div className="text-9xl mb-6 animate-bounce motion-reduce:animate-none">{isFirstToEscape ? '🏆' : '🎉'}</div>
          <h2 id="escape-room-escaped-title" className="text-5xl font-black mb-4">
            {isCoopMode ? t('escape_room.class_escaped') : (isFirstToEscape ? t('escape_room.first_escape') : t('escape_room.escaped'))}
          </h2>
          <p id="escape-room-escaped-description" className="text-2xl text-green-200">
            {isCoopMode ? t('escape_room.everyone_escaped') : t('escape_room.team_escaped', { team: userTeam })}
          </p>
          {!isCoopMode && (
            <div className={`mt-6 inline-flex items-center gap-2 px-6 py-3 rounded-full ${myTeamColors.bg} text-white font-bold text-xl`}>
              {t('escape_room.your_team')}: {userTeam}
            </div>
          )}
        </div>
      </div>
    );
  }
  const currentPuzzle = selectedPuzzle ? puzzles.find(p => p.linkedObjectId === selectedPuzzle || p.id === selectedPuzzle) : null;
  return (
    <div ref={escapeMainRef} tabIndex={-1} role="region" aria-labelledby="escape-room-active-title" className="fixed top-0 right-0 bottom-0 left-0 z-[9999] bg-gradient-to-br from-slate-900 via-purple-900 to-indigo-900 overflow-auto focus:outline-none focus:ring-4 focus:ring-inset focus:ring-white">
      <div className="sticky top-0 z-50 bg-slate-900/90 backdrop-blur-sm border-b border-purple-500/30 p-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-3">
            <DoorOpen className="text-purple-400" size={24} />
            <h2 id="escape-room-active-title" className="text-white font-bold text-lg">{escapeState.room?.theme || t('escape_room.title')}</h2>
          </div>
          <div className="flex items-center flex-wrap gap-3">
            <div className={`flex items-center gap-2 px-3 py-1.5 rounded-full ${myTeamColors.bg} text-white font-bold text-sm`} data-help-key="escape_room_team">
              <Users size={14} />
              {t(`escape_room.team_${userTeam.toLowerCase()}`, { defaultValue: `${userTeam} Team` })}
            </div>
            <div className="text-white font-mono" data-help-key="escape_room_progress">
              <span className="text-purple-300">{solvedPuzzlesSet.size}</span>
              <span className="text-slate-400">/{puzzles.length}</span>
            </div>
            {teamMaxLives < 99 && (
              <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-slate-700/50" role="img" aria-label={`${t('escape_room.lives')}: ${teamLives}/${teamMaxLives}`} title={t('escape_room.lives')} data-help-key="escape_room_lives">
                {Array.from({ length: teamMaxLives }).map((_, i) => (
                  <span key={i} aria-hidden="true" className={`text-sm ${i < teamLives ? 'text-red-500' : 'opacity-30 grayscale'}`}>
                    ❤️
                  </span>
                ))}
              </div>
            )}
            <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-slate-700/50" title={t('escape_room.hints_used')}>
              <Lightbulb size={14} className="text-yellow-400" />
              <span className="text-white text-xs font-bold">{teamHintsRemaining}</span>
            </div>
            {teamStreak >= 3 && (
              <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-orange-500/20 text-orange-400 font-bold text-xs animate-pulse motion-reduce:animate-none" data-help-key="escape_room_streak">
                🔥 x{teamStreak}
              </div>
            )}
            <div className={`px-3 py-1.5 rounded-full font-mono font-bold ${timeRemaining < 60 ? 'bg-red-600 text-white animate-pulse motion-reduce:animate-none' : 'bg-slate-700 text-white'}`} data-help-key="escape_room_timer">
              <Clock size={14} className="inline mr-1" />
              {formatTime(timeRemaining)}
            </div>
          </div>
        </div>
      </div>
      <div className="relative mx-4 mt-4 lg:fixed lg:right-4 lg:top-24 bg-slate-800/80 backdrop-blur-sm rounded-xl p-4 border border-purple-500/30 z-40" data-help-key="escape_room_leaderboard">
        <h4 className="text-xs font-bold text-slate-300 uppercase mb-3">{t('escape_room.live_progress')}</h4>
        {allTeams.map(team => {
          const progress = alloLiveEscapeProgress(escapeState.teamProgress?.[team], puzzles);
          const solved = (progress.solvedPuzzles || []).length;
          const percent = puzzles.length > 0 ? Math.round((solved / puzzles.length) * 100) : 0;
          const colors = teamColors[team] || teamColors.Blue;
          const escaped = progress.isEscaped;
          return (
            <div key={team} className={`mb-2 ${team === userTeam ? 'ring-2 ring-white/50 rounded-lg p-1' : ''}`}>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className={`font-bold ${colors.text}`}>{team}</span>
                <span className="text-slate-400">{solved}/{puzzles.length}</span>
              </div>
              <div className="w-32 h-2 bg-slate-700 rounded-full overflow-hidden">
                <div className={`h-full ${colors.bg} transition-all motion-reduce:transition-none duration-300`} style={{ width: `${percent}%` }} />
              </div>
              {escaped && <span className="text-xs text-green-700">🏆 {t('escape_room.escaped')}</span>}
            </div>
          );
        })}
      </div>
      <div className="max-w-4xl mx-auto p-4 sm:p-6 mt-4 lg:pr-40">
        <p className="text-center text-purple-200 mb-6 italic">{escapeState.room?.description}</p>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {objects.map((obj, idx) => {
            const puzzle = puzzles.find(p => p.linkedObjectId === obj.id) || puzzles[idx];
            const isSolved = puzzle && solvedPuzzlesSet.has(puzzle.id);
            return (
              <button type="button"
                key={obj.id}
                onClick={event => !isSolved && puzzle && openPuzzleDialog(event, obj.id)}
                disabled={isSolved}
                data-help-key="escape_room_object"
                className={`
                  aspect-square rounded-2xl p-4 flex flex-col items-center justify-center gap-2 transition-all motion-reduce:transition-none
                  border-2 ${isSolved
                    ? 'bg-green-900/50 border-green-500/50 cursor-default'
                    : 'bg-slate-800 border-purple-500/30 hover:border-purple-400 hover:scale-105 cursor-pointer'
                  }
                `}
              >
                <span className="text-4xl">{obj.emoji}</span>
                <span className="text-white text-sm font-bold text-center">{obj.name}</span>
                {isSolved && <CheckCircle className="text-green-400" size={20} />}
              </button>
            );
          })}
        </div>
      </div>
      {currentPuzzle && !isPaused && !solvedPuzzlesSet.has(currentPuzzle.id) && (
        <div className="fixed inset-0 z-[10000] bg-black/80 flex items-center justify-center p-4" role="presentation">
          <div
            ref={puzzleDialogRef}
            role="dialog"
            aria-modal="true"
            aria-labelledby="escape-room-puzzle-question"
            onKeyDown={event => {
              if (event.key === 'Escape') { event.preventDefault(); closePuzzleDialog(); return; }
              if (event.key !== 'Tab') return;
              const focusable = Array.from(event.currentTarget.querySelectorAll('button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'));
              if (!focusable.length) { event.preventDefault(); return; }
              const first = focusable[0];
              const last = focusable[focusable.length - 1];
              if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
              else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
            }}
            className="bg-slate-800 rounded-2xl p-6 max-w-lg w-full border-2 border-purple-500 max-h-[90vh] overflow-auto"
          >
            <div className="flex justify-between items-start mb-4">
              <div>
                <span className="text-xs px-2 py-0.5 bg-purple-600 text-white rounded-full uppercase font-bold">
                  {currentPuzzle.type || 'mcq'}
                </span>
              </div>
              <button type="button" data-initial-focus="true" onClick={closePuzzleDialog} data-help-key="escape_room_close_btn" className="min-w-11 min-h-11 inline-flex items-center justify-center text-slate-300 hover:text-white focus:outline-none focus:ring-2 focus:ring-white rounded-full" aria-label={t('common.close')}>
                <X size={24} aria-hidden="true" />
              </button>
            </div>
            <h2 id="escape-room-puzzle-question" className="text-xl text-white font-bold mb-4">{currentPuzzle.question}</h2>
            {syncError && <p role="alert" className="mb-3 rounded-lg bg-red-950 p-3 text-red-100">{syncError}</p>}
            <fieldset disabled={isSubmitting || isPaused} aria-busy={isSubmitting} className="min-w-0">
            <legend className="sr-only">{t('escape_room.submit_answer')}</legend>
            {isSubmitting && <p role="status" className="text-purple-200 mb-3">{t('common.saving', { defaultValue: 'Saving…' })}</p>}
            {currentPuzzle.hint && (
              <div className="mb-4">
                {(teamRevealedHints[alloLiveFieldKey(currentPuzzle.id)] || teamRevealedHints[currentPuzzle.id]) ? (
                  <div className="p-3 bg-yellow-500/20 border border-yellow-500/40 rounded-lg text-yellow-200 text-sm animate-in motion-reduce:animate-none fade-in">
                    <Lightbulb size={14} className="inline mr-2 text-yellow-400" />
                    {currentPuzzle.hint}
                  </div>
                ) : (
                  <button type="button"
                    onClick={async () => {
                      if (teamHintsRemaining <= 0 || submissionRef.current || isPaused || teamRevealedHints[alloLiveFieldKey(currentPuzzle.id)]) return;
                      submissionRef.current = true; setIsSubmitting(true); setSyncError('');
                      try {
                        const effectiveAppId = targetAppId || appId;
                        const sessionRef = doc(db, 'artifacts', effectiveAppId, 'public', 'data', 'sessions', activeSessionCode);
                        await updateDoc(sessionRef, teamProgress.progressVersion === 2 ? {
                          [`escapeRoomState.teamProgress.${userTeam}.revealedHints.${alloLiveFieldKey(currentPuzzle.id)}`]: true,
                          [`escapeRoomState.teamProgress.${userTeam}.hintedAt.${alloLiveFieldKey(currentPuzzle.id)}`]: Date.now()
                        } : {
                          [`escapeRoomState.teamProgress.${userTeam}.hintsRemaining`]: teamHintsRemaining - 1,
                          [`escapeRoomState.teamProgress.${userTeam}.revealedHints.${currentPuzzle.id}`]: true,
                          [`escapeRoomState.teamProgress.${userTeam}.streak`]: 0
                        });
                        playSound?.('notification');
                      } catch (e) {
                        warnLog("Failed to use hint:", e);
                        setSyncError('The hint could not be saved. Try again.');
                      } finally { submissionRef.current = false; setIsSubmitting(false); }
                    }}
                    disabled={teamHintsRemaining <= 0}
                    data-help-key="escape_room_hint_button"
                    className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold transition-colors motion-reduce:transition-none whitespace-nowrap ${
                      teamHintsRemaining > 0
                        ? 'bg-yellow-500/20 text-yellow-300 hover:bg-yellow-500/30 border border-yellow-500/40'
                        : 'bg-slate-700 text-slate-300 cursor-not-allowed'
                    }`}
                  >
                    <span className="text-sm">💡</span>
                    {t('escape_room.hint_btn')} ({teamHintsRemaining} {t('escape_room.left')})
                  </button>
                )}
              </div>
            )}
            {(!currentPuzzle.type || currentPuzzle.type === 'mcq') && currentPuzzle.options && (
              <div className="space-y-3">
                {currentPuzzle.options.map((opt, idx) => (
                  <button type="button"
                    key={idx}
                    onClick={() => handleSubmitAnswer(currentPuzzle.id, idx, 'mcq')}
                    data-help-key="escape_room_mcq_option"
                    className="w-full text-left p-4 bg-slate-700 hover:bg-purple-700 rounded-xl text-white font-medium transition-colors motion-reduce:transition-none border-2 border-transparent hover:border-purple-400"
                  >
                    <span className="inline-block w-8 font-bold text-purple-400">{String.fromCharCode(65+idx)}.</span>
                    {opt}
                  </button>
                ))}
              </div>
            )}
            {(currentPuzzle.type === 'cipher' || currentPuzzle.type === 'riddle') && (
              <div className="space-y-4">
                {currentPuzzle.encodedText && (
                  <div className="bg-slate-900 p-4 rounded-lg font-mono text-purple-300 text-center">
                    {currentPuzzle.encodedText}
                  </div>
                )}
                <input aria-label={t('common.escape_room_enter_answer')}
                  type="text"
                  value={userInput}
                  onChange={(e) => setUserInput(e.target.value)}
                  placeholder={t('escape_room.enter_answer')}
                  data-help-key="escape_room_cipher_input"
                  className="w-full p-4 bg-slate-700 text-white rounded-xl border-2 border-slate-600 focus:border-purple-400 focus:outline-none focus:ring-2 focus:ring-purple-300"
                />
                <button type="button"
                  disabled={!userInput.trim()} onClick={() => handleSubmitAnswer(currentPuzzle.id, userInput, 'cipher')}
                  data-help-key="escape_room_cipher_submit"
                  className="w-full p-4 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-xl transition-colors motion-reduce:transition-none"
                >
                  {t('escape_room.submit_answer')}
                </button>
              </div>
            )}
            {currentPuzzle.type === 'fillin' && (
              <div className="space-y-4">
                {currentPuzzle.sentence && (
                  <div className="bg-slate-900 p-4 rounded-lg text-white text-center text-lg">
                    {currentPuzzle.sentence.replace(/_+/g, userInput ? `[${userInput}]` : '______')}
                  </div>
                )}
                {currentPuzzle.wordbank && currentPuzzle.wordbank.length > 0 ? (
                  <div className="space-y-3">
                    <p className="text-xs text-slate-400 text-center uppercase font-bold">{t('escape_room.select_word') || 'Select the correct word:'}</p>
                    <div className="flex flex-wrap gap-2 justify-center">
                      {currentPuzzle.wordbank.map((word, idx) => (
                        <button type="button"
                          key={idx}
                          onClick={() => setUserInput(word)}
                          className={`px-4 py-2 rounded-lg font-bold transition-all motion-reduce:transition-none ${
                            userInput === word
                              ? 'bg-purple-600 text-white ring-2 ring-purple-300'
                              : 'bg-slate-700 text-white hover:bg-slate-600'
                          }`}
                        >
                          {word}
                        </button>
                      ))}
                    </div>
                  </div>
                ) : (
                  <input aria-label={t('common.escape_room_enter_answer')}
                    type="text"
                    value={userInput}
                    onChange={(e) => setUserInput(e.target.value)}
                    placeholder={t('escape_room.enter_answer')}
                    data-help-key="escape_room_fillin_input"
                    className="w-full p-4 bg-slate-700 text-white rounded-xl border-2 border-slate-600 focus:border-purple-400 focus:outline-none focus:ring-2 focus:ring-purple-300"
                  />
                )}
                <button type="button"
                  onClick={() => handleSubmitAnswer(currentPuzzle.id, userInput, 'fillin')}
                  disabled={!userInput}
                  data-help-key="escape_room_fillin_submit"
                  className="w-full p-4 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-xl transition-colors motion-reduce:transition-none disabled:opacity-50"
                >
                  {t('escape_room.submit_answer')}
                </button>
              </div>
            )}
            {currentPuzzle.type === 'scramble' && (
              <div className="space-y-4">
                <div className="flex flex-wrap gap-2 justify-center">
                  {(currentPuzzle.displayLetters || Array.from(currentPuzzle.scrambledWord || '')).map((letter, idx) => (
                    <span key={idx} className="w-10 h-10 flex items-center justify-center bg-purple-700 text-white font-bold rounded-lg text-xl">
                      {letter}
                    </span>
                  ))}
                </div>
                <input aria-label={t('common.escape_room_unscramble_placeholder')}
                  type="text"
                  value={userInput}
                  onChange={(e) => setUserInput(e.target.value)}
                  placeholder={t('escape_room.unscramble_placeholder')}
                  data-help-key="escape_room_scramble_input"
                  className="w-full p-4 bg-slate-700 text-white rounded-xl border-2 border-slate-600 focus:border-purple-400 focus:outline-none focus:ring-2 focus:ring-purple-300 text-center font-mono text-xl uppercase"
                />
                <button type="button"
                  disabled={!userInput.trim()} onClick={() => handleSubmitAnswer(currentPuzzle.id, userInput, 'scramble')}
                  data-help-key="escape_room_scramble_submit"
                  className="w-full p-4 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-xl transition-colors motion-reduce:transition-none"
                >
                  {t('escape_room.check_word')}
                </button>
              </div>
            )}
            {currentPuzzle.type === 'sequence' && (
              <div className="space-y-4" data-help-key="escape_room_sequence_container">
                <p className="text-sm text-purple-300 italic mb-2">{t('escape_room.sequence_instructions')}</p>
                <div className="space-y-2" role="list" aria-label={t('escape_room.sequence_list') || 'Sequence items to order'}>
                  {sequenceOrder.length === 0
                    ? (currentPuzzle.shuffledItems || currentPuzzle.items || []).map((item, idx) => (
                        <div key={idx} role="listitem" className="flex items-center gap-2 p-3 bg-slate-700 rounded-lg text-white">
                          <span className="flex-1">{item}</span>
                        </div>
                      ))
                    : sequenceOrder.map((itemIndex, idx) => (
                        <div key={idx} role="listitem" aria-label={`${t('escape_room.position') || 'Position'} ${idx + 1}: ${currentPuzzle.items[itemIndex]}`} className="flex items-center gap-2 p-3 bg-slate-700 rounded-lg text-white">
                          <span className="w-8 h-8 flex items-center justify-center bg-purple-600 rounded-full font-bold" aria-hidden="true">{idx + 1}</span>
                          <span className="flex-1">{currentPuzzle.items[itemIndex]}</span>
                          <div className="flex gap-1" role="group" aria-label={t('escape_room.reorder_buttons') || 'Reorder buttons'}>
                            <button type="button"
                              onClick={() => {
                                if (idx > 0) {
                                  const newOrder = [...sequenceOrder];
                                  [newOrder[idx], newOrder[idx - 1]] = [newOrder[idx - 1], newOrder[idx]];
                                  setSequenceOrder(newOrder);
                                }
                              }}
                              disabled={idx === 0}
                              aria-label={`${t('escape_room.move_up') || 'Move up'}: ${currentPuzzle.items[itemIndex]}`}
                              title={t('escape_room.move_up') || 'Move up'}
                              className="w-8 h-8 bg-slate-600 hover:bg-slate-500 text-white rounded disabled:opacity-30 focus:ring-2 focus:ring-purple-400 focus:outline-none"
                            >↑</button>
                            <button type="button"
                              onClick={() => {
                                if (idx < sequenceOrder.length - 1) {
                                  const newOrder = [...sequenceOrder];
                                  [newOrder[idx], newOrder[idx + 1]] = [newOrder[idx + 1], newOrder[idx]];
                                  setSequenceOrder(newOrder);
                                }
                              }}
                              disabled={idx === sequenceOrder.length - 1}
                              aria-label={`${t('escape_room.move_down') || 'Move down'}: ${currentPuzzle.items[itemIndex]}`}
                              title={t('escape_room.move_down') || 'Move down'}
                              className="w-8 h-8 bg-slate-600 hover:bg-slate-500 text-white rounded disabled:opacity-30 focus:ring-2 focus:ring-purple-400 focus:outline-none"
                            >↓</button>
                          </div>
                        </div>
                      ))
                  }
                </div>
                {sequenceOrder.length === 0 && (
                  <button type="button"
                    onClick={() => setSequenceOrder(alloLiveSequenceIndices(currentPuzzle))}
                    className="w-full p-3 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-xl transition-colors motion-reduce:transition-none"
                  >
                    {t('escape_room.start_ordering') || 'Start Ordering'}
                  </button>
                )}
                {sequenceOrder.length > 0 && (
                  <button type="button"
                    onClick={() => {
                      const originalItems = currentPuzzle.items || [];
                      const orderIndices = sequenceOrder;
                      handleSubmitAnswer(currentPuzzle.id, orderIndices, 'sequence');
                    }}
                    className="w-full p-4 bg-green-700 hover:bg-green-800 text-white font-bold rounded-xl transition-colors motion-reduce:transition-none"
                  >
                    {t('escape_room.check_sequence')}
                  </button>
                )}
              </div>
            )}
            {currentPuzzle.type === 'matching' && (
              <div className="space-y-4" data-help-key="escape_room_matching_container">
                <p className="text-sm text-purple-200 italic mb-2">{t('escape_room.matching_instructions')}</p>
                <div className="grid grid-cols-2 gap-4" role="group" aria-label={t('escape_room.matching_columns') || 'Matching columns'}>
                  <div className="space-y-2" role="group" aria-label={t('escape_room.left_column') || 'Left column options'}>
                    {(currentPuzzle.leftColumn || currentPuzzle.pairs?.map(p => p.left) || []).map((item, idx) => {
                      const isMatched = matchingPairs.some(p => p.left === item);
                      const isSelected = matchingSelected?.side === 'left' && matchingSelected?.item === item;
                      return (
                        <button type="button"
                          key={idx}
                          onClick={() => {
                            if (isMatched) return;
                            if (matchingSelected?.side === 'right') {
                              setMatchingPairs([...matchingPairs, { left: item, right: matchingSelected.item }]);
                              setMatchingSelected(null);
                            } else {
                              setMatchingSelected({ side: 'left', item });
                            }
                          }}
                          disabled={isMatched}
                          aria-label={isMatched ? `${item} - ${t('escape_room.matched') || 'matched'}` : isSelected ? `${item} - ${t('escape_room.selected') || 'selected'}` : item}
                          className={`w-full p-3 rounded-lg text-left font-medium transition-all motion-reduce:transition-none focus:outline-none focus:ring-2 focus:ring-purple-400 ${
                            isMatched ? 'bg-green-700 text-white opacity-60' :
                            isSelected ? 'bg-purple-600 text-white ring-2 ring-purple-300' :
                            'bg-slate-700 text-white hover:bg-slate-600'
                          }`}
                        >
                          {item}
                        </button>
                      );
                    })}
                  </div>
                  <div className="space-y-2" role="group" aria-label={t('escape_room.right_column') || 'Right column options'}>
                    {(currentPuzzle.rightColumn || currentPuzzle.pairs?.map(p => p.right) || []).map((item, idx) => {
                      const isMatched = matchingPairs.some(p => p.right === item);
                      const isSelected = matchingSelected?.side === 'right' && matchingSelected?.item === item;
                      return (
                        <button type="button"
                          key={idx}
                          onClick={() => {
                            if (isMatched) return;
                            if (matchingSelected?.side === 'left') {
                              setMatchingPairs([...matchingPairs, { left: matchingSelected.item, right: item }]);
                              setMatchingSelected(null);
                            } else {
                              setMatchingSelected({ side: 'right', item });
                            }
                          }}
                          disabled={isMatched}
                          aria-label={isMatched ? `${item} - ${t('escape_room.matched') || 'matched'}` : isSelected ? `${item} - ${t('escape_room.selected') || 'selected'}` : item}
                          className={`w-full p-3 rounded-lg text-left font-medium transition-all motion-reduce:transition-none focus:outline-none focus:ring-2 focus:ring-purple-400 ${
                            isMatched ? 'bg-green-700 text-white opacity-60' :
                            isSelected ? 'bg-purple-600 text-white ring-2 ring-purple-300' :
                            'bg-slate-700 text-white hover:bg-slate-600'
                          }`}
                        >
                          {item}
                        </button>
                      );
                    })}
                  </div>
                </div>
                {matchingPairs.length > 0 && (
                  <div className="bg-slate-900 p-3 rounded-lg" role="list" aria-label={t('escape_room.matched_pairs') || 'Matched pairs'}>
                    <p className="text-xs text-slate-600 mb-2" aria-hidden="true">{t('escape_room.matched_pairs')}</p>
                    <div className="space-y-1">
                      {matchingPairs.map((pair, idx) => (
                        <div key={idx} role="listitem" className="text-sm text-slate-100 flex items-center justify-between gap-2"><span>{pair.left} ↔ {pair.right}</span><button type="button" className="min-h-11 px-3 rounded bg-slate-700" aria-label={`${t('common.remove', { defaultValue: 'Remove' })}: ${pair.left} ↔ ${pair.right}`} onClick={() => { setMatchingPairs(prev => prev.filter((_, i) => i !== idx)); setMatchingSelected(null); }}>×</button></div>
                      ))}
                    </div>
                  </div>
                )}
                {matchingPairs.length >= (currentPuzzle.pairs?.length || 4) && (
                  <button type="button"
                    onClick={() => handleSubmitAnswer(currentPuzzle.id, matchingPairs, 'matching')}
                    className="w-full p-4 bg-green-700 hover:bg-green-800 text-white font-bold rounded-xl transition-colors motion-reduce:transition-none"
                  >
                    {t('escape_room.submit_answer')}
                  </button>
                )}
              </div>
            )}
            </fieldset>
          </div>
        </div>
      )}
      {isPaused && (
        <div
          ref={pauseDialogRef}
          tabIndex={-1}
          role="alertdialog"
          aria-modal="true"
          aria-labelledby="escape-room-paused-title"
          aria-describedby="escape-room-paused-description"
          onKeyDown={(event) => {
            if (event.key === 'Tab') {
              event.preventDefault();
              pauseDialogRef.current?.focus();
            }
          }}
          className="fixed top-0 right-0 bottom-0 left-0 z-[10001] bg-black/80 flex items-center justify-center backdrop-blur-sm focus:outline-none focus:ring-4 focus:ring-inset focus:ring-white"
        >
          <div className="text-center text-white animate-pulse motion-reduce:animate-none">
            <div className="text-8xl mb-6">⏸️</div>
            <h2 id="escape-room-paused-title" className="text-4xl font-black mb-3">{t('escape_room.game_paused')}</h2>
            <p id="escape-room-paused-description" className="text-xl text-slate-300">{t('escape_room.waiting_resume')}</p>
          </div>
        </div>
      )}
      {teamEscapeToast && (
        <div role="status" aria-live="polite" aria-atomic="true" className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[10002] animate-in motion-reduce:animate-none slide-in-from-bottom duration-300">
          <div className={`flex items-center gap-3 px-6 py-4 rounded-2xl shadow-2xl border-2 ${teamColors[teamEscapeToast]?.border || 'border-purple-500'} bg-slate-900`}>
            <span className="text-3xl">🚪</span>
            <div>
              <p className="text-white font-bold">{t('escape_room.team_escaped', { team: teamEscapeToast })}</p>
              <p className="text-slate-600 text-sm">{t('escape_room.hurry_up')}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
});
const ConnectedEscapeRoomLoader = React.memo(({ variant, ...props }) => {
  const [ready, setReady] = useState(() => !!window.AlloModules?.ConnectedEscapeRoomModule);
  useEffect(() => {
    if (ready) return;
    window.__alloLazyConnectedEscape?.();
    const timer = setInterval(() => { if (window.AlloModules?.ConnectedEscapeRoomModule) setReady(true); }, 250);
    return () => clearInterval(timer);
  }, [ready]);
  const View = window.AlloModules?.['ConnectedEscapeRoom' + variant];
  return ready && View ? <View {...props} /> : <div role="status" className={variant === 'Student' ? 'fixed inset-0 z-[9999] bg-slate-950 p-8 text-white' : 'rounded-xl bg-indigo-50 p-4 text-indigo-900'}>{props.t?.('connected_escape.loading', { defaultValue: 'Loading the connected room…' }) || 'Loading the connected room…'}</div>;
});
const LessonBoardLoader = React.memo(({ variant, ...props }) => {
  const [ready, setReady] = useState(() => !!window.AlloModules?.LessonBoardModule);
  useEffect(() => { if (ready) return; window.__alloLazyLessonBoard?.(); const timer = setInterval(() => { if (window.AlloModules?.LessonBoardModule) setReady(true); }, 250); return () => clearInterval(timer); }, [ready]);
  const View = window.AlloModules?.['LessonBoard' + variant];
  return ready && View ? <View {...props}/> : <div role="status">{props.t?.('lesson_board.loading', { defaultValue: 'Loading the lesson board…' }) || 'Loading the lesson board…'}</div>;
});
const StudentEscapeRoomOverlay = React.memo(props => (
  props.sessionData?.escapeRoomState?.mode === 'lesson-board' ? <LessonBoardLoader variant="Student" {...props}/> :
  props.sessionData?.escapeRoomState?.mode === 'connected-room'
    ? <ConnectedEscapeRoomLoader variant="Student" {...props} /> :
  props.sessionData?.escapeRoomState?.mode === 'concept-quest'
    ? <StudentConceptQuestOverlay {...props} />
    : <ClassicStudentEscapeRoomOverlay {...props} />
));

// @section ESCAPE_ROOM_TEACHER — Escape Room teacher controls
const ClassicEscapeRoomTeacherControls = React.memo(({ sessionData, activeSessionCode, appId, t, addToast }) => {
  const escapeState = sessionData?.escapeRoomState || {};
  const timeRemaining = useLiveEscapeSeconds(escapeState);
  const [controlBusy, setControlBusy] = useState(false);
  const [controlError, setControlError] = useState('');
  const controlRef = useRef(false);
  const warningsRef = useRef(new Set());
  useEffect(() => { warningsRef.current.clear(); }, [activeSessionCode, escapeState.startedAt]);
  const writeControl = async (patch) => {
    if (controlRef.current) return false;
    controlRef.current = true; setControlBusy(true); setControlError('');
    try {
      const sessionRef = doc(db, 'artifacts', appId, 'public', 'data', 'sessions', activeSessionCode);
      await updateDoc(sessionRef, patch); return true;
    } catch (error) { warnLog('Live escape room control failed:', error); setControlError('The session could not be updated. Check the connection and try again.'); return false; }
    finally { controlRef.current = false; setControlBusy(false); }
  };
  const [showEndConfirm, setShowEndConfirm] = useState(false);
  const endGameDialogRef = useRef(null);
  const endGameTriggerRef = useRef(null);
  useEffect(() => {
    if (!showEndConfirm) return;
    endGameDialogRef.current?.querySelector('[data-safe-default="true"]')?.focus();
  }, [showEndConfirm]);
  const closeEndGameDialog = () => {
    setShowEndConfirm(false);
    window.setTimeout(() => endGameTriggerRef.current?.focus(), 0);
  };
  const requestEndGame = (event) => {
    endGameTriggerRef.current = event.currentTarget;
    setShowEndConfirm(true);
  };
  useEffect(() => {
    if (!escapeState.isActive || escapeState.isPaused || escapeState.isGameOver || !activeSessionCode || !appId) return;
    const sessionRef = doc(db, 'artifacts', appId, 'public', 'data', 'sessions', activeSessionCode);
    if (!Number.isFinite(escapeState.endsAt)) {
      updateDoc(sessionRef, { 'escapeRoomState.endsAt': Date.now() + Math.max(0, escapeState.timeRemaining || 0) * 1000 })
        .catch(error => { warnLog('Live escape clock failed:', error); setControlError('The timer could not start. Check the connection and use Resume to retry.'); });
      return;
    }
    let stopped = false, writing = false;
    const tick = async () => {
      const seconds = alloLiveEscapeSeconds(escapeState);
      [60, 30].forEach(threshold => {
        if (seconds > 0 && seconds <= threshold && !warningsRef.current.has(threshold)) {
          warningsRef.current.add(threshold);
          addToast?.(t(threshold === 60 ? 'escape_room.one_minute_warning' : 'escape_room.thirty_seconds_warning'), 'warning');
        }
      });
      if (seconds > 0 || stopped || writing) return;
      writing = true;
      try {
        await updateDoc(sessionRef, { 'escapeRoomState.timeRemaining': 0, 'escapeRoomState.isGameOver': true, 'escapeRoomState.gameOverReason': 'time' });
        stopped = true; addToast?.(t('escape_room.time_up'), 'error');
      } catch (error) { warnLog('Live escape expiry failed:', error); setControlError('Time has ended. Reconnecting to save the result…'); }
      finally { writing = false; }
    };
    tick(); const timer = setInterval(tick, 1000);
    return () => { stopped = true; clearInterval(timer); };
  }, [escapeState.isActive, escapeState.isPaused, escapeState.isGameOver, escapeState.endsAt, activeSessionCode, appId]);
  const isCoopMode = escapeState.isCoopMode || false;
  const isPaused = escapeState.isPaused || false;
  const teamColors = {
    Red: { bg: 'bg-red-500', text: 'text-red-600', light: 'bg-red-100' },
    Blue: { bg: 'bg-blue-500', text: 'text-blue-600', light: 'bg-blue-100' },
    Green: { bg: 'bg-green-500', text: 'text-green-600', light: 'bg-green-100' },
    Yellow: { bg: 'bg-yellow-500', text: 'text-yellow-600', light: 'bg-yellow-100' },
    All: { bg: 'bg-purple-500', text: 'text-purple-600', light: 'bg-purple-100' }
  };
  const allTeams = Object.keys(escapeState.teamProgress || {});
  const puzzles = escapeState.puzzles || [];
  const totalPuzzles = puzzles.length;
  // Drop bogus deps `isEscaped`, `teamProgress` — those vars belong to a
  // different component scope (the student-side EscapeRoomStudentView) and
  // reading them here crashes the render. The function body only references
  // allTeams and escapeState.teamProgress[t].isEscaped, so those are the
  // correct deps. Surfaced by check_render_refs gate on 2026-06-04 when
  // rebuilding teacher_module.js after a hand-edit had silently removed
  // the bad deps from the build artifact without backporting to source.
  const escapedTeams = allTeams.filter(team => alloLiveEscapeProgress(escapeState.teamProgress?.[team], puzzles).isEscaped);
  const studentsAssigned = Object.keys(escapeState.teams || {}).length;
  const handlePauseToggle = async () => {
    if (escapeState.isGameOver) return;
    const remaining = alloLiveEscapeSeconds(escapeState);
    await writeControl({ 'escapeRoomState.isPaused': !isPaused, 'escapeRoomState.timeRemaining': remaining,
      'escapeRoomState.endsAt': isPaused ? Date.now() + remaining * 1000 : null });
  };
  const handleEndGame = async () => {
    if (await writeControl({ 'escapeRoomState.isActive': false, 'escapeRoomState.isGameOver': false, 'escapeRoomState.isPaused': false, 'escapeRoomState.endsAt': null })) setShowEndConfirm(false);
  };
  const formatTime = (seconds) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s.toString().padStart(2, '0')}`;
  };
  if (!escapeState.isActive && !escapeState.isGameOver) return null;
  return (
    <div className="bg-gradient-to-br from-purple-50 to-indigo-50 rounded-2xl p-4 border-2 border-purple-200 shadow-lg mb-4">
      {controlError && <p role="alert" className="mb-3 rounded-lg bg-red-100 p-3 text-red-900">{controlError}</p>}
      {escapeState.isGameOver && <p role="status" className="mb-3 font-bold text-red-800">{t('escape_room.time_up')} · {t('escape_room.end_game')}</p>}
      <div className="flex items-center justify-between flex-wrap gap-3 mb-4">
        <div className="flex items-center flex-wrap gap-2">
          <DoorOpen className="text-purple-600" size={20} />
          <h3 className="font-bold text-purple-900">{escapeState.room?.theme || t('escape_room.title')}</h3>
          {isCoopMode && (
            <span className="text-xs bg-purple-200 text-purple-700 px-2 py-0.5 rounded-full font-bold">
              {t('escape_room.coop_mode')}
            </span>
          )}
          {isPaused && (
            <span className="text-xs bg-yellow-200 text-yellow-800 px-2 py-0.5 rounded-full font-bold animate-pulse motion-reduce:animate-none">
              ⏸️ {t('escape_room.game_paused')}
            </span>
          )}
        </div>
        <div className="flex items-center flex-wrap gap-2">
          <span className="text-xs bg-purple-100 text-purple-700 px-2 py-1 rounded-full font-bold">
            {studentsAssigned} {t('escape_room.teams_competing', { count: allTeams.length })}
          </span>
          <span className={`px-3 py-1 rounded-full font-mono font-bold text-sm ${timeRemaining < 60 ? 'bg-red-600 text-white' : 'bg-slate-700 text-white'}`}>
            <Clock size={12} className="inline mr-1" />
            {formatTime(timeRemaining)}
          </span>
          <button type="button"
            onClick={handlePauseToggle} disabled={controlBusy || escapeState.isGameOver} aria-pressed={isPaused}
            className={`px-4 py-2 rounded-full font-bold text-sm transition-colors motion-reduce:transition-none whitespace-nowrap ${isPaused ? 'bg-green-700 hover:bg-green-800 text-white' : 'bg-yellow-300 hover:bg-yellow-400 text-slate-950'}`}
          >
            {isPaused ? '▶️ ' + t('escape_room.resume') : '⏸️ ' + t('escape_room.pause')}
          </button>
          <button type="button"
            onClick={requestEndGame} disabled={controlBusy}
            className="px-4 py-2 rounded-full font-bold text-sm bg-red-600 hover:bg-red-700 text-white transition-colors motion-reduce:transition-none whitespace-nowrap"
          >
            {t('escape_room.end_game')}
          </button>
        </div>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {allTeams.map(team => {
          const progress = alloLiveEscapeProgress(escapeState.teamProgress?.[team], puzzles);
          const solved = (progress.solvedPuzzles || []).length;
          const percent = totalPuzzles > 0 ? Math.round((solved / totalPuzzles) * 100) : 0;
          const colors = teamColors[team] || teamColors.Blue;
          const escaped = progress.isEscaped;
          const memberCount = Object.values(escapeState.teams || {}).filter(t => t === team).length;
          return (
            <div key={team} className={`p-3 rounded-xl border-2 ${escaped ? 'border-green-400 bg-green-50' : 'border-slate-200 bg-white'}`}>
              <div className="flex items-center justify-between mb-2">
                <span className={`font-bold ${colors.text}`}>{team}</span>
                <span className="text-xs text-slate-600">{memberCount} 👤</span>
              </div>
              <div className="w-full h-3 bg-slate-200 rounded-full overflow-hidden mb-2">
                <div className={`h-full ${colors.bg} transition-all motion-reduce:transition-none duration-500`} style={{ width: `${percent}%` }} />
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-600">{solved}/{totalPuzzles}</span>
                {progress.isGameOver && <span className="text-red-800 font-bold">{t('escape_room.game_over')}</span>}
                {escaped && <span className="text-green-600 font-bold">🏆 {t('escape_room.escaped')}</span>}
              </div>
            </div>
          );
        })}
      </div>
      {escapedTeams.length > 0 && (
        <div className="mt-4 p-3 bg-green-100 rounded-xl border border-green-300 text-center">
          <span className="text-green-800 font-bold">
            🎉 {escapedTeams.length === 1
              ? t('escape_room.first_escape') + ': ' + escapedTeams[0]
              : escapedTeams.length === allTeams.filter(team => Object.values(escapeState.teams || {}).includes(team)).length ? t('escape_room.all_teams_done') : escapedTeams.join(', ')
            }
          </span>
        </div>
      )}
      {showEndConfirm && (
        <div className="fixed inset-0 z-[9999] bg-black/50 flex items-center justify-center p-4" role="presentation">
          <div
            ref={endGameDialogRef}
            role="alertdialog"
            aria-modal="true"
            aria-labelledby="escape-room-end-game-title"
            aria-describedby="escape-room-end-game-description"
            onKeyDown={event => {
              if (event.key === 'Escape') { event.preventDefault(); closeEndGameDialog(); return; }
              if (event.key !== 'Tab') return;
              const focusable = Array.from(event.currentTarget.querySelectorAll('button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'));
              if (!focusable.length) { event.preventDefault(); return; }
              const first = focusable[0];
              const last = focusable[focusable.length - 1];
              if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
              else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
            }}
            className="bg-white rounded-2xl p-6 max-w-sm w-full shadow-2xl border-2 border-red-200"
          >
            <h4 id="escape-room-end-game-title" className="text-lg font-bold text-red-600 mb-2 flex items-center gap-2">
              <X className="text-red-500" size={20} aria-hidden="true" />
              {t('escape_room.end_game')}
            </h4>
            <p id="escape-room-end-game-description" className="text-slate-600 mb-4">{t('escape_room.end_game_confirm')}</p>
            <div className="flex gap-3">
              <button type="button" data-safe-default="true" onClick={closeEndGameDialog} className="flex-1 min-h-11 px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold rounded-xl transition-colors motion-reduce:transition-none focus:outline-none focus:ring-2 focus:ring-indigo-500">
                {t('cancel')}
              </button>
              <button type="button" onClick={handleEndGame} disabled={controlBusy} className="flex-1 min-h-11 px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl transition-colors motion-reduce:transition-none focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2">
                {t('escape_room.end_game')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
});
const ConceptQuestTeacherControlsLoader = React.memo(props => {
  const tr = (key, fallback) => {
    const fullKey = `concept_quest.${key}`;
    const translated = typeof props.t === 'function' ? props.t(fullKey) : '';
    return typeof translated === 'string' && translated && translated !== fullKey ? translated : fallback;
  };
  const [ready, setReady] = useState(() => !!window.AlloModules?.ConceptQuestTeacherControls);
  useEffect(() => {
    if (window.AlloModules?.ConceptQuestTeacherControls) { setReady(true); return; }
    const existing = document.querySelector('script[data-allo-concept-quest-teacher]');
    if (existing) { existing.addEventListener('load', () => setReady(true), { once: true }); return; }
    const script = document.createElement('script');
    script.dataset.alloConceptQuestTeacher = 'true';
    script.src = 'https://alloflow-cdn.pages.dev/concept_quest_teacher_module.js';
    script.onload = () => setReady(true);
    script.onerror = () => { script.onerror = null; script.src = './concept_quest_teacher_module.js'; };
    document.head.appendChild(script);
  }, []);
  const ConceptControls = window.AlloModules?.ConceptQuestTeacherControls;
  return ready && ConceptControls ? <ConceptControls {...props} /> : <div role="status" className="rounded-xl bg-indigo-50 p-4 text-indigo-800">{tr('loading_teacher_controls', 'Loading Concept Quest co-GM controls…')}</div>;
});

const EscapeRoomTeacherControls = React.memo(props => {
  if (props.sessionData?.escapeRoomState?.mode === 'lesson-board') return <LessonBoardLoader variant="Teacher" {...props}/>;
  if (props.sessionData?.escapeRoomState?.mode === 'connected-room') return <ConnectedEscapeRoomLoader variant="Teacher" {...props} />;
  if (props.sessionData?.escapeRoomState?.mode === 'concept-quest') {
    return <ConceptQuestTeacherControlsLoader {...props} />;
  }
  return <ClassicEscapeRoomTeacherControls {...props} />;
});

// @section LIVE_QUIZ — Teacher live quiz broadcast controls
const TeacherLiveQuizControls = React.memo(({ sessionData, generatedContent, activeSessionCode, appId, onGenerateImage, onRefineImage, onCreateGroup, onAssignStudent, onSetGroupResource, isPushingResource = {}, onSetGroupLanguage, onSetGroupProfile, onDeleteGroup, onUpdateQuestionRoutingRules, history = [], callGemini, addToast }) => {
    const { t } = useContext(LanguageContext);
    const { quizState, roster } = sessionData;
    const { currentQuestionIndex, phase, responses, responseReceipts, mode, bossStats, teamScores, scoringPolicy } = quizState;
    const question = generatedContent?.data?.questions?.[currentQuestionIndex];
    const [quizBusy, setQuizBusy] = useState(false);
    const [quizError, setQuizError] = useState('');
    const quizWriteRef = useRef(false);
    const completedWriteRef = useRef('');
    useEffect(() => { completedWriteRef.current = ''; setQuizError(''); }, [activeSessionCode, quizState.activityId, quizState.roundId, currentQuestionIndex, phase]);
    const writeQuiz = async (sessionRef, patch) => {
      const key = patch['quizState.phase'] && patch['quizState.phase'] !== 'idle' ? [quizState.roundId, currentQuestionIndex, phase, patch['quizState.phase'], patch['quizState.currentQuestionIndex'], patch['quizState.mode']].join(':') : JSON.stringify(patch);
      if (quizWriteRef.current || completedWriteRef.current === key) return false;
      quizWriteRef.current = true; setQuizBusy(true); setQuizError('');
      try { await updateDoc(sessionRef, patch); completedWriteRef.current = key; return true; }
      catch (error) { warnLog('Live quiz control failed:', error); setQuizError('The live quiz could not be updated. Check the connection and try again.'); return false; }
      finally { quizWriteRef.current = false; setQuizBusy(false); }
    };
    const [showLocalStats, setShowLocalStats] = useState(false);
    const [bossDifficulty, setBossDifficulty] = useState(bossStats?.difficulty || 'normal');
    useEffect(() => { setBossDifficulty(bossStats?.difficulty || 'normal'); }, [bossStats?.difficulty, activeSessionCode]);
    const bossBattleEnded = mode === 'boss-battle' && ['boss-defeated', 'class-defeated', 'battle-complete'].includes(phase);
    const bossPacingLocked = quizBusy || bossBattleEnded || phase === 'answering';
    const bossIdentity = [appId, activeSessionCode, quizState.activityId, mode, bossStats?.battleId || 'legacy'].join(':');
    const bossIdentityRef = useRef(bossIdentity); bossIdentityRef.current = bossIdentity;
    const bossVisualRequestRef = useRef(0);
    useEffect(() => { setBossGmDraft(null); setBossGmPrompt(''); return () => { bossVisualRequestRef.current++; }; }, [bossIdentity]);
    const [bossGmPrompt, setBossGmPrompt] = useState('');
    const [bossGmDraft, setBossGmDraft] = useState(null);
    const [bossGmBusy, setBossGmBusy] = useState(false);
    const normalizedBossPhase = String(bossStats?.phaseName || 'watchful').trim().toLowerCase().replace(/\s+/g, '_');
    const bossPhaseId = ['watchful', 'enraged', 'final_form'].includes(normalizedBossPhase) ? normalizedBossPhase : 'watchful';
    const bossPhaseKey = `concept_quest.boss_phase_${bossPhaseId}`;
    const translatedBossPhase = t(bossPhaseKey);
    const bossPhaseLabel = translatedBossPhase && translatedBossPhase !== bossPhaseKey ? translatedBossPhase : { watchful: 'Watchful', enraged: 'Enraged', final_form: 'Final form' }[bossPhaseId];
    // Phase-2 quiz auto-routing: per-question rules. Mirrored to window
    // so the App-level useEffect (AlloFlowANTI.txt, near rosterKey
    // auto-grouping) can read them. Rule schema:
    //   { id, version, when: { predicate, value }, then: { groupId?, hiddenResourceIds? } }
    //
    // PERSISTENCE CONTRACT (PHASE A — added 2026-06-04):
    //   1. SEED ON MOUNT: initial state is read from question.routingRules on
    //      every question in generatedContent. Pre-authored rules (AI-generated,
    //      imported from a quiz pack, or persisted from a prior teacher session)
    //      are visible to the editor immediately. Before this fix, the state
    //      initialized to {} and pre-authored rules were silently hidden.
    //   2. WRITE-THROUGH: every state change fires onUpdateQuestionRoutingRules
    //      (the callback prop) so the host can mirror the rules back onto
    //      generatedContent.data.questions[i].routingRules. The host then
    //      writes generatedContent into history, which the saveHistory debounce
    //      persists to IndexedDB (allo_offline_history). Result: rules survive
    //      teacher-tab reload AND ride with the quiz resource when exported.
    //   3. WINDOW MIRROR (legacy): window.__alloQuizRoutingRules is still
    //      written for the runtime consumer at AlloFlowANTI.txt:11444 which
    //      uses it as a fallback when generatedContent isn't yet hydrated.
    //      Both sources are now reconciled via the same useEffect below.
    const [quizRoutingRulesByQ, setQuizRoutingRulesByQ] = useState(() => {
      const seeded = {};
      const qs = (generatedContent && generatedContent.data && Array.isArray(generatedContent.data.questions))
        ? generatedContent.data.questions : [];
      qs.forEach((q, i) => {
        if (q && Array.isArray(q.routingRules) && q.routingRules.length > 0) {
          // Stamp version on legacy rules that lack one so subsequent edits
          // have something to increment. Idempotent — only adds version, leaves
          // existing version values alone.
          seeded[i] = q.routingRules.map(r =>
            (r && typeof r === 'object' && (r.version == null))
              ? Object.assign({}, r, { version: 1 })
              : r
          );
        }
      });
      return seeded;
    });
    const [showQuizRoutingPanel, setShowQuizRoutingPanel] = useState(false);
    useEffect(() => {
      // Mirror to window for the legacy runtime consumer fallback.
      if (typeof window !== 'undefined') window.__alloQuizRoutingRules = quizRoutingRulesByQ;
      // Phase A round-trip: fire the host callback so rules persist onto
      // generatedContent.data.questions[i].routingRules and ride into
      // allo_offline_history via the host's saveHistory debounce. The host
      // owns the merge strategy (it writes a single setGeneratedContent that
      // updates each question's routingRules in one batched call).
      if (typeof onUpdateQuestionRoutingRules === 'function') {
        try { onUpdateQuestionRoutingRules(quizRoutingRulesByQ); } catch (_) { /* host write errors are non-fatal */ }
      }
    }, [quizRoutingRulesByQ, onUpdateQuestionRoutingRules]);
    const groupsForRouting = sessionData?.groups || {};
    const groupEntriesForRouting = Object.entries(groupsForRouting).filter(([_, g]) => g !== null);
    const currentRules = quizRoutingRulesByQ[currentQuestionIndex] || [];
    // Phase E (poll subtype): structural single-tick block. Likert items cannot
    // be routed on a single-item basis — single-tick self-report is not
    // measurement-reliable enough to drive placement decisions. This is the
    // load-bearing scientific-integrity guardrail. Refuse at AUTHORING time
    // (not fire time) so the teacher never gets a chance to ship a single-tick
    // rule. Aggregation rules are created via a separate addQuizAggregationRule
    // path that initializes with when.aggregate and a 2-item acrossQuestions
    // floor.
    const _currentQuestionIsLikert = (question && question.itemType === 'likert');
    const addQuizRoutingRule = () => {
      if (_currentQuestionIsLikert) {
        // Should never be hit — the UI hides the "Add rule" button when
        // _currentQuestionIsLikert. Guard anyway in case a future refactor
        // re-enables it without the integrity check.
        if (typeof window !== 'undefined' && window.console) {
          console.warn('[TeacherLiveQuizControls] Refusing single-item routing rule on a Likert question — aggregation across >=2 items is required for measurement reliability.');
        }
        return;
      }
      setQuizRoutingRulesByQ(prev => {
        const next = { ...prev };
        const existing = Array.isArray(next[currentQuestionIndex]) ? next[currentQuestionIndex].slice() : [];
        const firstOption = (question?.options && question.options[0]) || '';
        const firstGroup = (groupEntriesForRouting[0] && groupEntriesForRouting[0][0]) || '';
        existing.push({
          id: 'qr-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 5),
          version: 1,
          when: { predicate: 'eq', value: firstOption },
          then: { groupId: firstGroup }
        });
        next[currentQuestionIndex] = existing;
        return next;
      });
    };
    // Confidence-pattern rules (screening heuristics, not measurements).
    // Quick-add seeds the current question + the next gradable question so
    // the >=2-item integrity floor holds at authoring time; the router
    // additionally requires >=2 items to MATCH before firing.
    const _gradableIdxs = (generatedContent?.data?.questions || [])
      .map((q, i) => ({ q, i }))
      .filter(({ q }) => q && q.correctAnswer != null && Array.isArray(q.options))
      .map(({ i }) => i);
    const addConfidencePatternRule = (pattern) => {
      const seed = [currentQuestionIndex].concat(_gradableIdxs.filter(i => i !== currentQuestionIndex).slice(0, 1));
      if (seed.length < 2) {
        if (typeof window !== 'undefined' && window.AlloFlowUX) window.AlloFlowUX.toast('Confidence rules need at least 2 gradable questions in this quiz.', 'info');
        return;
      }
      const firstGroup = (groupEntriesForRouting[0] && groupEntriesForRouting[0][0]) || '';
      setQuizRoutingRulesByQ(prev => {
        const next = { ...prev };
        const existing = Array.isArray(next[currentQuestionIndex]) ? next[currentQuestionIndex].slice() : [];
        existing.push({
          id: 'qr-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 5),
          version: 1,
          when: { confidencePattern: pattern, acrossQuestions: seed },
          then: { groupId: firstGroup }
        });
        next[currentQuestionIndex] = existing;
        return next;
      });
    };
    // Phase E (poll subtype) — note: aggregation-rule CREATION in the inline
    // editor is deferred to V1.1 (requires a chip-picker UI for acrossQuestions).
    // Pre-authored / AI-generated aggregation rules ARE renderable + deletable
    // in the rule list, and the router (AlloFlowANTI.txt _aggregateResponse)
    // evaluates them. The Likert banner in the rule panel explains this state
    // to the teacher.
    const removeQuizRoutingRule = (rid) => {
      setQuizRoutingRulesByQ(prev => {
        const next = { ...prev };
        next[currentQuestionIndex] = (next[currentQuestionIndex] || []).filter(r => r.id !== rid);
        return next;
      });
    };
    const updateQuizRoutingRule = (rid, patch) => {
      setQuizRoutingRulesByQ(prev => {
        const next = { ...prev };
        next[currentQuestionIndex] = (next[currentQuestionIndex] || []).map(r => {
          if (r.id !== rid) return r;
          return {
            ...r,
            version: (typeof r.version === 'number' ? r.version : 0) + 1,
            when: patch.when ? { ...r.when, ...patch.when } : r.when,
            then: patch.then ? { ...r.then, ...patch.then } : r.then,
          };
        });
        return next;
      });
    };
    // Toggle a single resource ID in/out of rule.then.hiddenResourceIds.
    // Default-show + rules hide: leaving the list empty means "no resources hidden
    // for students who match this rule" (back to normal behavior).
    const toggleQuizRoutingRuleHiddenId = (rid, resourceId) => {
      setQuizRoutingRulesByQ(prev => {
        const next = { ...prev };
        next[currentQuestionIndex] = (next[currentQuestionIndex] || []).map(r => {
          if (r.id !== rid) return r;
          const current = Array.isArray(r.then.hiddenResourceIds) ? r.then.hiddenResourceIds : [];
          const has = current.indexOf(resourceId) !== -1;
          const updated = has ? current.filter(x => x !== resourceId) : current.concat([resourceId]);
          return {
            ...r,
            version: (typeof r.version === 'number' ? r.version : 0) + 1,
            then: { ...r.then, hiddenResourceIds: updated },
          };
        });
        return next;
      });
    };
    // Resources teachers can choose to hide via routing. Exclude meta items
    // (advice, brainstorms, alignment reports) that students never see anyway.
    const hideableResources = (Array.isArray(history) ? history : [])
      .filter(item => item && item.id && item.type && !['udl-advice', 'brainstorm', 'alignment-report'].includes(item.type));
    const totalStudents = roster ? Object.keys(roster).length : 0;
    const scoredResponseUids = Object.keys(responses || {});
    const validReceiptUids = Object.entries(responseReceipts && typeof responseReceipts === 'object' ? responseReceipts : {})
      .slice(0, 250)
      .reduce((uids, [uid, rawReceipt]) => {
        const receipt = rawReceipt && typeof rawReceipt === 'object' && !Array.isArray(rawReceipt) ? rawReceipt : null;
        const keys = receipt ? Object.keys(receipt) : [];
        const fixedShape = !!receipt
          && keys.length === 4
          && keys.every(key => ['activityId', 'questionIndex', 'submittedAt', 'flow'].includes(key));
        const valid = fixedShape
          && (!roster || Object.prototype.hasOwnProperty.call(roster, uid))
          && receipt.activityId === quizState.activityId
          && receipt.questionIndex === currentQuestionIndex
          && typeof receipt.submittedAt === 'number'
          && Number.isFinite(receipt.submittedAt)
          && receipt.submittedAt > 0
          && receipt.flow === 'presentation';
        if (valid && !uids.includes(uid)) uids.push(uid);
        return uids;
      }, []);
    const answeredUidSet = new Set(scoredResponseUids.concat(validReceiptUids));
    const scoredAnsweredCount = scoredResponseUids.length;
    const answeredCount = answeredUidSet.size;
    const unscoredReceiptCount = validReceiptUids.filter(uid => !Object.prototype.hasOwnProperty.call(responses || {}, uid)).length;
    const percentage = totalStudents > 0 ? Math.min(100, Math.round((answeredCount / totalStudents) * 100)) : 0;
    // Success-criteria rollup for the lesson plan: class results per concept
    // label, published on window and announced so the plan's strip stays live
    // without threading session data through the plan view. Counts only.
    const criterionRollup = React.useMemo(() => {
      const agg = (typeof window !== 'undefined' && window.AlloModules) ? window.AlloModules.QuizLiveAggregators : null;
      if (!agg || typeof agg.aggregateSuccessCriteria !== 'function') return null;
      try { return agg.aggregateSuccessCriteria(quizState, generatedContent, roster); } catch (_) { return null; }
    }, [quizState, generatedContent, roster]);
    const planCriteria = React.useMemo(() => {
      const plan = (Array.isArray(history) ? history : []).slice().reverse()
        .find(item => item && item.type === 'lesson-plan' && item.data && Array.isArray(item.data.successCriteria) && item.data.successCriteria.length > 0);
      return plan ? plan.data.successCriteria : [];
    }, [history]);
    const criterionLiveByKey = React.useMemo(() => {
      const utils = typeof window !== 'undefined' && window.AlloModules ? window.AlloModules.UtilsPure : null;
      if (!criterionRollup || !utils || typeof utils.resolvePlanCriterionRollup !== 'function') return null;
      return utils.resolvePlanCriterionRollup(null, { byConcept: criterionRollup.byConcept });
    }, [criterionRollup]);
    const criterionLiveStat = (id) => {
      const utils = typeof window !== 'undefined' && window.AlloModules ? window.AlloModules.UtilsPure : null;
      if (criterionLiveByKey && utils && typeof utils.criterionRollupStat === 'function') return utils.criterionRollupStat(criterionLiveByKey, id);
      return criterionRollup && criterionRollup.byConcept ? criterionRollup.byConcept[id] || null : null;
    };
    // A pre-check runs before teaching, so it is never published as criteria met;
    // the quiz id, title and mode travel with the counts so the plan can name them.
    const liveQuizMode = String(generatedContent?.data?.mode || 'exit-ticket');
    useEffect(() => {
      if (typeof window === 'undefined' || !activeSessionCode || liveQuizMode === 'pre-check' || !criterionRollup || !criterionRollup.byConcept || !Object.keys(criterionRollup.byConcept).length) return;
      window.__alloCriterionRollup = {
        byConcept: criterionRollup.byConcept,
        respondents: criterionRollup.respondents,
        quizId: generatedContent?.id || null,
        quizTitle: typeof generatedContent?.title === 'string' ? generatedContent.title : '',
        quizMode: liveQuizMode,
        sessionCode: String(activeSessionCode),
        sessionLabel: `live session ${activeSessionCode}`,
        updatedAt: Date.now()
      };
      try { window.dispatchEvent(new CustomEvent('alloflow:criterion-rollup')); } catch (_) {}
    }, [criterionRollup, generatedContent?.id, generatedContent?.title, liveQuizMode, activeSessionCode]);
    const quizLiveAggregators = (typeof window !== 'undefined' && window.AlloModules)
      ? window.AlloModules.QuizLiveAggregators : null;
    const battleQuestionCount = (generatedContent?.data?.questions || []).filter(item => quizLiveAggregators?.presentationQuestionIsGameScorable
      ? quizLiveAggregators.presentationQuestionIsGameScorable(item)
      : Array.isArray(item?.options) && item.options.includes(item.correctAnswer)).length;
    const rawLiveScoringPolicy = scoringPolicy || generatedContent?.data?.scoringPolicy || {};
    const liveScoringPolicy = quizLiveAggregators && typeof quizLiveAggregators.normalizeLiveScoringPolicy === 'function'
      ? quizLiveAggregators.normalizeLiveScoringPolicy(rawLiveScoringPolicy)
      : {
          accuracy: rawLiveScoringPolicy?.accuracy !== false,
          confidence: rawLiveScoringPolicy?.confidence === true
            || String(rawLiveScoringPolicy?.liveMode || '').toLowerCase() === 'confidence',
          partialCredit: rawLiveScoringPolicy?.partialCredit !== false
        };
    // Compatibility fallback for a slow CDN/module load. It intentionally
    // stays option-only; the shared aggregator owns all generalized formats.
    const fallbackDetailedStats = (question && Array.isArray(question.options) ? question.options : []).map((opt, idx) => {
        const count = Object.values(responses || {}).filter(r => r === idx).length;
        const percent = scoredAnsweredCount > 0 ? Math.round((count / scoredAnsweredCount) * 100) : 0;
        return {
            label: String.fromCharCode(65 + idx),
            value: count,
            percent: percent,
            text: opt,
            imageUrl: Array.isArray(question.optionImageUrls) ? question.optionImageUrls[idx] : null,
            isCorrect: opt === question.correctAnswer
        };
    });
    const liveQuestionSummary = quizLiveAggregators && typeof quizLiveAggregators.aggregatePresentationResponses === 'function'
      ? quizLiveAggregators.aggregatePresentationResponses(question || {}, responses || {}, liveScoringPolicy)
      : {
          itemType: String(question?.itemType || question?.type || 'mcq'),
          kind: 'options',
          rows: fallbackDetailedStats,
          respondentCount: scoredAnsweredCount,
          evaluableResponseCount: scoredAnsweredCount,
          unscored: question?.itemType === 'likert' || question?.itemType === 'opinion-mcq',
          gameScorable: Array.isArray(question?.options) && question.options.length > 0 && question.correctAnswer != null,
          scoringPolicy: liveScoringPolicy,
          confidenceReportedCount: 0,
          confidenceMissingCount: 0,
          confidenceAwaitingReviewCount: 0,
          confidenceBuckets: { calibrated: 0, fragile: 0, confidentWrong: 0, uncertain: 0 },
          note: ''
        };
    const detailedStats = Array.isArray(liveQuestionSummary.rows) ? liveQuestionSummary.rows : [];
    const liveConfidenceBuckets = liveQuestionSummary.confidenceBuckets
      || { calibrated: 0, fragile: 0, confidentWrong: 0, uncertain: 0 };
    const liveConfidenceTiles = [
      { key: 'calibrated', label: 'Correct + knew it', tone: 'border-emerald-200 bg-emerald-50 text-emerald-900' },
      { key: 'fragile', label: 'Correct + unsure', tone: 'border-sky-200 bg-sky-50 text-sky-900' },
      { key: 'confidentWrong', label: 'Confident misconception', tone: 'border-rose-200 bg-rose-50 text-rose-900' },
      { key: 'uncertain', label: 'Incorrect + unsure', tone: 'border-amber-200 bg-amber-50 text-amber-900' }
    ];
    const liveAnswerGuide = quizLiveAggregators
      && typeof quizLiveAggregators.describePresentationCorrectAnswer === 'function'
      ? quizLiveAggregators.describePresentationCorrectAnswer(question || {})
      : (!liveQuestionSummary.unscored && question?.correctAnswer != null ? String(question.correctAnswer) : '');
    const renderAnalytics = () => (
        <div className="flex flex-col h-full w-full animate-in motion-reduce:animate-none fade-in duration-300">
            {liveQuestionSummary.note && (
              <div role="status" className={`mb-4 rounded-lg border px-3 py-2 text-xs font-bold ${liveQuestionSummary.unscored ? 'border-purple-200 bg-purple-50 text-purple-900' : 'border-amber-200 bg-amber-50 text-amber-900'}`}>
                {liveQuestionSummary.note}
              </div>
            )}
            {liveScoringPolicy.confidence && !liveQuestionSummary.unscored && (
              <section
                className="mb-4 rounded-xl border border-indigo-200 bg-indigo-50/70 p-3"
                data-live-confidence-summary="true"
                aria-label="Confidence check summary"
              >
                <div className="mb-2 flex items-center justify-between gap-3">
                  <span className="text-[11px] font-black uppercase tracking-wider text-indigo-900">Confidence check</span>
                  <span className="text-[11px] font-semibold text-indigo-700">Diagnostic only — never changes points</span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {liveConfidenceTiles.map((tile) => (
                    <div key={tile.key} className={`rounded-lg border px-2 py-1.5 ${tile.tone}`}>
                      <div className="text-lg font-black">{liveConfidenceBuckets[tile.key] || 0}</div>
                      <div className="text-[10px] font-bold">{tile.label}</div>
                    </div>
                  ))}
                </div>
                {(liveQuestionSummary.confidenceMissingCount > 0 || liveQuestionSummary.confidenceAwaitingReviewCount > 0) && (
                  <p className="mt-2 text-[11px] font-medium text-indigo-800">
                    {liveQuestionSummary.confidenceMissingCount || 0} without confidence · {liveQuestionSummary.confidenceAwaitingReviewCount || 0} awaiting teacher review
                  </p>
                )}
              </section>
            )}
            {detailedStats.length > 0 ? (
              <div className="w-full h-48 mb-6 shrink-0">
                  <SimpleBarChart data={detailedStats} color="indigo" />
              </div>
            ) : (
              <div role="status" className="w-full min-h-24 mb-6 rounded-lg border border-dashed border-slate-300 bg-white flex items-center justify-center px-4 text-center text-xs text-slate-600">
                Responses are present, but this item has no safe aggregate categories to display.
              </div>
            )}
            <div className="flex-grow overflow-y-auto pr-1 custom-scrollbar space-y-2">
                {detailedStats.map((stat, i) => (
                    <div
                        key={i}
                        className={`flex items-center justify-between p-3 rounded-lg border text-xs transition-all motion-reduce:transition-none ${
                            phase === 'revealed' && !liveQuestionSummary.unscored && stat.isCorrect
                            ? 'bg-green-50 border-green-200 ring-1 ring-green-300'
                            : 'bg-white border-slate-100 hover:border-indigo-200'
                        }`}
                    >
                        <div className="flex items-center gap-3 overflow-hidden mr-4">
                            <span className={`font-black w-6 h-6 flex items-center justify-center rounded shrink-0 ${
                                phase === 'revealed' && !liveQuestionSummary.unscored && stat.isCorrect ? 'bg-green-200 text-green-800' : 'bg-indigo-100 text-indigo-700'
                            }`}>
                                {stat.label}
                            </span>
                            {stat.imageUrl && (
                                <img
                                    src={stat.imageUrl}
                                    alt=""
                                    aria-hidden="true"
                                    loading="eager"
                                    decoding="async"
                                    onError={(event) => { event.currentTarget.hidden = true; }}
                                    data-live-quiz-presenter-option-image={i}
                                    className="h-12 w-16 shrink-0 rounded border border-slate-200 bg-white object-contain"
                                />
                            )}
                            <span className={`truncate font-medium ${phase === 'revealed' && !liveQuestionSummary.unscored && stat.isCorrect ? 'text-green-900' : 'text-slate-600'}`} title={stat.text}>
                                {stat.text}
                            </span>
                        </div>
                        <div className="flex items-center gap-3 shrink-0">
                            <div className="w-16 h-1.5 bg-slate-100 rounded-full overflow-hidden hidden sm:block">
                                <div
                                    className={`h-full ${phase === 'revealed' && !liveQuestionSummary.unscored && stat.isCorrect ? 'bg-green-500' : 'bg-indigo-500'}`}
                                    style={{ width: `${stat.percent}%` }}
                                ></div>
                            </div>
                            <div className="text-right min-w-[50px]">
                                <div className="font-black text-slate-800 text-sm">{stat.value}</div>
                                <div className="text-[11px] text-slate-600 font-mono">{stat.percent}%</div>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
            <div className="mt-4 pt-3 border-t border-slate-100 flex justify-between items-center gap-3 text-xs">
                <span className="font-bold text-slate-600 uppercase tracking-wider">
                    {t('quiz.total_responses')}
                    {unscoredReceiptCount > 0 && (
                      <span className="block mt-1 normal-case tracking-normal font-medium text-amber-700">
                        {unscoredReceiptCount} submitted, unscored (peer connection unavailable)
                      </span>
                    )}
                </span>
                <span className="font-mono font-black text-lg text-indigo-600 bg-indigo-50 px-3 py-0.5 rounded-full border border-indigo-100">
                    {liveQuestionSummary.respondentCount}
                </span>
            </div>
        </div>
    );
    const generateBossAsset = async () => {
        if (bossStats?.image || bossStats?.isGenerating || typeof onGenerateImage !== 'function') return;
        try {
            const sessionRef = doc(db, 'artifacts', appId, 'public', 'data', 'sessions', activeSessionCode);
            await updateDoc(sessionRef, { "quizState.bossStats.isGenerating": true });
            const topic = generatedContent.meta || "General Knowledge";
            const prompt = `Pixel art boss monster representing '${topic}'. Retro 8-bit video game sprite. Threatening but cute. White background. Isolated character.`;
            let imageUrl = await onGenerateImage(prompt, 300, 0.8);
            if (onRefineImage && imageUrl) {
                 try {
                     const rawBase64 = imageUrl.split(',')[1];
                     const refined = await onRefineImage(
                         "Remove all text, letters, labels, damage numbers, and UI elements. Remove background to make it transparent. Ensure clean pixel art sprite borders.",
                         rawBase64
                     );
                     if (refined) imageUrl = refined;
                 } catch (e) {
                     warnLog("Boss refinement failed, using original", e);
                 }
            }
            await updateDoc(sessionRef, {
                "quizState.bossStats.image": imageUrl,
                "quizState.bossStats.isGenerating": false
            });
        } catch (e) {
            warnLog("Boss Gen Failed", e);
            const sessionRef = doc(db, 'artifacts', appId, 'public', 'data', 'sessions', activeSessionCode);
            try { await updateDoc(sessionRef, { "quizState.bossStats.isGenerating": false }); } catch(e) { warnLog('Firestore sync failed:', e); }
        }
    };
    const triggerBossVisualUpdate = async (currentImageUrl, status) => {
        if (!onRefineImage || !currentImageUrl) return;
        const identity = bossIdentityRef.current;
        const request = ++bossVisualRequestRef.current;
        try {
            const rawBase64 = currentImageUrl.split(',')[1];
            let prompt = "";
            if (status === 'defeated') {
                prompt = "Edit this pixel art character to look defeated, collapsed, fainting, or turning into a ghost. Keep the style consistent.";
            } else {
                prompt = "Edit this pixel art character to look like it is taking damage, flinching, glowing red, or in pain. Keep the style consistent.";
            }
            const newImage = await onRefineImage(prompt, rawBase64);
            if (newImage && bossIdentityRef.current === identity && bossVisualRequestRef.current === request) {
                const sessionRef = doc(db, 'artifacts', appId, 'public', 'data', 'sessions', activeSessionCode);
                await updateDoc(sessionRef, { "quizState.bossStats.image": newImage });
            }
        } catch (e) {
            warnLog("Boss visual update failed", e);
        }
    };
    const handleStartQuestion = async () => {
        if (quizBusy || quizWriteRef.current || phase === 'answering' || !question || ['boss-defeated', 'class-defeated', 'battle-complete', 'closed'].includes(phase)) return;
        const sessionRef = doc(db, 'artifacts', appId, 'public', 'data', 'sessions', activeSessionCode);
        try { await writeQuiz(sessionRef, { "quizState.roundId": Date.now().toString(36) + Math.random().toString(36).slice(2, 8), "quizState.phase": "answering", "quizState.responses": {}, "quizState.responseReceipts": {}, "quizState.currentQuestionIndex": currentQuestionIndex, "quizState.bossStats.lastDamage": 0 }); } catch(e) { warnLog('Firestore sync failed:', e); }
    };
    const handleBossPacingAdjustment = async (kind) => {
        if (mode !== 'boss-battle' || !bossStats || bossPacingLocked || quizWriteRef.current || !['rally', 'soften', 'intensify'].includes(kind)) return;
        const sessionRef = doc(db, 'artifacts', appId, 'public', 'data', 'sessions', activeSessionCode);
        const updates = {};
        if (kind === 'rally') updates['quizState.bossStats.classHP'] = Math.min(bossStats.classMaxHP || 100, (bossStats.classHP ?? 100) + 10);
        if (kind === 'soften') updates['quizState.bossStats.currentHP'] = Math.max(1, (bossStats.currentHP ?? bossStats.maxHP) - Math.round((bossStats.maxHP || 1000) * 0.05));
        if (kind === 'intensify') updates['quizState.bossStats.currentHP'] = Math.min(bossStats.maxHP, (bossStats.currentHP ?? bossStats.maxHP) + Math.round((bossStats.maxHP || 1000) * 0.05));
        updates['quizState.bossStats.gmEvent'] = null;
        updates['quizState.bossStats.gmEventKey'] = `boss_event_${kind}`;
        await writeQuiz(sessionRef, updates);
    };
    const normalizeBossGmDraft = (draft = {}) => ({
        title: String(draft.title || t('concept_quest.boss_draft_default_title')).replace(/[<>]/g, '').trim().slice(0, 100),
        description: String(draft.description || bossGmPrompt || t('concept_quest.boss_draft_default_description')).replace(/[<>]/g, '').trim().slice(0, 500),
        effect: ['narrative', 'rally', 'expose', 'intensify'].includes(draft.effect) ? draft.effect : 'narrative',
        amount: Math.max(1, Math.min(10, Number(draft.amount) || 5))
    });
    const createBossGmDraft = () => setBossGmDraft(normalizeBossGmDraft({ description: bossGmPrompt }));
    const generateBossGmDraft = async () => {
        if (typeof callGemini !== 'function') { createBossGmDraft(); return; }
        if (bossGmBusy) return;
        const identity = bossIdentity;
        setBossGmBusy(true);
        try {
            const prompt = `Draft one short, classroom-safe teacher GM event for an educational Class-vs-Monsters battle about ${generatedContent?.meta || 'the lesson'}. Teacher direction: "${bossGmPrompt || 'Create a dramatic concept-based event.'}". Return only JSON: {"title":"...","description":"...","effect":"narrative|rally|expose|intensify","amount":1-10}. rally helps class HP; expose lowers monster HP; intensify raises monster HP. Never decide individual student outcomes.`;
            const response = await callGemini(prompt, true);
            const jsonText = String(response || '').replace(/```json\s*/gi, '').replace(/```/g, '').trim();
            if (bossIdentityRef.current === identity) setBossGmDraft(normalizeBossGmDraft(JSON.parse(jsonText)));
        } catch (error) {
            warnLog('Boss GM draft failed:', error);
            if (bossIdentityRef.current === identity) createBossGmDraft();
        } finally { setBossGmBusy(false); }
    };
    const publishBossGmDraft = async () => {
        if (!bossGmDraft || bossPacingLocked || quizWriteRef.current) return;
        const sessionRef = doc(db, 'artifacts', appId, 'public', 'data', 'sessions', activeSessionCode);
        const draft = normalizeBossGmDraft(bossGmDraft);
        const updates = { 'quizState.bossStats.gmEvent': `${draft.title}: ${draft.description}`, 'quizState.bossStats.gmEventKey': null };
        if (draft.effect === 'rally') updates['quizState.bossStats.classHP'] = Math.min(bossStats?.classMaxHP || 100, (bossStats?.classHP ?? 100) + draft.amount);
        const hpDelta = Math.round((bossStats?.maxHP || 1000) * (draft.amount / 100));
        if (draft.effect === 'expose') updates['quizState.bossStats.currentHP'] = Math.max(1, (bossStats?.currentHP ?? bossStats?.maxHP) - hpDelta);
        if (draft.effect === 'intensify') updates['quizState.bossStats.currentHP'] = Math.min(bossStats?.maxHP, (bossStats?.currentHP ?? bossStats?.maxHP) + hpDelta);
        if (await writeQuiz(sessionRef, updates)) { setBossGmDraft(null); setBossGmPrompt(''); }
    };
    const handleRevealResults = async () => {
        if (phase !== 'answering' || quizWriteRef.current) return;
        try {
            const sessionRef = doc(db, 'artifacts', appId, 'public', 'data', 'sessions', activeSessionCode);
            let updatePayload = {
                "quizState.phase": "revealed",
            };
            const gradeLiveResponse = (responseValue) => {
                if (quizLiveAggregators && typeof quizLiveAggregators.gradePresentationResponse === 'function') {
                    return quizLiveAggregators.gradePresentationResponse(responseValue, question || {}, liveScoringPolicy);
                }
                const responseIndex = Number.isInteger(responseValue) ? responseValue : -1;
                const correct = responseIndex >= 0 && Array.isArray(question?.options)
                  && question.options[responseIndex] === question.correctAnswer;
                return {
                    status: correct ? 'correct' : 'incorrect',
                    isCorrect: correct,
                    evaluable: responseIndex >= 0,
                    unscored: false,
                    scoreFraction: correct ? 1 : 0
                };
            };
            const accuracyWeightForGrade = (grade) => {
                if (quizLiveAggregators && typeof quizLiveAggregators.presentationAccuracyWeight === 'function') {
                    return quizLiveAggregators.presentationAccuracyWeight(grade, null, liveScoringPolicy);
                }
                if (!grade || grade.evaluable !== true || grade.unscored === true) return null;
                return typeof grade.scoreFraction === 'number'
                    ? Math.max(0, Math.min(1, grade.scoreFraction))
                    : (grade.isCorrect === true ? 1 : 0);
            };
            if (mode === 'boss-battle' && liveQuestionSummary.gameScorable && !(scoredAnsweredCount === 0 && unscoredReceiptCount > 0)) {
                const evaluatedResponses = Object.values(responses || {}).map(gradeLiveResponse).filter(grade => grade.evaluable);
                const correctCount = evaluatedResponses.filter(grade => grade.isCorrect === true).length;
                const totalResponses = evaluatedResponses.length;
                const earnedCredit = evaluatedResponses.reduce((sum, grade) => sum + (accuracyWeightForGrade(grade) || 0), 0);
                // A receipt-only delivery is unknown, not a wrong answer.
                const eligibleCount = Math.max(totalStudents - unscoredReceiptCount, totalResponses, 1);
                const wrongCredit = Math.max(0, eligibleCount - earnedCredit);
                // Budget damage across scorable items only; polls and teacher-review
                // prompts cannot drain the class's opportunities to defeat the boss.
                const bossMaxHP = bossStats?.maxHP || 1000;
                const quizLength = Math.max(1, battleQuestionCount);
                const perQuestionBudget = bossMaxHP / quizLength;
                const answerAccuracy = earnedCredit / eligibleCount;
                const baseDamage = Math.round(answerAccuracy * perQuestionBudget * 1.2);
                const masteryStreak = answerAccuracy >= 0.7 ? (bossStats?.masteryStreak || 0) + 1 : 0;
                const comboBonus = masteryStreak >= 3 ? Math.round(perQuestionBudget * 0.15) : 0;
                const damage = Math.min(bossStats?.currentHP ?? bossMaxHP, baseDamage + comboBonus);
                const currentHP = bossStats?.currentHP ?? bossMaxHP;
                const newHP = Math.max(0, currentHP - damage);
                const remainingBossPercent = newHP / bossMaxHP;
                const bossPhaseName = remainingBossPercent <= 0.33 ? 'final_form' : remainingBossPercent <= 0.66 ? 'enraged' : 'watchful';
                const difficultyMultiplier = bossStats?.difficulty === 'easy' ? 0.5 : bossStats?.difficulty === 'hard' ? 1.5 : 1.0;
                const baseClassDamage = Math.ceil((wrongCredit / eligibleCount) * 25);
                const classDamage = Math.min(bossStats?.classHP ?? 100, Math.round(baseClassDamage * difficultyMultiplier));
                const currentClassHP = bossStats?.classHP ?? 100;
                const newClassHP = Math.max(0, currentClassHP - classDamage);
                updatePayload["quizState.bossStats.currentHP"] = newHP;
                updatePayload["quizState.bossStats.lastDamage"] = damage;
                updatePayload["quizState.bossStats.classHP"] = newClassHP;
                updatePayload["quizState.bossStats.lastClassDamage"] = classDamage;
                updatePayload["quizState.bossStats.masteryStreak"] = masteryStreak;
                updatePayload["quizState.bossStats.lastComboBonus"] = comboBonus;
                updatePayload["quizState.bossStats.phaseName"] = bossPhaseName;
                updatePayload["quizState.bossStats.roundFeedback"] = {
                    accuracy: Math.round(answerAccuracy * 100),
                    scoredResponses: totalResponses,
                    excludedReceipts: unscoredReceiptCount,
                    masteryStreak,
                    comboBonus,
                    explanation: question?.explanation || question?.rationale || ''
                };
                const battleLogEntry = {
                    questionIndex: currentQuestionIndex,
                    damage,
                    classDamage,
                    correctCount,
                    totalResponses,
                    earnedCredit,
                    eligibleCount,
                    accuracy: Math.round(answerAccuracy * 100),
                    masteryStreak,
                    comboBonus,
                    bossPhase: bossPhaseName
                };
                const existingLog = bossStats?.battleLog || [];
                updatePayload["quizState.bossStats.battleLog"] = [...existingLog, battleLogEntry];
                const isLastQuestion = currentQuestionIndex >= (generatedContent?.data?.questions?.length || 1) - 1;
                if (newHP <= 0) {
                    // Includes the both-hit-zero edge (previously fell through to
                    // plain 'revealed'): the class landed the killing blow while
                    // falling — count it as the heroic win.
                    updatePayload["quizState.phase"] = "boss-defeated";
                    updatePayload["quizState.bossStats.endReason"] = "boss-health";
                } else if (newClassHP <= 0) {
                    updatePayload["quizState.phase"] = "class-defeated";
                    updatePayload["quizState.bossStats.endReason"] = "class-health";
                } else if (isLastQuestion && totalResponses === 0) {
                    updatePayload["quizState.phase"] = "class-defeated";
                } else if (isLastQuestion) {
                    // ── Last-question resolution (2026-07-16) ──────────────────
                    // Previously, running out of questions with both HP bars alive
                    // simply STALLED the battle — no ending, no debrief. The final
                    // reveal now resolves by comparing remaining HP percentages
                    // (class wins ties — be generous), reusing the existing phases
                    // so student overlays need no changes.
                    const bossPct = newHP / bossMaxHP;
                    const classPct = newClassHP / (bossStats?.classMaxHP || 100);
                    updatePayload["quizState.phase"] = classPct >= bossPct ? "boss-defeated" : "class-defeated";
                    updatePayload["quizState.bossStats.endReason"] = "questions-complete";
                }

            }
            else if (mode === 'boss-battle') {
                updatePayload['quizState.bossStats.lastDamage'] = 0;
                updatePayload['quizState.bossStats.lastClassDamage'] = 0;
                updatePayload['quizState.bossStats.roundFeedback'] = { scoringPaused: true, explanation: unscoredReceiptCount > 0 && scoredAnsweredCount === 0
                    ? 'Participation arrived without answer content. No health was lost. Reopen this question after students reconnect to score their answers.'
                    : 'This item is for discussion or teacher review. Battle health is unchanged.' };
                if (!liveQuestionSummary.gameScorable && currentQuestionIndex >= (generatedContent?.data?.questions?.length || 1) - 1) {
                    const hasScoredRounds = (bossStats?.battleLog || []).some(entry => entry.totalResponses > 0);
                    updatePayload['quizState.phase'] = !hasScoredRounds ? 'battle-complete'
                        : (bossStats?.classHP ?? 100) / (bossStats?.classMaxHP || 100) >= (bossStats?.currentHP ?? 1000) / (bossStats?.maxHP || 1000) ? 'boss-defeated' : 'class-defeated';
                    updatePayload['quizState.bossStats.endReason'] = hasScoredRounds ? 'questions-complete' : 'no-scored-items';
                }
            }
            else if (mode === 'team-showdown' && liveQuestionSummary.gameScorable) {
                const currentScores = sessionData.quizState.teamScores || {};
                const teamStats = {};
                Object.entries(responses || {}).forEach(([uid, responseValue]) => {
                    const grade = gradeLiveResponse(responseValue);
                    if (!grade.evaluable) return;
                    const teamColor = sessionData.quizState.teams?.[uid];
                    if (teamColor) {
                        if (!teamStats[teamColor]) teamStats[teamColor] = { total: 0, correct: 0, earned: 0 };
                        teamStats[teamColor].total++;
                        teamStats[teamColor].earned += accuracyWeightForGrade(grade) || 0;
                        if (grade.isCorrect === true) teamStats[teamColor].correct++;
                    }
                });
                // ── Team fairness (2026-07-16): score against TEAM SIZE, not just
                // responders. Previously a team where a single student answered
                // (correctly) scored a perfect 1000, beating a team with 5 of 6
                // correct (833) — rewarding non-participation. Every teammate now
                // counts in the denominator, so answering (and being right) is the
                // only way to score.
                const teamMemberCounts = {};
                Object.values(sessionData.quizState.teams || {}).forEach((color) => {
                    if (color) teamMemberCounts[color] = (teamMemberCounts[color] || 0) + 1;
                });
                Object.keys(Object.assign({}, teamMemberCounts, teamStats)).forEach((team) => {
                    const stats = teamStats[team] || { total: 0, correct: 0, earned: 0 };
                    const denominator = Math.max(stats.total, teamMemberCounts[team] || 0, 1);
                    const percentage = stats.earned / denominator;
                    const pointsEarned = Math.round(percentage * 1000);
                    const oldScore = currentScores[team] || 0;
                    updatePayload[`quizState.teamScores.${team}`] = oldScore + pointsEarned;
                    updatePayload[`quizState.lastRoundStats.${team}`] = {
                        points: pointsEarned,
                        percent: Math.round(percentage * 100),
                        earnedCredit: stats.earned,
                        responded: stats.total
                    };
                });
            }
            const saved = await writeQuiz(sessionRef, updatePayload);
            if (saved && bossIdentityRef.current === bossIdentity && updatePayload['quizState.bossStats.lastDamage'] > 0 && bossStats?.image) {
                triggerBossVisualUpdate(bossStats.image, updatePayload['quizState.phase'] === 'boss-defeated' ? 'defeated' : 'hurt');
            }
        } catch (e) { warnLog("Unhandled error in handleRevealResults:", e); }
    };
    const handleNextQuestion = async () => {
        if (phase === 'answering' || bossBattleEnded || quizWriteRef.current) return;
        try {
            const nextIdx = currentQuestionIndex + 1;
            if (nextIdx >= generatedContent?.data.questions.length) return;
            const sessionRef = doc(db, 'artifacts', appId, 'public', 'data', 'sessions', activeSessionCode);
            await writeQuiz(sessionRef, {
                "quizState.currentQuestionIndex": nextIdx,
                "quizState.phase": "idle",
                "quizState.responses": {},
                "quizState.responseReceipts": {},
                "quizState.bossStats.lastDamage": 0
            });
        } catch (e) { warnLog("Unhandled error in handleNextQuestion:", e); }
    };
    const handlePrevQuestion = async () => {
        if (phase === 'answering' || bossBattleEnded || quizWriteRef.current) return;
        try {
            const prevIdx = currentQuestionIndex - 1;
            if (prevIdx < 0) return;
            const sessionRef = doc(db, 'artifacts', appId, 'public', 'data', 'sessions', activeSessionCode);
            await writeQuiz(sessionRef, {
                "quizState.currentQuestionIndex": prevIdx,
                "quizState.phase": "idle",
                "quizState.responses": {},
                "quizState.responseReceipts": {},
                "quizState.bossStats.lastDamage": 0
            });
        } catch (e) { warnLog("Unhandled error in handlePrevQuestion:", e); }
    };
    // ── Boss Battle Debrief (2026-07-16) ────────────────────────────────────
    // battleLog was appended on every reveal (accuracy/damage per question) but
    // NEVER rendered — the formative half of boss mode was being discarded.
    // Shown inside the victory/defeat overlays: which questions the class aced
    // and which one wrecked them (the reteach candidate).
    const renderBattleDebrief = () => {
        const log = bossStats?.battleLog || [];
        if (log.length === 0) return null;
        const worst = log.reduce((min, e) => (e.accuracy < min.accuracy ? e : min), log[0]);
        const qText = (idx) => {
            const q = generatedContent?.data?.questions?.[idx];
            return (q && (q.question || q.text)) || '';
        };
        return (
            <div className="mt-5 w-full max-w-sm mx-auto text-left bg-black/30 rounded-xl p-3 max-h-44 overflow-y-auto">
                <div className="text-[10px] font-black uppercase tracking-widest text-white/70 mb-2">{t('quiz.boss.debrief_title') || 'Battle debrief — accuracy by question'}</div>
                {log.map((e, i) => (
                    <div key={i} className="flex items-center gap-2 mb-1" title={qText(e.questionIndex)}>
                        <span className="text-[10px] font-bold text-white/80 w-7 shrink-0">Q{(e.questionIndex ?? i) + 1}</span>
                        <div className="flex-1 h-2.5 bg-white/15 rounded-full overflow-hidden">
                            <div className={`h-full ${e.accuracy >= 70 ? 'bg-emerald-400' : e.accuracy >= 40 ? 'bg-amber-400' : 'bg-rose-500'}`} style={{ width: `${Math.max(4, e.accuracy)}%` }}></div>
                        </div>
                        <span className="text-[10px] font-bold text-white w-9 text-right shrink-0">{e.accuracy}%</span>
                        {log.length > 1 && e === worst && e.accuracy < 70 && (
                            <span className="text-[9px] font-black text-rose-200 bg-rose-900/60 border border-rose-400/40 rounded px-1 py-0.5 shrink-0" title={t('quiz.boss.debrief_reteach_title') || 'Lowest accuracy — a reteach candidate'}>{t('quiz.boss.debrief_reteach') || 'reteach?'}</span>
                        )}
                    </div>
                ))}
            </div>
        );
    };
    const handleEndQuiz = async () => {
        const sessionRef = doc(db, 'artifacts', appId, 'public', 'data', 'sessions', activeSessionCode);
        if (await writeQuiz(sessionRef, { 'quizState.isActive': false, 'quizState.phase': 'closed', 'quizState.endedAt': Date.now() })) {
            addToast?.(t('quiz.session_ended_success') || 'Session ended successfully.', 'success');
        }
    };
    const handleModeChange = async (e, nextDifficulty = bossDifficulty, restart = false) => {
        if (quizWriteRef.current || (!restart && (phase === 'answering' || answeredCount > 0)) || (restart && !bossBattleEnded)) return;
        const newMode = e.target.value;
        const sessionRef = doc(db, 'artifacts', appId, 'public', 'data', 'sessions', activeSessionCode);
        const updates = { "quizState.phase": "idle", "quizState.mode": newMode, "quizState.responses": {}, "quizState.responseReceipts": {} };
        if (restart) {
            updates['quizState.currentQuestionIndex'] = 0;
            updates['quizState.roundId'] = 'battle-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
        }
        if (newMode === 'boss-battle') {
            const qCount = Math.max(1, battleQuestionCount);
            const sCount = Math.max(1, totalStudents);
            const baseHP = (qCount * sCount * 10);
            const hpMultiplier = nextDifficulty === 'easy' ? 0.5 : nextDifficulty === 'hard' ? 1.5 : 1.0;
            const maxHP = Math.round(baseHP * hpMultiplier);
            const existingImage = bossStats?.image || null;
            updates["quizState.bossStats"] = {
                battleId: 'battle-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8),
                maxHP: maxHP,
                currentHP: maxHP,
                classHP: 100,
                classMaxHP: 100,
                name: t('quiz.boss.default_name'),
                lastDamage: 0,
                lastClassDamage: 0,
                image: existingImage,
                isGenerating: false,
                difficulty: nextDifficulty,
                battleLog: [],
                masteryStreak: 0,
                lastComboBonus: 0,
                phaseName: 'watchful',
                roundFeedback: null,
                gmEvent: null,
                gmEventKey: null,
                endReason: null
            };

        }
        if (await writeQuiz(sessionRef, updates)) {
            setBossDifficulty(nextDifficulty);
            if (newMode === 'boss-battle' && !bossStats?.image) generateBossAsset();
        }
    };
    const handleScoringPolicyChange = async (e) => {
        if (phase === 'answering' || answeredCount > 0) return;
        const nextPolicy = {
            accuracy: true,
            confidence: e.target.value === 'confidence',
            partialCredit: liveScoringPolicy.partialCredit !== false
        };
        const sessionRef = doc(db, 'artifacts', appId, 'public', 'data', 'sessions', activeSessionCode);
        try {
            await writeQuiz(sessionRef, {
                "quizState.scoringPolicy": nextPolicy,
                "quizState.responses": {},
                "quizState.responseReceipts": {}
            });
        } catch (error) { warnLog('Live response policy sync failed:', error); }
    };
    const [newGroupName, setNewGroupName] = useState("");
    const groups = sessionData.groups || {};
    const handleCreateGroup = async () => {
        if (!newGroupName.trim()) return;
        await onCreateGroup(newGroupName.trim());
        setNewGroupName("");
    };
    const handleAssignStudent = onAssignStudent;
    const handleSetGroupResource = onSetGroupResource;
    const handleSetGroupLanguage = onSetGroupLanguage;
    const handleSetGroupProfile = onSetGroupProfile;
    const handleDeleteGroup = onDeleteGroup;
    const availableResources = generatedContent?.data.resources || [];
    const activeGroups = useMemo(() => Object.entries(groups).filter(([_, g]) => g !== null), [groups]);
    return (
        <div className="bg-white rounded-2xl shadow-xl border border-slate-400 overflow-hidden mb-6 animate-in motion-reduce:animate-none slide-in-from-top-4 duration-500" aria-busy={quizBusy}>
            {quizError && <p role="alert" className="m-3 rounded-lg bg-red-100 p-3 font-bold text-red-900">{quizError}</p>}
            {quizBusy && <p role="status" className="px-4 py-2 text-indigo-900">Updating the live quiz…</p>}
            <div className="bg-indigo-900 text-white p-4 flex justify-between items-center flex-wrap gap-4">
                <h3 className="font-bold flex items-center gap-2"><MonitorPlay size={20} className="text-teal-700"/> {t('quiz.live_control_center')}</h3>
                <div className="flex items-center gap-4">
                     <select aria-label={t('common.selection')}
                        value={mode || 'live-pulse'} disabled={quizBusy || phase === 'answering' || answeredCount > 0} title="Choose a mode before starting an unanswered round." data-help-key="quiz_mode_select"
                        onChange={handleModeChange}
                        className="bg-indigo-800 text-white text-xs font-bold px-3 py-1.5 rounded-lg border border-indigo-600 focus:outline-none focus:ring-2 focus:ring-teal-400 cursor-pointer"
                     >
                         <option value="live-pulse">📊 {t('quiz.modes.live_pulse')}</option>
                         <option value="boss-battle">⚔️ {t('quiz.modes.boss_battle')}</option>
                         <option value="team-showdown">🏆 {t('quiz.modes.team_showdown')}</option>
                     </select>
                     <select
                        aria-label="Live response policy"
                        data-help-key="quiz_live_scoring_policy_select"
                        value={liveScoringPolicy.confidence ? 'confidence' : 'accuracy'}
                        onChange={handleScoringPolicyChange}
                        disabled={quizBusy || phase === 'answering' || answeredCount > 0}
                        className="bg-indigo-800 text-white text-xs font-bold px-3 py-1.5 rounded-lg border border-indigo-600 focus:outline-none focus:ring-2 focus:ring-teal-400 cursor-pointer disabled:cursor-not-allowed disabled:opacity-60"
                        title={phase === 'answering' || answeredCount > 0 ? 'Choose a response policy before students answer.' : 'Choose what students report with each answer.'}
                     >
                        <option value="accuracy">Accuracy</option>
                        <option value="confidence">Accuracy + confidence check</option>
                     </select>
                     {mode === 'boss-battle' && (
                         <select aria-label="Battle difficulty"
                             value={bossDifficulty}
                             onChange={(e) => handleModeChange({target:{value:'boss-battle'}}, e.target.value)}
                             disabled={quizBusy || (!['lobby', 'idle'].includes(phase) || answeredCount > 0 || (bossStats?.battleLog || []).length > 0)}
                             className={`text-xs font-bold px-3 py-1.5 rounded-lg border focus:outline-none focus:ring-2 focus:ring-teal-400 cursor-pointer ${
                                 bossDifficulty === 'easy' ? 'bg-emerald-700 border-emerald-500 text-white' :
                                 bossDifficulty === 'hard' ? 'bg-red-600 border-red-500 text-white' :
                                 'bg-amber-700 border-amber-400 text-white'
                             } ${(!['lobby', 'idle'].includes(phase) || answeredCount > 0 || (bossStats?.battleLog || []).length > 0) ? 'opacity-60 cursor-not-allowed' : ''}`}
                             title={(!['lobby', 'idle'].includes(phase) || answeredCount > 0 || (bossStats?.battleLog || []).length > 0) ? t('quiz.boss.difficulty_locked') : t('quiz.boss.select_difficulty')}
                         >
                             <option value="easy">🌱 {t('quiz.boss.difficulty_easy')}</option>
                             <option value="normal">⚔️ {t('quiz.boss.difficulty_normal')}</option>
                             <option value="hard">💀 {t('quiz.boss.difficulty_hard')}</option>
                         </select>
                     )}
                     {mode !== 'live-pulse' && (
                         <button type="button"
                             aria-label={showLocalStats ? t('quiz.show_game') : t('quiz.show_stats')} aria-pressed={showLocalStats}
                             onClick={() => setShowLocalStats(prev => !prev)} data-help-key="quiz_local_stats_btn"
                             className={`text-xs font-bold px-3 py-1.5 rounded-lg transition-colors motion-reduce:transition-none flex items-center gap-2 border ${showLocalStats ? 'bg-yellow-400 text-indigo-900 border-yellow-500' : 'bg-indigo-800 text-indigo-200 border-indigo-600 hover:bg-indigo-700'}`}
                             title={t('quiz.toggle_stats_tooltip')}
                         >
                             {showLocalStats ? <Gamepad2 size={14}/> : <Layout size={14}/>}
                             {showLocalStats ? t('quiz.show_game') : t('quiz.show_stats')}
                         </button>
                     )}
                     <div className="text-xs font-mono bg-indigo-800 px-3 py-1.5 rounded-full font-bold shadow-sm border border-indigo-700">
                        {t('quiz.answered_status', {
                            current: answeredCount,
                            total: totalStudents,
                            percent: percentage
                        })}
                     </div>
                     <button type="button" onClick={handleEndQuiz} disabled={quizBusy} className="text-xs bg-red-500 hover:bg-red-600 px-3 py-1.5 rounded-full font-bold transition-colors motion-reduce:transition-none focus:outline-none focus:ring-2 focus:ring-white">
                        {t('quiz.end_quiz')}
                     </button>
                </div>
            </div>
            <div className="w-full h-1.5 bg-slate-100 relative">
                <div className="bg-teal-500 h-full transition-all motion-reduce:transition-none duration-500 ease-out" style={{ width: `${percentage}%` }}></div>
            </div>
            <div className="border-b border-indigo-100 bg-indigo-50 px-4 py-2 text-xs font-semibold text-indigo-900" data-live-scoring-policy-note="true">
                {liveScoringPolicy.confidence
                  ? 'Accuracy scoring plus a confidence check. Confidence never changes points; it is diagnostic only.'
                  : 'Accuracy uses correctness and configured partial credit only. Response speed never changes points.'}
                {liveQuestionSummary.unscored && (
                  <span className="ml-1 font-black text-purple-800">This prompt remains distribution-only.</span>
                )}
            </div>
            {planCriteria.length > 0 && liveQuizMode !== 'pre-check' && criterionRollup && criterionRollup.byConcept && (
              <div className="border-b border-indigo-100 bg-white px-4 py-2 text-xs" data-live-success-criteria="true">
                <div className="font-black uppercase tracking-wider text-indigo-700 mb-1">Success criteria (this lesson plan)</div>
                <ul className="space-y-1">
                  {planCriteria.map((c, i) => {
                    if (!c || typeof c !== 'object') return null;
                    const s = criterionLiveStat(c.id);
                    const pct = s && s.total > 0 ? Math.round((s.met / s.total) * 100) : null;
                    return <li key={c.id || i} className="flex flex-wrap items-center gap-2">
                      <span className="text-slate-700">{typeof c.statement === 'string' ? c.statement : ''}</span>
                      <span className="font-mono text-[10px] text-indigo-700 bg-indigo-50 border border-indigo-100 rounded px-1">{c.id}</span>
                      {pct === null
                        ? <span className="text-[11px] text-slate-500">no scored answers yet</span>
                        : <span className={`font-bold ${pct >= 80 ? 'text-emerald-700' : pct >= 60 ? 'text-amber-700' : 'text-rose-700'}`} data-criterion-mastery={c.id}>{`${pct}% met (${s.met}/${s.total})`}</span>}
                    </li>;
                  })}
                </ul>
              </div>
            )}
            <div className="bg-slate-50 border-b border-slate-200 p-4">
                <div className="flex flex-col md:flex-row gap-4">
                    <div className="flex-1">
                        <h4 className="text-xs font-bold text-slate-600 uppercase mb-2">{t('groups.title')}</h4>
                        <div className="flex gap-2 mb-3">
                             <input aria-label={t('common.new_group_name')}
                                type="text"
                                value={newGroupName} data-help-key="quiz_new_group_input"
                                onChange={(e) => setNewGroupName(e.target.value)}
                                placeholder={t('groups.new_group_placeholder')}
                                className="text-sm p-1.5 rounded border border-slate-400 flex-1"
                             />
                             <button type="button"
                                onClick={handleCreateGroup} data-help-key="quiz_add_group_btn"
                                disabled={!newGroupName.trim()}
                                className="bg-indigo-600 text-white text-xs px-3 py-1.5 rounded hover:bg-indigo-700 disabled:opacity-50 font-bold"
                             >
                                 + {t('groups.add_button')}
                             </button>
                        </div>
                        <div className="space-y-2 max-h-40 overflow-y-auto custom-scrollbar">
                            {activeGroups.map(([gid, group]) => (
                                <div key={gid} className="bg-white p-2 rounded border border-indigo-100 shadow-sm flex flex-col gap-2">
                                    <div className="flex justify-between items-center">
                                        <div className="flex items-center gap-2">
                                            <span className="text-sm font-bold text-indigo-900">{group.name}</span>
                                            <button type="button" onClick={() => handleDeleteGroup(gid)} className="text-[11px] text-red-600 hover:text-red-600 font-bold focus:outline-none focus:ring-2 focus:ring-red-400 rounded">{t('groups.remove_button')}</button>
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <span className="text-[11px] uppercase font-bold text-slate-600">{t('groups.resource_label')}</span>
                                        <select aria-label={t('common.selection')}
                                            value={group.resourceId || ""} data-help-key="quiz_group_resource_select"
                                            onChange={(e) => handleSetGroupResource(gid, e.target.value)}
                                            disabled={isPushingResource[gid] === 'pushing'}
                                            className="text-xs p-1 rounded border border-slate-400 w-full truncate bg-slate-50 disabled:opacity-50 disabled:cursor-not-allowed"
                                        >
                                            <option value="">{t('groups.default_resource')}</option>
                                            {availableResources.map(r => (
                                                <option key={r.id} value={r.id}>{r.title || r.type}</option>
                                            ))}
                                        </select>
                                        {isPushingResource[gid] === 'pushing' && (
                                            <span className="flex items-center gap-1 text-[10px] text-purple-600 font-bold whitespace-nowrap">
                                                <RefreshCw size={11} className="animate-spin motion-reduce:animate-none" /> {t('groups.pushing') || 'Pushing…'}
                                            </span>
                                        )}
                                        {isPushingResource[gid] === 'success' && (
                                            <span className="flex items-center gap-1 text-[10px] text-emerald-600 font-bold whitespace-nowrap">
                                                <CheckCircle2 size={11} /> {t('groups.pushed') || 'Sent'}
                                            </span>
                                        )}
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <span className="text-[11px] uppercase font-bold text-slate-600">{t('groups.language_label') || 'Quiz Language'}</span>
                                        <select aria-label={t('common.selection')}
                                            value={group.language || ""} data-help-key="quiz_group_language_select"
                                            onChange={(e) => handleSetGroupLanguage(gid, e.target.value)}
                                            className="text-xs p-1 rounded border border-slate-400 w-full truncate bg-slate-50"
                                            title={t('groups.language_tooltip') || 'Students see quizzes in this language'}
                                        >
                                            <option value="">{t('groups.language_default') || 'English (Default)'}</option>
                                            <option value="Spanish">Spanish</option>
                                            <option value="Vietnamese">Vietnamese</option>
                                            <option value="Mandarin">Mandarin</option>
                                            <option value="Arabic">Arabic</option>
                                            <option value="French">French</option>
                                            <option value="Portuguese">Portuguese</option>
                                            <option value="Korean">Korean</option>
                                            <option value="Tagalog">Tagalog</option>
                                            <option value="Russian">Russian</option>
                                            <option value="Japanese">Japanese</option>
                                        </select>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <span className="text-[11px] uppercase font-bold text-slate-600">{t('groups.reading_level_label') || 'Reading Level'}</span>
                                        <select aria-label={t('common.reading_level')}
                                            value={group.readingLevel || ""} data-help-key="group_reading_level_select"
                                            onChange={(e) => handleSetGroupProfile(gid, 'readingLevel', e.target.value || null)}
                                            className="text-xs p-1 rounded border border-slate-400 w-full truncate bg-slate-50"
                                            title={t('groups.reading_level_tooltip') || 'Set reading level for content simplification'}
                                        >
                                            <option value="">{t('groups.class_default') || 'Class Default'}</option>
                                            <option value="K">K</option>
                                            <option value="1st">1st Grade</option>
                                            <option value="2nd">2nd Grade</option>
                                            <option value="3rd">3rd Grade</option>
                                            <option value="4th">4th Grade</option>
                                            <option value="5th">5th Grade</option>
                                            <option value="6th">6th Grade</option>
                                            <option value="7th">7th Grade</option>
                                            <option value="8th">8th Grade</option>
                                            <option value="9th-12th">9th-12th</option>
                                        </select>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <span className="text-[11px] uppercase font-bold text-slate-600">{t('groups.visual_density_label') || 'Visuals'}</span>
                                        <select aria-label={t('common.visual_density')}
                                            value={group.visualDensity || "normal"} data-help-key="group_visual_density_select"
                                            onChange={(e) => handleSetGroupProfile(gid, 'visualDensity', e.target.value)}
                                            className="text-xs p-1 rounded border border-slate-400 w-full truncate bg-slate-50"
                                            title={t('groups.visual_density_tooltip') || 'How much visual support this group receives'}
                                        >
                                            <option value="minimal">{t('groups.visuals_minimal') || 'Minimal'}</option>
                                            <option value="normal">{t('groups.visuals_normal') || 'Normal'}</option>
                                            <option value="high">{t('groups.visuals_high') || 'High (More images)'}</option>
                                        </select>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <span className="text-[11px] uppercase font-bold text-slate-600">{t('groups.tts_speed_label') || 'TTS Speed'}</span>
                                        <select aria-label={t('common.tts_speed')}
                                            value={group.ttsSpeed ?? 1.0} data-help-key="group_tts_speed_select"
                                            onChange={(e) => handleSetGroupProfile(gid, 'ttsSpeed', parseFloat(e.target.value))}
                                            className="text-xs p-1 rounded border border-slate-400 w-full truncate bg-slate-50"
                                            title={t('groups.tts_speed_tooltip') || 'Text-to-speech playback speed for this group'}
                                        >
                                            <option value="0.6">0.6x (Very Slow)</option>
                                            <option value="0.8">0.8x (Slow)</option>
                                            <option value="1.0">1.0x (Normal)</option>
                                            <option value="1.2">1.2x (Fast)</option>
                                            <option value="1.5">1.5x (Very Fast)</option>
                                        </select>
                                    </div>
                                    <div className="flex items-center gap-2 flex-wrap">
                                        <label className="flex items-center gap-1 text-[11px] font-bold text-slate-600 cursor-pointer" title={t('groups.karaoke_tooltip') || 'Auto-enable word highlighting for this group'}>
                                            <input type="checkbox" checked={group.karaokeMode || false} onChange={(e) => handleSetGroupProfile(gid, 'karaokeMode', e.target.checked)} className="rounded border-slate-300 text-indigo-500 focus:ring-indigo-400" />
                                            {t('groups.karaoke_label') || 'Karaoke Mode'}
                                        </label>
                                    <div className="flex items-center gap-3 mt-1">
                                        <label className="flex items-center gap-1 text-[11px] font-bold text-slate-600 cursor-pointer" title={t('common.toggle_emoji_usage_for_this_group')}>
                                            <input type="checkbox" checked={group.profile?.useEmojis || false} onChange={(e) => handleSetGroupProfile(gid, 'useEmojis', e.target.checked)} className="rounded border-slate-300 text-indigo-500 focus:ring-indigo-400" />
                                            {t('roster.emojis_label') || 'Use Emojis'}
                                        </label>
                                        <select aria-label={t('common.text_format')} value={group.profile?.textFormat || 'Standard Text'} onChange={(e) => handleSetGroupProfile(gid, 'textFormat', e.target.value)} className="text-[11px] p-1 rounded border border-slate-400 bg-slate-50">
                                            <option value="Standard Text">{t('roster.format_standard') || 'Standard'}</option>
                                            <option value="Bullet Points">{t('roster.format_bullets') || 'Bullets'}</option>
                                            <option value="Outline">{t('roster.format_outline') || 'Outline'}</option>
                                        </select>
                                    </div>
                                    </div>
                                </div>
                            ))}
                            {activeGroups.length === 0 && (
                                <div className="text-xs text-slate-600 italic text-center py-2">{t('groups.no_groups')}</div>
                            )}
                        </div>
                    </div>
                    <div className="flex-[2] border-l border-slate-200 pl-4">
                        <h4 className="text-xs font-bold text-slate-600 uppercase mb-2">{t('groups.roster_title')}</h4>
                        <div className="bg-white rounded border border-slate-400 p-3 max-h-52 overflow-y-auto custom-scrollbar">
                            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
                                {Object.entries(roster || {}).map(([uid, student]) => {
                                    const groupId = student.groupId;
                                    const groupName = groupId && groups[groupId] ? groups[groupId].name : null;
                                    return (
                                        <div key={uid} className={`relative p-2 rounded border text-xs ${groupName ? 'bg-indigo-50 border-indigo-200' : 'bg-slate-50 border-slate-100'}`}>
                                            <div className="font-bold truncate" title={student.displayName}>{student.displayName || "Anonymous"}</div>
                                            <div className={`mt-1 text-[11px] font-mono truncat ${groupName ? 'text-indigo-600' : 'text-slate-600'}`}>
                                                {groupName || t('groups.main_class')}
                                            </div>
                                            <select aria-label={t('common.selection')}
                                                onChange={(e) => handleAssignStudent(uid, e.target.value || null)} data-help-key="quiz_assign_student_select"
                                                value={groupId || ""}
                                                className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                                                title={t('groups.move_to')}
                                            >
                                                <option value="">{t('groups.main_class')}</option>
                                                {activeGroups.map(([gid, grp]) => (
                                                    <option key={gid} value={gid}>{grp.name}</option>
                                                ))}
                                            </select>
                                        </div>
                                    );
                                })}
                            </div>
                             {(!roster || Object.keys(roster).length === 0) && (
                                <div className="text-center text-slate-600 italic py-4">{t('groups.waiting_students')}</div>
                            )}
                        </div>
                    </div>
                </div>
            </div>
            <div className="p-6 grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="flex flex-col justify-between h-full">
                     <div className="mb-6">
                         <span className="text-xs font-bold text-slate-600 uppercase tracking-widest block mb-2">
                             {t('quiz.question_progress', {
                                 current: currentQuestionIndex + 1,
                                 total: generatedContent?.data.questions.length
                             })}
                         </span>
                         {question.imageUrl && (
                             <img
                                 src={question.imageUrl}
                                 alt={String(question.imageAlt || question.question || t('quiz.question_image') || 'Question image')}
                                 loading="eager"
                                 decoding="async"
                                 onError={(event) => { event.currentTarget.hidden = true; }}
                                 data-live-quiz-presenter-question-image="true"
                                 className="mb-4 max-h-56 w-full rounded-xl border border-slate-200 bg-slate-50 object-contain shadow-sm"
                             />
                         )}
                         <h2 className="text-2xl font-bold text-slate-800 leading-tight">{question?.question || question?.contextSentence || 'Live response item'}</h2>
                         {mode !== 'live-pulse' && !liveQuestionSummary.gameScorable && (
                           <div role="status" className="mt-3 rounded-lg border border-purple-200 bg-purple-50 px-3 py-2 text-xs font-bold text-purple-900">
                             {liveQuestionSummary.unscored
                               ? 'Unscored poll — Boss Battle and Team Showdown scoring pause for this round.'
                               : 'Teacher-review item — game scoring pauses until an evaluative item.'}
                           </div>
                         )}
                         {Array.isArray(question.optionImageUrls) && question.optionImageUrls.some(Boolean) && (
                             <div
                                 className="mt-4 grid grid-cols-2 gap-2"
                                 data-live-quiz-presenter-option-grid="true"
                                 role="group"
                                 aria-label={t('quiz.answer_options') || 'Answer options'}
                             >
                                 {(question.options || []).map((option, optionIndex) => (
                                     <div key={optionIndex} className="rounded-lg border border-slate-200 bg-slate-50 p-2">
                                         {question.optionImageUrls[optionIndex] && (
                                             <img
                                                 src={question.optionImageUrls[optionIndex]}
                                                 alt=""
                                                 aria-hidden="true"
                                                 loading="eager"
                                                 decoding="async"
                                                 onError={(event) => { event.currentTarget.hidden = true; }}
                                                 data-live-quiz-presenter-option-image={optionIndex}
                                                 className="mb-1 h-20 w-full rounded bg-white object-contain"
                                             />
                                         )}
                                         <p className="text-xs font-semibold text-slate-700">
                                             <span className="mr-1 font-black text-indigo-700">{String.fromCharCode(65 + optionIndex)}.</span>
                                             {option}
                                         </p>
                                     </div>
                                 ))}
                             </div>
                         )}
                     </div>
                     <div className="mb-4 bg-amber-50 border border-amber-200 rounded-lg p-2">
                         <button type="button"
                             onClick={() => setShowQuizRoutingPanel(v => !v)}
                             className="flex items-center gap-2 text-xs font-bold text-amber-800 hover:text-amber-900"
                             aria-expanded={showQuizRoutingPanel}
                         >
                             <span>{showQuizRoutingPanel ? '▾' : '▸'}</span>
                             <span>📊 Auto-routing rules for this question</span>
                             <span className="font-normal text-amber-700">({currentRules.length} rule{currentRules.length === 1 ? '' : 's'})</span>
                         </button>
                         {showQuizRoutingPanel && (
                             <div className="mt-2 space-y-2">
                                 <p className="text-[11px] text-amber-700 leading-snug">
                                     When a student answers, auto-assign them to a group. Use this for <strong>choice</strong> (e.g., "Pirate Crew vs Space Crew") or <strong>formative-assessment</strong> routing. Group resources can then be staged per group via the Groups panel above.
                                 </p>
                                 {groupEntriesForRouting.length === 0 && (
                                     <p className="text-[11px] text-red-700 italic">{t('teacher.quiz_routing.no_groups_warning') || 'Create at least one group in the Groups panel above before adding routing rules.'}</p>
                                 )}
                                 {currentRules.map(rule => {
                                     const hiddenIds = Array.isArray(rule.then.hiddenResourceIds) ? rule.then.hiddenResourceIds : [];
                                     // Phase E (poll subtype): aggregation rules have a different
                                     // shape (rule.when.aggregate + acrossQuestions). They're
                                     // routable by the router (Phase B) but the in-editor creator
                                     // doesn't ship with a chip picker for acrossQuestions in V1,
                                     // so pre-authored / AI-generated aggregation rules render as
                                     // a read-only summary with a delete affordance only.
                                     if (rule.when && rule.when.confidencePattern) {
                                       const across = Array.isArray(rule.when.acrossQuestions) ? rule.when.acrossQuestions : [];
                                       const patternLabel = rule.when.confidencePattern === 'fragile' ? '🌱 Fragile knowledge (correct but guessed)'
                                         : rule.when.confidencePattern === 'confident-wrong' ? '🧭 Confident misconception (wrong but sure)'
                                         : '⭐ Calibrated mastery (correct and sure)';
                                       return (
                                         <div key={rule.id} className="bg-white border border-sky-200 rounded p-1.5 text-xs space-y-1">
                                           <div className="flex flex-wrap items-center gap-1">
                                             <span className="px-1 py-0.5 rounded bg-sky-100 text-sky-800 text-[10px] font-bold uppercase tracking-wide">Confidence</span>
                                             <span className="text-slate-700">{patternLabel} across {across.map(i => `Q${i + 1}`).join(', ')}</span>
                                             <span className="text-slate-600">→</span>
                                             <select
                                                 value={rule.then.groupId || ''}
                                                 onChange={e => updateQuizRoutingRule(rule.id, { then: { groupId: e.target.value } })}
                                                 aria-label="Destination group"
                                                 className="border border-slate-300 rounded px-1 py-0.5 text-[11px]"
                                             >
                                               <option value="">— pick group —</option>
                                               {groupEntriesForRouting.map(([gid, g]) => <option key={gid} value={gid}>{g.name || gid}</option>)}
                                             </select>
                                             <button type="button"
                                                 onClick={() => removeQuizRoutingRule(rule.id)}
                                                 aria-label="Remove confidence rule"
                                                 className="ml-auto px-1.5 py-0.5 text-red-700 hover:bg-red-50 rounded border border-red-200"
                                             >✕</button>
                                           </div>
                                           <div className="text-[10px] text-slate-500 italic pl-1">
                                             Screening heuristic, not a measurement: fires only when ≥2 of these items match the pattern (with a confidence report). Use it to start a conversation, not to label a learner.
                                           </div>
                                         </div>
                                       );
                                     }
                                     if (rule.when && rule.when.aggregate) {
                                       const across = Array.isArray(rule.when.acrossQuestions) ? rule.when.acrossQuestions : [];
                                       return (
                                         <div key={rule.id} className="bg-white border border-purple-200 rounded p-1.5 text-xs space-y-1">
                                           <div className="flex flex-wrap items-center gap-1">
                                             <span className="px-1 py-0.5 rounded bg-purple-100 text-purple-800 text-[10px] font-bold uppercase tracking-wide">Aggregation</span>
                                             <span className="text-slate-700">
                                               {String(rule.when.aggregate)} of items {across.map(i => `Q${i + 1}`).join(', ') || '(none)'} {rule.when.predicate} {String(rule.when.value)}
                                             </span>
                                             {across.length < 2 && (
                                               <span className="ml-1 text-[10px] text-red-700 italic">— needs ≥2 items to fire</span>
                                             )}
                                             <button type="button"
                                                 onClick={() => removeQuizRoutingRule(rule.id)}
                                                 aria-label="Remove aggregation rule"
                                                 className="ml-auto px-1.5 py-0.5 text-red-700 hover:bg-red-50 rounded border border-red-200"
                                             >✕</button>
                                           </div>
                                           <div className="text-[10px] text-slate-500 italic pl-1">
                                             Aggregation-rule editing lands in a future update. Pre-authored or AI-generated rules can be deleted but not edited inline yet.
                                           </div>
                                         </div>
                                       );
                                     }
                                     return (
                                     <div key={rule.id} className="bg-white border border-amber-200 rounded p-1.5 text-xs space-y-1">
                                       <div className="flex flex-wrap items-center gap-1">
                                         <span className="text-slate-600">{t('teacher.quiz_routing.when_answer_label') || 'When answer'}</span>
                                         <select
                                             aria-label="Predicate"
                                             value={rule.when.predicate}
                                             onChange={(e) => updateQuizRoutingRule(rule.id, { when: { predicate: e.target.value } })}
                                             className="px-1 py-0.5 border border-slate-300 rounded text-xs"
                                         >
                                             <option value="eq">is</option>
                                             <option value="in">is one of</option>
                                         </select>
                                         <select
                                             aria-label={t('teacher.quiz_routing.answer_option_aria') || 'Answer option'}
                                             value={rule.when.predicate === 'in' ? '' : rule.when.value}
                                             onChange={(e) => updateQuizRoutingRule(rule.id, { when: { value: e.target.value } })}
                                             className="px-1 py-0.5 border border-slate-300 rounded text-xs"
                                         >
                                             <option value="">— pick option —</option>
                                             {(question?.options || []).map((opt, oi) => (
                                                 <option key={oi} value={opt}>{String.fromCharCode(65 + oi)}: {opt}</option>
                                             ))}
                                         </select>
                                         <span className="text-slate-600">→ assign to</span>
                                         <select
                                             aria-label={t('teacher.quiz_routing.target_group_aria') || 'Target group'}
                                             value={rule.then.groupId || ''}
                                             onChange={(e) => updateQuizRoutingRule(rule.id, { then: { groupId: e.target.value } })}
                                             className="px-1 py-0.5 border border-slate-300 rounded text-xs"
                                         >
                                             <option value="">— pick group —</option>
                                             {groupEntriesForRouting.map(([gid, g]) => (
                                                 <option key={gid} value={gid}>{g.name || gid}</option>
                                             ))}
                                         </select>
                                         <button type="button"
                                             onClick={() => removeQuizRoutingRule(rule.id)}
                                             aria-label={t('teacher.quiz_routing.remove_rule_aria') || 'Remove rule'}
                                             className="ml-auto px-1.5 py-0.5 text-red-700 hover:bg-red-50 rounded border border-red-200"
                                         >✕</button>
                                       </div>
                                       {/* Conditional resource visibility — fail-open. Checked items hide for
                                           students whose answer matches this rule. Empty list = no resources hidden. */}
                                       {hideableResources.length > 0 && (
                                         <details className="mt-1">
                                           <summary className="text-[11px] text-slate-600 cursor-pointer hover:text-slate-800">
                                             {hiddenIds.length > 0
                                               ? `→ Also hide ${hiddenIds.length} resource${hiddenIds.length === 1 ? '' : 's'}`
                                               : '→ Also hide resources (optional)'}
                                           </summary>
                                           <div className="mt-1 pl-2 pt-1 border-t border-amber-100 space-y-0.5 max-h-32 overflow-y-auto">
                                             <p className="text-[10px] text-slate-500 italic mb-1">
                                               Students whose answer matches this rule won't see the checked resources in their history panel. Other students still see everything.
                                             </p>
                                             {hideableResources.map(item => {
                                               const isChecked = hiddenIds.indexOf(item.id) !== -1;
                                               const label = item.title || (item.data && item.data.title) || item.type || item.id;
                                               return (
                                                 <label key={item.id} className="flex items-center gap-1.5 text-[11px] text-slate-700 hover:bg-amber-50 rounded px-1 py-0.5 cursor-pointer">
                                                   <input
                                                     type="checkbox"
                                                     checked={isChecked}
                                                     onChange={() => toggleQuizRoutingRuleHiddenId(rule.id, item.id)}
                                                     aria-label={`Hide ${label} from students matching this rule`}
                                                     className="cursor-pointer"
                                                   />
                                                   <span className="text-slate-500 uppercase text-[9px] font-bold min-w-[40px]">{item.type}</span>
                                                   <span className="truncate flex-1">{label}</span>
                                                 </label>
                                               );
                                             })}
                                           </div>
                                         </details>
                                       )}
                                     </div>
                                     );
                                 })}
                                 {/* Phase E (poll subtype): show the appropriate Add button
                                     for the current question's item type. Likert items REQUIRE
                                     aggregation across >=2 distinct items (single-tick routing
                                     is structurally refused — single self-report ticks aren't
                                     measurement-reliable for placement decisions per the
                                     CBM-style discipline Aaron applies in Word Sounds). */}
                                 {_currentQuestionIsLikert ? (
                                   <div className="rounded border border-purple-200 bg-purple-50 px-2 py-1.5 text-[11px] text-purple-900 leading-snug">
                                     <strong className="font-bold">Likert routing:</strong> single-item Likert routing is refused — a single self-report tick is not measurement-reliable. Multi-item aggregation rules (avg / min / max across ≥2 items) are supported by the router and can be pre-authored or AI-generated; in-editor rule creation lands in a future update.
                                   </div>
                                 ) : (
                                   <div className="flex flex-wrap gap-1">
                                     <button type="button"
                                         onClick={addQuizRoutingRule}
                                         disabled={groupEntriesForRouting.length === 0}
                                         className={`text-xs font-bold px-2 py-1 rounded border border-dashed ${groupEntriesForRouting.length === 0 ? 'border-slate-300 text-slate-400 cursor-not-allowed' : 'border-amber-500 text-amber-800 hover:bg-amber-100'}`}
                                     >+ Add rule</button>
                                     <button type="button"
                                         onClick={() => addConfidencePatternRule('fragile')}
                                         disabled={groupEntriesForRouting.length === 0 || _gradableIdxs.length < 2}
                                         title="Route students who are getting answers right while reporting 'I guessed' (≥2 items) — consolidation support, not a label"
                                         className={`text-xs font-bold px-2 py-1 rounded border border-dashed ${(groupEntriesForRouting.length === 0 || _gradableIdxs.length < 2) ? 'border-slate-300 text-slate-400 cursor-not-allowed' : 'border-sky-500 text-sky-800 hover:bg-sky-100'}`}
                                     >+ 🌱 Fragile-knowledge rule</button>
                                     <button type="button"
                                         onClick={() => addConfidencePatternRule('confident-wrong')}
                                         disabled={groupEntriesForRouting.length === 0 || _gradableIdxs.length < 2}
                                         title="Route students who are answering wrong while reporting 'I knew it' (≥2 items) — misconception conference list"
                                         className={`text-xs font-bold px-2 py-1 rounded border border-dashed ${(groupEntriesForRouting.length === 0 || _gradableIdxs.length < 2) ? 'border-slate-300 text-slate-400 cursor-not-allowed' : 'border-sky-500 text-sky-800 hover:bg-sky-100'}`}
                                     >+ 🧭 Misconception rule</button>
                                   </div>
                                 )}
                             </div>
                         )}
                     </div>
                     <div className="space-y-3 mt-auto">
                         {phase === 'answering' && <p className="text-sm text-slate-700">Reveal results before moving to another question. Responses stay available until then.</p>}
                         {bossBattleEnded ? <div className="rounded-xl border border-indigo-200 bg-indigo-50 p-3"><p className="mb-2 text-sm text-indigo-900">Review the battle below. Restart begins at question 1 with full health and a new battle history.</p><button type="button" disabled={quizBusy} onClick={() => handleModeChange({target:{value:'boss-battle'}}, bossStats?.difficulty || 'normal', true)} className="min-h-11 w-full rounded-lg bg-indigo-700 px-4 py-3 font-bold text-white disabled:opacity-50">Restart battle</button></div> : phase === 'answering' ? (
                             <button type="button" aria-label={t('quiz.reveal_results')}
                                onClick={handleRevealResults} disabled={quizBusy} data-help-key="quiz_reveal_btn"
                                className="w-full py-4 rounded-xl bg-yellow-500 hover:bg-yellow-400 text-indigo-900 font-black text-xl shadow-lg transition-transform motion-reduce:transition-none active:scale-95 flex items-center justify-center gap-2"
                             >
                                 <Eye size={24}/> {t('quiz.reveal_results')}
                             </button>
                         ) : (
                             <button type="button" aria-label={phase === 'revealed' ? t('quiz.restart_question') : t('quiz.start_question')}
                                onClick={handleStartQuestion} disabled={quizBusy || !question || ['boss-defeated', 'class-defeated', 'battle-complete', 'closed'].includes(phase)} data-help-key="quiz_start_question_btn"
                                className="w-full py-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xl shadow-lg transition-transform motion-reduce:transition-none active:scale-95 flex items-center justify-center gap-2"
                             >
                                 <Play size={24} className="fill-current"/> {phase === 'revealed' ? t('quiz.restart_question') : t('quiz.start_question')}
                             </button>
                         )}
                         <div className="flex gap-3 pt-2">
                             <button type="button"
                                onClick={handlePrevQuestion} data-help-key="quiz_prev_question_btn"
                                disabled={quizBusy || bossBattleEnded || phase === 'answering' || currentQuestionIndex === 0}
                                className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl font-bold disabled:opacity-50 transition-colors motion-reduce:transition-none flex items-center justify-center gap-2"
                            >
                                <ArrowDown className="rotate-90" size={16}/> {t('common.prev')}
                             </button>
                             <button type="button"
                                onClick={handleNextQuestion} data-help-key="quiz_next_question_btn"
                                disabled={quizBusy || bossBattleEnded || phase === 'answering' || currentQuestionIndex >= generatedContent?.data?.questions?.length - 1}
                                className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl font-bold disabled:opacity-50 transition-colors motion-reduce:transition-none flex items-center justify-center gap-2"
                            >
                                {t('common.next')} <ArrowDown className="-rotate-90" size={16}/>
                             </button>
                         </div>
                     </div>
                </div>
                <div className="bg-slate-50 rounded-xl border border-slate-400 p-6 flex flex-col items-center justify-center min-h-[300px] relative">
                     {(showLocalStats || mode === 'live-pulse') ? (
                         scoredAnsweredCount > 0 ? renderAnalytics() : unscoredReceiptCount > 0 ? (
                            <div role="status" className="text-amber-800 flex flex-col items-center gap-2 h-full justify-center text-center max-w-sm">
                                <Layout size={48} className="opacity-20"/>
                                <span className="text-sm font-bold">{unscoredReceiptCount} submitted, unscored</span>
                                <span className="text-xs text-amber-700">Their peer connection was unavailable, so AlloFlow recorded participation without storing answer content.</span>
                            </div>
                         ) : (
                            <div className="text-slate-600 italic flex flex-col items-center gap-2 h-full justify-center">
                                <Layout size={48} className="opacity-20"/>
                                <span className="text-sm font-medium">{t('quiz.waiting_responses')}</span>
                            </div>
                         )
                     ) : (
                         <>
                            {mode === 'boss-battle' && bossStats ? (
                                <div className="w-full h-full flex flex-col items-center justify-center animate-in motion-reduce:animate-none fade-in zoom-in duration-300 relative">
                                     {bossBattleEnded && <section aria-label="Battle result" className="mb-5 w-full rounded-xl border border-indigo-300 bg-slate-900 p-5 text-center text-white">
                                         <h3 className="text-2xl font-black" role="status">{phase === 'boss-defeated' ? 'Class victory!' : phase === 'battle-complete' ? 'Battle complete' : 'A chance to regroup'}</h3>
                                         <p className="mt-2 text-sm text-slate-200">{bossStats.endReason === 'no-scored-items' ? 'This quiz had no scored battle rounds. Discuss the responses together.' : bossStats.endReason === 'questions-complete' ? 'All questions are complete. The result compares the percentage of health remaining; ties favor the class.' : phase === 'boss-defeated' ? 'The class defeated the monster together.' : 'Review the explanations, discuss a strategy, and try another battle.'}</p>
                                         {renderBattleDebrief()}
                                     </section>}
                                     <div className={`relative mb-6 ${phase === 'revealed' && bossStats.lastDamage > 0 ? 'animate-shake motion-reduce:animate-none' : ''}`}>
                                         {bossStats.image ? (
                                             <img loading="lazy"
                                                src={bossStats.image}
                                                alt="Boss"
                                                className="w-48 h-48 object-contain pixelated drop-shadow-xl"
                                                style={{ imageRendering: 'pixelated' }}
                                             />
                                         ) : (
                                             <div className="w-32 h-32 bg-red-100 rounded-full border-4 border-red-500 flex items-center justify-center text-6xl shadow-xl relative z-10">
                                                 {bossStats.isGenerating ? <RefreshCw className="animate-spin motion-reduce:animate-none text-red-500"/> : "👾"}
                                             </div>
                                         )}
                                         {phase === 'revealed' && bossStats.lastDamage > 0 && (
                                             <div className={`absolute top-0 right-[-20px] font-black z-20 stroke-white drop-shadow-md animate-[bounce_0.5s_infinite] motion-reduce:animate-none ${bossStats.lastDamage >= (bossStats.maxHP || 1000) * 0.15 ? 'text-yellow-500 text-6xl' : 'text-red-600 text-4xl'}`}>
                                                 {bossStats.lastDamage >= (bossStats.maxHP || 1000) * 0.15 ? '💥 ' : ''}-{bossStats.lastDamage}
                                             </div>
                                         )}
                                     </div>
                                     <h3 className="text-xl font-black text-slate-800 uppercase tracking-widest mb-2">{bossStats.name || t('quiz.boss.default_name')}</h3>
                                     <div className="mb-2 flex flex-wrap items-center justify-center gap-2 text-xs font-bold"><span className="rounded-full bg-red-100 px-2 py-1 text-red-800">{t('concept_quest.boss_phase', { phase: bossPhaseLabel })}</span><span className="rounded-full bg-yellow-100 px-2 py-1 text-yellow-900">{t('concept_quest.boss_mastery_streak', { count: bossStats.masteryStreak || 0 })}</span>{bossStats.lastComboBonus > 0 && <span className="rounded-full bg-purple-100 px-2 py-1 text-purple-800">⚡ {t('concept_quest.boss_combo_bonus', { bonus: bossStats.lastComboBonus })}</span>}</div>
                                     <p className="mb-3 max-w-sm text-center text-xs text-slate-600">{phase === 'answering' ? 'Reveal results before changing battle health or publishing an event.' : bossBattleEnded ? 'Battle finished. Restart to change health or publish another event.' : 'Correct answers help the class attack. Strong rounds build a combo. Pacing controls apply between questions.'}</p>
                                     {unscoredReceiptCount > 0 && <p role="status" className="mb-3 max-w-sm rounded-lg border border-amber-300 bg-amber-50 p-3 text-sm text-amber-950">{unscoredReceiptCount} participation-only submission(s). These are excluded from damage calculations.</p>}
                                     {phase === 'revealed' && bossStats.roundFeedback?.scoringPaused && <p role="status" className="mb-3 max-w-sm rounded-lg border border-indigo-200 bg-indigo-50 p-3 text-sm text-indigo-950">{bossStats.roundFeedback.explanation}</p>}
                                     <div role="group" className="mb-3 flex flex-wrap justify-center gap-2" aria-label={t('concept_quest.boss_pacing_aria')}><button type="button" disabled={bossPacingLocked} onClick={() => handleBossPacingAdjustment('rally')} className="disabled:opacity-50 disabled:cursor-not-allowed min-h-11 rounded-lg bg-emerald-700 px-3 text-xs font-bold text-white">{t('concept_quest.boss_rally_class_hp')}</button><button type="button" disabled={bossPacingLocked} onClick={() => handleBossPacingAdjustment('soften')} className="disabled:opacity-50 disabled:cursor-not-allowed min-h-11 rounded-lg bg-indigo-700 px-3 text-xs font-bold text-white">{t('concept_quest.boss_expose_weakness')}</button><button type="button" disabled={bossPacingLocked} onClick={() => handleBossPacingAdjustment('intensify')} className="disabled:opacity-50 disabled:cursor-not-allowed min-h-11 rounded-lg border border-red-300 bg-white px-3 text-xs font-bold text-red-800">{t('concept_quest.boss_intensify_monster')}</button></div>
                                     <details className="mb-3 w-full max-w-sm rounded-xl border border-purple-200 bg-purple-50 p-3 text-left"><summary className="cursor-pointer text-sm font-black text-purple-900">🎲 {t('concept_quest.boss_event_workshop')}</summary><p className="mt-1 text-xs text-purple-700">{t('concept_quest.ai_draft_notice')}</p><textarea aria-label="Teacher event direction" maxLength={500} value={bossGmPrompt} onChange={event => setBossGmPrompt(event.target.value)} rows={2} placeholder={t('concept_quest.boss_event_placeholder')} className="mt-2 w-full rounded-lg border border-purple-300 p-2 text-sm" /><div className="mt-2 flex gap-2"><button type="button" onClick={createBossGmDraft} className="min-h-11 flex-1 rounded-lg border border-purple-300 bg-white text-xs font-bold text-purple-800">{t('concept_quest.manual_draft')}</button><button type="button" disabled={bossGmBusy} onClick={generateBossGmDraft} className="min-h-11 flex-1 rounded-lg bg-purple-700 text-xs font-bold text-white disabled:opacity-50">{bossGmBusy ? t('concept_quest.boss_drafting') : t('concept_quest.ai_draft')}</button></div>{bossGmDraft && <div className="mt-2 rounded-lg border border-amber-300 bg-amber-50 p-2"><label className="text-xs font-bold text-slate-700">{t('concept_quest.draft_title_label')}<input value={bossGmDraft.title} onChange={event => setBossGmDraft({ ...bossGmDraft, title: event.target.value })} className="mt-1 min-h-11 w-full rounded border border-amber-300 p-2" /></label><label className="mt-2 block text-xs font-bold text-slate-700">{t('concept_quest.description')}<textarea value={bossGmDraft.description} onChange={event => setBossGmDraft({ ...bossGmDraft, description: event.target.value })} rows={2} className="mt-1 w-full rounded border border-amber-300 p-2" /></label><p className="mt-1 text-xs text-amber-900">{t('concept_quest.boss_effect')} <strong>{t(`concept_quest.boss_effect_${bossGmDraft.effect}`)}</strong> · {t('concept_quest.boss_strength', { amount: bossGmDraft.amount })}</p><div className="mt-2 flex gap-2"><button type="button" onClick={() => setBossGmDraft(null)} className="min-h-11 flex-1 rounded-lg bg-slate-200 text-xs font-bold">{t('concept_quest.discard')}</button><button type="button" disabled={bossPacingLocked} onClick={publishBossGmDraft} className="disabled:opacity-50 disabled:cursor-not-allowed min-h-11 flex-1 rounded-lg bg-emerald-700 text-xs font-bold text-white">{t('concept_quest.boss_publish_event')}</button></div></div>}</details>
                                     <div className={`w-full max-w-sm bg-slate-300 h-8 rounded-full border-4 relative overflow-hidden shadow-inner mb-2 ${bossStats.currentHP > 0 && (bossStats.currentHP / bossStats.maxHP) < 0.25 ? 'border-red-500 animate-pulse motion-reduce:animate-none' : 'border-slate-400'}`}>
                                         <div
                                            role="progressbar" aria-label="Monster health" aria-valuemin={0} aria-valuemax={bossStats.maxHP || 1} aria-valuenow={Math.min(bossStats.maxHP || 1, Math.max(0, bossStats.currentHP || 0))}
                                            className={`h-full transition-all motion-reduce:transition-none duration-1000 ease-out ${(bossStats.currentHP / bossStats.maxHP) < 0.25 ? 'bg-gradient-to-r from-red-700 to-red-500' : 'bg-gradient-to-r from-red-600 to-orange-500'}`}
                                            style={{ width: `${Math.min(100, Math.max(0, (bossStats.currentHP / (bossStats.maxHP || 1)) * 100))}%` }}
                                         ></div>
                                         <div className="absolute inset-0 flex items-center justify-center text-xs font-black text-white drop-shadow-md">
                                             {Math.round(bossStats.currentHP)} / {bossStats.maxHP} {t('quiz.hp')}
                                         </div>
                                     </div>
                                     <div className="w-full max-w-sm bg-slate-300 h-6 rounded-full border-4 border-slate-400 relative overflow-hidden shadow-inner mb-2">
                                         <div
                                            role="progressbar" aria-label="Class health" aria-valuemin={0} aria-valuemax={bossStats.classMaxHP || 100} aria-valuenow={Math.min(bossStats.classMaxHP || 100, Math.max(0, bossStats.classHP ?? 100))}
                                            className="h-full bg-gradient-to-r from-green-600 to-emerald-400 transition-all motion-reduce:transition-none duration-1000 ease-out"
                                            style={{ width: `${Math.min(100, Math.max(0, ((bossStats.classHP ?? 100) / (bossStats.classMaxHP || 100)) * 100))}%` }}
                                         ></div>
                                         <div className="absolute inset-0 flex items-center justify-center text-xs font-black text-white drop-shadow-md">
                                             {t('quiz.boss.class_hp')}: {Math.round(bossStats.classHP ?? 100)} / {bossStats.classMaxHP || 100}
                                         </div>
                                     </div>
                                     {phase === 'revealed' && bossStats.lastClassDamage > 0 && (
                                         <div className="text-orange-600 font-bold text-sm mb-2 animate-pulse motion-reduce:animate-none">
                                             {t('quiz.boss.counter_attack_msg', { damage: bossStats.lastClassDamage })}
                                         </div>
                                     )}
                                     {phase === 'revealed' && (
                                         <div className="mt-2 text-center">
                                             {(bossStats.classHP ?? 100) <= 0 ? (
                                                 <div className="text-red-600 font-black text-2xl animate-bounce motion-reduce:animate-none">{t('quiz.boss.class_defeat_msg')}</div>
                                             ) : bossStats.currentHP <= 0 ? (
                                                 <div className="text-green-600 font-black text-2xl animate-bounce motion-reduce:animate-none">{t('quiz.boss.victory_msg')}</div>
                                             ) : bossStats.lastDamage > 0 ? (
                                                 <div className="text-red-500 font-bold">{t('quiz.boss.attack_msg', { damage: bossStats.lastDamage })}</div>
                                             ) : (
                                                 <div className="text-slate-600 font-bold">{t('quiz.boss.miss_msg')}</div>
                                             )}
                                         </div>
                                     )}
                                 </div>
                            ) : mode === 'team-showdown' ? (
                                <div className="w-full h-full flex flex-col items-center justify-center gap-6">
                                     <div className="flex items-end justify-center gap-4 w-full h-48 pb-2 border-b-2 border-slate-200">
                                         {['Red', 'Blue', 'Green', 'Yellow'].map(team => {
                                             const score = teamScores?.[team] || 0;
                                             const maxScore = Math.max(2000, ...Object.values(teamScores || {}));
                                             const height = Math.max(5, (score / maxScore) * 100);
                                             const colors = {
                                                 Red: 'bg-red-500', Blue: 'bg-blue-500', Green: 'bg-green-500', Yellow: 'bg-yellow-400',
                                             };
                                             return (
                                                 <div key={team} className="flex flex-col items-center justify-end h-full w-16 group relative">
                                                     <span className="mb-1 font-black text-slate-700 text-sm">{score}</span>
                                                     <div
                                                        className={`w-full rounded-t-lg transition-all motion-reduce:transition-none duration-700 ease-out ${colors[team]} shadow-lg`}
                                                        style={{ height: `${height}%` }}
                                                     ></div>
                                                     <span className="mt-2 text-xs font-bold uppercase text-slate-600">{t(`quiz.teams.${team.toLowerCase()}`)}</span>
                                                     {phase === 'revealed' && sessionData.quizState.lastRoundStats?.[team]?.points > 0 && (
                                                         <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-yellow-300 text-indigo-900 text-xs font-black px-2 py-1 rounded shadow-sm animate-bounce motion-reduce:animate-none whitespace-nowrap z-10">
                                                             +{sessionData.quizState.lastRoundStats[team].points}
                                                         </div>
                                                     )}
                                                 </div>
                                             );
                                         })}
                                     </div>
                                     <p className="text-xs text-slate-600 font-bold uppercase tracking-wider">{t('quiz.team_leaderboard')}</p>
                                 </div>
                            ) : null}
                         </>
                     )}
                     {(phase === 'revealed' || bossBattleEnded) && !liveQuestionSummary.unscored && liveAnswerGuide && (
                         <div className="mt-6 w-full bg-green-100 border border-green-200 text-green-800 p-4 rounded-xl text-center animate-in motion-reduce:animate-none slide-in-from-bottom-2 shadow-sm z-10">
                             <span className="block text-[11px] font-black uppercase tracking-widest text-green-600 mb-1">{t('quiz.correct_answer_label')}</span>
                             <span className="text-lg font-bold">{liveAnswerGuide}</span>
                         </div>
                     )}
                </div>
            </div>
        </div>
    );
});
const calculateAnalyticsMetrics = (dashboardData) => {
  if (!dashboardData || !Array.isArray(dashboardData) || dashboardData.length === 0) {
    return {
      averageScore: 0,
      quizCompletionRate: 0,
      avgAdventureLevel: 0,
      misconceptions: []
    };
  }
  let totalQuizPercentage = 0;
  let totalQuizzesCount = 0;
  let studentsWithAtLeastOneQuiz = 0;
  let totalAdventureLevels = 0;
  let studentsWithAdventureData = 0;
  const missedQuestionsFrequency = {};
  dashboardData.forEach(student => {
    const history = student.history || [];
    const responses = student.responses || {};
    let studentHasQuiz = false;
    const adventureItems = history.filter(h => h.type === 'adventure');
    if (adventureItems.length > 0) {
        const lastAdventure = adventureItems[adventureItems.length - 1];
        // The game saves progress under data.snapshot; data.level is the legacy shape.
        const level = Number(lastAdventure.data?.snapshot?.level ?? lastAdventure.data?.level);
        if (Number.isFinite(level) && level > 0) {
            totalAdventureLevels += level;
            studentsWithAdventureData++;
        }
    }
    const quizItems = history.filter(h => h.type === 'quiz');
    if (quizItems.length > 0) {
        studentHasQuiz = true;
        quizItems.forEach(quiz => {
            const questions = quiz.data?.questions || [];
            if (questions.length === 0) return;
            let correctCount = 0;
            questions.forEach((q, qIdx) => {
                const studentResponse = responses[quiz.id]?.[qIdx];
                if (studentResponse !== undefined && studentResponse !== null) {
                    let selectedOptionText = studentResponse;
                    if (!isNaN(parseInt(studentResponse)) && q.options && q.options[studentResponse]) {
                         selectedOptionText = q.options[studentResponse];
                    }
                    const cleanSelected = String(selectedOptionText).trim().toLowerCase();
                    const cleanCorrect = String(q.correctAnswer).trim().toLowerCase();
                    if (cleanSelected === cleanCorrect) {
                        correctCount++;
                    } else {
                        const qText = q.question;
                        if (!missedQuestionsFrequency[qText]) {
                            missedQuestionsFrequency[qText] = 0;
                        }
                        missedQuestionsFrequency[qText]++;
                    }
                } else {
                    const qText = q.question;
                    if (!missedQuestionsFrequency[qText]) {
                        missedQuestionsFrequency[qText] = 0;
                    }
                    missedQuestionsFrequency[qText]++;
                }
            });
            const score = (correctCount / questions.length) * 100;
            totalQuizPercentage += score;
            totalQuizzesCount++;
        });
    }
    if (studentHasQuiz) {
        studentsWithAtLeastOneQuiz++;
    }
  });
  const averageScore = totalQuizzesCount > 0 ? (totalQuizPercentage / totalQuizzesCount) : 0;
  const quizCompletionRate = dashboardData.length > 0 ? (studentsWithAtLeastOneQuiz / dashboardData.length) * 100 : 0;
  const avgAdventureLevel = studentsWithAdventureData > 0 ? (totalAdventureLevels / studentsWithAdventureData) : 0;
  const misconceptions = Object.entries(missedQuestionsFrequency)
    .map(([question, count]) => ({ question, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);
  return {
    averageScore: Number(averageScore.toFixed(1)),
    quizCompletionRate: Number(quizCompletionRate.toFixed(1)),
    avgAdventureLevel: Number(avgAdventureLevel.toFixed(1)),
    misconceptions
  };
};
const LongitudinalProgressChart = React.memo(({ logs }) => {
    const { t } = useContext(LanguageContext);
    if (!logs || logs.length < 2) return (
        <div className="w-full bg-white p-6 rounded-xl border border-slate-400 shadow-sm mt-4 flex flex-col items-center justify-center text-slate-600 italic gap-2">
            <History size={24} className="opacity-50"/>
            <span className="text-xs">{t('dashboard.progress_chart.empty_msg')}</span>
        </div>
    );
    const width = 600;
    const height = 200;
    const padding = 30;
    const maxXP = Math.max(...logs.map(l => l.xp), 100);
    const minTime = new Date(logs[0].timestamp).getTime();
    const maxTime = new Date(logs[logs.length - 1].timestamp).getTime();
    const timeSpan = maxTime - minTime || 1;
    const points = logs.map(l => {
        const x = padding + ((new Date(l.timestamp).getTime() - minTime) / timeSpan) * (width - (padding * 2));
        const y = height - padding - ((l.xp / maxXP) * (height - (padding * 2)));
        return `${x},${y}`;
    }).join(" ");
    return (
        <div className="w-full bg-white p-6 rounded-xl border border-slate-400 shadow-sm mt-6 animate-in motion-reduce:animate-none slide-in-from-bottom-2">
            <h4 className="text-xs font-bold text-slate-600 uppercase tracking-wider mb-6 flex items-center gap-2">
                <Trophy size={14} className="text-yellow-500"/> {t('dashboard.progress_chart.title')}
            </h4>
            <div className="w-full overflow-x-auto">
                <svg role="img" aria-label={(t('dashboard.progress_chart.title') || 'Progress over time') + ': ' + logs.map(l => `${new Date(l.timestamp).toLocaleDateString()}, ${l.xp} XP`).join('; ')} viewBox={`0 0 ${width} ${height}`} className="w-full h-auto min-w-[500px] overflow-visible">
                    <line x1={padding} y1={height - padding} x2={width - padding} y2={height - padding} stroke="#e2e8f0" strokeWidth="2" />
                    <line x1={padding} y1={padding} x2={padding} y2={height - padding} stroke="#e2e8f0" strokeWidth="2" />
                    <polyline
                        points={points}
                        fill="none"
                        stroke="#6366f1"
                        strokeWidth="3"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="drop-shadow-sm"
                    />
                    {logs.map((l, i) => {
                         const x = padding + ((new Date(l.timestamp).getTime() - minTime) / timeSpan) * (width - (padding * 2));
                         const y = height - padding - ((l.xp / maxXP) * (height - (padding * 2)));
                         return (
                             <g key={i} className="group cursor-pointer">
                                 <circle cx={x} cy={y} r="5" className="fill-white stroke-indigo-600 stroke-2 transition-all motion-reduce:transition-none duration-300 group-hover:r-7 group-hover:fill-indigo-50" />
                                 <foreignObject x={Math.min(width - 120, Math.max(0, x - 60))} y={y - 50} width="120" height="50" className="opacity-0 group-hover:opacity-100 transition-opacity motion-reduce:transition-none pointer-events-none z-10">
                                     <div className="bg-slate-800 text-white text-[11px] px-3 py-2 rounded-lg text-center shadow-xl">
                                         <div className="font-bold">{new Date(l.timestamp).toLocaleDateString()}</div>
                                         <div className="text-yellow-300 font-mono">{l.xp} XP</div>
                                     </div>
                                 </foreignObject>
                             </g>
                         )
                    })}
                </svg>
            </div>
            <div className="flex justify-between text-[11px] text-slate-600 font-medium mt-2 px-2">
                <span>{t('dashboard.progress_chart.label_start')}: {new Date(logs[0].timestamp).toLocaleDateString()}</span>
                <span>{t('dashboard.progress_chart.label_current')}: {new Date(logs[logs.length-1].timestamp).toLocaleDateString()}</span>
            </div>
        </div>
    );
});
// ── TEACHER_METRIC_REGISTRY ──────────────────────────────────────────────
// Single source of truth for per-tool teacher-dashboard metrics.
//
// Each entry CAN declare:
//   id           (required) tool id matching dispatcher type
//   label        (required) display name
//   icon         (required) emoji for the tile
//   color        (required) palette key (see _metricTileColor)
//   count(s)     (required) per-student count function
//   qualitySignals(dashboardData)   (optional) returns array of class-wide
//                                    deterministic quality signals
//                                    [{ key, label, value, suffix, denom, hint, tone }]
//   misconceptions(dashboardData)   (optional) returns array of misconception
//                                    pattern objects (shape varies by category)
//                                    [{ category, ...categorySpecificFields }]
//
// External tool modules can extend the registry by pushing entries to
// window.AlloModules.TeacherMetricRegistry BEFORE or AFTER teacher_module.js
// loads — the merge logic at the bottom of this file handles both orders.
//
// To add a new tool to the dashboard from within teacher_source.jsx:
//   1. Push an entry below with id + label + icon + color + count(student)
//   2. Optionally add qualitySignals and/or misconceptions functions
//   3. The "All Tool Activity" tile cluster + CSV columns + Class Quality
//      Signals + Cross-Tool Pattern Detection auto-pick it up — no inline
//      edits in 5 places.
//
// To add a tool from an EXTERNAL CDN module (e.g., sel_hub_module.js):
//   window.AlloModules = window.AlloModules || {};
//   window.AlloModules.TeacherMetricRegistry = window.AlloModules.TeacherMetricRegistry || [];
//   window.AlloModules.TeacherMetricRegistry.push({ id: 'foo', ... });
//
// Doesn't replace the specialized panels (probes, fluency, notebook detail)
// which need richer rendering — this is the uniform "how many of each" layer
// plus the two extension points (qualitySignals / misconceptions) for any
// future deterministic per-tool analysis.
const _BUILTIN_METRIC_REGISTRY = [
  { id: 'quiz',            label: 'Quizzes',            icon: '📝', color: 'indigo',  count: (s) => (s.history || []).filter(h => h && h.type === 'quiz').length },
  { id: 'adventure',       label: 'Adventures',         icon: '🗺️', color: 'purple',  count: (s) => (s.history || []).filter(h => h && h.type === 'adventure').length },
  { id: 'glossary',        label: 'Glossaries',         icon: '📖', color: 'sky',     count: (s) => (s.history || []).filter(h => h && h.type === 'glossary').length },
  { id: 'simplified',      label: 'Leveled Texts',      icon: '📄', color: 'blue',    count: (s) => (s.history || []).filter(h => h && h.type === 'simplified').length },
  { id: 'outline',         label: 'Visual Organizers',  icon: '📊', color: 'cyan',    count: (s) => (s.history || []).filter(h => h && h.type === 'outline').length },
  {
    id: 'concept-sort', label: 'Concept Sorts', icon: '🃏', color: 'rose',
    count: (s) => (s.history || []).filter(h => h && h.type === 'concept-sort').length,
    // Class-wide concept-sort misconception detection: aggregate per-item
    // misplacement patterns across all student attempts (data captured by
    // ConceptSortGame's conceptSortAttempt event into gameCompletions).
    misconceptions: (dashboardData) => {
      const csKey = (p) => `${(p.itemText || '').toLowerCase().trim()}|${(p.placedCategoryLabel || '').toLowerCase().trim()}|${(p.correctCategoryLabel || '').toLowerCase().trim()}`;
      // Counted per STUDENT: one student retrying the same board (each check is
      // an attempt event) must not look like a class-wide pattern.
      const csAgg = new Map();
      let csTotalAttempts = 0;
      (dashboardData || []).forEach(s => {
        const gc = s.gameCompletions || {};
        const attempts = (gc.conceptSortAttempt || []).concat(gc.conceptSort || []);
        if (!attempts.length) return;
        csTotalAttempts++;
        const studentKeys = new Set();
        attempts.forEach(att => {
          const incPlacements = Array.isArray(att.incorrectPlacements) ? att.incorrectPlacements : [];
          incPlacements.forEach(p => {
            if (!p || !p.itemText) return;
            const key = csKey(p);
            if (studentKeys.has(key)) return;
            studentKeys.add(key);
            if (!csAgg.has(key)) {
              csAgg.set(key, { itemText: p.itemText, placedLabel: p.placedCategoryLabel, correctLabel: p.correctCategoryLabel, count: 0 });
            }
            csAgg.get(key).count++;
          });
        });
      });
      return Array.from(csAgg.values())
        .filter(p => p.count >= 3 && csTotalAttempts > 0 && (p.count / csTotalAttempts) >= 0.20)
        .sort((a, b) => b.count - a.count)
        .map(p => ({ category: 'conceptSort', ...p, totalAttempts: csTotalAttempts, missPct: Math.round((p.count / csTotalAttempts) * 100) }));
    },
  },
  { id: 'timeline',        label: 'Timelines',          icon: '🕒', color: 'amber',   count: (s) => (s.history || []).filter(h => h && h.type === 'timeline').length },
  {
    id: 'sentence-frames', label: 'Sentence Frames', icon: '✍️', color: 'teal',
    count: (s) => (s.history || []).filter(h => h && h.type === 'sentence-frames').length,
    // Class-wide sentence-frame response-rate detection: flag scaffolds where
    // students collectively left ≥30% of frames blank (signal of difficulty
    // with the scaffold OR underlying concept).
    misconceptions: (dashboardData) => {
      const sfMap = new Map();
      const sfTitles = new Map();
      const sfFrameCounts = new Map();
      (dashboardData || []).forEach(s => {
        const hist = s.history || [];
        const sfItems = hist.filter(h => h && h.type === 'sentence-frames');
        sfItems.forEach(item => {
          sfTitles.set(item.id, item.title || 'Sentence Frames');
          const studentResps = (s.responses && s.responses[item.id]) || {};
          const items = (item.data && Array.isArray(item.data.items)) ? item.data.items : [];
          items.forEach((_, idx) => {
            const responseVal = studentResps[idx];
            const filled = responseVal !== undefined && responseVal !== null && String(responseVal).trim().length > 0;
            sfMap.set(`${s.id}:${item.id}:${idx}`, filled);
            sfFrameCounts.set(item.id, Math.max(sfFrameCounts.get(item.id) || 0, idx + 1));
          });
        });
      });
      const results = [];
      for (const [genId, frameCount] of sfFrameCounts.entries()) {
        if (frameCount === 0) continue;
        let totalStudentFrames = 0, filledFrames = 0;
        const studentsAttempted = new Set();
        for (const [key, filled] of sfMap.entries()) {
          const [studentId, gid] = key.split(':');
          if (gid !== genId) continue;
          totalStudentFrames++;
          if (filled) { filledFrames++; studentsAttempted.add(studentId); }
        }
        if (totalStudentFrames === 0 || studentsAttempted.size < 2) continue;
        const missingPct = Math.round(((totalStudentFrames - filledFrames) / totalStudentFrames) * 100);
        if (missingPct >= 30) {
          results.push({ category: 'sentenceFrames', generationTitle: sfTitles.get(genId) || 'Sentence Frames', frameCount, studentsAttempted: studentsAttempted.size, missingPct });
        }
      }
      return results.sort((a, b) => b.missingPct - a.missingPct);
    },
  },
  {
    id: 'note-taking', label: 'Notebooks', icon: '📓', color: 'violet',
    count: (s) => (s.history || []).filter(h => h && h.type === 'note-taking').length,
    // Per-template field-completion misconceptions: ≥40% of entries missing
    // a key field (with ≥2 affected) surfaces as an instructional opportunity.
    misconceptions: (dashboardData) => {
      const ntStats = {
        'cornell-notes':    { fields: ['summary', 'cuesFilled', 'notesFilled'], counts: {}, total: 0 },
        'lab-report':       { fields: ['hypothesis', 'analysis', 'conclusion', 'procedureFilled'], counts: {}, total: 0 },
        'reading-response': { fields: ['favoriteLine', 'thinkings', 'connection', 'question'], counts: {}, total: 0 },
        'double-entry':     { fields: ['responsesFilled'], counts: {}, total: 0 },
        'guided-notes':     { fields: ['blanksFilled', 'ownNotes'], counts: {}, total: 0 },
        'q-and-a':          { fields: ['answersFilled'], counts: {}, total: 0 },
      };
      Object.keys(ntStats).forEach(tt => ntStats[tt].fields.forEach(f => ntStats[tt].counts[f] = 0));
      (dashboardData || []).forEach(s => {
        const hist = s.history || [];
        const notes = hist.filter(h => h && h.type === 'note-taking');
        notes.forEach(e => {
          const d = e.data || {};
          const tt = d.templateType;
          if (!ntStats[tt]) return;
          ntStats[tt].total++;
          if (tt === 'cornell-notes') {
            if (!(d.summary || '').trim()) ntStats[tt].counts.summary++;
            const cuesCount = (Array.isArray(d.cues) ? d.cues : []).filter(c => c && (c.text || '').trim()).length;
            if (cuesCount === 0) ntStats[tt].counts.cuesFilled++;
            const notesCount = (Array.isArray(d.notes) ? d.notes : []).filter(n => n && (n.text || '').trim()).length;
            if (notesCount === 0) ntStats[tt].counts.notesFilled++;
          } else if (tt === 'lab-report') {
            if (!(d.hypothesis || '').trim()) ntStats[tt].counts.hypothesis++;
            if (!(d.analysis || '').trim()) ntStats[tt].counts.analysis++;
            if (!(d.conclusion || '').trim()) ntStats[tt].counts.conclusion++;
            const procCount = (Array.isArray(d.procedure) ? d.procedure : []).filter(p => p && (p.text || '').trim()).length;
            if (procCount === 0) ntStats[tt].counts.procedureFilled++;
          } else if (tt === 'reading-response') {
            if (!(d.favoriteLine || '').trim()) ntStats[tt].counts.favoriteLine++;
            if (!(d.thinkings || '').trim()) ntStats[tt].counts.thinkings++;
            if (!(d.connection && d.connection.text || '').trim()) ntStats[tt].counts.connection++;
            if (!(d.question || '').trim()) ntStats[tt].counts.question++;
          } else if (tt === 'double-entry') {
            const respCount = (Array.isArray(d.entries) ? d.entries : []).filter(en => en && (en.response || '').trim()).length;
            if (respCount === 0) ntStats[tt].counts.responsesFilled++;
          } else if (tt === 'guided-notes') {
            const blanks = Array.isArray(d.blanks) ? d.blanks : [];
            const filledBlanks = blanks.filter(b => b && (b.studentAnswer || '').trim()).length;
            if (blanks.length > 0 && filledBlanks < Math.ceil(blanks.length / 2)) ntStats[tt].counts.blanksFilled++;
            if (!(d.notesExtra || '').trim()) ntStats[tt].counts.ownNotes++;
          } else if (tt === 'q-and-a') {
            const pairs = Array.isArray(d.pairs) ? d.pairs : [];
            const hasUnanswered = pairs.some(p => p && (p.question || '').trim() && !(p.answer || '').trim());
            if (hasUnanswered) ntStats[tt].counts.answersFilled++;
          }
        });
      });
      const fieldLabels = {
        'cornell-notes': {
          summary: 'Summary box (Pauk: where retention consolidation happens)',
          cuesFilled: 'Cue column (the metacognitive lever — drives retrieval practice)',
          notesFilled: 'Notes column (the lesson content itself)',
        },
        'lab-report': {
          hypothesis: 'Hypothesis (testable prediction with reasoning)',
          analysis: 'Analysis / CER (claim-evidence-reasoning — the science thinking)',
          conclusion: 'Conclusion (what was learned + sources of error)',
          procedureFilled: 'Procedure (reproducibility — could another student follow it?)',
        },
        'reading-response': {
          favoriteLine: 'Favorite line (close-reading anchor — direct quote from text)',
          thinkings: 'What this made me think about (substantive reflection)',
          connection: 'Connection (text-to-self / text / world — Keene & Zimmermann)',
          question: 'Open question (genuine inquiry — metacognitive engagement)',
        },
        'double-entry': {
          responsesFilled: 'Response column (the thinking — dialogue with the text, not just copied quotes)',
        },
        'guided-notes': {
          blanksFilled: 'Blanks completion (under half filled — retrieval of the core key terms)',
          ownNotes: 'Own-notes space (student-generated elaboration beyond the blanks)',
        },
        'q-and-a': {
          answersFilled: 'Unanswered questions (questions written but left unanswered — retrieval practice incomplete)',
        },
      };
      const templateNames = { 'cornell-notes': 'Cornell Notes', 'lab-report': 'Lab Report', 'reading-response': 'Reading Response', 'double-entry': 'Double-Entry Journal', 'guided-notes': 'Guided Notes', 'q-and-a': 'Q&A Study Notes' };
      const results = [];
      Object.keys(ntStats).forEach(tt => {
        const stats = ntStats[tt];
        if (stats.total === 0) return;
        stats.fields.forEach(field => {
          const missing = stats.counts[field];
          const pct = Math.round((missing / stats.total) * 100);
          if (pct >= 40 && missing >= 2) {
            results.push({ category: 'noteTaking', template: templateNames[tt], field, fieldLabel: fieldLabels[tt][field], missingCount: missing, totalCount: stats.total, missingPct: pct });
          }
        });
      });
      return results.sort((a, b) => b.missingPct - a.missingPct);
    },
    // Note-taking quality signals: 6 deterministic class-wide signals against
    // research thresholds (Pauk, Kiewra, McNeill & Krajcik, Keene & Zimmermann,
    // Hattie). Each returns a tone (green/amber/red) for at-a-glance scanning.
    qualitySignals: (dashboardData) => {
      const wc = (s) => { const t = String(s || '').trim(); return t ? t.split(/\s+/).length : 0; };
      let cornellCount = 0, cornellWithSummary = 0;
      let cornellCuesTotal = 0, cornellEntriesForCues = 0;
      let cerWordsTotal = 0, cerEntriesCounted = 0;
      let rrCount = 0, rrWithEvidence = 0;
      let studentsWithRR = 0, studentsWith2PlusConnTypes = 0;
      let studentsWithNotebook = 0, studentsWithFeedback = 0;
      let deCount = 0, deWithResponse = 0;
      let gnBlanksTotal = 0, gnBlanksFilled = 0;
      let qaPairsWithQ = 0, qaPairsAnswered = 0;
      (dashboardData || []).forEach(s => {
        const hist = s.history || [];
        const notes = hist.filter(h => h && h.type === 'note-taking');
        if (notes.length === 0) return;
        studentsWithNotebook++;
        let studentFeedbackCount = 0;
        const connTypesSeen = new Set();
        let studentHasRR = false;
        notes.forEach(e => {
          const d = e.data || {};
          const tt = d.templateType;
          studentFeedbackCount += d.feedbackCount || 0;
          if (tt === 'cornell-notes') {
            cornellCount++;
            if (wc(d.summary) >= 20) cornellWithSummary++;
            const cueCount = (Array.isArray(d.cues) ? d.cues : []).filter(c => c && (c.text || '').trim()).length;
            if (cueCount > 0) { cornellCuesTotal += cueCount; cornellEntriesForCues++; }
          } else if (tt === 'lab-report') {
            const cerWords = wc(d.analysis);
            if (cerWords > 0) { cerWordsTotal += cerWords; cerEntriesCounted++; }
          } else if (tt === 'reading-response') {
            rrCount++; studentHasRR = true;
            if ((d.favoriteLine || '').trim()) rrWithEvidence++;
            if (d.connection && d.connection.type) connTypesSeen.add(d.connection.type);
          } else if (tt === 'double-entry') {
            deCount++;
            if ((Array.isArray(d.entries) ? d.entries : []).some(en => en && wc(en.response) >= 15)) deWithResponse++;
          } else if (tt === 'guided-notes') {
            const blanks = Array.isArray(d.blanks) ? d.blanks : [];
            if (blanks.length > 0) {
              gnBlanksTotal += blanks.length;
              gnBlanksFilled += blanks.filter(b => b && (b.studentAnswer || '').trim()).length;
            }
          } else if (tt === 'q-and-a') {
            (Array.isArray(d.pairs) ? d.pairs : []).forEach(p => {
              if (p && (p.question || '').trim()) { qaPairsWithQ++; if ((p.answer || '').trim()) qaPairsAnswered++; }
            });
          }
        });
        if (studentHasRR) { studentsWithRR++; if (connTypesSeen.size >= 2) studentsWith2PlusConnTypes++; }
        if (studentFeedbackCount > 0) studentsWithFeedback++;
      });
      const signals = [];
      const _tone = (v, h, p) => v >= h ? 'green' : v >= p ? 'amber' : 'red';
      if (cornellCount > 0) {
        const v = Math.round((cornellWithSummary / cornellCount) * 100);
        signals.push({ key: 'summaryFillRate', label: 'Cornell summary rate', value: v, suffix: '%', denom: `${cornellWithSummary}/${cornellCount}`, hint: '% of Cornell entries with ≥20-word summary (research threshold; Pauk/Kiewra)', tone: _tone(v, 70, 40) });
      }
      if (cornellEntriesForCues > 0) {
        const v = (cornellCuesTotal / cornellEntriesForCues).toFixed(1);
        signals.push({ key: 'avgCues', label: 'Cornell cue density', value: v, denom: `avg / ${cornellEntriesForCues} entries`, hint: 'Avg cues per Cornell entry. ≥5 is healthy retrieval-practice density', tone: _tone(parseFloat(v), 5, 3) });
      }
      if (cerEntriesCounted > 0) {
        const v = Math.round(cerWordsTotal / cerEntriesCounted);
        signals.push({ key: 'avgCerWords', label: 'Lab CER length', value: v, suffix: ' wd', denom: `avg / ${cerEntriesCounted} reports`, hint: 'Avg word count of CER analysis. ≥30 words is where reasoning lives (McNeill & Krajcik)', tone: _tone(v, 30, 15) });
      }
      if (rrCount > 0) {
        const v = Math.round((rrWithEvidence / rrCount) * 100);
        signals.push({ key: 'rrEvidenceRate', label: 'Reading evidence rate', value: v, suffix: '%', denom: `${rrWithEvidence}/${rrCount}`, hint: '% of Reading Responses with a favorite line filled (close-reading anchor)', tone: _tone(v, 70, 40) });
      }
      if (studentsWithRR > 0) {
        const v = Math.round((studentsWith2PlusConnTypes / studentsWithRR) * 100);
        signals.push({ key: 'connectionVariety', label: 'Connection variety', value: v, suffix: '%', denom: `${studentsWith2PlusConnTypes}/${studentsWithRR} students`, hint: '% of students using ≥2 of 3 connection types (text-to-self/text/world)', tone: _tone(v, 50, 25) });
      }
      if (studentsWithNotebook > 0) {
        const v = Math.round((studentsWithFeedback / studentsWithNotebook) * 100);
        signals.push({ key: 'selfAssessment', label: 'Self-assessment use', value: v, suffix: '%', denom: `${studentsWithFeedback}/${studentsWithNotebook} students`, hint: '% of students who have requested AI feedback ≥1× (metacognitive engagement proxy)', tone: _tone(v, 50, 25) });
      }
      if (deCount > 0) {
        const v = Math.round((deWithResponse / deCount) * 100);
        signals.push({ key: 'deResponseRate', label: 'Double-entry response rate', value: v, suffix: '%', denom: `${deWithResponse}/${deCount}`, hint: '% of double-entry journals with a substantive (≥15-word) response — dialogue with the text, not just copied quotes', tone: _tone(v, 60, 30) });
      }
      if (gnBlanksTotal > 0) {
        const v = Math.round((gnBlanksFilled / gnBlanksTotal) * 100);
        signals.push({ key: 'guidedCompletion', label: 'Guided-notes completion', value: v, suffix: '%', denom: `${gnBlanksFilled}/${gnBlanksTotal} blanks`, hint: '% of guided-note blanks completed across the class — engagement with the key terms', tone: _tone(v, 70, 40) });
      }
      if (qaPairsWithQ > 0) {
        const v = Math.round((qaPairsAnswered / qaPairsWithQ) * 100);
        signals.push({ key: 'qaAnswerRate', label: 'Q&A answer rate', value: v, suffix: '%', denom: `${qaPairsAnswered}/${qaPairsWithQ} pairs`, hint: '% of study questions that have an answer written — completed retrieval-practice sets', tone: _tone(v, 70, 40) });
      }
      return signals;
    },
  },
  { id: 'anchor-chart',    label: 'Anchor Charts',      icon: '📋', color: 'orange',  count: (s) => (s.history || []).filter(h => h && h.type === 'anchor-chart').length },
  { id: 'dbq',             label: 'DBQs',               icon: '⚖️', color: 'rose',    count: (s) => (s.history || []).filter(h => h && h.type === 'dbq').length },
  { id: 'persona',         label: 'Personas',           icon: '🎭', color: 'fuchsia', count: (s) => (s.history || []).filter(h => h && h.type === 'persona').length },
  { id: 'math',            label: 'STEAM Lab',           icon: '🧪', color: 'emerald', count: (s) => (s.history || []).filter(h => h && h.type === 'math').length },
  { id: 'faq',             label: 'FAQs',               icon: '❓', color: 'slate',   count: (s) => (s.history || []).filter(h => h && h.type === 'faq').length },
  { id: 'image',           label: 'Generated Images',   icon: '🖼️', color: 'pink',    count: (s) => (s.history || []).filter(h => h && h.type === 'image').length },
  { id: 'brainstorm',      label: 'Brainstorms',        icon: '💡', color: 'amber',   count: (s) => (s.history || []).filter(h => h && h.type === 'brainstorm').length },
  { id: 'fluency-record',  label: 'Fluency Records',    icon: '🎙️', color: 'green',   count: (s) => (s.history || []).filter(h => h && h.type === 'fluency-record').length },
];

// Publish registry on window.AlloModules so external modules can self-register
// metrics by pushing entries. Merges any pre-existing entries (external module
// loaded before teacher_module.js) with the built-in registry.
if (typeof window !== 'undefined') {
  window.AlloModules = window.AlloModules || {};
  const preExisting = Array.isArray(window.AlloModules.TeacherMetricRegistry)
    ? window.AlloModules.TeacherMetricRegistry
    : [];
  // Dedupe by id; built-in wins on conflict (intentional — external overrides
  // would silently change dashboard math)
  const builtinIds = new Set(_BUILTIN_METRIC_REGISTRY.map(e => e.id));
  const externalEntries = preExisting.filter(e => e && e.id && !builtinIds.has(e.id));
  window.AlloModules.TeacherMetricRegistry = [..._BUILTIN_METRIC_REGISTRY, ...externalEntries];
}
// Live getter — always returns the current registry, including entries added
// by other modules AFTER teacher_module.js loaded.
function getTeacherMetricRegistry() {
  if (typeof window !== 'undefined' && Array.isArray(window.AlloModules && window.AlloModules.TeacherMetricRegistry)) {
    return window.AlloModules.TeacherMetricRegistry;
  }
  return _BUILTIN_METRIC_REGISTRY;
}
// Backwards-compat alias — older code paths still reference this constant.
const TEACHER_METRIC_REGISTRY = _BUILTIN_METRIC_REGISTRY;
const _metricTileColor = (color) => ({
  indigo:  'bg-indigo-50 border-indigo-200 text-indigo-700',
  purple:  'bg-purple-50 border-purple-200 text-purple-700',
  sky:     'bg-sky-50 border-sky-200 text-sky-700',
  blue:    'bg-blue-50 border-blue-200 text-blue-700',
  cyan:    'bg-cyan-50 border-cyan-200 text-cyan-700',
  rose:    'bg-rose-50 border-rose-200 text-rose-700',
  amber:   'bg-amber-50 border-amber-200 text-amber-700',
  teal:    'bg-teal-50 border-teal-200 text-teal-700',
  violet:  'bg-violet-50 border-violet-200 text-violet-700',
  orange:  'bg-orange-50 border-orange-200 text-orange-700',
  fuchsia: 'bg-fuchsia-50 border-fuchsia-200 text-fuchsia-700',
  emerald: 'bg-emerald-50 border-emerald-200 text-emerald-700',
  slate:   'bg-slate-50 border-slate-200 text-slate-700',
  pink:    'bg-pink-50 border-pink-200 text-pink-700',
  green:   'bg-green-50 border-green-200 text-green-700',
})[color] || 'bg-slate-50 border-slate-200 text-slate-700';

// Registry-driven "All Tool Activity" tile cluster.
// Renders one tile per registry entry whose count(student) > 0 (so we don't
// flood the panel with empty tiles for tools the student hasn't touched).
// Drops into the per-student detail view alongside the existing specialized
// tile clusters.
const AllToolActivityPanel = React.memo(({ student, t }) => {
  if (!student) return null;
  // Read from the LIVE registry so externally-registered tools also surface
  const active = getTeacherMetricRegistry()
    .map(entry => ({ ...entry, n: entry.count(student) }))
    .filter(e => e.n > 0)
    .sort((a, b) => b.n - a.n);
  if (active.length === 0) return null;
  return (
    <div className="bg-white p-4 sm:p-6 rounded-xl border border-slate-400 shadow-sm mb-6" data-help-key="dashboard_all_tool_activity">
      <h4 className="text-xs font-bold text-slate-600 uppercase tracking-wider mb-4 flex items-center gap-2">
        🧰 {t('dashboard.all_tool_activity') || 'All Tool Activity'}
        <span className="text-[10px] font-normal italic text-slate-500 normal-case">({active.length} tool{active.length === 1 ? '' : 's'} used)</span>
      </h4>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2 sm:gap-3">
        {active.map(e => (
          <div key={e.id} className={`${_metricTileColor(e.color)} border rounded-lg p-3 text-center`}>
            <div className="text-2xl font-black">{e.n}</div>
            <div className="text-[10px] font-bold uppercase mt-1 leading-tight">{e.icon} {e.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
});

// ── Class Quality Signals (registry-driven orchestrator) ────────────────
// Iterates the metric registry and flat-maps each tool's qualitySignals()
// contribution. Tools with no qualitySignals function contribute nothing.
// Replaces the previous hand-rolled _computeNotebookQualitySignals which
// hardcoded note-taking specifics.
function _computeAllQualitySignals(dashboardData) {
  const out = [];
  getTeacherMetricRegistry().forEach(entry => {
    if (typeof entry.qualitySignals !== 'function') return;
    try {
      const signals = entry.qualitySignals(dashboardData) || [];
      signals.forEach(s => out.push({ ...s, _toolId: entry.id, _toolLabel: entry.label }));
    } catch (e) { console.warn('[qualitySignals] tool', entry.id, 'failed', e); }
  });
  return out;
}
// Kept for any callers that referenced the old function name (defensive shim).
function _computeNotebookQualitySignals(dashboardData) {
  // Returns a shape-compatible object so any external/legacy callers still work.
  // New code should use _computeAllQualitySignals() instead.
  const flat = _computeAllQualitySignals(dashboardData);
  const out = {
    summaryFillRate: { value: null, count: 0, total: 0 },
    avgCues: { value: null, total: 0, n: 0 },
    avgCerWords: { value: null, total: 0, n: 0 },
    rrEvidenceRate: { value: null, count: 0, total: 0 },
    connectionVariety: { value: null, count: 0, total: 0 },
    selfAssessment: { value: null, count: 0, total: 0 },
  };
  flat.forEach(s => { if (out[s.key]) out[s.key].value = s.value; });
  return out;
}
function _wordCount(str) {
  if (!str) return 0;
  const trimmed = String(str).trim();
  if (!trimmed) return 0;
  return trimmed.split(/\s+/).length;
}
// Deprecated — quality signals now live inside note-taking's registry entry.
// This function body is preserved so any old external callers that may have
// referenced it as a module-level helper still parse, but new code paths use
// the registry-driven flow above. Returns an empty result; the new flow's
// _computeAllQualitySignals delivers the real signals.
// (Legacy body removed — note-taking quality signals now live in the
// 'note-taking' registry entry's qualitySignals() function above. The thin
// _computeNotebookQualitySignals shim above maps the registry output back to
// the legacy object shape any old caller might still expect.)
// (Removed dead _DEAD_LEGACY_DO_NOT_CALL — confirmed zero callers; the live logic lives in the metric registry. Cleanup 2026-06-08.)
// Cross-tool misconception / completion-gap detection — registry-driven.
// Iterates the metric registry and flat-maps each tool's misconceptions()
// contribution into category-keyed buckets. Tools with no misconceptions()
// function contribute nothing. Each pattern carries a 'category' field
// (e.g. 'noteTaking', 'sentenceFrames', 'conceptSort') that the rendering
// section uses to group + style the patterns.
function _computeCrossToolMisconceptions(dashboardData) {
  const out = { noteTaking: [], sentenceFrames: [], conceptSort: [] };
  getTeacherMetricRegistry().forEach(entry => {
    if (typeof entry.misconceptions !== 'function') return;
    try {
      const patterns = entry.misconceptions(dashboardData) || [];
      patterns.forEach(p => {
        const cat = p && p.category;
        if (cat && Array.isArray(out[cat])) out[cat].push(p);
        else if (!out._other) (out._other = []).push(p); // future-proof for new categories
        else out._other.push(p);
      });
    } catch (e) { console.warn('[misconceptions] tool', entry.id, 'failed', e); }
  });
  return out;
}
// Legacy body retained inside a dead function so the parser still accepts the
// file. Will be removed in next cleanup pass after verifying no external refs.
// (Removed dead _DEAD_LEGACY_CROSS_TOOL_DO_NOT_CALL — confirmed zero callers; the live logic lives in the metric registry. Cleanup 2026-06-08.)

// Color-code each signal: green (healthy), amber (partial), red (weak), gray (no data).
function _signalTone(signalKey, value) {
  if (value === null || value === undefined) return 'gray';
  const thresholds = {
    summaryFillRate:    { healthy: 70, partial: 40 }, // %
    avgCues:            { healthy: 5,  partial: 3 },  // count
    avgCerWords:        { healthy: 30, partial: 15 }, // words
    rrEvidenceRate:     { healthy: 70, partial: 40 }, // %
    connectionVariety:  { healthy: 50, partial: 25 }, // %
    selfAssessment:     { healthy: 50, partial: 25 }, // %
  };
  const t = thresholds[signalKey];
  if (!t) return 'gray';
  const v = parseFloat(value);
  if (v >= t.healthy) return 'green';
  if (v >= t.partial) return 'amber';
  return 'red';
}
const _NotebookQualityCard = ({ tone, label, value, suffix, denom, hint }) => {
  const palette = ({
    green:  { bg: 'bg-emerald-50',  border: 'border-emerald-300',  text: 'text-emerald-800',  num: 'text-emerald-700'  },
    amber:  { bg: 'bg-amber-50',    border: 'border-amber-300',    text: 'text-amber-800',    num: 'text-amber-700'    },
    red:    { bg: 'bg-rose-50',     border: 'border-rose-300',     text: 'text-rose-800',     num: 'text-rose-700'     },
    gray:   { bg: 'bg-slate-50',    border: 'border-slate-300',    text: 'text-slate-600',    num: 'text-slate-500'    },
  })[tone];
  return (
    <div className={`${palette.bg} ${palette.border} border rounded-lg p-3`} title={hint}>
      <div className="flex items-baseline justify-between mb-1">
        <span className={`text-[10px] font-bold uppercase tracking-wider ${palette.text}`}>{label}</span>
        {denom ? <span className="text-[10px] text-slate-500 font-mono">{denom}</span> : null}
      </div>
      <div className={`text-2xl font-black ${palette.num}`}>{value === null || value === undefined ? '—' : value}{suffix || ''}</div>
      {hint ? <div className="text-[10px] text-slate-600 mt-1 leading-snug">{hint}</div> : null}
    </div>
  );
};

// ── CrossToolMisconceptionsSection ───────────────────────────────────────
// Surfaces non-quiz misconception signals (note-taking field-completion gaps
// + sentence-frames frame-completion gaps) on the Insights tab. Complements
// the existing quiz misconceptions panel which only looks at quiz items.
// Hidden when no signals trigger their thresholds (avoids noise).
const CrossToolMisconceptionsSection = React.memo(({ dashboardData, t }) => {
  const signals = React.useMemo(() => _computeCrossToolMisconceptions(dashboardData), [dashboardData]);
  if (signals.noteTaking.length === 0 && signals.sentenceFrames.length === 0 && signals.conceptSort.length === 0) return null;
  return (
    <div className="bg-white p-4 sm:p-6 rounded-2xl shadow-sm border border-slate-400" data-help-key="dashboard_cross_tool_misconceptions">
      <h3 className="text-lg font-bold text-slate-800 mb-1 flex items-center gap-2">
        <AlertCircle size={20} className="text-orange-500"/>
        {t('dashboard.cross_misconceptions.title') || 'Cross-Tool Pattern Detection'}
      </h3>
      <p className="text-xs text-slate-600 mb-4 italic">{t('dashboard.cross_misconceptions.subtitle') || 'Structural gaps in student work across non-quiz tools. Each pattern is a class-wide instructional opportunity.'}</p>
      {signals.noteTaking.length > 0 && (
        <div className="mb-4">
          <h4 className="text-[11px] font-bold text-violet-700 uppercase tracking-wider mb-2">📓 {t('dashboard.cross_misconceptions.notebook_label') || 'Note-taking field gaps'}</h4>
          <ul className="space-y-2">
            {signals.noteTaking.slice(0, 6).map((s, i) => (
              <li key={i} className="bg-orange-50 border-l-4 border-orange-400 rounded-r-md p-3">
                <div className="flex justify-between items-baseline gap-2">
                  <span className="text-sm font-bold text-orange-900">{s.template}: {s.fieldLabel}</span>
                  <span className="text-xs font-bold text-orange-700 bg-white border border-orange-300 px-2 py-0.5 rounded whitespace-nowrap">{s.missingPct}% missing</span>
                </div>
                <div className="text-xs text-slate-600 mt-1">{s.missingCount} of {s.totalCount} entries across the class have this field empty.</div>
              </li>
            ))}
          </ul>
        </div>
      )}
      {signals.sentenceFrames.length > 0 && (
        <div className="mb-4">
          <h4 className="text-[11px] font-bold text-indigo-700 uppercase tracking-wider mb-2">✍️ {t('dashboard.cross_misconceptions.frames_label') || 'Sentence-frame response gaps'}</h4>
          <ul className="space-y-2">
            {signals.sentenceFrames.slice(0, 5).map((s, i) => (
              <li key={i} className="bg-indigo-50 border-l-4 border-indigo-400 rounded-r-md p-3">
                <div className="flex justify-between items-baseline gap-2">
                  <span className="text-sm font-bold text-indigo-900 truncate">{s.generationTitle}</span>
                  <span className="text-xs font-bold text-indigo-700 bg-white border border-indigo-300 px-2 py-0.5 rounded whitespace-nowrap">{s.missingPct}% blank</span>
                </div>
                <div className="text-xs text-slate-600 mt-1">{s.frameCount} frame{s.frameCount === 1 ? '' : 's'} · {s.studentsAttempted} student{s.studentsAttempted === 1 ? '' : 's'} attempted</div>
              </li>
            ))}
          </ul>
        </div>
      )}
      {signals.conceptSort.length > 0 && (
        <div>
          <h4 className="text-[11px] font-bold text-rose-700 uppercase tracking-wider mb-2">🃏 {t('dashboard.cross_misconceptions.concept_sort_label') || 'Concept Sort misplacement patterns'}</h4>
          <ul className="space-y-2">
            {signals.conceptSort.slice(0, 6).map((s, i) => (
              <li key={i} className="bg-rose-50 border-l-4 border-rose-400 rounded-r-md p-3">
                <div className="flex justify-between items-baseline gap-2">
                  <span className="text-sm font-bold text-rose-900 truncate">"{s.itemText}" → placed in "{s.placedLabel}"</span>
                  <span className="text-xs font-bold text-rose-700 bg-white border border-rose-300 px-2 py-0.5 rounded whitespace-nowrap">{s.count}× ({s.missPct}%)</span>
                </div>
                <div className="text-xs text-slate-600 mt-1">Correct category: <span className="font-bold">"{s.correctLabel}"</span>. Likely conflation between these two concepts.</div>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
});

// ── TeacherCommentThread ─────────────────────────────────────────────────
// Inline thread of teacher-private comments on a single student resource.
// Teacher's annotations persist in localStorage on the dashboard side; never
// synced back to the student (dashboard is one-way upload). Useful for:
//   - per-resource feedback notes the teacher wants to remember for IEP team
//   - tracking observations across multiple review passes
//   - bundling comments into Research/Notebook PDF exports (future)
const TeacherCommentThread = React.memo(({ studentId, resourceId, comments, onAdd, onDelete, t }) => {
  const [draft, setDraft] = React.useState('');
  const [expanded, setExpanded] = React.useState(false);
  const list = comments || [];
  const handleSubmit = (e) => {
      if (e) e.preventDefault();
      if (!draft.trim()) return;
      onAdd(studentId, resourceId, draft);
      setDraft('');
  };
  if (list.length === 0 && !expanded) {
      return (
          <button type="button"
              onClick={() => setExpanded(true)}
              className="mt-3 text-xs font-bold text-slate-500 hover:text-indigo-700 flex items-center gap-1.5 transition-colors motion-reduce:transition-none"
              data-help-key="dashboard_teacher_comment_add"
              aria-label={t('dashboard.comments.add_aria') || 'Add a private teacher comment to this resource'}
          >
              💬 {t('dashboard.comments.add_btn') || 'Add private note'}
          </button>
      );
  }
  return (
      <div className="mt-3 border-t border-slate-200 pt-3" data-help-key="dashboard_teacher_comment_thread">
          <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              💬 {t('dashboard.comments.label') || 'Teacher notes'}
              {list.length > 0 && <span className="text-slate-600 normal-case font-normal">({list.length})</span>}
              <span className="ml-auto text-slate-500 normal-case font-normal italic">{t('dashboard.comments.privacy_note') || 'Private to you — never shared with student'}</span>
          </div>
          {list.length > 0 && (
              <ul className="space-y-2 mb-3">
                  {list.map(c => (
                      <li key={c.id} className="bg-amber-50/50 border-l-4 border-amber-400 rounded-r-md p-2 group">
                          <div className="flex items-start justify-between gap-2">
                              <div className="text-sm text-slate-700 leading-relaxed whitespace-pre-wrap flex-1">{c.text}</div>
                              <button type="button"
                                  onClick={() => onDelete(studentId, resourceId, c.id)}
                                  className="text-slate-600 hover:text-red-600 opacity-0 group-hover:opacity-100 transition-opacity motion-reduce:transition-none text-xs"
                                  aria-label={t('dashboard.comments.delete_aria') || 'Delete this comment'}
                                  title={t('dashboard.comments.delete_tooltip') || 'Delete this comment'}
                              >✕</button>
                          </div>
                          <div className="text-[10px] text-slate-500 mt-1 font-mono">{new Date(c.timestamp).toLocaleString()}</div>
                      </li>
                  ))}
              </ul>
          )}
          <form onSubmit={handleSubmit} className="flex gap-2 items-start">
              <textarea
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  onKeyDown={(e) => { if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') handleSubmit(); }}
                  placeholder={t('dashboard.comments.placeholder') || 'Note to yourself about this resource (Cmd/Ctrl+Enter to save)'}
                  className="flex-1 text-sm bg-white border border-slate-300 rounded-md p-2 outline-none focus:ring-2 focus:ring-amber-300 resize-y min-h-[60px]"
                  rows={2}
                  aria-label={t('dashboard.comments.textarea_aria') || 'New teacher comment'}
              />
              <div className="flex flex-col gap-1.5">
                  <button
                      type="submit"
                      disabled={!draft.trim()}
                      className="px-3 py-1.5 text-xs font-bold bg-amber-700 hover:bg-amber-800 text-white rounded-md disabled:opacity-40 disabled:cursor-not-allowed"
                  >{t('dashboard.comments.save_btn') || 'Save'}</button>
                  {list.length === 0 && (
                      <button
                          type="button"
                          onClick={() => setExpanded(false)}
                          className="px-3 py-1.5 text-xs font-bold text-slate-500 hover:text-slate-700"
                      >{t('common.cancel') || 'Cancel'}</button>
                  )}
              </div>
          </form>
      </div>
  );
});

// ── ClassNotebookSection ─────────────────────────────────────────────────
// Class-wide aggregate of note-taking + anchor-chart activity, with an AI
// button that surfaces patterns across the roster (parallel to the per-
// student Note-Taking Insights but cross-classroom: "12 of your 22 students
// consistently skip CER Reasoning — consider a mini-lesson").
//
// Drops into the Insights tab. Shows nothing if the roster has no notebook
// activity at all (avoids a useless empty section for classes that haven't
// adopted note-taking templates yet).
const ClassNotebookSection = React.memo(({ dashboardData, callGemini, addToast, t }) => {
  const [insights, setInsights] = React.useState(null);
  const [insightsLoading, setInsightsLoading] = React.useState(false);

  // Deterministic notebook quality signals — computed from data alone (no AI).
  // Surfaced as a color-coded card grid for at-a-glance class diagnostics.
  // Flat array of all note-taking quality signals (registry-driven). Each carries
  // its own tone + denom, so we render them generically — new template signals
  // surface automatically without per-key wiring.
  const qualitySignals = React.useMemo(() => _computeAllQualitySignals(dashboardData), [dashboardData]);

  // Aggregate notebook activity across the whole roster.
  const agg = React.useMemo(() => {
    const out = {
      studentsWithNotebook: 0,
      totalEntries: 0,
      cornell: 0,
      labReport: 0,
      readingResponse: 0,
      doubleEntry: 0,
      guidedNotes: 0,
      qAndA: 0,
      anchorChart: 0,
      feedbackRequests: 0,
      byStudent: [], // [{ name, total, cornell, labReport, readingResponse, doubleEntry, guidedNotes, qAndA, anchorChart, feedbackRequests }]
    };
    (dashboardData || []).forEach(s => {
      const hist = s.history || [];
      const notes = hist.filter(h => h && h.type === 'note-taking');
      const anchors = hist.filter(h => h && h.type === 'anchor-chart');
      if (notes.length === 0 && anchors.length === 0) return;
      out.studentsWithNotebook++;
      const countType = (tt) => notes.filter(e => (e.data && e.data.templateType) === tt).length;
      const sCornell = countType('cornell-notes');
      const sLab = countType('lab-report');
      const sReading = countType('reading-response');
      const sDouble = countType('double-entry');
      const sGuided = countType('guided-notes');
      const sQA = countType('q-and-a');
      const sFeedback = notes.reduce((sum, e) => sum + ((e.data && e.data.feedbackCount) || 0), 0);
      out.cornell += sCornell;
      out.labReport += sLab;
      out.readingResponse += sReading;
      out.doubleEntry += sDouble;
      out.guidedNotes += sGuided;
      out.qAndA += sQA;
      out.anchorChart += anchors.length;
      out.feedbackRequests += sFeedback;
      out.totalEntries += notes.length + anchors.length;
      out.byStudent.push({
        name: s.studentNickname || 'Anonymous',
        total: notes.length + anchors.length,
        cornell: sCornell, labReport: sLab, readingResponse: sReading,
        doubleEntry: sDouble, guidedNotes: sGuided, qAndA: sQA, anchorChart: anchors.length,
        feedbackRequests: sFeedback,
      });
    });
    return out;
  }, [dashboardData]);

  const handleGenerateClassInsights = React.useCallback(async () => {
    if (typeof callGemini !== 'function') {
      addToast(t('dashboard.class_notebook.no_ai') || 'AI is not available right now.', 'warning');
      return;
    }
    if (agg.studentsWithNotebook < 2) {
      addToast(t('dashboard.class_notebook.need_more_students') || 'Need at least 2 students with notebook entries to surface class patterns.', 'info');
      return;
    }
    setInsightsLoading(true);
    setInsights(null);
    try {
      // Compact per-student summary (don't ship full note bodies — too large).
      // We sample up to 3 entries per student and serialize headline fields only.
      const sampleEntries = [];
      (dashboardData || []).forEach(s => {
        const hist = s.history || [];
        const notes = hist.filter(h => h && h.type === 'note-taking').slice(0, 3);
        notes.forEach(n => {
          const d = n.data || {};
          const tt = d.templateType || 'cornell-notes';
          const headline = ({
            'cornell-notes': () => `cues=${(d.cues || []).length}, notes=${(d.notes || []).length}, summary_len=${(d.summary || '').length}`,
            'lab-report': () => `hyp_len=${(d.hypothesis || '').length}, analysis_len=${(d.analysis || '').length}, conclusion_len=${(d.conclusion || '').length}`,
            'reading-response': () => `evidence_len=${(d.favoriteLine || '').length}, thinking_len=${(d.thinkings || '').length}, connection_type=${(d.connection && d.connection.type) || 'none'}`,
            'double-entry': () => { const en = Array.isArray(d.entries) ? d.entries : []; return `entries=${en.length}, with_response=${en.filter(x => x && (x.response || '').trim()).length}`; },
            'guided-notes': () => { const bl = Array.isArray(d.blanks) ? d.blanks : []; return `blanks=${bl.length}, filled=${bl.filter(b => b && (b.studentAnswer || '').trim()).length}, own_notes_len=${(d.notesExtra || '').length}`; },
            'q-and-a': () => { const pr = Array.isArray(d.pairs) ? d.pairs : []; return `pairs=${pr.length}, answered=${pr.filter(p => p && (p.answer || '').trim()).length}`; },
          })[tt];
          sampleEntries.push(`${s.studentNickname || 'Anon'} (${tt}): ${headline ? headline() : 'no data'}`);
        });
      });
      const prompt = `
You are a teaching coach analyzing patterns ACROSS a class's note-taking work. Your goal is to surface 2-4 class-wide patterns that would inform the teacher's next mini-lesson, not individual student feedback.

CLASS COMPOSITION:
- Total students: ${dashboardData.length}
- Students using notebook tools: ${agg.studentsWithNotebook}
- Total Cornell Notes entries: ${agg.cornell}
- Total Lab Reports: ${agg.labReport}
- Total Reading Responses: ${agg.readingResponse}
- Total Double-Entry Journals: ${agg.doubleEntry}
- Total Guided Notes: ${agg.guidedNotes}
- Total Q&A Study Notes: ${agg.qAndA}
- Total Anchor Charts: ${agg.anchorChart}
- Total AI feedback requests across class: ${agg.feedbackRequests}

PER-STUDENT ENTRY HEADLINES (sample of up to 3 entries per student):
${sampleEntries.slice(0, 80).join('\n')}

Surface 2-4 patterns the teacher can act on. Examples of useful patterns:
- "Cornell summary boxes are consistently 1-2 sentences across the class (avg estimated <20 words). Consider a mini-lesson on summary writing."
- "12 of 22 students have not yet tried Lab Report mode. If you have a lab coming up, model the template explicitly."
- "AI feedback requests are concentrated in 4 students. Consider explicitly inviting reluctant students to use the Get AI Feedback button."

DO NOT name individual students unless flagging an equity / engagement disparity that needs attention.

Return ONLY JSON:
{
  "classSummary": "1-2 sentence overview of the class's notebook engagement.",
  "patterns": [
    { "title": "Short label (4-8 words)", "observation": "1-2 sentences describing the pattern.", "miniLesson": "1 sentence suggesting a concrete next step or mini-lesson." }
  ],
  "celebration": "1 sentence naming a class-wide strength worth acknowledging."
}
`.trim();
      const raw = await callGemini(prompt, true);
      const parsed = JSON.parse((window.__alloUtils && window.__alloUtils.cleanJson ? window.__alloUtils.cleanJson(raw) : raw));
      setInsights(parsed);
    } catch (e) {
      console.warn('[ClassNotebookInsights] failed', e);
      addToast(t('dashboard.class_notebook.error') || 'Could not generate class insights right now. Try again in a moment.', 'error');
    } finally {
      setInsightsLoading(false);
    }
  }, [callGemini, dashboardData, agg, addToast, t]);

  if (agg.totalEntries === 0) return null;

  return (
    <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-400" data-help-key="dashboard_class_notebook_section">
      <div className="flex items-start justify-between mb-4">
        <h4 className="text-sm font-bold text-violet-700 uppercase tracking-wider flex items-center gap-2">
          📓 {t('dashboard.class_notebook.title') || 'Class Notebook Activity'}
        </h4>
        <button type="button"
          onClick={handleGenerateClassInsights}
          disabled={insightsLoading || agg.studentsWithNotebook < 2}
          className="px-3 py-1.5 text-xs font-bold text-violet-800 bg-violet-100 border border-violet-300 rounded-full hover:bg-violet-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1"
          aria-label={t('dashboard.class_notebook.ai_button_aria') || 'Generate AI insights on class-wide note-taking patterns'}
          title={agg.studentsWithNotebook < 2 ? (t('dashboard.class_notebook.need_more_short') || 'Need 2+ students with notebook') : (t('dashboard.class_notebook.ai_button_tooltip') || 'AI looks for class-wide patterns and suggests mini-lessons')}
          data-help-key="dashboard_class_notebook_ai_btn"
        >
          {insightsLoading ? '⏳' : '✨'} {t('dashboard.class_notebook.ai_button') || 'AI Class Insights'}
        </button>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
        <div className="bg-violet-50 rounded-xl p-3 text-center border border-violet-200">
          <div className="text-2xl font-black text-violet-700">{agg.studentsWithNotebook}</div>
          <div className="text-[10px] font-bold text-violet-600 uppercase mt-1">{t('dashboard.class_notebook.students_with') || 'Students using'}</div>
        </div>
        {agg.cornell > 0 && <div className="bg-indigo-50 rounded-xl p-3 text-center border border-indigo-200">
          <div className="text-2xl font-black text-indigo-700">{agg.cornell}</div>
          <div className="text-[10px] font-bold text-indigo-600 uppercase mt-1">📓 Cornell</div>
        </div>}
        {agg.labReport > 0 && <div className="bg-sky-50 rounded-xl p-3 text-center border border-sky-200">
          <div className="text-2xl font-black text-sky-700">{agg.labReport}</div>
          <div className="text-[10px] font-bold text-sky-600 uppercase mt-1">🧪 Lab Report</div>
        </div>}
        {agg.readingResponse > 0 && <div className="bg-fuchsia-50 rounded-xl p-3 text-center border border-fuchsia-200">
          <div className="text-2xl font-black text-fuchsia-700">{agg.readingResponse}</div>
          <div className="text-[10px] font-bold text-fuchsia-600 uppercase mt-1">📖 Reading</div>
        </div>}
        {agg.doubleEntry > 0 && <div className="bg-rose-50 rounded-xl p-3 text-center border border-rose-200">
          <div className="text-2xl font-black text-rose-700">{agg.doubleEntry}</div>
          <div className="text-[10px] font-bold text-rose-600 uppercase mt-1">✍️ Double-Entry</div>
        </div>}
        {agg.guidedNotes > 0 && <div className="bg-emerald-50 rounded-xl p-3 text-center border border-emerald-200">
          <div className="text-2xl font-black text-emerald-700">{agg.guidedNotes}</div>
          <div className="text-[10px] font-bold text-emerald-600 uppercase mt-1">📝 Guided</div>
        </div>}
        {agg.qAndA > 0 && <div className="bg-cyan-50 rounded-xl p-3 text-center border border-cyan-200">
          <div className="text-2xl font-black text-cyan-700">{agg.qAndA}</div>
          <div className="text-[10px] font-bold text-cyan-600 uppercase mt-1">❓ Q&amp;A</div>
        </div>}
        {agg.anchorChart > 0 && <div className="bg-amber-50 rounded-xl p-3 text-center border border-amber-200">
          <div className="text-2xl font-black text-amber-700">{agg.anchorChart}</div>
          <div className="text-[10px] font-bold text-amber-600 uppercase mt-1">📋 Anchor Chart</div>
        </div>}
      </div>
      {agg.feedbackRequests > 0 && (
        <div className="bg-emerald-50 border-l-4 border-emerald-400 rounded-r-md p-3 mb-4 text-sm">
          <span className="font-bold text-emerald-800">💬 {agg.feedbackRequests} AI-feedback request{agg.feedbackRequests === 1 ? '' : 's'}</span>
          <span className="text-emerald-700"> across the class. A useful proxy for metacognitive engagement (students who request feedback are practicing self-assessment).</span>
        </div>
      )}
      {/* Deterministic quality signals — no AI required, color-coded against research
          thresholds. Rendered generically from the registry-driven flat array so
          every template's signals (incl. new ones) surface with correct denominators. */}
      {Array.isArray(qualitySignals) && qualitySignals.length > 0 && (
        <div className="mb-4" data-help-key="dashboard_class_notebook_quality_signals">
          <div className="flex items-center justify-between mb-2">
            <h5 className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">{t('dashboard.class_notebook.quality_signals_label') || 'Quality Signals (research thresholds)'}</h5>
            <span className="text-[10px] text-slate-500 italic">{t('dashboard.class_notebook.quality_signals_legend') || 'green = healthy · amber = partial · red = needs attention'}</span>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {qualitySignals.map((sig) => (
              <_NotebookQualityCard
                key={sig.key}
                tone={sig.tone || 'gray'}
                label={t('dashboard.class_notebook.signal_' + sig.key) || sig.label}
                value={sig.value}
                suffix={sig.suffix || ''}
                denom={sig.denom || ''}
                hint={t('dashboard.class_notebook.signal_' + sig.key + '_hint') || sig.hint}
              />
            ))}
          </div>
        </div>
      )}
      {insightsLoading ? (
        <div className="text-center py-8">
          <div className="text-4xl mb-2 animate-pulse motion-reduce:animate-none">📓</div>
          <p className="text-sm text-slate-600 font-bold">{t('dashboard.class_notebook.loading') || 'AI is reading across the class...'}</p>
        </div>
      ) : insights ? (
        <div className="space-y-3 mt-4 bg-slate-50 rounded-xl p-4 border border-slate-200">
          {insights.classSummary && (
            <div className="bg-white border border-slate-200 rounded-md p-3">
              <div className="text-[11px] font-black text-slate-500 uppercase tracking-wider mb-1">{t('dashboard.class_notebook.overview_label') || 'Class overview'}</div>
              <div className="text-sm text-slate-700 leading-relaxed">{insights.classSummary}</div>
            </div>
          )}
          {Array.isArray(insights.patterns) && insights.patterns.map((p, i) => (
            <div key={i} className="bg-white border-l-4 border-violet-400 rounded-r-md p-3">
              <div className="text-sm font-black text-violet-800 mb-1">{p.title}</div>
              <div className="text-sm text-slate-700 leading-relaxed mb-2">{p.observation}</div>
              <div className="text-xs bg-violet-50 border border-violet-200 rounded p-2 text-violet-900">
                <span className="font-bold">{t('dashboard.class_notebook.mini_lesson_label') || 'Try a mini-lesson:'}</span> {p.miniLesson}
              </div>
            </div>
          ))}
          {insights.celebration && (
            <div className="bg-emerald-50 border-2 border-emerald-300 rounded-md p-3">
              <div className="text-[11px] font-black text-emerald-800 uppercase tracking-wider mb-1">🌱 {t('dashboard.class_notebook.celebration_label') || 'Class strength'}</div>
              <div className="text-sm text-slate-700 leading-relaxed">{insights.celebration}</div>
            </div>
          )}
        </div>
      ) : null}
    </div>
  );
});

// @section LEARNER_PROGRESS — Student learning journey view
const LearnerProgressView = React.memo(({
    globalPoints = 0, globalLevel = 1, globalProgress = 0, currentLevelXP = 0, globalXPNext = 100,
    history = [], wordSoundsHistory = [], phonemeMastery = {},
    studentProgressLog = [], pointHistory = [], wordSoundsBadges = {},
    gameCompletions = [], fluencyAssessments = [], labelChallengeResults = [],
    wordSoundsScore = { streak: 0 },
    isParentMode = false, isIndependentMode = false, isTeacherMode = false, t, onClose,
    rosterKey, setRosterKey, onShareWithTeacher
}) => {
    // gameCompletions has two shapes in the wild: this view expects the flat
    // array, but per-student session docs store an OBJECT keyed by game type
    // (e.g. { conceptSortAttempt: [...] }). A caller passing the object shape
    // crashed the whole view ("gameCompletions?.filter is not a function"
    // fatal via ErrorBoundary, field report 2026-08-11). Normalize here:
    // arrays pass through, object shapes flatten to their entries.
    gameCompletions = Array.isArray(gameCompletions)
        ? gameCompletions
        : Object.values(gameCompletions || {}).flat().filter((g) => g && typeof g === 'object');
    const [showDiagnostics, setShowDiagnostics] = useState(() => isIndependentMode);
    const [selectedChild, setSelectedChild] = useState(null);
    const childProfiles = useMemo(() => {
        if (!isParentMode || !rosterKey?.students) return [];
        return Object.entries(rosterKey.students).map(([name, groupId]) => ({
            name,
            groupId,
            lastSession: rosterKey?.progressHistory?.[name]?.slice(-1)?.[0]?.timestamp || null,
            sessionCount: rosterKey?.progressHistory?.[name]?.length || 0
        }));
    }, [isParentMode, rosterKey]);
    const isPhonemeMastered = (value) => {
        if (!value || typeof value !== 'object') return false;
        const independentAttempts = Number(value.independentAttempts || 0);
        const independentAccuracy = Number(
            value.independentAccuracy != null ? value.independentAccuracy : value.accuracy
        );
        return independentAttempts >= 5 && Number.isFinite(independentAccuracy) && independentAccuracy >= 80;
    };
    const stats = useMemo(() => {
        const quizzes = history.filter(h => h.type === 'quiz');
        // Word Sounds writes two kinds of row. Graded rows are items the child
        // could get wrong. practiceOnly rows come from coach-until-right
        // activities (Letter Trace) that never mark an answer wrong, so they
        // are always correct:true — pooling them turns the accuracy bar into a
        // measure of how much tracing the child did. wsTotal stays the full
        // count because "Words Practiced" is a volume, not a score. (The
        // activity test covers rows saved before the flag existed.)
        const wsGraded = wordSoundsHistory.filter(
            h => h && h.practiceOnly !== true && h.activity !== 'letter_tracing'
        );
        const wsCorrect = wsGraded.filter(h => h.correct).length;
        const wsGradedTotal = wsGraded.length;
        const wsTotal = wordSoundsHistory.length;
        const wsAccuracy = wsGradedTotal > 0 ? Math.round((wsCorrect / wsGradedTotal) * 100) : 0;
        // Right on the second try is not the same as right first time, and the
        // difference is the whole signal when deciding whether a skill is
        // secure. `attempts` is 1 on a first presentation. Rows saved before
        // that field existed default to 1, i.e. they read as first-try — which
        // is exactly how they were recorded.
        const wsFirstTryCorrect = wsGraded.filter(h => h.correct && (h.attempts || 1) === 1).length;
        const wsFirstTryAccuracy = wsGradedTotal > 0 ? Math.round((wsFirstTryCorrect / wsGradedTotal) * 100) : 0;
        const wsHasPracticeOnly = wsTotal > wsGradedTotal;
        const masteredPhonemes = Object.entries(phonemeMastery).filter(([_, v]) => isPhonemeMastered(v));
        const practicingPhonemes = Object.entries(phonemeMastery).filter(([_, v]) => (v.total || 0) > 0 && !isPhonemeMastered(v));
        const totalActivities = history.length + (wsTotal > 0 ? 1 : 0) + (gameCompletions?.length || 0);
        const recentSessions = studentProgressLog.slice(-5);
        const trend = recentSessions.length >= 2
            ? recentSessions[recentSessions.length - 1].xp - recentSessions[0].xp
            : 0;
        return {
            quizCount: quizzes.length,
            wsAccuracy, wsCorrect, wsTotal, wsGradedTotal,
            wsFirstTryAccuracy, wsFirstTryCorrect, wsHasPracticeOnly,
            masteredPhonemes, practicingPhonemes,
            totalActivities,
            gamesPlayed: gameCompletions?.length || 0,
            fluencyTests: fluencyAssessments?.length || 0,
            labelChallenges: labelChallengeResults?.length || 0,
            sessionCount: studentProgressLog.length,
            trend
        };
    }, [history, wordSoundsHistory, phonemeMastery, gameCompletions, fluencyAssessments, labelChallengeResults, studentProgressLog]);
    const heading = isParentMode
        ? (selectedChild ? selectedChild + "'s Learning Journey" : "Your Child's Learning Journey")
        : "My Learning Progress";
    return (
        <div className="max-w-4xl mx-auto p-4 md:p-6 space-y-6 animate-in motion-reduce:animate-none fade-in slide-in-from-bottom-2 duration-500" data-help-key="learner_progress_panel">
            <div className="flex items-center justify-between">
                <div>
                    <h2 className="text-2xl md:text-3xl font-black text-slate-800 flex items-center gap-3">
                        <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
                            <TrendingUp size={22} className="text-white" />
                        </div>
                        {heading}
                    </h2>
                    <p className="text-sm text-slate-600 mt-1 font-medium">
                        {isParentMode ? "Track your family's learning growth" : "Track your learning growth over time"}
                    </p>
                </div>
                <div className="flex items-center gap-2">
                    <button type="button"
                        onClick={() => setShowDiagnostics(prev => !prev)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all motion-reduce:transition-none ${
                            showDiagnostics
                                ? 'bg-indigo-100 text-indigo-700 ring-1 ring-indigo-300'
                                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                        }`}
                        title={showDiagnostics ? "Hide detailed metrics" : "Show detailed metrics"}
                        data-help-key="learner_progress_details_toggle"
                    >
                        <BarChart3 size={14} />
                        {showDiagnostics ? 'Details On' : 'Details'}
                    </button>
                    {onClose && (
                        <button
                            type="button"
                            onClick={onClose}
                            className="p-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 transition-colors motion-reduce:transition-none"
                            aria-label={t('common.close_dashboard') || t('common.close') || 'Close progress dashboard'}
                        >
                            <X aria-hidden="true" size={18} />
                        </button>
                    )}
                </div>
            </div>
            {isParentMode && childProfiles.length > 0 && (
                <div className="bg-gradient-to-r from-purple-50 to-indigo-50 rounded-2xl p-4 border border-purple-100" data-help-key="learner_progress_family_filter">
                    <h3 className="text-xs font-bold text-purple-600 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                        <Users size={14} /> Family Members
                    </h3>
                    <div className="flex flex-wrap gap-2">
                        <button type="button"
                            onClick={() => setSelectedChild(null)}
                            className={`px-4 py-2 rounded-xl font-bold text-sm transition-all motion-reduce:transition-none ${
                                !selectedChild ? 'bg-white text-indigo-700 shadow-md ring-2 ring-indigo-300' : 'bg-white/60 text-slate-600 hover:bg-white'
                            }`}
                        >
                            Everyone
                        </button>
                        {childProfiles.map(child => (
                            <button type="button"
                                key={child.name}
                                onClick={() => setSelectedChild(child.name)}
                                className={`px-4 py-2 rounded-xl font-bold text-sm transition-all motion-reduce:transition-none flex items-center gap-2 ${
                                    selectedChild === child.name ? 'bg-white text-indigo-700 shadow-md ring-2 ring-indigo-300' : 'bg-white/60 text-slate-600 hover:bg-white'
                                }`}
                            >
                                {child.name}
                                {child.sessionCount > 0 && (
                                    <span className="text-[11px] bg-indigo-100 text-indigo-600 px-1.5 py-0.5 rounded-full font-mono">
                                        {child.sessionCount} sessions
                                    </span>
                                )}
                            </button>
                        ))}
                    </div>
                </div>
            )}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-white rounded-2xl border border-slate-400 shadow-sm p-5 hover:shadow-md transition-shadow motion-reduce:transition-none">
                    <div className="flex items-center gap-3 mb-4">
                        <div className="w-14 h-14 bg-yellow-400 rounded-full flex items-center justify-center border-4 border-indigo-900 shadow-lg relative">
                            <Trophy size={28} className="text-indigo-900 fill-current" />
                            <div className="absolute -bottom-2 bg-indigo-900 text-yellow-200 text-[11px] font-black px-2 py-0.5 rounded-full border border-white">
                                Lvl {globalLevel}
                            </div>
                        </div>
                        <div className="flex-1">
                            <div className="text-xs font-bold text-slate-600 uppercase tracking-wider">{t('learner.total_xp')}</div>
                            <div className="text-2xl font-black text-indigo-900">{globalPoints.toLocaleString()}</div>
                        </div>
                        {stats.trend > 0 && (
                            <div className="text-xs font-bold text-green-800 bg-green-50 px-2 py-1 rounded-full flex items-center gap-1">
                                <TrendingUp size={12} /> +{stats.trend} XP
                            </div>
                        )}
                    </div>
                    {!isTeacherMode && (wordSoundsScore?.streak > 0 || (() => {
                        const days = new Set();
                        pointHistory.forEach(e => { if (e.timestamp) days.add(new Date(e.timestamp).toDateString()); });
                        const dayList = Array.from(days).sort((a, b) => new Date(b) - new Date(a));
                        let dayStreak = 0;
                        const today = new Date();
                        for (let i = 0; i < dayList.length; i++) {
                            const expected = new Date(today);
                            expected.setDate(today.getDate() - i);
                            if (dayList[i] === expected.toDateString()) dayStreak++;
                            else break;
                        }
                        return dayStreak >= 2;
                    })()) && (
                        <div className="flex items-center gap-3 mb-2 px-3 py-2 bg-gradient-to-r from-orange-50 to-red-50 rounded-xl border border-orange-100">
                            {wordSoundsScore?.streak > 0 && (
                                <div className="flex items-center gap-1">
                                    <span className="text-lg">🔥</span>
                                    <div>
                                        <div className="text-sm font-black text-orange-600">{wordSoundsScore.streak} Streak</div>
                                        <div className="text-[11px] text-orange-700 font-bold uppercase">{t('learner.current_run')}</div>
                                    </div>
                                </div>
                            )}
                            {(() => {
                                const days = new Set();
                                pointHistory.forEach(e => { if (e.timestamp) days.add(new Date(e.timestamp).toDateString()); });
                                const dayList = Array.from(days).sort((a, b) => new Date(b) - new Date(a));
                                let dayStreak = 0;
                                const today = new Date();
                                for (let i = 0; i < dayList.length; i++) {
                                    const expected = new Date(today);
                                    expected.setDate(today.getDate() - i);
                                    if (dayList[i] === expected.toDateString()) dayStreak++;
                                    else break;
                                }
                                return dayStreak >= 2 ? (
                                    <div className="flex items-center gap-1 ml-auto">
                                        <span className="text-lg">📅</span>
                                        <div>
                                            <div className="text-sm font-black text-red-600">{dayStreak} Days</div>
                                            <div className="text-[11px] text-red-600 font-bold uppercase">{t('learner.daily_streak')}</div>
                                        </div>
                                    </div>
                                ) : null;
                            })()}
                        </div>
                    )}
                    <div className="space-y-1.5">
                        <div className="flex justify-between text-[11px] font-bold text-slate-600 uppercase">
                            <span>Level {globalLevel}</span>
                            <span>{Math.round(globalProgress)}%</span>
                        </div>
                        <div className="w-full bg-slate-100 rounded-full h-3 overflow-hidden">
                            <div className="h-full bg-gradient-to-r from-yellow-400 to-orange-500 transition-all motion-reduce:transition-none duration-1000 rounded-full" style={{ width: `${Math.max(5, globalProgress)}%` }} />
                        </div>
                        <div className="flex justify-between text-[11px] font-mono text-slate-600">
                            <span>{currentLevelXP} XP</span>
                            <span>{globalXPNext} XP to next</span>
                        </div>
                    </div>
                </div>
                <div className="bg-white rounded-2xl border border-slate-400 shadow-sm p-5 hover:shadow-md transition-shadow motion-reduce:transition-none" data-help-key="learner_progress_activities_card">
                    <h3 className="text-xs font-bold text-slate-600 uppercase tracking-wider mb-4 flex items-center gap-1.5">
                        <Activity size={14} /> Activities Completed
                    </h3>
                    <div className="text-3xl font-black text-slate-800 mb-4">{stats.totalActivities}</div>
                    <div className="grid grid-cols-2 gap-2">
                        {[
                            { label: 'Quizzes', value: stats.quizCount, icon: '📝', color: 'bg-blue-50 text-blue-800' },
                            { label: 'Words Practiced', value: stats.wsTotal, icon: '🔤', color: 'bg-purple-50 text-purple-800' },
                            { label: 'Games', value: stats.gamesPlayed, icon: '🎮', color: 'bg-green-50 text-green-800' },
                            { label: 'Fluency Tests', value: stats.fluencyTests, icon: '⏱️', color: 'bg-orange-50 text-orange-800' },
                        ].map(item => (
                            <div key={item.label} className={`${item.color} rounded-lg px-3 py-2 text-center`}>
                                <div className="text-lg font-black">{item.icon} {item.value}</div>
                                <div className="text-[11px] font-bold uppercase tracking-wider">{item.label}</div>
                            </div>
                        ))}
                    </div>
                </div>
                <div className="bg-white rounded-2xl border border-slate-400 shadow-sm p-5 hover:shadow-md transition-shadow motion-reduce:transition-none" data-help-key="learner_progress_skills_chart">
                    <h3 className="text-xs font-bold text-slate-600 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                        <Target size={14} /> Skills Progress
                    </h3>
                    {stats.wsTotal === 0 && Object.keys(phonemeMastery).length === 0 ? (
                        <div className="text-center py-6 text-slate-600 italic text-sm">
                            <BookOpen size={32} className="mx-auto mb-2 opacity-40" />
                            Start practicing to see your skills grow!
                        </div>
                    ) : (
                        <div className="space-y-3">
                            {stats.wsGradedTotal > 0 && (
                                <div>
                                    <div className="flex justify-between items-center mb-1">
                                        <span className="text-sm font-bold text-slate-600">{t('learner.ws_accuracy')}</span>
                                        <span className={`text-sm font-black ${stats.wsAccuracy >= 80 ? 'text-green-600' : stats.wsAccuracy >= 60 ? 'text-yellow-600' : 'text-orange-500'}`}>
                                            {stats.wsAccuracy}%
                                        </span>
                                    </div>
                                    <div className="w-full bg-slate-100 rounded-full h-2.5">
                                        <div
                                            className={`h-full rounded-full transition-all motion-reduce:transition-none duration-500 ${stats.wsAccuracy >= 80 ? 'bg-green-500' : stats.wsAccuracy >= 60 ? 'bg-yellow-500' : 'bg-orange-400'}`}
                                            style={{ width: `${stats.wsAccuracy}%` }}
                                        />
                                    </div>
                                    {/* First-try accuracy sits under the overall bar rather than
                                        replacing it: the gap between the two is the signal about
                                        whether a skill is secure or still propped up by retries. */}
                                    <div className="flex justify-between items-center mt-1.5">
                                        <span className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">{t('learner.ws_first_try_accuracy')}</span>
                                        <span className="text-[11px] font-black text-slate-700">
                                            {stats.wsFirstTryAccuracy}% <span className="font-bold text-slate-600">({stats.wsFirstTryCorrect}/{stats.wsGradedTotal})</span>
                                        </span>
                                    </div>
                                    {stats.wsHasPracticeOnly && (
                                        <div className="text-[10px] text-slate-600 mt-1 leading-snug">
                                            {t('learner.ws_practice_only_note')}
                                        </div>
                                    )}
                                </div>
                            )}
                            {stats.masteredPhonemes.length > 0 && (
                                <div>
                                    <div className="text-[11px] font-bold text-green-600 uppercase tracking-wider mb-1.5">
                                        ✨ {stats.masteredPhonemes.length} Sounds Mastered
                                    </div>
                                    <div className="flex flex-wrap gap-1">
                                        {stats.masteredPhonemes.slice(0, 12).map(([phoneme]) => (
                                            <span key={phoneme} className="px-2 py-0.5 bg-green-50 text-green-700 text-xs font-bold rounded-full border border-green-200">
                                                /{phoneme}/
                                            </span>
                                        ))}
                                        {stats.masteredPhonemes.length > 12 && (
                                            <span className="px-2 py-0.5 bg-green-50 text-green-800 text-xs font-bold rounded-full">
                                                +{stats.masteredPhonemes.length - 12} more
                                            </span>
                                        )}
                                    </div>
                                </div>
                            )}
                            {showDiagnostics && stats.practicingPhonemes.length > 0 && (
                                <div>
                                    <div className="text-[11px] font-bold text-amber-600 uppercase tracking-wider mb-1.5">
                                        🔄 {stats.practicingPhonemes.length} Sounds In Progress
                                    </div>
                                    <div className="flex flex-wrap gap-1">
                                        {stats.practicingPhonemes.slice(0, 8).map(([phoneme, data]) => (
                                            <span key={phoneme} className="px-2 py-0.5 bg-amber-50 text-amber-700 text-xs font-bold rounded-full border border-amber-200" title={`${Math.round(data.accuracy)}% accuracy`}>
                                                /{phoneme}/ <span className="opacity-60">{Math.round(data.accuracy)}%</span>
                                            </span>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </div>
                    )}
                </div>
                <div className="bg-white rounded-2xl border border-slate-400 shadow-sm p-5 hover:shadow-md transition-shadow motion-reduce:transition-none">
                    <h3 className="text-xs font-bold text-slate-600 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                        <Award size={14} /> Achievements
                    </h3>
                    {(() => {
                        const milestones = [
                            { name: 'First Steps', earned: globalPoints >= 10, icon: '👣', desc: 'Earned your first XP' },
                            { name: 'Quiz Whiz', earned: stats.quizCount >= 3, icon: '🧠', desc: 'Completed 3 quizzes' },
                            { name: 'Word Explorer', earned: stats.wsTotal >= 20, icon: '🔍', desc: 'Practiced 20 words' },
                            { name: 'Game Champion', earned: stats.gamesPlayed >= 5, icon: '🏆', desc: 'Played 5 games' },
                            { name: 'Level Up!', earned: globalLevel >= 2, icon: '⭐', desc: 'Reached Level 2' },
                            { name: 'Super Scholar', earned: globalLevel >= 5, icon: '🌟', desc: 'Reached Level 5' },
                            { name: 'Sound Master', earned: stats.masteredPhonemes.length >= 5, icon: '🎵', desc: 'Mastered 5 phonemes' },
                            { name: 'Consistent', earned: stats.sessionCount >= 3, icon: '📅', desc: '3 learning sessions' },
                        ];
                        const earned = milestones.filter(m => m.earned);
                        const locked = milestones.filter(m => !m.earned);
                        return (
                            <div className="space-y-3">
                                {earned.length > 0 && (
                                    <div className="flex flex-wrap gap-2">
                                        {earned.map(m => (
                                            <div key={m.name} className="bg-yellow-50 border border-yellow-200 rounded-xl px-3 py-2 text-center min-w-[80px] hover:shadow-sm transition-shadow motion-reduce:transition-none" title={m.desc}>
                                                <div className="text-xl">{m.icon}</div>
                                                <div className="text-[11px] font-bold text-yellow-800 mt-0.5">{m.name}</div>
                                            </div>
                                        ))}
                                    </div>
                                )}
                                {earned.length === 0 && (
                                    <div className="text-center py-4 text-slate-600 italic text-sm">
                                        Complete activities to earn achievements! 🌟
                                    </div>
                                )}
                                {showDiagnostics && locked.length > 0 && (
                                    <div>
                                        <div className="text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1.5">{t('learner.coming_up')}</div>
                                        <div className="flex flex-wrap gap-1.5">
                                            {locked.slice(0, 4).map(m => (
                                                <div key={m.name} className="bg-slate-50 border border-slate-400 rounded-lg px-2 py-1.5 text-center opacity-50" title={m.desc}>
                                                    <div className="text-sm grayscale">{m.icon}</div>
                                                    <div className="text-[11px] font-bold text-slate-600">{m.name}</div>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                )}
                            </div>
                        );
                    })()}
                </div>
            </div>
            {(() => {
                const today = new Date().toDateString();
                const todayXP = pointHistory.filter(e => e.timestamp && new Date(e.timestamp).toDateString() === today);
                const todayWords = wordSoundsHistory.filter(h => h.timestamp && new Date(h.timestamp).toDateString() === today);
                if (todayXP.length === 0 && todayWords.length === 0) return null;
                return (
                    <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl border border-blue-100 p-5">
                        <h3 className="text-xs font-bold text-blue-600 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                            <Clock size={14} /> Today's Activity
                        </h3>
                        <div className="grid grid-cols-3 gap-3 mb-3">
                            <div className="bg-white rounded-xl p-3 text-center border border-blue-100">
                                <div className="text-lg font-black text-blue-700">{todayXP.reduce((s,e) => s + (e.points || 0), 0)}</div>
                                <div className="text-[11px] font-bold text-blue-700 uppercase">{t('learner.xp_earned')}</div>
                            </div>
                            <div className="bg-white rounded-xl p-3 text-center border border-blue-100">
                                <div className="text-lg font-black text-blue-700">{todayXP.length}</div>
                                <div className="text-[11px] font-bold text-blue-700 uppercase">Activities</div>
                            </div>
                            <div className="bg-white rounded-xl p-3 text-center border border-blue-100">
                                <div className="text-lg font-black text-blue-700">{todayWords.filter(w => w.correct).length}/{todayWords.length}</div>
                                <div className="text-[11px] font-bold text-blue-700 uppercase">{t('learner.words_today')}</div>
                            </div>
                        </div>
                        {todayXP.length > 0 && (
                            <div className="space-y-1 max-h-24 overflow-y-auto">
                                {todayXP.slice(0, 8).map((entry, i) => (
                                    <div key={entry.id || i} className="flex justify-between items-center text-xs px-2 py-1 rounded bg-white/60">
                                        <span className="text-slate-600 font-medium truncate max-w-[220px]">{entry.activity}</span>
                                        <span className="font-bold text-green-600 whitespace-nowrap">+{entry.points} XP</span>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                );
            })()}
            {(() => {
                const now = new Date();
                const weekAgo = new Date(now);
                weekAgo.setDate(now.getDate() - 7);
                const weekXP = pointHistory.filter(e => e.timestamp && new Date(e.timestamp) >= weekAgo);
                const weekWords = wordSoundsHistory.filter(h => h.timestamp && new Date(h.timestamp) >= weekAgo);
                const weekGames = gameCompletions?.filter(g => g.timestamp && new Date(g.timestamp) >= weekAgo) || [];
                const prevWeekStart = new Date(weekAgo);
                prevWeekStart.setDate(prevWeekStart.getDate() - 7);
                const prevWeekXP = pointHistory.filter(e => e.timestamp && new Date(e.timestamp) >= prevWeekStart && new Date(e.timestamp) < weekAgo);
                const weekTotalXP = weekXP.reduce((s, e) => s + (e.points || 0), 0);
                const prevTotalXP = prevWeekXP.reduce((s, e) => s + (e.points || 0), 0);
                const xpDelta = weekTotalXP - prevTotalXP;
                const weekAccuracy = weekWords.length > 0 ? Math.round(weekWords.filter(w => w.correct).length / weekWords.length * 100) : null;
                if (weekXP.length === 0 && weekWords.length === 0) return null;
                return (
                    <div className="bg-gradient-to-r from-emerald-50 to-teal-50 rounded-2xl border border-emerald-100 p-5">
                        <h3 className="text-xs font-bold text-emerald-600 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                            <Calendar size={14} /> This Week's Progress
                        </h3>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-3">
                            <div className="bg-white rounded-xl p-3 text-center border border-emerald-100">
                                <div className="text-lg font-black text-emerald-700">{weekTotalXP}</div>
                                <div className="text-[11px] font-bold text-emerald-700 uppercase">{t('learner.xp_this_week')}</div>
                                {xpDelta !== 0 && (
                                    <div className={`text-[11px] font-bold mt-0.5 ${xpDelta > 0 ? 'text-green-500' : 'text-red-400'}`}>
                                        {xpDelta > 0 ? '↑' : '↓'} {Math.abs(xpDelta)} vs last week
                                    </div>
                                )}
                            </div>
                            <div className="bg-white rounded-xl p-3 text-center border border-emerald-100">
                                <div className="text-lg font-black text-emerald-700">{weekXP.length}</div>
                                <div className="text-[11px] font-bold text-emerald-700 uppercase">Activities</div>
                            </div>
                            <div className="bg-white rounded-xl p-3 text-center border border-emerald-100">
                                <div className="text-lg font-black text-emerald-700">{weekWords.filter(w => w.correct).length}/{weekWords.length}</div>
                                <div className="text-[11px] font-bold text-emerald-700 uppercase">{t('learner.words_this_week')}</div>
                            </div>
                            <div className="bg-white rounded-xl p-3 text-center border border-emerald-100">
                                <div className="text-lg font-black text-emerald-700">{weekAccuracy !== null ? weekAccuracy + '%' : '—'}</div>
                                <div className="text-[11px] font-bold text-emerald-700 uppercase">Accuracy</div>
                            </div>
                        </div>
                        {weekGames.length > 0 && (
                            <div className="text-xs text-emerald-600 font-medium bg-white/60 rounded-lg px-3 py-2">
                                🎮 {weekGames.length} game{weekGames.length !== 1 ? 's' : ''} played this week
                            </div>
                        )}
                    </div>
                );
            })()}
            {studentProgressLog.length >= 2 && (
                <div className="bg-white rounded-2xl border border-slate-400 shadow-sm p-5 hover:shadow-md transition-shadow motion-reduce:transition-none" data-help-key="learner_progress_growth_chart">
                    <h3 className="text-xs font-bold text-slate-600 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                        <TrendingUp size={14} /> Growth Over Time
                    </h3>
                    <LongitudinalProgressChart logs={studentProgressLog} />
                </div>
            )}
            {showDiagnostics && (
                <div className="bg-slate-50 rounded-2xl border border-slate-400 p-5 space-y-4 animate-in motion-reduce:animate-none slide-in-from-top-2 duration-300" data-help-key="learner_progress_diagnostics_panel">
                    <h3 className="text-xs font-bold text-slate-600 uppercase tracking-wider flex items-center gap-1.5">
                        <BarChart3 size={14} /> Detailed Metrics
                    </h3>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                        <div className="bg-white rounded-xl p-3 border border-slate-400 text-center">
                            {/* Denominator is the graded count, not the practice volume —
                                wsCorrect can only come from rows that could have been wrong. */}
                            <div className="text-lg font-black text-slate-700">{stats.wsCorrect}/{stats.wsGradedTotal}</div>
                            <div className="text-[11px] font-bold text-slate-600 uppercase">{t('learner.words_correct')}</div>
                        </div>
                        <div className="bg-white rounded-xl p-3 border border-slate-400 text-center">
                            <div className="text-lg font-black text-slate-700">{Object.keys(phonemeMastery).length}</div>
                            <div className="text-[11px] font-bold text-slate-600 uppercase">{t('learner.phonemes_touched')}</div>
                        </div>
                        <div className="bg-white rounded-xl p-3 border border-slate-400 text-center">
                            <div className="text-lg font-black text-slate-700">{stats.sessionCount}</div>
                            <div className="text-[11px] font-bold text-slate-600 uppercase">Sessions</div>
                        </div>
                        <div className="bg-white rounded-xl p-3 border border-slate-400 text-center">
                            <div className="text-lg font-black text-slate-700">{stats.labelChallenges}</div>
                            <div className="text-[11px] font-bold text-slate-600 uppercase">{t('learner.label_challenges')}</div>
                        </div>
                    </div>
                    {pointHistory.length > 0 && (
                        <div>
                            <h4 className="text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-2">{t('learner.recent_activity')}</h4>
                            <div className="space-y-1 max-h-32 overflow-y-auto">
                                {pointHistory.slice(0, 10).map((entry, i) => (
                                    <div key={entry.id || i} className="flex justify-between items-center text-xs px-2 py-1 rounded hover:bg-white">
                                        <span className="text-slate-600 font-medium truncate max-w-[200px]">{entry.activity}</span>
                                        <span className="font-bold text-green-600">+{entry.points} XP</span>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                </div>
            )}
            <div className="flex flex-wrap justify-center gap-3 pt-2">
                <button type="button"
                    onClick={() => {
                        const date = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
                        const metricBar = (label, value, max, unit, icon) => {
                            const pct = max > 0 ? Math.min(100, Math.round((value / max) * 100)) : 0;
                            const barColor = pct >= 80 ? '#16a34a' : pct >= 50 ? '#d97706' : '#e11d48';
                            return `<div style="margin-bottom:14px"><div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:4px"><span style="font-size:13px;font-weight:600;color:#334155">${icon} ${label}</span><span style="font-size:14px;font-weight:800;color:${barColor}">${value}${unit}</span></div><div style="background:#f1f5f9;border-radius:6px;height:10px;overflow:hidden"><div style="background:${barColor};height:100%;border-radius:6px;width:${pct}%"></div></div></div>`;
                        };
                        const masteredCount = Object.entries(phonemeMastery).filter(([_,v]) => isPhonemeMastered(v)).length;
                        const masteredList = Object.entries(phonemeMastery).filter(([_,v]) => isPhonemeMastered(v)).map(([p]) => '/' + p + '/').join(', ');
                        const html = `<!DOCTYPE html><html><head><meta charset="UTF-8">` +
                          `<title>${t('learner.progress_report')}</title>` +
                          `<style>` +
                          `@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap');` +
                          `*{box-sizing:border-box;margin:0;padding:0}` +
                          `body{font-family:'Inter',-apple-system,sans-serif;color:#1e293b;background:#f8fafc;padding:32px;line-height:1.5}` +
                          `.report{max-width:700px;margin:0 auto;background:white;border-radius:16px;box-shadow:0 4px 24px rgba(0,0,0,.08);overflow:hidden}` +
                          `.header{padding:28px 32px;background:linear-gradient(135deg,#4f46e5 0%,#7c3aed 100%);color:white}` +
                          `.header h1{font-size:22px;font-weight:800;margin-bottom:4px}` +
                          `.header p{font-size:13px;opacity:.85}` +
                          `.content{padding:28px 32px}` +
                          `.section-title{font-size:15px;font-weight:800;color:#334155;margin:20px 0 12px;padding-bottom:6px;border-bottom:2px solid #e2e8f0}` +
                          `.badge-row{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:16px}` +
                          `.badge{display:inline-flex;align-items:center;gap:6px;padding:8px 14px;background:#fef9c3;border:1px solid #fcd34d;border-radius:10px;font-size:12px;font-weight:700;color:#92400e}` +
                          `.footer{padding:16px 32px;background:#f8fafc;border-top:1px solid #e2e8f0;text-align:center;font-size:11px;color:#94a3b8}` +
                          `.print-btn{display:block;margin:16px auto;padding:10px 28px;background:#4f46e5;color:white;border:none;border-radius:8px;font-size:14px;font-weight:700;cursor:pointer;font-family:inherit}` +
                          `.print-btn:hover{background:#4338ca}` +
                          `@media print{body{padding:0;background:white}.report{box-shadow:none;border-radius:0}.print-btn{display:none!important}.header{-webkit-print-color-adjust:exact;print-color-adjust:exact}}` +
                          `</style></head>` +
                          `<body><div class="report">` +
                          `<div class="header">` +
                          `<h1>🌟 ${isParentMode ? "Your Child's" : 'My'} Learning Progress Report</h1>` +
                          `<p>${isParentMode ? 'Family Progress Overview' : 'Personal Progress Overview'} &bull; ${date}</p>` +
                          `</div>` +
                          `<div class="content">` +
                          `<div style="display:flex;align-items:center;gap:16px;padding:16px;background:linear-gradient(135deg,#fef3c7,#fef9c3);border:2px solid #fcd34d;border-radius:12px;margin-bottom:20px">` +
                          `<div style="width:56px;height:56px;background:#eab308;border-radius:50%;display:flex;align-items:center;justify-content:center;border:4px solid #1e1b4b;font-size:24px;font-weight:900;color:#1e1b4b">Lv${globalLevel}</div>` +
                          `<div>` +
                          `<div style="font-size:20px;font-weight:800;color:#1e1b4b">${globalPoints.toLocaleString()} Total XP</div>` +
                          `<div style="font-size:12px;color:#92400e;font-weight:600">Level ${globalLevel} Learner &bull; ${Math.round(globalProgress)}% to next level</div>` +
                          `</div></div>` +
                          `<div class="section-title">📊 Performance Summary</div>` +
                          `${metricBar('Word Sounds Accuracy', stats.wsAccuracy, 100, '%', '🔊')}` +
                          `${metricBar('Right First Try', stats.wsFirstTryAccuracy, 100, '%', '🎯')}` +
                          `${metricBar('Quizzes Completed', stats.quizCount, 10, '', '📝')}` +
                          `${metricBar('Words Practiced', stats.wsTotal, 50, '', '🔤')}` +
                          `${metricBar('Games Played', stats.gamesPlayed, 10, '', '🎮')}` +
                          `${metricBar('Fluency Tests', stats.fluencyTests, 5, '', '⏱️')}` +
                          `${metricBar('Total Activities', stats.totalActivities, 20, '', '📊')}` +
                          `<div class="section-title">🎯 Skills Mastered</div>` +
                          `<div style="font-size:13px;color:#475569;margin-bottom:8px"><strong>${masteredCount}</strong> phoneme sounds mastered${masteredCount > 0 ? ':' : ''}</div>` +
                          `${masteredCount > 0 ? '<div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:16px">' + Object.entries(phonemeMastery).filter(([_,v]) => isPhonemeMastered(v)).map(([p]) => '<span style="padding:4px 12px;background:#dcfce7;color:#16a34a;border:1px solid #86efac;border-radius:20px;font-size:12px;font-weight:700">/' + p + '/</span>').join('') + '</div>' : '<p style="font-size:13px;color:#94a3b8;font-style:italic">Keep practicing to master sounds!</p>'}` +
                          `<div class="section-title">🏅 Achievements Earned</div>` +
                          `<div class="badge-row">` +
                          `${globalPoints >= 10 ? '<div class="badge">👣 First Steps</div>' : ''}` +
                          `${stats.quizCount >= 3 ? '<div class="badge">🧠 Quiz Whiz</div>' : ''}` +
                          `${stats.wsTotal >= 20 ? '<div class="badge">🔍 Word Explorer</div>' : ''}` +
                          `${stats.gamesPlayed >= 5 ? '<div class="badge">🏆 Game Champion</div>' : ''}` +
                          `${globalLevel >= 2 ? '<div class="badge">⭐ Level Up!</div>' : ''}` +
                          `${globalLevel >= 5 ? '<div class="badge">🌟 Super Scholar</div>' : ''}` +
                          `${stats.masteredPhonemes.length >= 5 ? '<div class="badge">🎵 Sound Master</div>' : ''}` +
                          `${stats.sessionCount >= 3 ? '<div class="badge">📅 Consistent</div>' : ''}` +
                          `</div></div>` +
                          `<div class="footer">Generated ${date} &bull; Created with AlloFlow &bull; Learning Progress Report</div>` +
                          `</div>` +
                          `<button type="button" class="print-btn" onclick="window.print()">🖨️ Print This Report</button>` +
                          `</body></html>`;
                        const w = window.open('', '_blank');
                        if (w) { w.document.write(html); w.document.close(); }
                    }}
                    className="px-5 py-2.5 bg-gradient-to-r from-emerald-700 to-teal-700 text-white font-bold rounded-xl shadow-lg hover:shadow-xl transition-all motion-reduce:transition-none hover:scale-[1.02] flex items-center gap-2 text-sm"
                    data-help-key="learner_progress_print_report_btn"
                >
                    <Printer size={16} /> Print Progress Report
                </button>
                {isParentMode && onShareWithTeacher && (
                    <button type="button"
                        onClick={onShareWithTeacher}
                        className="px-5 py-2.5 bg-gradient-to-r from-indigo-700 to-purple-700 text-white font-bold rounded-xl shadow-lg hover:shadow-xl transition-all motion-reduce:transition-none hover:scale-[1.02] flex items-center gap-2 text-sm"
                        data-help-key="learner_progress_share_teacher_btn"
                    >
                        <Share2 size={16} /> Share Progress with Teacher
                    </button>
                )}
            </div>
        </div>
    );
});
// @section TEACHER_DASHBOARD — Main teacher dashboard
const TeacherDashboard = React.memo(({ onClose, dashboardData = [], setDashboardData, addToast, setSelectedStudentId, setDashboardView, dashboardView, selectedStudentId, generateResourceHTML, onOpenBehaviorLens, callGemini }) => {
  const { t } = useContext(LanguageContext);
  const modalRef = useRef(null);
  useFocusTrap(modalRef, true, onClose);
  const [gradedIds, setGradedIds] = useState(new Set());
  // Teacher comment threads per (student, resource). Persisted to localStorage
  // since the dashboard is a one-way student→teacher upload and the comments
  // are the teacher's PRIVATE annotations, not shared with the student.
  // Shape: Map<string "{studentId}:{resourceId}", Array<{ id, text, timestamp }>>
  const [teacherComments, setTeacherComments] = useState(() => {
      try {
          const stored = localStorage.getItem('allo_teacher_comments');
          if (stored) return new Map(JSON.parse(stored));
      } catch (_) {}
      return new Map();
  });
  React.useEffect(() => {
      try {
          localStorage.setItem('allo_teacher_comments', JSON.stringify(Array.from(teacherComments.entries())));
      } catch (_) {}
  }, [teacherComments]);
  const _commentKey = (studentId, resourceId) => `${studentId || 'unknown'}:${resourceId || 'unknown'}`;
  const getCommentsFor = React.useCallback((studentId, resourceId) => {
      return teacherComments.get(_commentKey(studentId, resourceId)) || [];
  }, [teacherComments]);
  const addComment = (studentId, resourceId, text) => {
      const trimmed = (text || '').trim();
      if (!trimmed) return;
      setTeacherComments(prev => {
          const next = new Map(prev);
          const key = _commentKey(studentId, resourceId);
          const list = next.get(key) || [];
          next.set(key, [...list, { id: 'c-' + Date.now() + '-' + Math.random().toString(36).slice(2, 6), text: trimmed, timestamp: new Date().toISOString() }]);
          return next;
      });
      if (addToast) addToast(t('dashboard.comments.saved') || 'Comment saved.', 'success');
  };
  const deleteComment = (studentId, resourceId, commentId) => {
      setTeacherComments(prev => {
          const next = new Map(prev);
          const key = _commentKey(studentId, resourceId);
          const list = next.get(key) || [];
          const updated = list.filter(c => c.id !== commentId);
          if (updated.length === 0) next.delete(key);
          else next.set(key, updated);
          return next;
      });
  };
  const [studentFilter, setStudentFilter] = useState('all');
  const [activeTab, setActiveTab] = useState('students');
  const dashboardTabIds = ['students', 'insights', 'behavior', 'stems'];
  const dashboardTabRefs = useRef({});
  const handleDashboardTabKeyDown = (event, tabId) => {
      const currentIndex = dashboardTabIds.indexOf(tabId);
      let nextIndex = currentIndex;
      if (event.key === 'ArrowRight' || event.key === 'ArrowDown') nextIndex = (currentIndex + 1) % dashboardTabIds.length;
      else if (event.key === 'ArrowLeft' || event.key === 'ArrowUp') nextIndex = (currentIndex - 1 + dashboardTabIds.length) % dashboardTabIds.length;
      else if (event.key === 'Home') nextIndex = 0;
      else if (event.key === 'End') nextIndex = dashboardTabIds.length - 1;
      else return;
      event.preventDefault();
      const nextId = dashboardTabIds[nextIndex];
      setActiveTab(nextId);
      window.setTimeout(() => dashboardTabRefs.current[nextId]?.focus(), 0);
  };
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const clearConfirmDialogRef = useRef(null);
  const clearConfirmTriggerRef = useRef(null);
  useEffect(() => {
    if (!showClearConfirm) return;
    clearConfirmDialogRef.current?.querySelector('[data-safe-default="true"]')?.focus();
  }, [showClearConfirm]);
  const closeClearConfirm = () => {
    setShowClearConfirm(false);
    window.setTimeout(() => clearConfirmTriggerRef.current?.focus(), 0);
  };
  const toggleGraded = (id) => {
      setGradedIds(prev => {
          const next = new Set(prev);
          if (next.has(id)) {
              next.delete(id);
          } else {
              next.add(id);
              if (addToast) addToast(t('dashboard.toasts.marked_graded'), "success");
          }
          return next;
      });
  };
  // ── Bulk teacher actions ────────────────────────────────────────────────
  // Apply an action to whichever student set is currently visible (after the
  // student-filter chip — "All / Has Probes / Has Notebook / Graded / etc").
  // Lets a teacher mark a whole group reviewed in one click, export their
  // notebooks to a single PDF, or generate AI feedback messages for all of
  // them in batch.
  const getCurrentFilteredStudents = React.useCallback(() => {
      return (dashboardData || []).filter(s => {
          if (studentFilter === 'probes') return s.probeHistory && Object.keys(s.probeHistory).length > 0;
          if (studentFilter === 'surveys') return s.surveyResponses && s.surveyResponses.length > 0;
          if (studentFilter === 'notebook') return (s.history || []).some(h => h && (h.type === 'note-taking' || h.type === 'anchor-chart'));
          if (studentFilter === 'graded') return gradedIds.has(s.id);
          if (studentFilter === 'ungraded') return !gradedIds.has(s.id);
          return true;
      });
  }, [dashboardData, studentFilter, gradedIds]);
  const handleBulkMarkGraded = () => {
      const students = getCurrentFilteredStudents();
      if (students.length === 0) {
          if (addToast) addToast(t('dashboard.bulk.no_students_in_filter') || 'No students in the current filter.', 'info');
          return;
      }
      const ids = students.map(s => s.id);
      setGradedIds(prev => {
          const next = new Set(prev);
          let added = 0;
          ids.forEach(id => { if (!next.has(id)) { next.add(id); added++; } });
          if (addToast) addToast((t('dashboard.bulk.marked_graded', { count: added }) || `Marked ${added} student${added === 1 ? '' : 's'} graded.`), 'success');
          return next;
      });
  };
  const handleBulkUnmarkGraded = () => {
      const students = getCurrentFilteredStudents();
      if (students.length === 0) {
          if (addToast) addToast(t('dashboard.bulk.no_students_in_filter') || 'No students in the current filter.', 'info');
          return;
      }
      const ids = new Set(students.map(s => s.id));
      setGradedIds(prev => {
          const next = new Set(prev);
          let removed = 0;
          ids.forEach(id => { if (next.has(id)) { next.delete(id); removed++; } });
          if (addToast) addToast((t('dashboard.bulk.unmarked_graded', { count: removed }) || `Cleared graded flag on ${removed} student${removed === 1 ? '' : 's'}.`), 'info');
          return next;
      });
  };
  const handleBulkExportNotebooksPDF = async () => {
      const students = getCurrentFilteredStudents().filter(s => (s.history || []).some(h => h && (h.type === 'note-taking' || h.type === 'anchor-chart')));
      if (students.length === 0) {
          if (addToast) addToast(t('dashboard.bulk.no_notebook_students') || 'No students in the current filter have notebook entries.', 'info');
          return;
      }
      if (!window.jspdf) {
          if (addToast) addToast(t('dashboard.bulk.pdf_unavailable') || 'PDF library not loaded.', 'error');
          return;
      }
      if (addToast) addToast((t('dashboard.bulk.generating_notebooks_pdf', { count: students.length }) || `Generating notebook PDF for ${students.length} student${students.length === 1 ? '' : 's'}...`), 'info');
      const { jsPDF } = window.jspdf;
      const doc = new jsPDF();
      const escapeHtml = (s) => String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
      const renderCommentsBlock = (studentId, resourceId) => {
          const list = getCommentsFor(studentId, resourceId);
          if (!list || list.length === 0) return '';
          const items = list.map(c => `
              <li style="margin-bottom:8px; padding:8px 10px; background:#fffbeb; border-left:3px solid #f59e0b; border-radius:4px;">
                  <div style="font-size:0.85em; color:#1e293b; line-height:1.5; white-space:pre-wrap;">${escapeHtml(c.text)}</div>
                  <div style="font-size:0.7em; color:#92400e; font-style:italic; margin-top:4px;">📝 ${new Date(c.timestamp).toLocaleString()}</div>
              </li>
          `).join('');
          return `
              <div style="margin-top:12px;">
                  <div style="font-size:0.7em; font-weight:bold; text-transform:uppercase; color:#92400e; margin-bottom:6px;">💬 Teacher notes (${list.length})</div>
                  <ul style="list-style:none; padding:0; margin:0;">${items}</ul>
              </div>
          `;
      };
      const studentSections = students.map((student, sidx) => {
          const notebookEntries = (student.history || []).filter(h => h && (h.type === 'note-taking' || h.type === 'anchor-chart'));
          const entriesHtml = notebookEntries.map((item) => {
              try {
                  const body = generateResourceHTML ? generateResourceHTML(item, true, student.responses || {}) : '';
                  const comments = renderCommentsBlock(student.id, item.id);
                  return body + comments;
              } catch (_) { return ''; }
          }).filter(Boolean).join('<hr style="margin:30px 0; border:0; border-top:1px dashed #cbd5e1;" />');
          // Count any teacher comments on this student for the header badge
          const commentCount = notebookEntries.reduce((sum, item) => sum + getCommentsFor(student.id, item.id).length, 0);
          return `
              <div style="margin-bottom:40px; ${sidx > 0 ? 'page-break-before:always;' : ''}">
                  <h2 style="font-size:18px; font-weight:bold; color:#4f46e5; border-bottom:2px solid #c7d2fe; padding-bottom:6px; margin-bottom:16px;">
                      ${(student.studentNickname || 'Anonymous')} — Notebook (${notebookEntries.length} ${notebookEntries.length === 1 ? 'entry' : 'entries'})${commentCount > 0 ? ` <span style="font-size:11px; font-weight:normal; color:#92400e;">· ${commentCount} teacher note${commentCount === 1 ? '' : 's'}</span>` : ''}
                  </h2>
                  ${entriesHtml || '<p style="color:#64748b; font-style:italic;">No notebook entries.</p>'}
              </div>
          `;
      }).join('');
      const reportHtml = `
          <div style="font-family:Helvetica,sans-serif; padding:30px; color:#1e293b; font-size:11px; line-height:1.5;">
              <h1 style="font-size:20px; color:#4f46e5; border-bottom:2px solid #4f46e5; padding-bottom:8px; margin-bottom:4px;">Class Notebook Export</h1>
              <p style="font-size:11px; color:#64748b; margin-top:0;">${students.length} students · ${new Date().toLocaleDateString()} · Generated by AlloFlow</p>
              ${studentSections}
          </div>
      `;
      const container = document.createElement('div');
      container.style.position = 'absolute';
      container.style.left = '-9999px';
      container.style.top = '0';
      container.innerHTML = reportHtml;
      document.body.appendChild(container);
      try {
          await doc.html(container, {
              callback: (d) => { d.save(`class_notebooks_${new Date().toISOString().split('T')[0]}.pdf`); if (addToast) addToast(t('dashboard.bulk.notebooks_pdf_saved') || 'Class notebooks PDF saved.', 'success'); },
              x: 8, y: 8, width: 195,
              windowWidth: 800,
          });
      } catch (err) {
          if (addToast) addToast('PDF error: ' + err.message, 'error');
      }
      document.body.removeChild(container);
  };
  const handleBulkGenerateFeedback = async () => {
      const students = getCurrentFilteredStudents().filter(s => (s.history || []).some(h => h && h.type === 'note-taking'));
      if (students.length === 0) {
          if (addToast) addToast(t('dashboard.bulk.no_notebook_students') || 'No students with note-taking entries in the current filter.', 'info');
          return;
      }
      if (typeof callGemini !== 'function') {
          if (addToast) addToast(t('dashboard.bulk.no_ai') || 'AI is not available.', 'warning');
          return;
      }
      if (addToast) addToast((t('dashboard.bulk.generating_feedback', { count: students.length }) || `Generating feedback messages for ${students.length} student${students.length === 1 ? '' : 's'}...`), 'info');
      // Generate one teacher-facing summary feedback per student. Strengths-first
      // framing per the existing per-instance pattern. Output goes into a PDF
      // bundle so the teacher can print + hand back individual sheets.
      const results = [];
      for (const student of students) {
          const notes = (student.history || []).filter(h => h && h.type === 'note-taking').slice(0, 3);
          const sample = notes.map(n => {
              const d = n.data || {};
              const tt = d.templateType || 'cornell-notes';
              return `${tt}: ${JSON.stringify(d).slice(0, 600)}`;
          }).join('\n---\n');
          const prompt = `
You are a teacher writing a short hand-back feedback note to ONE student about their note-taking work this week. Lead with one specific strength (quote their work). Then ONE concrete growth nudge. Keep it under 80 words total. Warm, direct, growth-focused. No grades or numbers.

STUDENT WORK SAMPLE:
${sample}

Return ONLY the feedback text (no JSON, no headers, just the paragraph).
`.trim();
          try {
              const txt = await callGemini(prompt, false);
              results.push({ name: student.studentNickname || 'Anonymous', feedback: (txt || '').trim() });
          } catch (e) {
              results.push({ name: student.studentNickname || 'Anonymous', feedback: '(could not generate)' });
          }
      }
      if (!window.jspdf) {
          if (addToast) addToast('PDF library not loaded.', 'error');
          return;
      }
      const { jsPDF } = window.jspdf;
      const doc = new jsPDF();
      const sections = results.map((r, i) => `
          <div style="margin-bottom:30px; padding:15px; background:#fffbeb; border-left:4px solid #f59e0b; ${i > 0 && i % 3 === 0 ? 'page-break-before:always;' : ''}">
              <div style="font-size:13px; font-weight:bold; color:#92400e; margin-bottom:6px;">📨 ${r.name}</div>
              <div style="font-size:11px; color:#1e293b; line-height:1.5;">${(r.feedback || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\n/g,'<br/>')}</div>
          </div>
      `).join('');
      const reportHtml = `
          <div style="font-family:Helvetica,sans-serif; padding:30px; color:#1e293b; font-size:11px;">
              <h1 style="font-size:18px; color:#4f46e5; margin-bottom:4px;">Class Feedback Sheets</h1>
              <p style="font-size:10px; color:#64748b;">Cut along the dashed lines and hand back to each student. ${new Date().toLocaleDateString()}</p>
              ${sections}
          </div>
      `;
      const container = document.createElement('div');
      container.style.position = 'absolute';
      container.style.left = '-9999px';
      container.style.top = '0';
      container.innerHTML = reportHtml;
      document.body.appendChild(container);
      try {
          await doc.html(container, {
              callback: (d) => { d.save(`class_feedback_${new Date().toISOString().split('T')[0]}.pdf`); if (addToast) addToast((t('dashboard.bulk.feedback_pdf_saved') || 'Feedback PDF saved.'), 'success'); },
              x: 8, y: 8, width: 195,
              windowWidth: 800,
          });
      } catch (err) {
          if (addToast) addToast('PDF error: ' + err.message, 'error');
      }
      document.body.removeChild(container);
  };
  const calculateScore = (history) => {
      if (!history || !Array.isArray(history)) return t('dashboard.status.zero_activities');
      let quizCount = 0;
      history.forEach(item => {
          if (item.type === 'quiz') {
              quizCount++;
          }
      });
      if (quizCount === 0) return t('dashboard.status.no_quizzes');
      return quizCount === 1
        ? t('dashboard.status.quizzes_completed', { count: quizCount })
        : t('dashboard.status.quizzes_completed_plural', { count: quizCount });
  };
  const getStudentLevel = (history) => {
      if (!history || !Array.isArray(history)) return "N/A";
      const adventureItem = history.slice().reverse().find(item => item.type === 'adventure');
      const adventureLevel = adventureItem && adventureItem.data ? Number(adventureItem.data.snapshot?.level ?? adventureItem.data.level) : NaN;
      if (Number.isFinite(adventureLevel) && adventureLevel > 0) return adventureLevel;
      return "N/A";
  };
  const getClassMetrics = () => {
      const count = dashboardData.length;
      let totalLevels = 0;
      let studentsWithLevel = 0;
      dashboardData.forEach(s => {
          const lvl = getStudentLevel(s.history);
          if (lvl !== "N/A") {
              totalLevels += Number(lvl);
              studentsWithLevel++;
          }
      });
      const avgLevel = studentsWithLevel > 0 ? (totalLevels / studentsWithLevel).toFixed(1) : "-";
      return { count, avgLevel };
  };
  const { count: studentCount, avgLevel: classAvgLevel } = getClassMetrics();
  const analytics = useMemo(() => calculateAnalyticsMetrics(dashboardData), [dashboardData]);
  const misconceptionChartData = useMemo(() => analytics.misconceptions.map((m, idx) => ({
      label: `Q${idx + 1}`,
      value: m.count
  })), [analytics.misconceptions]);
  const selectedStudent = useMemo(() => dashboardData.find(s => s.id === selectedStudentId), [dashboardData, selectedStudentId]);
  const getStudentAvgScore = (student) => {
      if (!student) return 0;
      const history = student.history || [];
      const responses = student.responses || {};
      const quizzes = history.filter(h => h.type === 'quiz');
      if (quizzes.length === 0) return 0;
      let totalPct = 0;
      quizzes.forEach(quiz => {
          const questions = quiz.data?.questions || [];
          if (!questions.length) return;
          let correct = 0;
          questions.forEach((q, i) => {
              const resp = responses[quiz.id]?.[i];
              if (resp !== undefined) {
                   let val = resp;
                   if (!isNaN(parseInt(resp)) && q.options && q.options[resp]) val = q.options[resp];
                   if (String(val).trim().toLowerCase() === String(q.correctAnswer).trim().toLowerCase()) correct++;
              }
          });
          totalPct += (correct / questions.length) * 100;
      });
      return Math.round(totalPct / quizzes.length);
  };
  const studentAvg = selectedStudent ? getStudentAvgScore(selectedStudent) : 0;
  const handleClearAll = (event) => {
      clearConfirmTriggerRef.current = event?.currentTarget || document.activeElement;
      setShowClearConfirm(true);
  };
  const confirmClearAll = () => {
      setDashboardData([]);
      setGradedIds(new Set());
      closeClearConfirm();
      if (addToast) addToast(t('dashboard.toasts.dashboard_cleared'), "info");
  };
  const handleExportResearchPDF = async () => {
    addToast('Generating research report...', 'info');
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    const date = new Date().toLocaleDateString();
    // Compute TAM data
    const allSurveys = dashboardData.flatMap(s => s.surveyResponses || []);
    const tamConstructs = { usefulness: [], ease: [], intention: [] };
    allSurveys.forEach(r => {
        if (r.construct === 'usefulness' && r.score !== undefined) tamConstructs.usefulness.push(r.score);
        if (r.construct === 'ease' && r.score !== undefined) tamConstructs.ease.push(r.score);
        if (r.construct === 'intention' && r.score !== undefined) tamConstructs.intention.push(r.score);
    });
    const calcStats = arr => {
        if (!arr.length) return { n: 0, mean: 'N/A', sd: 'N/A' };
        const mean = arr.reduce((s, v) => s + v, 0) / arr.length;
        const sd = Math.sqrt(arr.reduce((s, v) => s + (v - mean) ** 2, 0) / Math.max(1, arr.length - 1));
        return { n: arr.length, mean: mean.toFixed(2), sd: sd.toFixed(2) };
    };
    const useStats = calcStats(tamConstructs.usefulness);
    const easeStats = calcStats(tamConstructs.ease);
    const intStats = calcStats(tamConstructs.intention);
    // Compute probe data
    const allProbes = dashboardData.flatMap(s => s.probeHistory ? Object.values(s.probeHistory).flat() : []);
    const wcpmProbes = allProbes.filter(p => p.wcpm !== undefined);
    const dcpmProbes = allProbes.filter(p => p.dcpm !== undefined);
    const accProbes = allProbes.filter(p => p.accuracy !== undefined);
    const wcpmStats = calcStats(wcpmProbes.map(p => p.wcpm));
    const dcpmStats = calcStats(dcpmProbes.map(p => p.dcpm));
    const accStats = calcStats(accProbes.map(p => p.accuracy));
    // Session data
    const totalSessions = dashboardData.reduce((s, st) => s + (st.sessionCounter || 0), 0);
    const totalFidelity = dashboardData.reduce((s, st) => s + (st.fidelityLog ? st.fidelityLog.length : 0), 0);
    const reportHtml = `
        <div style="font-family: 'Times New Roman', serif; padding: 40px; color: #333; max-width: 800px; margin: 0 auto;">
            <h1 style="text-align: center; font-size: 18px; font-weight: bold; margin-bottom: 5px;">${t('teacher.research.report_title') || 'AlloFlow UDL Platform — Research Data Report'}</h1>
            <p style="text-align: center; font-size: 12px; color: #666; margin-bottom: 30px;">Generated: ${date} | N = ${dashboardData.length} students</p>
            <hr style="border: 1px solid #333; margin-bottom: 25px;">
            <h2 style="font-size: 14px; font-weight: bold; margin-bottom: 10px;">${t('teacher.research.table1_heading') || 'Table 1. TAM Survey Construct Descriptives'}</h2>
            <table style="width: 100%; border-collapse: collapse; font-size: 12px; margin-bottom: 25px;">
                <thead>
                    <tr style="border-bottom: 2px solid #333; border-top: 2px solid #333;">
                        <th scope="col" style="text-align: left; padding: 6px 8px;">${t('research.construct')}</th>
                        <th scope="col" style="text-align: center; padding: 6px 8px;">n</th>
                        <th scope="col" style="text-align: center; padding: 6px 8px;">M</th>
                        <th scope="col" style="text-align: center; padding: 6px 8px;">SD</th>
                        <th scope="col" style="text-align: center; padding: 6px 8px;">${t('research.scale')}</th>
                    </tr>
                </thead>
                <tbody>
                    <tr style="border-bottom: 1px solid #ddd;">
                        <td style="padding: 6px 8px;">${t('research.perceived_usefulness')}</td>
                        <td style="text-align: center; padding: 6px 8px;">${useStats.n}</td>
                        <td style="text-align: center; padding: 6px 8px;">${useStats.mean}</td>
                        <td style="text-align: center; padding: 6px 8px;">${useStats.sd}</td>
                        <td style="text-align: center; padding: 6px 8px;">1–5</td>
                    </tr>
                    <tr style="border-bottom: 1px solid #ddd;">
                        <td style="padding: 6px 8px;">${t('research.perceived_ease')}</td>
                        <td style="text-align: center; padding: 6px 8px;">${easeStats.n}</td>
                        <td style="text-align: center; padding: 6px 8px;">${easeStats.mean}</td>
                        <td style="text-align: center; padding: 6px 8px;">${easeStats.sd}</td>
                        <td style="text-align: center; padding: 6px 8px;">1–5</td>
                    </tr>
                    <tr style="border-bottom: 2px solid #333;">
                        <td style="padding: 6px 8px;">${t('research.behavioral_intention')}</td>
                        <td style="text-align: center; padding: 6px 8px;">${intStats.n}</td>
                        <td style="text-align: center; padding: 6px 8px;">${intStats.mean}</td>
                        <td style="text-align: center; padding: 6px 8px;">${intStats.sd}</td>
                        <td style="text-align: center; padding: 6px 8px;">1–5</td>
                    </tr>
                </tbody>
            </table>
            <h2 style="font-size: 14px; font-weight: bold; margin-bottom: 10px;">${t('teacher.research.table2_heading') || 'Table 2. Oral Reading Fluency Probe Descriptives'}</h2>
            <table style="width: 100%; border-collapse: collapse; font-size: 12px; margin-bottom: 25px;">
                <thead>
                    <tr style="border-bottom: 2px solid #333; border-top: 2px solid #333;">
                        <th scope="col" style="text-align: left; padding: 6px 8px;">${t('research.measure')}</th>
                        <th scope="col" style="text-align: center; padding: 6px 8px;">n</th>
                        <th scope="col" style="text-align: center; padding: 6px 8px;">M</th>
                        <th scope="col" style="text-align: center; padding: 6px 8px;">SD</th>
                    </tr>
                </thead>
                <tbody>
                    <tr style="border-bottom: 1px solid #ddd;">
                        <td style="padding: 6px 8px;">${t('teacher.research.measure_wcpm') || 'Words Correct Per Minute (WCPM)'}</td>
                        <td style="text-align: center; padding: 6px 8px;">${wcpmStats.n}</td>
                        <td style="text-align: center; padding: 6px 8px;">${wcpmStats.mean}</td>
                        <td style="text-align: center; padding: 6px 8px;">${wcpmStats.sd}</td>
                    </tr>
                    <tr style="border-bottom: 1px solid #ddd;">
                        <td style="padding: 6px 8px;">${t('teacher.research.measure_dcpm') || 'Digits Correct Per Minute (DCPM)'}</td>
                        <td style="text-align: center; padding: 6px 8px;">${dcpmStats.n}</td>
                        <td style="text-align: center; padding: 6px 8px;">${dcpmStats.mean}</td>
                        <td style="text-align: center; padding: 6px 8px;">${dcpmStats.sd}</td>
                    </tr>
                    <tr style="border-bottom: 2px solid #333;">
                        <td style="padding: 6px 8px;">${t('teacher.research.measure_accuracy_pct') || 'Accuracy (%)'}</td>
                        <td style="text-align: center; padding: 6px 8px;">${accStats.n}</td>
                        <td style="text-align: center; padding: 6px 8px;">${accStats.mean}</td>
                        <td style="text-align: center; padding: 6px 8px;">${accStats.sd}</td>
                    </tr>
                </tbody>
            </table>
            <h2 style="font-size: 14px; font-weight: bold; margin-bottom: 10px;">${t('teacher.research.table3_heading') || 'Table 3. Implementation Fidelity Summary'}</h2>
            <table style="width: 100%; border-collapse: collapse; font-size: 12px; margin-bottom: 25px;">
                <thead>
                    <tr style="border-bottom: 2px solid #333; border-top: 2px solid #333;">
                        <th scope="col" style="text-align: left; padding: 6px 8px;">${t('research.metric')}</th>
                        <th scope="col" style="text-align: center; padding: 6px 8px;">${t('research.value')}</th>
                    </tr>
                </thead>
                <tbody>
                    <tr style="border-bottom: 1px solid #ddd;"><td style="padding: 6px 8px;">${t('class_analytics.total_students')}</td><td style="text-align: center; padding: 6px 8px;">${dashboardData.length}</td></tr>
                    <tr style="border-bottom: 1px solid #ddd;"><td style="padding: 6px 8px;">${t('class_analytics.total_sessions')}</td><td style="text-align: center; padding: 6px 8px;">${totalSessions}</td></tr>
                    <tr style="border-bottom: 1px solid #ddd;"><td style="padding: 6px 8px;">${t('research.avg_sessions')}</td><td style="text-align: center; padding: 6px 8px;">${dashboardData.length > 0 ? (totalSessions / dashboardData.length).toFixed(1) : 0}</td></tr>
                    <tr style="border-bottom: 1px solid #ddd;"><td style="padding: 6px 8px;">${t('research.fidelity_records')}</td><td style="text-align: center; padding: 6px 8px;">${totalFidelity}</td></tr>
                    <tr style="border-bottom: 2px solid #333;"><td style="padding: 6px 8px;">${t('research.total_probes')}</td><td style="text-align: center; padding: 6px 8px;">${allProbes.length}</td></tr>
                </tbody>
            </table>
            <div style="page-break-before: always;"></div>
            <h2 style="font-size: 16px; font-weight: bold; margin-top: 30px; margin-bottom: 15px; border-bottom: 2px solid #333; padding-bottom: 5px;">${t('teacher.research.appendix_a_heading') || 'Appendix A: Individual Student Data'}</h2>
            ${dashboardData.filter(s => {
                                          if (studentFilter === 'probes') return s.probeHistory && Object.keys(s.probeHistory).length > 0;
                                          if (studentFilter === 'surveys') return s.surveyResponses && s.surveyResponses.length > 0;
                                          if (studentFilter === 'notebook') return (s.history || []).some(h => h && (h.type === 'note-taking' || h.type === 'anchor-chart'));
                                          if (studentFilter === 'graded') return gradedIds.has(s.id);
                                          if (studentFilter === 'ungraded') return !gradedIds.has(s.id);
                                          return true;
                                      }).map((student, idx) => {
                const sProbes = student.probeHistory ? Object.values(student.probeHistory).flat() : [];
                const sSurveys = student.surveyResponses || [];
                const sQuizzes = (student.history || []).filter(h => h.type === "quiz");
                const sExplore = (student.history || []).filter(h => h.type === "explore-challenge");
                const sSessions = student.sessionCounter || 0;
                const sProbeWcpm = sProbes.filter(p => p.wcpm !== undefined);
                const avgWcpm = sProbeWcpm.length > 0 ? (sProbeWcpm.reduce((s,p) => s + p.wcpm, 0) / sProbeWcpm.length).toFixed(1) : "N/A";
                // Notebook activity (note-taking templates + anchor charts)
                const sNotes = (student.history || []).filter(h => h.type === "note-taking");
                const sAnchorCharts = (student.history || []).filter(h => h.type === "anchor-chart");
                const sNotebookFeedback = sNotes.reduce((sum, e) => sum + ((e.data && e.data.feedbackCount) || 0), 0);
                return `
                <div style="margin-bottom: 20px; padding: 15px; border: 1px solid #ddd; border-radius: 4px; ${idx > 0 ? "page-break-before: auto;" : ""}">
                    <h3 style="font-size: 13px; font-weight: bold; margin-bottom: 8px; color: #333;">Student ${idx + 1}: ${student.studentNickname}</h3>
                    <table style="width: 100%; border-collapse: collapse; font-size: 11px; margin-bottom: 10px;">
                        <tr style="border-bottom: 1px solid #eee;">
                            <td style="padding: 4px 6px; color: #666; width: 40%;">${t('research.sessions_completed')}</td>
                            <td style="padding: 4px 6px; font-weight: bold;">${sSessions}</td>
                        </tr>
                        <tr style="border-bottom: 1px solid #eee;">
                            <td style="padding: 4px 6px; color: #666;">${t('research.quiz_responses')}</td>
                            <td style="padding: 4px 6px; font-weight: bold;">${sQuizzes.length}</td>
                        </tr>
                        <tr style="border-bottom: 1px solid #eee;">
                            <td style="padding: 4px 6px; color: #666;">${t('research.probes_administered')}</td>
                            <td style="padding: 4px 6px; font-weight: bold;">${sProbes.length} (Avg WCPM: ${avgWcpm})</td>
                        </tr>
                        <tr style="border-bottom: 1px solid #eee;">
                            <td style="padding: 4px 6px; color: #666;">${t('research.survey_responses')}</td>
                            <td style="padding: 4px 6px; font-weight: bold;">${sSurveys.length}</td>
                        </tr>
                        <tr style="border-bottom: 1px solid #eee;">
                            <td style="padding: 4px 6px; color: #666;">${t('research.explore_challenges')}</td>
                            <td style="padding: 4px 6px; font-weight: bold;">${sExplore.length}</td>
                        </tr>
                        ${(sNotes.length + sAnchorCharts.length) > 0 ? `
                        <tr style="border-bottom: 1px solid #eee;">
                            <td style="padding: 4px 6px; color: #666;">Notebook Activity (notes + charts)</td>
                            <td style="padding: 4px 6px; font-weight: bold;">${sNotes.length + sAnchorCharts.length}</td>
                        </tr>
                        ${sNotebookFeedback > 0 ? `
                        <tr style="border-bottom: 1px solid #eee;">
                            <td style="padding: 4px 6px; color: #666;">AI feedback requests on notes</td>
                            <td style="padding: 4px 6px; font-weight: bold;">${sNotebookFeedback}</td>
                        </tr>
                        ` : ''}
                        ` : ''}
                    </table>
                    ${sProbeWcpm.length > 0 ? `
                    <p style="font-size: 10px; font-weight: bold; color: #555; margin-bottom: 4px;">${t('teacher.research.probe_history_wcpm_label') || 'Probe History (WCPM):'}</p>
                    <div style="display: flex; gap: 4px; flex-wrap: wrap; margin-bottom: 8px;">
                        ${sProbeWcpm.map(p => `<span style="font-size: 9px; padding: 2px 6px; border-radius: 3px; background: ${p.wcpm >= 100 ? "#d1fae5" : p.wcpm >= 60 ? "#fef3c7" : "#fee2e2"}; color: ${p.wcpm >= 100 ? "#065f46" : p.wcpm >= 60 ? "#92400e" : "#991b1b"}; font-weight: bold;">${p.wcpm}${p.date ? " (" + new Date(p.date).toLocaleDateString("en", {month: "short", day: "numeric"}) + ")" : ""}</span>`).join("")}
                    </div>
                    ` : ""}
                    ${sQuizzes.length > 0 ? `
                    <p style="font-size: 10px; font-weight: bold; color: #555; margin-bottom: 4px;">${t('teacher.research.quiz_scores_label') || 'Quiz Scores:'}</p>
                    <div style="display: flex; gap: 4px; flex-wrap: wrap; margin-bottom: 8px;">
                        ${sQuizzes.map(q => `<span style="font-size: 9px; padding: 2px 6px; border-radius: 3px; background: #ede9fe; color: #5b21b6; font-weight: bold;">${q.score !== undefined ? q.score : "—"}${q.label ? " " + q.label : ""}</span>`).join("")}
                    </div>
                    ` : ""}
                    ${sSurveys.length > 0 ? `
                    <p style="font-size: 10px; font-weight: bold; color: #555; margin-bottom: 4px;">${t('teacher.research.survey_responses_label') || 'Survey Responses:'}</p>
                    <div style="display: flex; gap: 4px; flex-wrap: wrap;">
                        ${sSurveys.map(s => `<span style="font-size: 9px; padding: 2px 6px; border-radius: 3px; background: #fce7f3; color: #9d174d; font-weight: bold;">${s.construct || "—"}: ${s.score !== undefined ? s.score + "/5" : "—"}</span>`).join("")}
                    </div>
                    ` : ""}
                </div>
                `;
            }).join("")}
                        <div style="margin-top: 40px; font-size: 10px; color: #999; text-align: center; border-top: 1px solid #eee; padding-top: 15px;">
                <p><em>Note.</em> TAM = Technology Acceptance Model (Davis, 1989). WCPM = Words Correct Per Minute. DCPM = Digits Correct Per Minute.</p>
                <p>${t('teacher.research.export_footer') || 'Generated by AlloFlow UDL Platform — Research Export Module'}</p>
            </div>
        </div>
    `;
    const container = document.createElement('div');
    container.style.position = 'absolute';
    container.style.left = '-9999px';
    container.style.top = '0';
    container.innerHTML = reportHtml;
    document.body.appendChild(container);
    try {
        await doc.html(container, {
            callback: (doc) => {
                doc.save('alloflow_research_report_' + new Date().toISOString().split('T')[0] + '.pdf');
                addToast('Research report saved!', 'success');
            },
            x: 10, y: 10, width: 190,
            windowWidth: 800,
        });
    } catch (err) { addToast('PDF error: ' + err.message, 'error'); }
    document.body.removeChild(container);
  };
  const handleExportAnalyticsPDF = async () => {
      addToast(t('dashboard.toasts.generating_report'), "info");
      const { jsPDF } = window.jspdf;
      const doc = new jsPDF();
      const date = new Date().toLocaleDateString();
      const reportHtml = `
        <div style="font-family: Helvetica, sans-serif; padding: 40px; color: #333;">
            <h1 style="color: #4f46e5; border-bottom: 2px solid #ddd; padding-bottom: 10px;">${t('dashboard.report.title')}</h1>
            <p style="color: #666; margin-bottom: 30px;">${t('dashboard.insights.generated_date')} ${date}</p>
            <div style="display: flex; gap: 20px; margin-bottom: 40px;">
                <div style="flex: 1; padding: 20px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; text-align: center;">
                    <div style="font-size: 12px; font-weight: bold; text-transform: uppercase; color: #64748b;">${t('dashboard.report.avg_score')}</div>
                    <div style="font-size: 32px; font-weight: bold; color: #4f46e5;">${analytics.averageScore}%</div>
                </div>
                <div style="flex: 1; padding: 20px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; text-align: center;">
                    <div style="font-size: 12px; font-weight: bold; text-transform: uppercase; color: #64748b;">${t('dashboard.report.participation')}</div>
                    <div style="font-size: 32px; font-weight: bold; color: #0ea5e9;">${Math.round(analytics.quizCompletionRate)}%</div>
                </div>
                <div style="flex: 1; padding: 20px; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; text-align: center;">
                    <div style="font-size: 12px; font-weight: bold; text-transform: uppercase; color: #64748b;">${t('dashboard.report.avg_level')}</div>
                    <div style="font-size: 32px; font-weight: bold; color: #9333ea;">${analytics.avgAdventureLevel.toFixed(1)}</div>
                </div>
            </div>
            <h2 style="color: #1e293b; margin-bottom: 20px;">${t('dashboard.report.misconceptions')}</h2>
            ${analytics.misconceptions.length > 0 ? `
                <ul style="list-style: none; padding: 0;">
                    ${analytics.misconceptions.map((m, i) => `
                        <li style="margin-bottom: 15px; padding: 15px; background: #fef2f2; border-left: 4px solid #ef4444; border-radius: 4px;">
                            <div style="font-weight: bold; color: #991b1b; margin-bottom: 5px;">${t('dashboard.report.question_focus')}:</div>
                            <div style="font-style: italic; color: #333; margin-bottom: 10px;">"${m.question}"</div>
                            <div style="font-size: 12px; font-weight: bold; color: #ef4444;">${t('dashboard.report.students_missed', { count: m.count })}</div>
                        </li>
                    `).join('')}
                </ul>
            ` : `<p style="font-style: italic; color: #666;">${t('dashboard.insights.no_misconceptions')}</p>`}
            <h2 style="color: #1e293b; margin-top: 40px; margin-bottom: 20px;">📊 Research & Assessment Data</h2>
            <div style="display: flex; gap: 20px; margin-bottom: 20px;">
                <div style="flex: 1; padding: 20px; background: #fffbeb; border: 1px solid #fed7aa; border-radius: 8px; text-align: center;">
                    <div style="font-size: 12px; font-weight: bold; text-transform: uppercase; color: #92400e;">${t('class_analytics.total_probes')}</div>
                    <div style="font-size: 32px; font-weight: bold; color: #d97706;">${dashboardData.reduce((sum, s) => sum + (s.probeHistory ? Object.values(s.probeHistory).flat().length : 0), 0)}</div>
                </div>
                <div style="flex: 1; padding: 20px; background: #f5f3ff; border: 1px solid #e9d5ff; border-radius: 8px; text-align: center;">
                    <div style="font-size: 12px; font-weight: bold; text-transform: uppercase; color: #6b21a8;">${t('research.survey_responses')}</div>
                    <div style="font-size: 32px; font-weight: bold; color: #9333ea;">${dashboardData.reduce((sum, s) => sum + (s.surveyResponses ? s.surveyResponses.length : 0), 0)}</div>
                </div>
                <div style="flex: 1; padding: 20px; background: #ecfdf5; border: 1px solid #bbf7d0; border-radius: 8px; text-align: center;">
                    <div style="font-size: 12px; font-weight: bold; text-transform: uppercase; color: #065f46;">${t('class_analytics.total_sessions')}</div>
                    <div style="font-size: 32px; font-weight: bold; color: #059669;">${dashboardData.reduce((sum, s) => sum + (s.sessionCounter || 0), 0)}</div>
                </div>
            </div>
            <div style="margin-top: 50px; font-size: 10px; color: #999; text-align: center; border-top: 1px solid #eee; padding-top: 20px;">
                ${t('dashboard.report.footer')}
            </div>
        </div>
      `;
      const container = document.createElement('div');
      container.style.position = 'absolute';
      container.style.left = '-9999px';
      container.style.top = '0';
      container.style.width = '595px';
      container.innerHTML = reportHtml;
      document.body.appendChild(container);
      try {
          await doc.html(container, {
              callback: function(pdf) {
                  pdf.save('Class_Analytics_Report.pdf');
                  document.body.removeChild(container);
                  addToast(t('dashboard.toasts.report_downloaded'), "success");
              },
              x: 10,
              y: 10,
              width: 190,
              windowWidth: 650
          });
      } catch (e) {
          warnLog("PDF Export Error", e);
          addToast(t('toasts.export_failed'), "error");
          if (document.body.contains(container)) document.body.removeChild(container);
      }
  };
  const handleBatchUpload = async (e) => {
    const files = Array.from(e.target.files);
    if (files.length === 0) return;
    const promises = files.map(file => new Promise((resolve) => {
        const reader = new FileReader();
        reader.onload = (ev) => {
            try {
                const parsed = JSON.parse(ev.target.result);
                if (parsed && parsed.mode === 'student' && Array.isArray(parsed.history)) {
                    const validSubmission = {
                        id: generateUUID(),
                        ...parsed,
                        studentNickname: parsed.studentNickname || parsed.settings?.nickname || "Anonymous",
                        timestamp: parsed.timestamp || new Date().toISOString(),
                        sourceFilename: file.name
                    };
                    resolve(validSubmission);
                } else {
                    warnLog("Skipping invalid file (not a student save):", file.name);
                    resolve(null);
                }
            } catch (err) {
                warnLog("Failed to parse file:", file.name);
                resolve(null);
            }
        };
        reader.onerror = () => {
            warnLog("Error reading file:", file.name);
            resolve(null);
        };
        reader.readAsText(file);
    }));
    const results = await Promise.all(promises);
    const validSubmissions = results.filter(item => item !== null);
    if (validSubmissions.length > 0 && setDashboardData) {
        setDashboardData(prev => [...prev, ...validSubmissions]);
        if (addToast) addToast(t('dashboard.toasts.submissions_loaded', { count: validSubmissions.length }), "success");
    } else if (files.length > 0) {
        if (addToast) addToast(t('dashboard.toasts.no_files'), "error");
    }
    e.target.value = "";
  };
  const handleExportCSV = () => {
    if (!dashboardData || dashboardData.length === 0) return;
    // Registry-driven per-tool count columns. Auto-extends when new tools
    // get registered (incl. externally-registered tools via window.AlloModules
    // .TeacherMetricRegistry.push()) — no manual column-list updates needed.
    const registryHeaders = getTeacherMetricRegistry().map(e => e.label);
    const headers = [
        t('dashboard.csv.header_name'),
        t('dashboard.csv.header_date'),
        t('dashboard.csv.header_level'),
        t('dashboard.csv.header_quiz_avg'),
        t('dashboard.csv.header_total_xp')
    , 'Probes', 'Avg WCPM', 'Surveys', 'Sessions', 'Cornell Notes', 'Lab Reports', 'Reading Responses', 'Double-Entry Journals', 'Guided Notes', 'Q&A Study Notes', 'Anchor Charts', 'Notebook Feedback Requests', ...registryHeaders];
    const rows = dashboardData.map(student => {
        const name = (student.studentNickname || "Anonymous").replace(/"/g, '""');
        const date = new Date(student.timestamp).toLocaleDateString();
        const adventureItem = student.history.slice().reverse().find(item => item.type === 'adventure');
        const adventureLevel = adventureItem && adventureItem.data ? Number(adventureItem.data.snapshot?.level ?? adventureItem.data.level) : NaN;
        const level = Number.isFinite(adventureLevel) && adventureLevel > 0 ? adventureLevel : "N/A";
        let totalQuizScore = 0;
        let quizCount = 0;
        const quizzes = student.history.filter(h => h.type === 'quiz');
        quizzes.forEach(quiz => {
            const questions = quiz.data?.questions || [];
            if (questions.length === 0) return;
            let correct = 0;
            const studentResps = student.responses && student.responses[quiz.id] ? student.responses[quiz.id] : {};
            questions.forEach((q, i) => {
                const resp = studentResps[i];
                if (resp !== undefined && resp !== null) {
                    let val = resp;
                    if (!isNaN(parseInt(resp)) && q.options && q.options[resp]) val = q.options[resp];
                    if (String(val).trim().toLowerCase() === String(q.correctAnswer).trim().toLowerCase()) correct++;
                }
            });
            const score = (correct / questions.length) * 100;
            totalQuizScore += score;
            quizCount++;
        });
        const quizAvg = quizCount > 0 ? Math.round(totalQuizScore / quizCount) + "%" : "N/A";
        const xp = student.stats?.totalXP || "N/A";
        const probeCount = student.probeHistory ? Object.values(student.probeHistory).flat().length : 0;
        const wcpmProbes = student.probeHistory ? Object.values(student.probeHistory).flat().filter(x => x && x.wcpm !== undefined) : [];
        const avgWcpm = wcpmProbes.length > 0 ? (wcpmProbes.reduce((sum,x) => sum + x.wcpm, 0) / wcpmProbes.length).toFixed(0) : 'N/A';
        const surveyCount = student.surveyResponses ? student.surveyResponses.length : 0;
        const sessionCount = student.sessionCounter || 0;
        // Notebook activity columns
        const hist = student.history || [];
        const noteEntries = hist.filter(h => h && h.type === 'note-taking');
        const cornellCount = noteEntries.filter(e => (e.data && e.data.templateType) === 'cornell-notes').length;
        const labCount = noteEntries.filter(e => (e.data && e.data.templateType) === 'lab-report').length;
        const readingCount = noteEntries.filter(e => (e.data && e.data.templateType) === 'reading-response').length;
        const doubleEntryCount = noteEntries.filter(e => (e.data && e.data.templateType) === 'double-entry').length;
        const guidedCount = noteEntries.filter(e => (e.data && e.data.templateType) === 'guided-notes').length;
        const qAndACount = noteEntries.filter(e => (e.data && e.data.templateType) === 'q-and-a').length;
        const anchorCount = hist.filter(h => h && h.type === 'anchor-chart').length;
        const feedbackCount = noteEntries.reduce((sum, e) => sum + ((e.data && e.data.feedbackCount) || 0), 0);
        // Registry-driven per-tool counts (extends with each new registry entry,
        // including externally-registered tools)
        const registryCounts = getTeacherMetricRegistry().map(entry => entry.count(student));
        return `"${name}","${date}","${level}","${quizAvg}","${xp}","${probeCount}","${avgWcpm}","${surveyCount}","${sessionCount}","${cornellCount}","${labCount}","${readingCount}","${doubleEntryCount}","${guidedCount}","${qAndACount}","${anchorCount}","${feedbackCount}",${registryCounts.map(n => `"${n}"`).join(',')}`;
    });
    const csvContent = [headers.join(","), ...rows].join("\n");
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", `${t('dashboard.csv.filename_prefix')}${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  const quizHistory = useMemo(() => selectedStudent?.history?.filter(h => h.type === 'quiz') || [], [selectedStudent?.history]);
  return (
    <div
        className="fixed inset-0 z-[200] bg-slate-100 flex flex-col animate-in motion-reduce:animate-none fade-in duration-300"
        ref={modalRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby="teacher-grading-dashboard-title"
    >
      <div className="bg-white/80 backdrop-blur-md border-b border-slate-200 shadow-sm shrink-0 z-10 flex flex-col">
          <div className="p-3 sm:p-4 flex flex-wrap justify-between items-center gap-2">
            <div className="flex items-center gap-2 sm:gap-3 min-w-0">
                <div className="bg-indigo-100 p-2 rounded-lg text-indigo-600 shrink-0">
                    <Layout size={24} />
                </div>
                <h2 id="teacher-grading-dashboard-title" className="text-base sm:text-xl font-black text-slate-800 truncate">{t('dashboard.grading_dashboard')}</h2>
            </div>
            <div className="flex items-center gap-1 sm:gap-2 flex-wrap">
                {dashboardData.length > 0 && (<>
                    <button type="button"
                        onClick={handleExportCSV} data-help-key="dashboard_export_csv_btn"
                        className="text-xs font-bold text-green-800 hover:text-green-800 hover:bg-green-50 px-2 sm:px-3 py-1.5 rounded-full transition-colors motion-reduce:transition-none border border-green-200 shadow-sm flex items-center gap-1"
                        title={t('dashboard.export_csv_tooltip')}
                        aria-label={t('dashboard.export_csv_tooltip')}
                    >
                        <FileDown size={14} /> <span className="hidden sm:inline">{t('dashboard.export_csv')}</span><span className="sm:hidden">CSV</span>
                    </button>
                    <button type="button"
                        onClick={handleExportResearchPDF} data-help-key="dashboard_export_research_btn"
                        className="text-xs font-bold text-purple-800 hover:text-purple-800 hover:bg-purple-50 px-2 sm:px-3 py-1.5 rounded-full transition-colors motion-reduce:transition-none border border-purple-200 shadow-sm flex items-center gap-1"
                        title={t('research.export_apa_title')}
                        aria-label={t('teacher.research.export_btn_aria') || 'Export Research Report'}
                    >
                        <FileDown size={14} /> <span className="hidden sm:inline">📊 Research PDF</span><span className="sm:hidden">📊 PDF</span>
                    </button>
                </>)}
                {dashboardData.length > 0 && (
                    <button type="button"
                        onClick={handleClearAll} data-help-key="dashboard_clear_all_btn"
                        className="text-xs font-bold text-red-500 hover:text-red-700 hover:bg-red-50 px-2 sm:px-3 py-1.5 rounded-full transition-colors motion-reduce:transition-none border border-transparent hover:border-red-100"
                        title={t('dashboard.reset_tooltip')}
                        aria-label={t('dashboard.reset_tooltip')}
                    >
                        <span className="hidden sm:inline">{t('dashboard.clear_all')}</span><span className="sm:hidden">Clear</span>
                    </button>
                )}
                <button type="button"
                onClick={onClose}
                className="p-2 rounded-full text-slate-600 hover:bg-slate-100 focus:bg-slate-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors motion-reduce:transition-none shrink-0"
                autoFocus
                aria-label={t('common.close_dashboard')}
                >
                <X size={24} />
                </button>
            </div>
          </div>
          {dashboardData.length > 0 && dashboardView === 'list' && (
              <div role="tablist" aria-label={t('dashboard.sections') || 'Dashboard sections'} className="flex px-3 sm:px-6 gap-4 sm:gap-6 overflow-x-auto whitespace-nowrap">
                  <button type="button" ref={element => { dashboardTabRefs.current.students = element; }} role="tab" id="teacher-dashboard-tab-students" aria-selected={activeTab === 'students'} aria-controls="teacher-dashboard-panel-students" tabIndex={activeTab === 'students' ? 0 : -1} onKeyDown={event => handleDashboardTabKeyDown(event, 'students')}
                      onClick={() => setActiveTab('students')}
                      className={`pb-3 text-sm font-bold border-b-2 transition-all motion-reduce:transition-none shrink-0 ${activeTab === 'students' ? 'border-indigo-600 text-indigo-700' : 'border-transparent text-slate-600 hover:text-slate-700'}`}
                  >
                      {t('dashboard.tab_students')} ({dashboardData.length})
                  </button>
                  <button type="button" ref={element => { dashboardTabRefs.current.insights = element; }} role="tab" id="teacher-dashboard-tab-insights" aria-selected={activeTab === 'insights'} aria-controls="teacher-dashboard-panel-insights" tabIndex={activeTab === 'insights' ? 0 : -1} onKeyDown={event => handleDashboardTabKeyDown(event, 'insights')}
                      onClick={() => setActiveTab('insights')}
                      className={`pb-3 text-sm font-bold border-b-2 transition-all motion-reduce:transition-none shrink-0 ${activeTab === 'insights' ? 'border-indigo-600 text-indigo-700' : 'border-transparent text-slate-600 hover:text-slate-700'}`}
                  >
                      {t('dashboard.tab_insights')}
                  </button>
                  <button type="button" ref={element => { dashboardTabRefs.current.behavior = element; }} role="tab" id="teacher-dashboard-tab-behavior" aria-selected={activeTab === 'behavior'} aria-controls="teacher-dashboard-panel-behavior" tabIndex={activeTab === 'behavior' ? 0 : -1} onKeyDown={event => handleDashboardTabKeyDown(event, 'behavior')}
                      onClick={() => setActiveTab('behavior')}
                      className={`pb-3 text-sm font-bold border-b-2 transition-all motion-reduce:transition-none shrink-0 ${activeTab === 'behavior' ? 'border-orange-600 text-orange-700' : 'border-transparent text-slate-600 hover:text-slate-700'}`}
                  >
                      🔍 {t('behavior_lens.hub.title') || 'Behavior'}
                  </button>
                  <button type="button" ref={element => { dashboardTabRefs.current.stems = element; }} role="tab" id="teacher-dashboard-tab-stems" aria-selected={activeTab === 'stems'} aria-controls="teacher-dashboard-panel-stems" tabIndex={activeTab === 'stems' ? 0 : -1} onKeyDown={event => handleDashboardTabKeyDown(event, 'stems')}
                      onClick={() => setActiveTab('stems')}
                      className={`pb-3 text-sm font-bold border-b-2 transition-all motion-reduce:transition-none shrink-0 ${activeTab === 'stems' ? 'border-emerald-600 text-emerald-700' : 'border-transparent text-slate-600 hover:text-slate-700'}`}
                  >
                      🔬 STEM Stations
                  </button>
              </div>
          )}
      </div>
      <div className="flex-grow p-6 overflow-y-auto bg-slate-100">
         {dashboardView === 'detail' && selectedStudent ? (
             <div className="max-w-5xl mx-auto h-full flex flex-col animate-in motion-reduce:animate-none slide-in-from-right-8 duration-300">
                 <div className="flex flex-wrap items-center justify-between gap-3 sm:gap-6 mb-6 border-b border-slate-200 pb-4 sm:pb-6 sticky top-0 bg-slate-50 z-10 pt-2">
                     <div className="flex items-center gap-3 sm:gap-6 min-w-0 flex-1">
                         <button type="button"
                             aria-label={t('dashboard.back_button') || 'Back'}
                            onClick={() => setDashboardView('list')}
                            className="flex items-center gap-1 sm:gap-2 px-3 sm:px-4 py-2 bg-white text-slate-600 font-bold rounded-full shadow-sm border border-slate-400 hover:bg-slate-50 transition-colors motion-reduce:transition-none shrink-0 text-xs sm:text-sm"
                         >
                             <ArrowDown className="rotate-90" size={16}/> <span className="hidden sm:inline">{t('dashboard.back_button')}</span>
                         </button>
                         <div className="min-w-0 flex-1">
                             <h2 className="text-xl sm:text-3xl font-black text-slate-800 flex items-center gap-2 sm:gap-3 min-w-0">
                                <div className="relative shrink-0">
                                    <div className="w-9 h-9 sm:w-12 sm:h-12 rounded-full bg-indigo-600 text-white flex items-center justify-center text-base sm:text-xl shadow-md border-2 sm:border-4 border-indigo-100">
                                        {selectedStudent.studentNickname.charAt(0).toUpperCase()}
                                    </div>
                                    {gradedIds.has(selectedStudent.id) && (
                                        <div className="absolute -bottom-1 -right-1 bg-green-700 text-white rounded-full p-0.5 border-2 border-white shadow-sm">
                                            <CheckCircle2 size={12} />
                                        </div>
                                    )}
                                </div>
                                <span className="truncate">{selectedStudent.studentNickname}</span>
                             </h2>
                             <div className="flex items-center gap-3 mt-2 flex-wrap">
                                 <p className="text-xs text-slate-600 font-mono bg-slate-100 px-2 py-1 rounded border border-slate-400">
                                    {new Date(selectedStudent.timestamp).toLocaleString()}
                                 </p>
                                 <div className="h-4 w-px bg-slate-300 hidden sm:block"></div>
                                 <span className="text-xs font-bold bg-purple-100 text-purple-700 px-3 py-1 rounded-full border border-purple-200 flex items-center gap-1">
                                    <MapIcon size={12} /> {t('dashboard.detail.adventure_badge', { level: getStudentLevel(selectedStudent.history) })}
                                 </span>
                                 <span className="text-xs font-bold bg-green-100 text-green-700 px-3 py-1 rounded-full border border-green-200 flex items-center gap-1">
                                    <CheckSquare size={12} /> {t('dashboard.detail.quiz_badge', { count: quizHistory.length })}
                                 </span>
                                 {selectedStudent.probeHistory && Object.keys(selectedStudent.probeHistory).length > 0 && (
                                     <span className="text-xs font-bold bg-amber-100 text-amber-700 px-3 py-1 rounded-full border border-amber-200 flex items-center gap-1">
                                         📊 {Object.values(selectedStudent.probeHistory).flat().length} Probes
                                     </span>
                                 )}
                                 {selectedStudent.surveyResponses && selectedStudent.surveyResponses.length > 0 && (
                                     <span className="text-xs font-bold bg-purple-100 text-purple-700 px-3 py-1 rounded-full border border-purple-200 flex items-center gap-1">
                                         📝 {selectedStudent.surveyResponses.length} Surveys
                                     </span>
                                 )}
                             </div>
                         </div>
                     </div>
                     <label className={`flex items-center gap-2 cursor-pointer px-4 py-2 rounded-full border-2 transition-all motion-reduce:transition-none select-none shadow-sm ${gradedIds.has(selectedStudent.id) ? 'bg-green-50 border-green-500 text-green-800' : 'bg-white border-slate-200 text-slate-600 hover:border-indigo-300'}`}>
                        <input aria-label={t('common.text_field')}
                            type="checkbox"
                            className="hidden"
                            checked={gradedIds.has(selectedStudent.id)}
                            onChange={() => toggleGraded(selectedStudent.id)}
                        />
                        {gradedIds.has(selectedStudent.id) ? <CheckCircle2 size={18} className="fill-green-500 text-white"/> : <div className="w-4 h-4 rounded-full border-2 border-slate-300"></div>}
                        <span className="font-bold text-sm">{gradedIds.has(selectedStudent.id) ? t('dashboard.table.graded') : t('dashboard.table.mark_graded')}</span>
                     </label>
                 </div>
                 {selectedStudent.progressLog && (
                     <LongitudinalProgressChart logs={selectedStudent.progressLog} />
                 )}
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6 mt-6">
                    <div className="bg-white p-6 rounded-xl border border-slate-400 shadow-sm">
                        <h4 className="text-xs font-bold text-slate-600 uppercase tracking-wider mb-4">{t('dashboard.charts.student_vs_class')}</h4>
                        <div className="flex items-center gap-6">
                            <div className="w-1/2">
                                <SimpleBarChart
                                    data={[
                                        { label: t('dashboard.charts.student_avg'), value: studentAvg },
                                        { label: t('dashboard.charts.class_avg'), value: analytics.averageScore }
                                    ]}
                                    color={studentAvg >= analytics.averageScore ? "green" : "orange"}
                                />
                            </div>
                            <div className="w-1/2 flex flex-col justify-center gap-2">
                                <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 text-center">
                                    <div className="text-2xl font-black text-indigo-900">{studentAvg}%</div>
                                    <div className="text-[11px] font-bold text-slate-600 uppercase">{t('dashboard.charts.student_avg')}</div>
                                </div>
                                <div className="p-3 bg-slate-50 rounded-lg border border-slate-100 text-center">
                                    <div className="text-xl font-bold text-slate-600">{analytics.averageScore}%</div>
                                    <div className="text-[11px] font-bold text-slate-600 uppercase">{t('dashboard.charts.class_avg')}</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="bg-white p-6 rounded-xl border border-slate-400 shadow-sm flex flex-col justify-center">
                        <h4 className="text-xs font-bold text-slate-600 uppercase tracking-wider mb-2">{t('dashboard.charts.quiz_participation')}</h4>
                        <div className="flex items-end gap-2">
                            <span className="text-4xl font-black text-slate-800">{quizHistory.length}</span>
                            <span className="text-sm font-medium text-slate-600 mb-1">{t('dashboard.charts.quizzes_taken')}</span>
                        </div>
                    </div>
                 </div>
                 <AllToolActivityPanel student={selectedStudent} t={t} />
                 {(selectedStudent.probeHistory || selectedStudent.interventionLogs || selectedStudent.surveyResponses || selectedStudent.fluencyAssessments) && (
                     <div className="bg-white p-4 sm:p-6 rounded-xl border border-slate-400 shadow-sm mb-6 mt-6">
                         <h4 className="text-xs font-bold text-slate-600 uppercase tracking-wider mb-4 flex items-center gap-2">
                             📊 Assessment & Research Data
                         </h4>
                         <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4">
                             {selectedStudent.probeHistory && Object.keys(selectedStudent.probeHistory).length > 0 && (
                                 <div className="bg-amber-50 rounded-xl p-4 border border-amber-200">
                                     <div className="text-2xl font-black text-amber-700">{Object.values(selectedStudent.probeHistory).flat().length}</div>
                                     <div className="text-[11px] font-bold text-amber-600 uppercase mt-1">{t('probes.probe_results')}</div>
                                     <div className="text-[11px] text-slate-600 mt-2">
                                         {Object.keys(selectedStudent.probeHistory).map(name => (
                                             <div key={name} className="flex justify-between">
                                                 <span>{name}</span>
                                                 <span className="font-bold">{selectedStudent.probeHistory[name].length} probes</span>
                                             </div>
                                         ))}
                                     </div>
                                 </div>
                             )}
                             {selectedStudent.interventionLogs && selectedStudent.interventionLogs.length > 0 && (
                                 <div className="bg-blue-50 rounded-xl p-4 border border-blue-200">
                                     <div className="text-2xl font-black text-blue-700">{selectedStudent.interventionLogs.length}</div>
                                     <div className="text-[11px] font-bold text-blue-600 uppercase mt-1">{t('research.intervention_logs')}</div>
                                 </div>
                             )}
                             {selectedStudent.surveyResponses && selectedStudent.surveyResponses.length > 0 && (
                                 <div className="bg-purple-50 rounded-xl p-4 border border-purple-200">
                                     <div className="text-2xl font-black text-purple-700">{selectedStudent.surveyResponses.length}</div>
                                     <div className="text-[11px] font-bold text-purple-600 uppercase mt-1">{t('research.survey_responses')}</div>
                                     <div className="text-[11px] text-slate-600 mt-2">
                                         {selectedStudent.surveyResponses.slice(-1).map((r, i) => (
                                             <div key={i}>Latest: {r.type || 'survey'} ({new Date(r.timestamp || Date.now()).toLocaleDateString()})</div>
                                         ))}
                                     </div>
                                 </div>
                             )}
                             {selectedStudent.sessionCounter !== undefined && (
                                 <div className="bg-emerald-50 rounded-xl p-4 border border-emerald-200">
                                     <div className="text-2xl font-black text-emerald-700">{selectedStudent.sessionCounter}</div>
                                     <div className="text-[11px] font-bold text-emerald-600 uppercase mt-1">{t('research.sessions_completed')}</div>
                                     {selectedStudent.fidelityLog && selectedStudent.fidelityLog.length > 0 && (
                                         <div className="text-[11px] text-slate-600 mt-2">{selectedStudent.fidelityLog.length} fidelity records</div>
                                     )}
                                 </div>
                             )}
                             {(() => {
                                 // Notebook activity tile: counts of Cornell / Lab / Reading / Anchor Chart
                                 // entries, plus AI-feedback request count rolled up across all entries.
                                 const hist = selectedStudent.history || [];
                                 const noteEntries = hist.filter(h => h && h.type === 'note-taking');
                                 const anchorEntries = hist.filter(h => h && h.type === 'anchor-chart');
                                 const totalNotebook = noteEntries.length + anchorEntries.length;
                                 if (totalNotebook === 0) return null;
                                 const byType = {
                                     'cornell-notes': noteEntries.filter(e => (e.data && e.data.templateType) === 'cornell-notes').length,
                                     'lab-report': noteEntries.filter(e => (e.data && e.data.templateType) === 'lab-report').length,
                                     'reading-response': noteEntries.filter(e => (e.data && e.data.templateType) === 'reading-response').length,
                                     'double-entry': noteEntries.filter(e => (e.data && e.data.templateType) === 'double-entry').length,
                                     'guided-notes': noteEntries.filter(e => (e.data && e.data.templateType) === 'guided-notes').length,
                                     'q-and-a': noteEntries.filter(e => (e.data && e.data.templateType) === 'q-and-a').length,
                                     'anchor-chart': anchorEntries.length,
                                 };
                                 const feedbackEvents = noteEntries.reduce((sum, e) => sum + ((e.data && e.data.feedbackCount) || 0), 0);
                                 return (
                                     <div className="bg-violet-50 rounded-xl p-4 border border-violet-200" data-help-key="dashboard_notebook_activity_tile">
                                         <div className="text-2xl font-black text-violet-700">{totalNotebook}</div>
                                         <div className="text-[11px] font-bold text-violet-600 uppercase mt-1">{t('dashboard.notebook_activity') || 'Notebook Activity'}</div>
                                         <div className="text-[11px] text-slate-600 mt-2 space-y-0.5">
                                             {byType['cornell-notes'] > 0 && <div className="flex justify-between"><span>📓 Cornell</span><span className="font-bold">{byType['cornell-notes']}</span></div>}
                                             {byType['lab-report'] > 0 && <div className="flex justify-between"><span>🧪 Lab Report</span><span className="font-bold">{byType['lab-report']}</span></div>}
                                             {byType['reading-response'] > 0 && <div className="flex justify-between"><span>📖 Reading</span><span className="font-bold">{byType['reading-response']}</span></div>}
                                             {byType['double-entry'] > 0 && <div className="flex justify-between"><span>✍️ Double-Entry</span><span className="font-bold">{byType['double-entry']}</span></div>}
                                             {byType['guided-notes'] > 0 && <div className="flex justify-between"><span>📝 Guided Notes</span><span className="font-bold">{byType['guided-notes']}</span></div>}
                                             {byType['q-and-a'] > 0 && <div className="flex justify-between"><span>❓ Q&amp;A</span><span className="font-bold">{byType['q-and-a']}</span></div>}
                                             {byType['anchor-chart'] > 0 && <div className="flex justify-between"><span>📋 Anchor Chart</span><span className="font-bold">{byType['anchor-chart']}</span></div>}
                                             {feedbackEvents > 0 && <div className="flex justify-between text-violet-700 font-semibold pt-1 mt-1 border-t border-violet-200"><span>💬 AI feedback</span><span>{feedbackEvents}×</span></div>}
                                         </div>
                                     </div>
                                 );
                             })()}
                         </div>
                         {selectedStudent.probeHistory && Object.keys(selectedStudent.probeHistory).length > 0 && (
                             <div className="mt-4 space-y-2">
                                 <h5 className="text-[11px] font-bold text-slate-600 uppercase">{t('research.recent_probe_results')}</h5>
                                 <div className="space-y-1.5">
                                     {Object.entries(selectedStudent.probeHistory).flatMap(([name, probes]) =>
                                         probes.slice(-3).map((p, i) => (
                                             <div key={name + '-' + i} className="flex items-center justify-between bg-slate-50 rounded-lg px-3 py-2 border border-slate-100 text-xs">
                                                 <span className="font-bold text-slate-700">{name}</span>
                                                 <div className="flex items-center gap-3">
                                                     <span className="text-slate-600">{p.probeType || p.type || 'Probe'}</span>
                                                     {p.wcpm !== undefined && <span className="font-mono font-bold text-amber-700">{p.wcpm} WCPM</span>}
                                                     {p.dcpm !== undefined && <span className="font-mono font-bold text-amber-700">{p.dcpm} DCPM</span>}
                                                     {p.accuracy !== undefined && <span className="font-mono font-bold text-emerald-700">{Math.round(p.accuracy * 100)}%</span>}
                                                     {p.score !== undefined && <span className="font-mono font-bold text-indigo-700">{p.score}</span>}
                                                     <span className="text-slate-600">{new Date(p.timestamp || p.date || Date.now()).toLocaleDateString()}</span>
                                                 </div>
                                             </div>
                                         ))
                                     )}
                                 </div>
                             </div>
                         )}
                         {selectedStudent.externalCBMScores && Object.keys(selectedStudent.externalCBMScores).length > 0 && (
                             <div className="mt-4">
                                 <h5 className="text-[11px] font-bold text-slate-600 uppercase mb-2">{t('research.external_cbm_scores')}</h5>
                                 <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                                     {Object.entries(selectedStudent.externalCBMScores).map(([source, scores]) => (
                                         <div key={source} className="bg-slate-50 rounded-lg px-3 py-2 border border-slate-100">
                                             <div className="text-[11px] font-bold text-slate-600 uppercase">{source}</div>
                                             {Array.isArray(scores) ? scores.slice(-1).map((s, i) => (
                                                 <div key={i} className="text-sm font-bold text-slate-800">{s.score || s.value || JSON.stringify(s)}</div>
                                             )) : <div className="text-sm font-bold text-slate-800">{JSON.stringify(scores)}</div>}
                                         </div>
                                     ))}
                                 </div>
                             </div>
                         )}
                     </div>
                 )}
                 <div className="flex-grow overflow-y-auto custom-scrollbar space-y-6 pb-10">
                     {(selectedStudent.history || []).map((item, idx) => (
                        <div key={item.id || idx} className="bg-white p-6 rounded-xl border border-slate-400 shadow-sm hover:border-indigo-300 transition-colors motion-reduce:transition-none">
                            <div className="flex justify-between items-start mb-3">
                                <div>
                                    <h3 className="font-bold text-lg text-slate-800">{item.title || "Untitled Resource"}</h3>
                                    <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider bg-indigo-50 px-2 py-0.5 rounded border border-indigo-100">{item.type}</span>
                                </div>
                                <span className="text-xs text-slate-600 font-mono">
                                    {new Date(item.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                                </span>
                            </div>
                            {item.meta && (
                                <p className="text-sm text-slate-600 italic border-l-2 border-slate-200 pl-3 mb-4">
                                    {item.meta}
                                </p>
                            )}
                            <div className="bg-slate-50 rounded-lg p-4 border border-slate-100 overflow-x-auto">
                                <div
                                    className="prose prose-sm max-w-none text-slate-700 leading-relaxed"
                                    dangerouslySetInnerHTML={{
                                        __html: generateResourceHTML
                                            ? generateResourceHTML(item, true, selectedStudent.responses || {})
                                    : '<p>Error: Renderer not available.</p>',
                            }}
                        />
                    </div>
                    <TeacherCommentThread
                        studentId={selectedStudent.id}
                        resourceId={item.id}
                        comments={getCommentsFor(selectedStudent.id, item.id)}
                        onAdd={addComment}
                        onDelete={deleteComment}
                        t={t}
                    />
                </div>
                ))}
                {selectedStudent.history.length === 0 && (
                    <div className="text-center py-12 text-slate-600 italic">
                        {t('dashboard.empty.no_history')}
                    </div>
                )}
            </div>
        </div>
    ) : (
             <>
                 {dashboardData.length === 0 ? (
                     <div className="relative flex flex-col items-center justify-center h-full text-slate-600 gap-4 border-4 border-dashed border-slate-300 rounded-3xl hover:bg-slate-100 hover:border-indigo-300 hover:text-indigo-500 transition-all motion-reduce:transition-none cursor-pointer group min-h-[400px] bg-white">
                         <div className="bg-slate-50 p-6 rounded-full shadow-sm mb-2 group-hover:scale-110 transition-transform motion-reduce:transition-none">
                              <Upload size={48} className="text-slate-600 group-hover:text-indigo-500" />
                         </div>
                         <h3 className="text-2xl font-black text-slate-600 group-hover:text-indigo-700">{t('dashboard.drop_files')}</h3>
                         <p className="text-sm font-bold opacity-70 bg-slate-200 px-3 py-1 rounded-full group-hover:bg-indigo-100 group-hover:text-indigo-600 transition-colors motion-reduce:transition-none">{t('dashboard.batch_supported')}</p>
                         <input aria-label={t('common.upload_json_file')}
                            type="file"
                            multiple
                            accept=".json"
                            onChange={handleBatchUpload} data-help-key="dashboard_drop_zone_input"
                            className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                         />
                     </div>
                 ) : (
                    <>
                     {activeTab === 'students' && (
                     <div role="tabpanel" id="teacher-dashboard-panel-students" aria-labelledby="teacher-dashboard-tab-students" tabIndex={0} className="max-w-6xl mx-auto space-y-6 animate-in motion-reduce:animate-none fade-in slide-in-from-left-4 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                         <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                             <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-400 flex items-center gap-4">
                                 <div className="bg-blue-100 p-3 rounded-full text-blue-800"><Users size={24}/></div>
                                 <div>
                                     <div className="text-2xl font-black text-slate-800">{dashboardData.length}</div>
                                     <div className="text-xs font-bold text-slate-600 uppercase">{t('dashboard.stats.students_loaded')}</div>
                                 </div>
                             </div>
                             <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-400 flex items-center gap-4 relative group cursor-pointer hover:border-indigo-300 transition-colors motion-reduce:transition-none">
                                 <div className="bg-green-100 p-3 rounded-full text-green-800"><Upload size={24}/></div>
                                 <div>
                                     <div className="text-sm font-bold text-green-700">{t('dashboard.stats.add_files')}</div>
                                     <div className="text-xs text-slate-600">{t('dashboard.stats.click_upload')}</div>
                                 </div>
                                 <input aria-label={t('common.upload_json_file')}
                                    type="file"
                                    multiple
                                    accept=".json"
                                    onChange={handleBatchUpload} data-help-key="dashboard_add_file_btn_input" className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                                 />
                             </div>
                             <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-400 flex items-center gap-4 cursor-pointer hover:bg-red-50 transition-colors motion-reduce:transition-none" onClick={handleClearAll} role="button" tabIndex="0" aria-label={t('dashboard.stats.clear_dashboard')} onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && (e.preventDefault(), handleClearAll(e))}>
                                 <div className="bg-red-100 p-3 rounded-full text-red-800"><Trash2 size={24}/></div>
                                 <div>
                                     <div className="text-sm font-bold text-red-700">{t('dashboard.stats.clear_dashboard')}</div>
                                     <div className="text-xs text-slate-600">{t('dashboard.stats.clear_desc')}</div>
                                 </div>
                             </div>
                         </div>
                         {/* Bulk actions toolbar — operates on whichever students are currently visible (after the filter chip). */}
                         {(() => {
                             const filteredCount = getCurrentFilteredStudents().length;
                             const filteredNotebookCount = getCurrentFilteredStudents().filter(s => (s.history || []).some(h => h && h.type === 'note-taking')).length;
                             if (filteredCount === 0) return null;
                             return (
                                 <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap bg-slate-50 border border-slate-200 rounded-xl p-2" data-help-key="dashboard_bulk_actions_toolbar">
                                     <span className="text-[10px] sm:text-[11px] font-bold text-slate-600 uppercase tracking-wider pl-1 sm:pl-2 pr-1 w-full sm:w-auto">
                                         {t('dashboard.bulk.label') || 'Bulk actions'} ({filteredCount}):
                                     </span>
                                     <button type="button"
                                         onClick={handleBulkMarkGraded}
                                         className="text-xs font-bold text-green-700 bg-green-50 hover:bg-green-100 border border-green-300 px-2 sm:px-2.5 py-1 rounded-full transition-colors motion-reduce:transition-none"
                                         title={t('dashboard.bulk.mark_graded_tooltip') || 'Mark all currently-filtered students as graded'}
                                     ><span className="hidden sm:inline">✅ Mark all graded</span><span className="sm:hidden">✅ Mark</span></button>
                                     <button type="button"
                                         onClick={handleBulkUnmarkGraded}
                                         className="text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-300 px-2 sm:px-2.5 py-1 rounded-full transition-colors motion-reduce:transition-none"
                                         title={t('dashboard.bulk.unmark_graded_tooltip') || 'Clear graded flag on all currently-filtered students'}
                                     ><span className="hidden sm:inline">⬜ Clear graded</span><span className="sm:hidden">⬜ Clear</span></button>
                                     <button type="button"
                                         onClick={handleBulkExportNotebooksPDF}
                                         disabled={filteredNotebookCount === 0}
                                         className="text-xs font-bold text-violet-800 bg-violet-50 hover:bg-violet-100 border border-violet-300 px-2 sm:px-2.5 py-1 rounded-full transition-colors motion-reduce:transition-none disabled:opacity-40 disabled:cursor-not-allowed"
                                         title={filteredNotebookCount === 0 ? (t('dashboard.bulk.no_notebook_in_filter') || 'No filtered students have notebook entries') : (t('dashboard.bulk.export_notebooks_tooltip') || 'Export all filtered students\' notebooks as one PDF (cut-apart classroom set)')}
                                     ><span className="hidden sm:inline">📓 Export notebooks ({filteredNotebookCount})</span><span className="sm:hidden">📓 PDF ({filteredNotebookCount})</span></button>
                                     <button type="button"
                                         onClick={handleBulkGenerateFeedback}
                                         disabled={filteredNotebookCount === 0}
                                         className="text-xs font-bold text-amber-800 bg-amber-50 hover:bg-amber-100 border border-amber-300 px-2 sm:px-2.5 py-1 rounded-full transition-colors motion-reduce:transition-none disabled:opacity-40 disabled:cursor-not-allowed"
                                         title={filteredNotebookCount === 0 ? (t('dashboard.bulk.no_notebook_in_filter') || 'No filtered students have notebook entries') : (t('dashboard.bulk.feedback_tooltip') || 'AI generates one short feedback note per student, ready to print + hand back')}
                                     ><span className="hidden sm:inline">💬 AI feedback sheets ({filteredNotebookCount})</span><span className="sm:hidden">💬 AI ({filteredNotebookCount})</span></button>
                                 </div>
                             );
                         })()}
                         <div className="flex items-center gap-2 flex-wrap">
                             {[
                                 ["all", "👥 All", dashboardData.length],
                                 ["probes", "📊 Has Probes", dashboardData.filter(s => s.probeHistory && Object.keys(s.probeHistory).length > 0).length],
                                 ["surveys", "📝 Has Surveys", dashboardData.filter(s => s.surveyResponses && s.surveyResponses.length > 0).length],
                                 ["notebook", "📓 Has Notebook", dashboardData.filter(s => (s.history || []).some(h => h && (h.type === 'note-taking' || h.type === 'anchor-chart'))).length],
                                 ["graded", "✅ Graded", dashboardData.filter(s => gradedIds.has(s.id)).length],
                                 ["ungraded", "⬜ Ungraded", dashboardData.filter(s => !gradedIds.has(s.id)).length],
                             ].map(([key, label, count]) => (
                                 <button type="button" key={key} onClick={() => setStudentFilter(key)}
                                     className={"text-xs font-bold px-3 py-1.5 rounded-full transition-all motion-reduce:transition-none border " + (studentFilter === key ? "bg-indigo-600 text-white border-indigo-600 shadow-sm" : "bg-white text-slate-600 border-slate-200 hover:border-indigo-300 hover:bg-indigo-50")}
                                 >{label} ({count})</button>
                             ))}
                         </div>
                         <div className="bg-white rounded-2xl shadow-sm border border-slate-400 overflow-x-auto">
                             <table className="w-full text-left text-sm text-slate-600 min-w-[600px]">
                                 <thead className="bg-slate-50 text-xs uppercase font-bold text-slate-600">
                                     <tr>
                                         <th scope="col" className="p-4">{t('dashboard.header_nickname')}</th>
                                         <th scope="col" className="p-4">{t('dashboard.header_date')}</th>
                                         <th scope="col" className="p-4">{t('dashboard.header_progress')}</th>
                                         <th scope="col" className="p-4">{t('dashboard.header_level')}</th>
                                         <th scope="col" className="p-4 text-right">{t('dashboard.header_actions')}</th>
                                     </tr>
                                 </thead>
                                 <tbody className="divide-y divide-slate-100">
                                     {dashboardData.map((student, idx) => {
                                         const level = getStudentLevel(student.history);
                                         const isGraded = gradedIds.has(student.id);
                                         return (
                                             <tr key={idx} className={`hover:bg-slate-50 transition-colors motion-reduce:transition-none ${isGraded ? 'bg-green-50/30' : ''}`}>
                                                 <td className="p-4 font-bold text-indigo-900 flex items-center gap-2">
                                                     <div className="relative">
                                                         <div className="w-8 h-8 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center text-xs">
                                                             {student.studentNickname.charAt(0).toUpperCase()}
                                                         </div>
                                                         {isGraded && (
                                                             <div className="absolute -bottom-1 -right-1 bg-green-700 text-white rounded-full p-0.5 border border-white shadow-sm">
                                                                 <CheckCircle2 size={8} />
                                                             </div>
                                                         )}
                                                     </div>
                                                     {student.studentNickname}
                                                     {isGraded && <span className="text-[11px] font-bold text-green-700 bg-green-100 px-1.5 py-0.5 rounded ml-2 uppercase tracking-wider">{t('dashboard.table.graded')}</span>}
                                                 
                                                      {student.probeHistory && Object.keys(student.probeHistory).length > 0 && <span className="text-[11px] font-bold text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded ml-1 border border-amber-200" title={Object.values(student.probeHistory).flat().length + ' probes'}>📊</span>}
                                                      {student.surveyResponses && student.surveyResponses.length > 0 && <span className="text-[11px] font-bold text-purple-700 bg-purple-50 px-1.5 py-0.5 rounded ml-1 border border-purple-200" title={student.surveyResponses.length + ' surveys'}>📝</span>}
                                                      {student.sessionCounter > 0 && <span className="text-[11px] font-bold text-cyan-700 bg-cyan-50 px-1.5 py-0.5 rounded ml-1 border border-cyan-200" title={student.sessionCounter + ' sessions'}>🔄</span>}
                                                      {(() => {
                                                          const noteCount = (student.history || []).filter(h => h && (h.type === 'note-taking' || h.type === 'anchor-chart')).length;
                                                          return noteCount > 0 ? <span className="text-[11px] font-bold text-violet-700 bg-violet-50 px-1.5 py-0.5 rounded ml-1 border border-violet-200" title={noteCount + ' notebook entries (notes + anchor charts)'}>📓</span> : null;
                                                      })()}
                                                      {(() => {
                                                          // Count teacher comments across all this student's resources
                                                          const commentCount = Array.from(teacherComments.keys()).filter(k => k.startsWith(`${student.id}:`)).reduce((sum, k) => sum + (teacherComments.get(k) || []).length, 0);
                                                          return commentCount > 0 ? <span className="text-[11px] font-bold text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded ml-1 border border-amber-200" title={commentCount + ' private teacher notes on this student\'s work'}>💬</span> : null;
                                                      })()}
                                                  </td>
                                                 <td className="p-4 text-slate-600 font-mono text-xs">
                                                     {new Date(student.timestamp).toLocaleDateString()} <span className="hidden sm:inline">{new Date(student.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                                                 </td>
                                                 <td className="p-4">
                                                     <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full font-bold border border-green-200">
                                                         {calculateScore(student.history)}
                                                     </span>
                                                 </td>
                                                 <td className="p-4">
                                                     {level !== "N/A" ? (
                                                         <span className="bg-purple-100 text-purple-800 text-xs px-2 py-1 rounded-full font-bold border border-purple-200 flex items-center gap-1 w-fit">
                                                             <MapIcon size={10} /> Lvl {level}
                                                         </span>
                                                     ) : (
                                                         <span className="text-slate-600 text-xs">-</span>
                                                     )}
                                                 </td>
                                                 <td className="p-4 text-right">
                                                     <button type="button"
                                                        onClick={() => {
                                                            setSelectedStudentId(student.id);
                                                            setDashboardView('detail');
                                                        }} data-help-key="dashboard_review_btn"
                                                        className="text-indigo-600 hover:text-indigo-800 font-bold text-xs px-3 py-1 rounded-lg hover:bg-indigo-50 border border-transparent hover:border-indigo-200 transition-all motion-reduce:transition-none"
                                                     >
                                                         {t('dashboard.table.review_work')}
                                                     </button>
                                                 </td>
                                             </tr>
                                         );
                                     })}
                                 </tbody>
                             </table>
                         </div>
                     </div>
                     )}
                     {activeTab === 'insights' && (
                         <div role="tabpanel" id="teacher-dashboard-panel-insights" aria-labelledby="teacher-dashboard-tab-insights" tabIndex={0} className="max-w-6xl mx-auto space-y-6 animate-in motion-reduce:animate-none fade-in slide-in-from-right-4 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                            <div className="flex justify-between items-center bg-white p-4 rounded-xl shadow-sm border border-slate-400">
                                <div>
                                    <h3 className="font-bold text-lg text-slate-800">{t('dashboard.insights.class_performance')}</h3>
                                    <p className="text-xs text-slate-600">{t('dashboard.insights.generated_date')} {new Date().toLocaleDateString()}</p>
                                </div>
                                <button type="button"
                                    onClick={handleExportAnalyticsPDF} data-help-key="dashboard_export_pdf_btn"
                                    className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-xs font-bold transition-colors motion-reduce:transition-none shadow-sm"
                                >
                                    <FileDown size={14} /> {t('dashboard.insights.export_report')}
                                </button>
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-400 flex flex-col items-center">
                                    <h3 className="text-sm font-bold text-slate-600 uppercase tracking-wider mb-4">{t('dashboard.insights.avg_score')}</h3>
                                    <SimpleDonutChart
                                        percentage={analytics.averageScore}
                                        label={`${analytics.averageScore}%`}
                                        color={analytics.averageScore >= 80 ? "green" : analytics.averageScore >= 60 ? "yellow" : "red"}
                                    />
                                </div>
                                <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-400 flex flex-col items-center">
                                    <h3 className="text-sm font-bold text-slate-600 uppercase tracking-wider mb-4">{t('dashboard.insights.quiz_completion')}</h3>
                                    <SimpleDonutChart
                                        percentage={analytics.quizCompletionRate}
                                        label={`${Math.round(analytics.quizCompletionRate)}%`}
                                        color="blue"
                                    />
                                    <p className="text-xs text-slate-600 mt-2 text-center">{t('dashboard.insights.students_participating')}</p>
                                </div>
                                <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-400 flex flex-col justify-center">
                                    <h3 className="text-sm font-bold text-slate-600 uppercase tracking-wider mb-2">{t('dashboard.insights.avg_adv_level')}</h3>
                                    <div className="text-5xl font-black text-purple-600 text-center mb-2">{analytics.avgAdventureLevel.toFixed(1)}</div>
                                    <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                                        <div className="bg-purple-500 h-full" style={{ width: `${Math.min(100, (analytics.avgAdventureLevel / 10) * 100)}%` }}></div>
                                    </div>
                                    <p className="text-xs text-slate-600 mt-2 text-center">{t('dashboard.insights.adv_level_desc')}</p>
                                </div>
                            </div>
                            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-400">
                                <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
                                    <AlertCircle size={20} className="text-red-500"/> {t('dashboard.insights.misconceptions_title')}
                                </h3>
                                {misconceptionChartData.length > 0 ? (
                                    <div className="flex flex-col md:flex-row gap-8 items-center">
                                        <div className="flex-1 w-full">
                                            <SimpleBarChart data={misconceptionChartData} color="red" />
                                        </div>
                                        <div className="flex-1 w-full">
                                            <ul className="space-y-3">
                                                {analytics.misconceptions.map((m, i) => (
                                                    <li key={i} className="text-sm bg-red-50 p-3 rounded-lg border border-red-100">
                                                        <div className="font-bold text-red-800 mb-1 flex justify-between">
                                                            <span>Question {i+1}</span>
                                                            <span className="bg-white px-2 rounded text-red-600 border border-red-200">{m.count} {t('dashboard.insights.misses')}</span>
                                                        </div>
                                                        <p className="text-slate-600 italic line-clamp-2">"{m.question}"</p>
                                                    </li>
                                                ))}
                                            </ul>
                                        </div>
                                    </div>
                                ) : (
                                    <div className="text-center py-10 text-slate-600 italic">
                                        {t('dashboard.insights.no_misconceptions')}
                                    </div>
                                )}
                            </div>
                            {/* Cross-tool misconception / completion-gap detection (non-quiz tools) */}
                            <CrossToolMisconceptionsSection dashboardData={dashboardData} t={t} />

                            {/* Class Notebook Activity — note-taking + anchor-chart aggregated across roster */}
                            <ClassNotebookSection dashboardData={dashboardData} callGemini={callGemini} addToast={addToast} t={t} />

                            {/* Research & Assessment Analytics */}
                            {(() => {
                                const allProbes = dashboardData.flatMap(s => 
                                    s.probeHistory ? Object.values(s.probeHistory).flat() : []
                                );
                                const allSurveys = dashboardData.flatMap(s => s.surveyResponses || []);
                                const totalSessions = dashboardData.reduce((sum, s) => sum + (s.sessionCounter || 0), 0);
                                const studentsWithProbes = dashboardData.filter(s => s.probeHistory && Object.keys(s.probeHistory).length > 0).length;
                                const studentsWithSurveys = dashboardData.filter(s => s.surveyResponses && s.surveyResponses.length > 0).length;
                                
                                if (allProbes.length === 0 && allSurveys.length === 0 && totalSessions === 0) return null;
                                
                                return React.createElement('div', { className: 'space-y-6' },
                                    React.createElement('h3', { className: 'text-lg font-bold text-slate-800 flex items-center gap-2 mt-4' },
                                        t('dashboard.insights.research_analytics')),
                                    
                                    allProbes.length > 0 && React.createElement('div', { className: 'bg-white p-6 rounded-2xl shadow-sm border border-slate-400' },
                                        React.createElement('h4', { className: 'text-sm font-bold text-amber-700 uppercase tracking-wider mb-4 flex items-center gap-2' },
                                            t('dashboard.insights.probe_summary')),
                                        React.createElement('div', { className: 'grid grid-cols-2 md:grid-cols-4 gap-4' },
                                            React.createElement('div', { className: 'bg-amber-50 rounded-xl p-4 text-center border border-amber-100' },
                                                React.createElement('div', { className: 'text-3xl font-black text-amber-700' }, allProbes.length),
                                                React.createElement('div', { className: 'text-[11px] font-bold text-amber-500 uppercase mt-1' }, t('dashboard.insights.total_probes'))),
                                            React.createElement('div', { className: 'bg-amber-50 rounded-xl p-4 text-center border border-amber-100' },
                                                React.createElement('div', { className: 'text-3xl font-black text-amber-700' }, studentsWithProbes),
                                                React.createElement('div', { className: 'text-[11px] font-bold text-amber-500 uppercase mt-1' }, t('dashboard.insights.students_assessed'))),
                                            (() => {
                                                const wcpmProbes = allProbes.filter(p => p.wcpm !== undefined);
                                                if (wcpmProbes.length === 0) return null;
                                                const avgWcpm = Math.round(wcpmProbes.reduce((s,p) => s + p.wcpm, 0) / wcpmProbes.length);
                                                return React.createElement('div', { className: 'bg-amber-50 rounded-xl p-4 text-center border border-amber-100' },
                                                    React.createElement('div', { className: 'text-3xl font-black text-amber-700' }, avgWcpm),
                                                    React.createElement('div', { className: 'text-[11px] font-bold text-amber-500 uppercase mt-1' }, t('dashboard.insights.avg_wcpm')));
                                            })(),
                                            (() => {
                                                const dcpmProbes = allProbes.filter(p => p.dcpm !== undefined);
                                                if (dcpmProbes.length === 0) return null;
                                                const avgDcpm = Math.round(dcpmProbes.reduce((s,p) => s + p.dcpm, 0) / dcpmProbes.length);
                                                return React.createElement('div', { className: 'bg-amber-50 rounded-xl p-4 text-center border border-amber-100' },
                                                    React.createElement('div', { className: 'text-3xl font-black text-amber-700' }, avgDcpm),
                                                    React.createElement('div', { className: 'text-[11px] font-bold text-amber-500 uppercase mt-1' }, t('dashboard.insights.avg_dcpm')));
                                            })(),
                                            (() => {
                                                const accProbes = allProbes.filter(p => p.accuracy !== undefined);
                                                if (accProbes.length === 0) return null;
                                                const avgAcc = Math.round(accProbes.reduce((s,p) => s + p.accuracy, 0) / accProbes.length * 100);
                                                return React.createElement('div', { className: 'bg-amber-50 rounded-xl p-4 text-center border border-amber-100' },
                                                    React.createElement('div', { className: 'text-3xl font-black text-amber-700' }, avgAcc + '%'),
                                                    React.createElement('div', { className: 'text-[11px] font-bold text-amber-500 uppercase mt-1' }, t('dashboard.insights.avg_accuracy')));
                                            })()
                                        )
                                    ),
                                    
                                    allSurveys.length > 0 && React.createElement('div', { className: 'bg-white p-6 rounded-2xl shadow-sm border border-slate-400' },
                                        React.createElement('h4', { className: 'text-sm font-bold text-purple-700 uppercase tracking-wider mb-4 flex items-center gap-2' },
                                            t('dashboard.insights.tam_survey_analysis')),
                                        React.createElement('div', { className: 'grid grid-cols-2 md:grid-cols-4 gap-4 mb-4' },
                                            React.createElement('div', { className: 'bg-purple-50 rounded-xl p-4 text-center border border-purple-100' },
                                                React.createElement('div', { className: 'text-3xl font-black text-purple-700' }, allSurveys.length),
                                                React.createElement('div', { className: 'text-[11px] font-bold text-purple-500 uppercase mt-1' }, t('dashboard.insights.total_responses'))),
                                            React.createElement('div', { className: 'bg-purple-50 rounded-xl p-4 text-center border border-purple-100' },
                                                React.createElement('div', { className: 'text-3xl font-black text-purple-700' }, studentsWithSurveys),
                                                React.createElement('div', { className: 'text-[11px] font-bold text-purple-500 uppercase mt-1' }, t('dashboard.insights.respondents')))
                                        ),
                                        (() => {
                                            const tamIds = ['perceived_usefulness', 'ease_of_use', 'intention'];
                                            const tamLabels = { perceived_usefulness: t('dashboard.insights.perceived_usefulness'), ease_of_use: t('dashboard.insights.ease_of_use'), intention: t('dashboard.insights.behavioral_intention') };
                                            const tamColors = { perceived_usefulness: 'text-blue-700', ease_of_use: 'text-green-700', intention: 'text-indigo-700' };
                                            const tamBgs = { perceived_usefulness: 'bg-blue-50 border-blue-100', ease_of_use: 'bg-green-50 border-green-100', intention: 'bg-indigo-50 border-indigo-100' };
                                            const constructs = tamIds.map(id => {
                                                const scores = allSurveys.filter(s => s.answers && s.answers[id] !== undefined).map(s => s.answers[id]);
                                                if (scores.length === 0) return null;
                                                const avg = (scores.reduce((a,b) => a+b, 0) / scores.length).toFixed(1);
                                                return { id, label: tamLabels[id], avg, n: scores.length, color: tamColors[id], bg: tamBgs[id] };
                                            }).filter(Boolean);
                                            if (constructs.length === 0) return null;
                                            return React.createElement('div', { className: 'grid grid-cols-1 md:grid-cols-3 gap-4' },
                                                ...constructs.map(c => 
                                                    React.createElement('div', { key: c.id, className: 'rounded-xl p-4 border ' + c.bg },
                                                        React.createElement('div', { className: 'text-xs font-bold text-slate-600 uppercase tracking-wider mb-2' }, c.label),
                                                        React.createElement('div', { className: 'flex items-end gap-2' },
                                                            React.createElement('span', { className: 'text-3xl font-black ' + c.color }, c.avg),
                                                            React.createElement('span', { className: 'text-xs text-slate-600 mb-1' }, '/ 5.0')),
                                                        React.createElement('div', { className: 'w-full bg-slate-200 rounded-full h-2 mt-2 overflow-hidden' },
                                                            React.createElement('div', { className: 'h-full rounded-full bg-gradient-to-r from-purple-500 to-indigo-500 transition-all motion-reduce:transition-none', style: { width: (parseFloat(c.avg) / 5 * 100) + '%' } })),
                                                        React.createElement('div', { className: 'text-[11px] text-slate-600 mt-1' }, 'n = ' + c.n + ' responses')
                                                    )
                                                )
                                            );
                                        })()
                                    ),
                                    
                                    totalSessions > 0 && React.createElement('div', { className: 'bg-white p-6 rounded-2xl shadow-sm border border-slate-400' },
                                        React.createElement('h4', { className: 'text-sm font-bold text-emerald-700 uppercase tracking-wider mb-4 flex items-center gap-2' },
                                            t('dashboard.insights.session_fidelity')),
                                        React.createElement('div', { className: 'grid grid-cols-2 md:grid-cols-3 gap-4' },
                                            React.createElement('div', { className: 'bg-emerald-50 rounded-xl p-4 text-center border border-emerald-100' },
                                                React.createElement('div', { className: 'text-3xl font-black text-emerald-700' }, totalSessions),
                                                React.createElement('div', { className: 'text-[11px] font-bold text-emerald-500 uppercase mt-1' }, t('dashboard.insights.total_sessions'))),
                                            React.createElement('div', { className: 'bg-emerald-50 rounded-xl p-4 text-center border border-emerald-100' },
                                                React.createElement('div', { className: 'text-3xl font-black text-emerald-700' }, 
                                                    dashboardData.length > 0 ? (totalSessions / dashboardData.length).toFixed(1) : '0'),
                                                React.createElement('div', { className: 'text-[11px] font-bold text-emerald-500 uppercase mt-1' }, t('dashboard.insights.avg_per_student'))),
                                            (() => {
                                                const totalFidelity = dashboardData.reduce((sum, s) => sum + (s.fidelityLog ? s.fidelityLog.length : 0), 0);
                                                if (totalFidelity === 0) return null;
                                                return React.createElement('div', { className: 'bg-emerald-50 rounded-xl p-4 text-center border border-emerald-100' },
                                                    React.createElement('div', { className: 'text-3xl font-black text-emerald-700' }, totalFidelity),
                                                    React.createElement('div', { className: 'text-[11px] font-bold text-emerald-500 uppercase mt-1' }, t('dashboard.insights.fidelity_records')));
                                            })()
                                        )
                                    ),
                                    
                                    allProbes.length > 2 && React.createElement('div', { className: 'bg-white p-6 rounded-2xl shadow-sm border border-slate-400' },
                                        React.createElement('h4', { className: 'text-sm font-bold text-cyan-700 uppercase tracking-wider mb-4 flex items-center gap-2' },
                                            '📈 Probe Trends Over Time'),
                                        (() => {
                                            const sorted = allProbes.filter(p => p.date && p.wcpm !== undefined).sort((a,b) => new Date(a.date) - new Date(b.date));
                                            if (sorted.length < 2) return React.createElement('p', { className: 'text-sm text-slate-600 italic' }, 'Need at least 2 probes with dates to show trends.');
                                            const maxWcpm = Math.max(...sorted.map(p => p.wcpm), 10);
                                            const chartH = 160;
                                            const barW = Math.max(20, Math.min(50, 600 / sorted.length));
                                            return React.createElement('div', { className: 'space-y-3' },
                                                React.createElement('div', { className: 'flex items-end gap-1 overflow-x-auto pb-2', style: { height: (chartH + 40) + 'px' } },
                                                    ...sorted.map((p, i) => {
                                                        const h = Math.max(4, (p.wcpm / maxWcpm) * chartH);
                                                        const color = p.wcpm >= 100 ? '#059669' : p.wcpm >= 60 ? '#d97706' : '#dc2626';
                                                        return React.createElement('div', { key: i, className: 'flex flex-col items-center', style: { width: barW + 'px' } },
                                                            React.createElement('div', { className: 'text-[11px] font-bold mb-1', style: { color } }, p.wcpm),
                                                            React.createElement('div', { style: { width: (barW - 4) + 'px', height: h + 'px', background: color, borderRadius: '4px 4px 0 0', transition: 'height 0.3s ease' } }),
                                                            React.createElement('div', { className: 'text-[11px] text-slate-600 mt-1 text-center', style: { width: barW + 'px' } }, 
                                                                p.date ? new Date(p.date).toLocaleDateString('en', { month: 'short', day: 'numeric' }) : '')
                                                        );
                                                    })
                                                ),
                                                React.createElement('div', { className: 'flex items-center gap-4 text-[11px] text-slate-600' },
                                                    React.createElement('span', null, '🟢 ≥100 WCPM'),
                                                    React.createElement('span', null, '🟡 60-99 WCPM'),
                                                    React.createElement('span', null, '🔴 <60 WCPM'),
                                                    React.createElement('span', { className: 'ml-auto font-bold' }, sorted.length + ' probes plotted')
                                                )
                                            );
                                        })()
                                    )
                                );
                            })()}
                        </div>
                     )}
                     {activeTab === 'behavior' && (
                         <div role="tabpanel" id={`teacher-dashboard-panel-${activeTab}`} aria-labelledby={`teacher-dashboard-tab-${activeTab}`} tabIndex={0} className="max-w-6xl mx-auto space-y-6 animate-in motion-reduce:animate-none fade-in slide-in-from-right-4 px-3 sm:px-0 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                             <div className="bg-white p-6 sm:p-8 rounded-2xl shadow-sm border border-slate-400 text-center">
                                 <div className="text-4xl sm:text-5xl mb-4">🔍</div>
                                 <h3 className="text-xl sm:text-2xl font-black text-slate-800 mb-2">{t('behavior_lens.hub.title') || 'BehaviorLens'}</h3>
                                 <p className="text-sm text-slate-600 mb-6 max-w-md mx-auto">{t('behavior_lens.hub.subtitle') || 'Functional Behavior Assessment, ABC data collection, and Behavior Intervention Plan tools.'}</p>
                                 <button type="button"
                                     onClick={() => { if (onOpenBehaviorLens) onOpenBehaviorLens(); }}
                                     className="px-6 py-3 bg-gradient-to-r from-orange-700 to-amber-700 text-white font-bold rounded-xl shadow-lg hover:shadow-xl hover:scale-105 transition-all motion-reduce:transition-none text-sm flex items-center gap-2 mx-auto"
                                 >
                                     🔍 {t('behavior_lens.hub.open_btn') || 'Open BehaviorLens'}
                                 </button>
                             </div>
                         </div>
                     )}
                     {activeTab === 'stems' && (
                         <div role="tabpanel" id={`teacher-dashboard-panel-${activeTab}`} aria-labelledby={`teacher-dashboard-tab-${activeTab}`} tabIndex={0} className="max-w-6xl mx-auto space-y-6 animate-in motion-reduce:animate-none fade-in slide-in-from-right-4 px-3 sm:px-0 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                             <div className="bg-white p-4 sm:p-6 rounded-2xl shadow-sm border border-slate-400">
                                 <h3 className="text-base sm:text-lg font-black text-slate-800 flex items-center gap-2 mb-4">
                                     {t('teacher.stem_stations.section_title') || '🔬 STEM Station Activity'}
                                 </h3>
                                 {(() => {
                                     const stations = JSON.parse(localStorage.getItem('alloflow_stem_stations') || '[]');
                                     const xpLog = JSON.parse(localStorage.getItem('alloflow_stem_xp_log') || '[]');
                                     if (stations.length === 0) {
                                         return (
                                             <div className="text-center py-8">
                                                 <div className="text-4xl mb-3">📌</div>
                                                 <p className="text-sm text-slate-600">{t('teacher.stem_stations.empty_title') || 'No STEM Stations created yet.'}</p>
                                                 <p className="text-xs text-slate-600 mt-1">{t('teacher.stem_stations.empty_hint') || 'Generate a lesson plan to get AI-recommended STEM tools.'}</p>
                                             </div>
                                         );
                                     }
                                     return (
                                         <div className="space-y-4">
                                             <div className="grid grid-cols-3 gap-2 sm:gap-4 mb-4">
                                                 <div className="bg-emerald-50 rounded-xl p-3 sm:p-4 text-center border border-emerald-100">
                                                     <div className="text-xl sm:text-2xl font-black text-emerald-700">{stations.length}</div>
                                                     <div className="text-[10px] sm:text-xs text-emerald-600 font-bold mt-1 leading-tight">{t('teacher.stem_stations.stations_created') || 'Stations Created'}</div>
                                                 </div>
                                                 <div className="bg-teal-50 rounded-xl p-3 sm:p-4 text-center border border-teal-100">
                                                     <div className="text-xl sm:text-2xl font-black text-teal-700">
                                                         {new Set(stations.flatMap(s => s.tools)).size}
                                                     </div>
                                                     <div className="text-[10px] sm:text-xs text-teal-600 font-bold mt-1 leading-tight">{t('teacher.stem_stations.unique_tools_used') || 'Unique Tools Used'}</div>
                                                 </div>
                                                 <div className="bg-indigo-50 rounded-xl p-3 sm:p-4 text-center border border-indigo-100">
                                                     <div className="text-xl sm:text-2xl font-black text-indigo-700">
                                                         {xpLog.filter(e => e.stationId).length}
                                                     </div>
                                                     <div className="text-[10px] sm:text-xs text-indigo-600 font-bold mt-1 leading-tight">{t('teacher.stem_stations.station_xp_events') || 'Station XP Events'}</div>
                                                 </div>
                                             </div>
                                             {stations.map((st) => {
                                                 const stationXP = xpLog.filter(e => e.stationId === st.id);
                                                 const totalXP = stationXP.reduce((s, e) => s + (e.xp || 0), 0);
                                                 return (
                                                     <div key={st.id} className="bg-slate-50 rounded-xl p-3 sm:p-4 border border-slate-400 hover:border-emerald-300 transition-all motion-reduce:transition-none">
                                                         <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                                                             <div className="flex items-center gap-2 flex-wrap min-w-0">
                                                                 <span className="text-lg shrink-0">📌</span>
                                                                 <h4 className="font-bold text-sm text-slate-800 truncate">{st.name}</h4>
                                                                 <span className="bg-emerald-100 text-emerald-700 text-[11px] font-bold px-2 py-0.5 rounded-full shrink-0">
                                                                     {st.tools.length} tool{st.tools.length !== 1 ? 's' : ''}
                                                                 </span>
                                                             </div>
                                                             <div className="flex items-center gap-2 sm:gap-3 shrink-0">
                                                                 <span className="text-xs text-slate-600 hidden sm:inline">
                                                                     {new Date(st.createdAt).toLocaleDateString()}
                                                                 </span>
                                                                 <span className="bg-indigo-100 text-indigo-700 text-[11px] font-bold px-2 py-0.5 rounded-full">
                                                                     {totalXP} XP
                                                                 </span>
                                                             </div>
                                                         </div>
                                                         <div className="flex flex-wrap gap-1.5 mt-2">
                                                             {st.tools.map((toolId) => {
                                                                 const registry = window.STEM_TOOL_REGISTRY || [];
                                                                 const meta = registry.find(r => r.id === toolId);
                                                                 return (
                                                                     <span key={toolId} className="bg-white text-slate-600 text-[11px] font-medium px-2 py-1 rounded-lg border border-slate-400">
                                                                         🧪 {meta ? meta.name : toolId}
                                                                     </span>
                                                                 );
                                                             })}
                                                         </div>
                                                         {st.teacherNote && (
                                                             <p className="text-xs text-slate-600 italic mt-2">"{st.teacherNote}"</p>
                                                         )}
                                                     </div>
                                                 );
                                             })}
                                         </div>
                                     );
                                 })()}
                             </div>
                         </div>
                     )}
                    </>
                 )}
             </>
         )}
      </div>
      {showClearConfirm && (
          <div role="presentation" className="fixed inset-0 z-[300] bg-black/50 flex items-center justify-center animate-in motion-reduce:animate-none fade-in duration-200" onMouseDown={(event) => { if (event.target === event.currentTarget) closeClearConfirm(); }}>
              <div
                  ref={clearConfirmDialogRef}
                  className="bg-white rounded-2xl shadow-2xl p-6 max-w-sm mx-4 animate-in motion-reduce:animate-none zoom-in-95 duration-200"
                  role="alertdialog"
                  aria-modal="true"
                  aria-labelledby="teacher-clear-confirm-title"
                  aria-describedby="teacher-clear-confirm-description"
                  onKeyDown={event => {
                      if (event.key === 'Escape') { event.preventDefault(); closeClearConfirm(); return; }
                      if (event.key !== 'Tab') return;
                      const focusable = Array.from(event.currentTarget.querySelectorAll('button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'));
                      if (!focusable.length) { event.preventDefault(); return; }
                      const first = focusable[0];
                      const last = focusable[focusable.length - 1];
                      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
                      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
                  }}
              >
                  <div className="flex items-center gap-3 mb-4">
                      <div className="bg-red-100 p-3 rounded-full" aria-hidden="true"><Trash2 size={24} className="text-red-600"/></div>
                      <h3 id="teacher-clear-confirm-title" className="text-lg font-bold text-slate-800">{t('dashboard.clear_all')}</h3>
                  </div>
                  <p id="teacher-clear-confirm-description" className="text-slate-600 mb-6">{t('dashboard.clear_confirm')}</p>
                  <div className="flex gap-3">
                      <button type="button" data-safe-default="true" onClick={closeClearConfirm} className="flex-1 min-h-11 py-2.5 px-4 rounded-xl font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 transition-colors motion-reduce:transition-none focus:outline-none focus:ring-2 focus:ring-indigo-500">
                          {t('common.cancel')}
                      </button>
                      <button type="button" onClick={confirmClearAll} className="flex-1 min-h-11 py-2.5 px-4 rounded-xl font-bold text-white bg-red-700 hover:bg-red-800 transition-colors motion-reduce:transition-none focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2">
                          {t('common.confirm')}
                      </button>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
});

// ─────────────────────────────────────────────────────────────────────────────
// CDN module registrations — wire each component on window.AlloModules so the
// shims in AlloFlowANTI.txt can find them. Without these the shims fall back
// to a "Loading…" placeholder forever.
// ─────────────────────────────────────────────────────────────────────────────
window.AlloModules = window.AlloModules || {};
window.AlloModules.RosterKeyPanel             = RosterKeyPanel;
window.AlloModules.normalizeRosterSessionFollowUpPlan = normalizeRosterSessionFollowUpPlan;
window.AlloModules.buildRosterSessionEvidenceCsv = buildRosterSessionEvidenceCsv;
window.AlloModules.SimpleBarChart             = SimpleBarChart;
window.AlloModules.SimpleDonutChart           = SimpleDonutChart;
window.AlloModules.ConfettiEffect             = ConfettiEffect;
window.AlloModules.LiveEscapeRoomInternals = { progress: alloLiveEscapeProgress, seconds: alloLiveEscapeSeconds, answer: alloLiveEscapeAnswer, sequence: alloLiveSequenceIndices };
window.AlloModules.StudentEscapeRoomOverlay   = StudentEscapeRoomOverlay;
window.AlloModules.EscapeRoomTeacherControls  = EscapeRoomTeacherControls;
window.AlloModules.TeacherLiveQuizControls    = TeacherLiveQuizControls;
window.AlloModules.LongitudinalProgressChart  = LongitudinalProgressChart;
window.AlloModules.LearnerProgressView        = LearnerProgressView;
window.AlloModules.TeacherDashboard           = TeacherDashboard;
